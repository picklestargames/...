// Game: owns the renderer and every system, runs the loading sequence and the per-frame loop (desktop + WebXR).
import * as THREE from 'three';
import { clamp, nextFrame } from './core/Utils.js';
import { SettingsManager } from './core/SettingsManager.js';
import { AudioManager } from './core/AudioManager.js';
import { PerformanceManager } from './core/PerformanceManager.js';
import { ParticleSystem } from './core/Particles.js';
import { WorldManager } from './world/WorldManager.js';
import { DMAP, SPAWN, toI, inGrid } from './world/Constants.js';
import { PlayerController } from './player/PlayerController.js';
import { LocomotionSystem } from './player/LocomotionSystem.js';
import { CameraController } from './player/CameraController.js';
import { DesktopController } from './player/DesktopController.js';
import { VRPlayerController } from './player/VRPlayerController.js';
import { GliderSystem } from './player/GliderSystem.js';
import { PickleAvatar } from './player/PickleAvatar.js';
import { HealthSystem } from './gameplay/HealthSystem.js';
import { JumpPadSystem } from './gameplay/JumpPadSystem.js';
import { PickupSystem } from './gameplay/PickupSystem.js';
import { InteractionSystem } from './gameplay/InteractionSystem.js';
import { WeaponSystem } from './weapons/WeaponSystem.js';
import { NPCSystem } from './npc/NPCSystem.js';
import { VehicleSystem } from './vehicles/VehicleSystem.js';
import { CrimeSystem } from './gameplay/CrimeSystem.js';
import { NetworkSystem } from './net/NetworkSystem.js';
import { ApartmentSystem } from './gameplay/ApartmentSystem.js';
import { UIManager } from './ui/UIManager.js';
import { TouchControls } from './ui/TouchControls.js';

export class Game {
  constructor(canvas) {
    this.canvas = canvas;
    this.state = 'boot';            // boot | loading | ready | playing | paused
    this.time = 0; this.last = 0;
    this.loaded = false; this.loading = false; this.mode = 'desktop';
    this.settings = new SettingsManager();
    this.audio = new AudioManager(this.settings);
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
    const r = this.renderer;
    r.outputColorSpace = THREE.SRGBColorSpace;
    r.toneMapping = THREE.ACESFilmicToneMapping; r.toneMappingExposure = 1.0;
    r.shadowMap.type = THREE.PCFSoftShadowMap;
    r.xr.enabled = true; r.xr.setReferenceSpaceType('local-floor');
    try { r.xr.setFoveation(1); } catch (e) { /* */ }
    this.camera = new THREE.PerspectiveCamera(80, innerWidth / innerHeight, 0.05, 1600);
    this.rig = new THREE.Group(); this.rig.add(this.camera);
    this.world = new WorldManager(this);
    this.scene = this.world.scene;
    this.scene.add(this.rig);
    this.perf = new PerformanceManager(this);
    this.player = new PlayerController(this);
    this.vr = new VRPlayerController(this);     // lightweight until init()
    this.ui = new UIManager(this);              // DOM only; needs this.desktop lazily
    this.touchMode = !!(window.matchMedia && matchMedia('(pointer:coarse)').matches);
    this.touch = new TouchControls(this);
    window.addEventListener('resize', () => this.resize());
    document.addEventListener('visibilitychange', () => { if (document.hidden && this.state === 'playing' && !this.vr.active) this.pause(); });
    window.addEventListener('keydown', (e) => { if (e.code === 'Escape' && this.state === 'playing' && !this.vr.active) this.pause(); });
    this.resize();
  }

  resize() {
    const w = innerWidth, h = innerHeight;
    if (!this.renderer.xr.isPresenting) {
      this.renderer.setSize(w, h, false);
      this.camera.aspect = w / h; this.camera.updateProjectionMatrix();
      if (this.particles) this.particles.setScale(h * this.renderer.getPixelRatio() / 1.68);
    }
  }

  // ------------------------------------------------------------------ loading
  async boot() {
    this.ui.showMenu(true);
    const hasXR = !!navigator.xr;
    await this.vr.detect();
    this.ui.setVRStatus(this.vr.supported, this.vr.secure, hasXR);
    if (navigator.xr && navigator.xr.addEventListener) navigator.xr.addEventListener('devicechange', async () => { await this.vr.detect(); this.ui.setVRStatus(this.vr.supported, this.vr.secure, hasXR); });
    this.state = 'menu';
  }

  async start(mode) {
    if (this.loading) return;
    if (this.loaded) return this.begin(mode);
    this.loading = true; this.mode = mode;
    this.audio.init(); this.audio.resume();           // inside the click gesture
    this.ui.showMenu(false); this.ui.showLoading(true); this.state = 'loading';
    let assets = 0, init = 0;
    const set = (a, i, m) => { assets = a ?? assets; init = i ?? init; this.ui.setLoading(assets, init, m); };
    try {
      set(0, 0, 'Brining the city…'); await nextFrame();
      this.world.init(this.renderer, (n, f) => set(f, null, n)); set(0.7, 0, 'Generating audio & textures…'); await nextFrame();
      this.avatar = new PickleAvatar(this.world.mats); this.scene.add(this.avatar.root, this.avatar.ikGroup); this.avatar.setMode('hidden');
      set(1, 0.05, 'Starting systems…'); await nextFrame();
      this.particles = new ParticleSystem(this.scene); this.particles.world = this.world; this.particles.camera = this.camera; this.resize();
      this.health = new HealthSystem(this);
      this.loco = new LocomotionSystem(this);
      const origLaunch = this.loco.launch.bind(this.loco);
      this.loco.launch = (...a) => { origLaunch(...a); this.padEvent = true; };
      this.glider = new GliderSystem(this);
      this.camera_ctrl = new CameraController(this);
      this.desktop = new DesktopController(this);
      this.interaction = this.interactables = new InteractionSystem(this);
      this.jumpPads = new JumpPadSystem(this);
      this.pickups = new PickupSystem(this);
      this.weapons = new WeaponSystem(this);
      this.npcs = new NPCSystem(this);
      this.vehicles = new VehicleSystem(this);
      this.crime = new CrimeSystem(this);
      this.apartment = new ApartmentSystem(this);
      this.net = new NetworkSystem(this);
      this.vr.init();
      this.ui.buildControls(); this.ui.refreshWeapon();
      this.health.on('death', () => { this.ui.toast('PICKLED! Back in the jar…', 2200); this.vr.fadeTarget = 1; });
      this.health.on('respawn', () => this.respawn());
      this.health.on('damage', () => this.camera_ctrl.punch(0.6));
      this.perf.apply(this.renderer, this.world);
      set(null, 0.15, 'Building the streets…'); await nextFrame();
      const s = this.player.pos;
      await this.world.chunks.preload(s.x, s.z, (f) => set(null, 0.15 + f * 0.8, 'Building the streets…'), nextFrame);
      this.apartment.enter(true);
      this.world.update(0.016, this.player.pos);
      set(1, 1, 'Ready!');
      this.loaded = true; this.loading = false; this.state = 'ready';
      this.last = 0;
      this.renderer.setAnimationLoop((t, f) => this.frame(t, f));
      this.ui.loadReady(mode, this.vr.supported);
    } catch (e) {
      console.error(e); this.loading = false;
      document.getElementById('load-msg').textContent = 'Failed to load: ' + (e && e.message ? e.message : e) + ' (see console)';
    }
  }

  async begin(mode) {
    this.mode = mode;
    this.ui.showLoading(false); this.ui.showMenu(false); this.ui.showPause(false);
    this.audio.init(); this.audio.resume(); this.audio.startAmbience();
    if (mode === 'vr') {
      const ok = await this.vr.enter();
      if (!ok) { this.ui.showMenu(true); this.state = 'ready'; return; }
      this.state = 'playing';
    } else {
      this.state = 'playing'; this.ui.showHUD(true);
      this.touch.enable(this.touchMode);
      this.desktop.enable(true); if (!this.touchMode) this.desktop.lock();
      this.avatar.setMode(this.camera_ctrl.third ? 'third' : 'hidden');
      this.ui.refreshWeapon();
    }
  }

  onVRStart() { for (let i = 0; i < 2; i++) this.weapons.holster(i); this.state = 'playing'; this.ui.showHUD(false); this.desktop.enable(false); this.desktop.unlock(); this.particles.setScale(600); this.vr.ui.setVisible(true); this.ui.showMenu(false); this.ui.showPause(false); }
  onVREnd() { this.ui.showHUD(false); this.state = 'ready'; this.ui.showMenu(true); this.ui.setVRStatus(this.vr.supported, this.vr.secure, true); this.resize(); }

  pause() { if (this.state !== 'playing') return; this.state = 'paused'; this.desktop.enable(false); this.desktop.unlock(); this.ui.showPause(true); }
  resume() { if (this.state !== 'paused') return; this.state = 'playing'; this.ui.showPause(false); this.ui.panel('settings', false); this.ui.panel('controls', false); this.desktop.enable(true); if (!this.touchMode) this.desktop.lock(); this.last = 0; }
  quitToMenu() { this.state = 'ready'; this.desktop.enable(false); this.desktop.unlock(); this.ui.showPause(false); this.ui.showHUD(false); this.ui.showMenu(true); }

  respawn() {
    const p = this.player, s = p.safePos;
    if (this.glider.active) this.glider.retract();
    p.teleport(s.x, s.y + 0.3, s.z); p.gliding = false;
    this.vr.fadeTarget = 0;
    this.ui.toast('Respawned', 900);
  }

  toggleThirdPerson() { this.camera_ctrl.third = !this.camera_ctrl.third; }
  toggleFps() { this.settings.set('showFps', !this.settings.get('showFps')); this.ui.el.fps.classList.toggle('hidden', !this.settings.get('showFps')); }

  // ------------------------------------------------------------------ frame
  frame(t, xrFrame) {
    const now = t / 1000;
    let dt = this.last ? clamp(now - this.last, 0, 0.05) : 0.016; this.last = now;
    const p = this.player;
    this.touch.sync();
    if (this.state === 'playing') {
      this.time += dt;
      const vr = this.vr.active;
      if (vr) this.vr.preUpdate(dt, xrFrame); else this.desktop.update(dt);
      this.health.update(dt);
      this.glider.update(dt);
      if (!this.vehicles.driving) this.loco.update(dt);
      if (this.vehicles.driving) { this.vehicles.update(dt); if (this.health.dead) this.vehicles.exit(); }
      this.interaction.update(dt);
      this.jumpPads.update(dt);
      this.pickups.update(dt);
      if (vr) this.vr.postUpdate(dt); else this.camera_ctrl.update(dt);
      this.weapons.update(dt);
      this.npcs.update(dt);
      this.crime.update(dt);
      this.apartment.update(dt);
      this.net.update(dt);
      this.world.update(dt, p.pos);
      this.particles.update(dt);
      if (!vr) { this.updateAvatar(dt); this.audio.setListener(this.camera); this.ui.update(dt); }
      else this.ui.update(dt);
      this.updateAudio();
      this.perf.update(dt, this.renderer, this.world);
    } else if (this.state === 'ready' || this.state === 'paused') {
      if (this.state === 'ready') { this.time += dt; p.yaw += dt * 0.08; this.camera_ctrl.update(dt); this.world.update(dt, p.pos); this.particles.update(dt); this.npcs.update(dt); }
    }
    this.renderer.render(this.scene, this.camera);
  }

  updateAvatar(dt) {
    const p = this.player, av = this.avatar, th = this.camera_ctrl.third;
    if (!th || p.driving) { if (av.mode === 'third') av.setMode('hidden'); return; }
    av.setMode('third'); av.ikGroup.visible = false;
    av.root.position.copy(p.pos); av.root.rotation.y = p.yaw;
    const ev = this.loco.events; const landed = ev.includes('land'); ev.length = 0;
    const h0 = this.weapons.holders[0];
    av.animate(dt, {
      speed: p.speedH, grounded: p.grounded, crouch: p.crouching, slide: p.sliding, sprint: p.sprinting, vy: p.vel.y, gliding: p.gliding,
      deploy: this.glider.active && this.glider.deploy > 0 && this.glider.deploy < 0.9, shoot: this.time - this.weapons.lastShotT < 0.12, reload: !!h0.reload,
      pad: !!this.padEvent, landImpact: landed ? p.landImpact : 0, turn: 0, aiming: !!h0.model && h0.ads > 0.4, hurt: p.hurtT > 0,
    });
    this.padEvent = false;
  }

  updateAudio() {
    const p = this.player, i = toI(p.pos.x), j = toI(p.pos.z);
    const district = inGrid(i, j) ? DMAP[j][i] : 'ind';
    this.audio.updateAmbient({ speed: p.speedH, altitude: p.altitude, gliding: p.gliding, indoor: this.world.interiorLight.intensity > 0 && p.pos.y < 6, district, nearHum: district === 'ind' || district === 'metro' });
  }
}
