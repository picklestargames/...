import { Game } from './Game.js';

const canvas = document.getElementById('gl');
const game = new Game(canvas);
window.pickleCity = game;       // handy for debugging in the console
game.boot().catch((e) => { console.error(e); document.getElementById('vr-status').textContent = 'Startup error: ' + e.message; });
