// Pooled GPU-friendly particle system (THREE.Points, soft round sprites) + shell casing pool.
import * as THREE from 'three';

const VERT = `
attribute float size; attribute float alpha; attribute vec3 color;
varying float vA; varying vec3 vC; uniform float scale;
void main(){ vA = alpha; vC = color; vec4 mv = modelViewMatrix*vec4(position,1.0);
  gl_PointSize = size * scale / max(0.1,-mv.z); gl_Position = projectionMatrix*mv; }`;
const FRAG = `
varying float vA; varying vec3 vC;
void main(){ vec2 d = gl_PointCoord-0.5; float r = length(d)*2.0; if(r>1.0) discard;
  float a = (1.0-r*r)*vA; gl_FragColor = vec4(vC, a); }`;

class Layer {
  constructor(max, additive) {
    this.max = max; this.n = 0; this.head = 0;
    this.pos = new Float32Array(max * 3); this.vel = new Float32Array(max * 3);
    this.col = new Float32Array(max * 3); this.size = new Float32Array(max); this.alpha = new Float32Array(max);
    this.life = new Float32Array(max); this.maxLife = new Float32Array(max);
    this.grav = new Float32Array(max); this.drag = new Float32Array(max); this.grow = new Float32Array(max); this.size0 = new Float32Array(max);
    this.geo = new THREE.BufferGeometry();
    this.geo.setAttribute('position', new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage));
    this.geo.setAttribute('color', new THREE.BufferAttribute(this.col, 3).setUsage(THREE.DynamicDrawUsage));
    this.geo.setAttribute('size', new THREE.BufferAttribute(this.size, 1).setUsage(THREE.DynamicDrawUsage));
    this.geo.setAttribute('alpha', new THREE.BufferAttribute(this.alpha, 1).setUsage(THREE.DynamicDrawUsage));
    this.mat = new THREE.ShaderMaterial({ vertexShader: VERT, fragmentShader: FRAG, transparent: true, depthWrite: false, blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending, uniforms: { scale: { value: 600 } } });
    this.points = new THREE.Points(this.geo, this.mat);
    this.points.frustumCulled = false;
    this.points.renderOrder = 5;
  }
  emit(x, y, z, vx, vy, vz, r, g, b, size, life, grav = 0, drag = 0, grow = 0, a0 = 1) {
    const i = this.head; this.head = (this.head + 1) % this.max; if (this.n < this.max) this.n++;
    const k = i * 3;
    this.pos[k] = x; this.pos[k + 1] = y; this.pos[k + 2] = z; this.vel[k] = vx; this.vel[k + 1] = vy; this.vel[k + 2] = vz;
    this.col[k] = r; this.col[k + 1] = g; this.col[k + 2] = b;
    this.size0[i] = size; this.size[i] = size; this.alpha[i] = a0; this.life[i] = life; this.maxLife[i] = life;
    this.grav[i] = grav; this.drag[i] = drag; this.grow[i] = grow;
  }
  update(dt) {
    for (let i = 0; i < this.max; i++) {
      if (this.life[i] <= 0) { this.alpha[i] = 0; continue; }
      this.life[i] -= dt;
      const k = i * 3, d = Math.exp(-this.drag[i] * dt);
      this.vel[k] *= d; this.vel[k + 1] = this.vel[k + 1] * d - this.grav[i] * dt; this.vel[k + 2] *= d;
      this.pos[k] += this.vel[k] * dt; this.pos[k + 1] += this.vel[k + 1] * dt; this.pos[k + 2] += this.vel[k + 2] * dt;
      const t = Math.max(0, this.life[i] / this.maxLife[i]);
      this.alpha[i] = t;
      this.size[i] = this.size0[i] * (1 + this.grow[i] * (1 - t));
    }
    const g = this.geo.attributes;
    g.position.needsUpdate = g.color.needsUpdate = g.size.needsUpdate = g.alpha.needsUpdate = true;
  }
}

export class ParticleSystem {
  constructor(scene) {
    this.add = new Layer(900, true);
    this.smoke = new Layer(500, false);
    scene.add(this.add.points, this.smoke.points);
    // shell casings
    this.shellGeo = new THREE.BoxGeometry(0.012, 0.012, 0.035);
    this.shells = new THREE.InstancedMesh(this.shellGeo, new THREE.MeshStandardMaterial({ color: 0xc8a040, metalness: 0.9, roughness: 0.35 }), 32);
    this.shells.frustumCulled = false;
    this.shellData = Array.from({ length: 32 }, () => ({ life: 0, p: new THREE.Vector3(), v: new THREE.Vector3(), r: new THREE.Euler(), rv: new THREE.Vector3() }));
    this.shellHead = 0;
    this._m = new THREE.Matrix4(); this._q = new THREE.Quaternion(); this._s = new THREE.Vector3(1, 1, 1);
    scene.add(this.shells);
    for (let i = 0; i < 32; i++) { this._m.makeScale(0, 0, 0); this.shells.setMatrixAt(i, this._m); }
    this.camera = null;
    this.world = null;
  }
  setScale(h) { this.add.mat.uniforms.scale.value = h; this.smoke.mat.uniforms.scale.value = h; }

  muzzleFlash(p, dir, power = 1) {
    const A = this.add;
    for (let i = 0; i < 4; i++) A.emit(p.x + dir.x * 0.02 * i, p.y + dir.y * 0.02 * i, p.z + dir.z * 0.02 * i, dir.x * 2, dir.y * 2, dir.z * 2, 1, 0.8, 0.35, (0.35 + Math.random() * 0.2) * power, 0.05, 0, 0, 0.5);
    for (let i = 0; i < 6; i++) { const s = 4 + Math.random() * 6; A.emit(p.x, p.y, p.z, dir.x * s + (Math.random() - 0.5) * 2, dir.y * s + (Math.random() - 0.5) * 2, dir.z * s + (Math.random() - 0.5) * 2, 1, 0.65, 0.2, 0.08, 0.12, 0, 4); }
    const S = this.smoke;
    S.emit(p.x, p.y, p.z, dir.x * 0.8, dir.y * 0.8 + 0.3, dir.z * 0.8, 0.8, 0.8, 0.8, 0.18 * power, 0.7, -0.4, 2.5, 3, 0.35);
  }
  hit(p, n, color = [1, 0.85, 0.5], count = 7) {
    const A = this.add, S = this.smoke;
    for (let i = 0; i < count; i++) { const s = 2 + Math.random() * 4; A.emit(p.x, p.y, p.z, n.x * s + (Math.random() - 0.5) * 3, n.y * s + (Math.random() - 0.3) * 3 + 1, n.z * s + (Math.random() - 0.5) * 3, color[0], color[1], color[2], 0.06, 0.35, 9, 0.5, 0, 1); }
    S.emit(p.x + n.x * 0.05, p.y + n.y * 0.05, p.z + n.z * 0.05, n.x * 0.5, n.y * 0.5 + 0.4, n.z * 0.5, 0.65, 0.65, 0.62, 0.22, 0.6, -0.5, 2, 2.5, 0.45);
  }
  poof(p, color = [0.9, 0.9, 0.9], n = 8, spread = 1.5, size = 0.35) {
    for (let i = 0; i < n; i++) { const a = Math.random() * 6.283; this.smoke.emit(p.x, p.y + 0.05, p.z, Math.cos(a) * spread * (0.4 + Math.random()), 0.5 + Math.random(), Math.sin(a) * spread * (0.4 + Math.random()), color[0], color[1], color[2], size, 0.7 + Math.random() * 0.4, -0.3, 2, 2.5, 0.4); }
  }
  sparkleFountain(p, color, count = 3, up = 6) {
    for (let i = 0; i < count; i++) { const a = Math.random() * 6.283, s = Math.random() * 1.6; this.add.emit(p.x + Math.cos(a) * 0.6, p.y + 0.1, p.z + Math.sin(a) * 0.6, Math.cos(a) * s, up * (0.6 + Math.random() * 0.6), Math.sin(a) * s, color[0], color[1], color[2], 0.14, 0.9, 6, 0.2, -0.2, 1); }
  }
  windStreak(p, v, count = 1) {
    for (let i = 0; i < count; i++) this.add.emit(p.x + (Math.random() - 0.5) * 6, p.y + (Math.random() - 0.5) * 4, p.z + (Math.random() - 0.5) * 6, v.x * -0.3, v.y * -0.3, v.z * -0.3, 0.85, 0.92, 1, 0.07, 0.5, 0, 0, 0, 0.5);
  }
  burst(p, color, count = 20, speed = 5, size = 0.1, life = 0.6) {
    for (let i = 0; i < count; i++) { const a = Math.random() * 6.283, e = (Math.random() - 0.5) * 2; const s = speed * (0.4 + Math.random() * 0.8); this.add.emit(p.x, p.y, p.z, Math.cos(a) * s, e * s, Math.sin(a) * s, color[0], color[1], color[2], size, life, 3, 1.5, 0, 1); }
  }
  shell(p, dir, up) {
    const s = this.shellData[this.shellHead]; const i = this.shellHead; this.shellHead = (this.shellHead + 1) % this.shellData.length;
    s.life = 1.6; s.p.copy(p); s.v.copy(dir).multiplyScalar(2 + Math.random()).addScaledVector(up, 1.4 + Math.random()); s.rv.set(Math.random() * 20, Math.random() * 20, Math.random() * 20);
  }

  update(dt) {
    this.add.update(dt); this.smoke.update(dt);
    for (let i = 0; i < this.shellData.length; i++) {
      const s = this.shellData[i];
      if (s.life > 0) {
        s.life -= dt; s.v.y -= 9.8 * dt; s.p.addScaledVector(s.v, dt);
        const gy = this.world ? this.world.collision.groundBelow(s.p.x, s.p.y + 0.1, s.p.z, 0.01, 0.2) : 0;
        if (s.p.y < gy + 0.01) { s.p.y = gy + 0.01; if (Math.abs(s.v.y) > 0.5) { s.v.y *= -0.35; s.v.x *= 0.6; s.v.z *= 0.6; } else { s.v.set(0, 0, 0); s.rv.set(0, 0, 0); } }
        s.r.x += s.rv.x * dt; s.r.y += s.rv.y * dt; s.r.z += s.rv.z * dt;
        this._q.setFromEuler(s.r);
        this._s.setScalar(s.life > 0.2 ? 1 : s.life / 0.2);
        this._m.compose(s.p, this._q, this._s);
        this.shells.setMatrixAt(i, this._m);
        if (s.life <= 0) { this._m.makeScale(0, 0, 0); this.shells.setMatrixAt(i, this._m); }
      }
    }
    this.shells.instanceMatrix.needsUpdate = true;
  }
}
