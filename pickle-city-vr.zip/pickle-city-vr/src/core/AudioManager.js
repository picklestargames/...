// Fully procedural, spatialised audio (no audio files). Sounds are synthesised into AudioBuffers at init.
import { rng, clamp } from './Utils.js';

const SR = 44100;

function makeBuf(ctx, secs, fn) {
  const n = Math.floor(secs * SR);
  const b = ctx.createBuffer(1, n, SR);
  const d = b.getChannelData(0);
  fn(d, n);
  return b;
}
const env = (t, a, d) => (t < a ? t / a : Math.exp(-(t - a) * d));

export class AudioManager {
  constructor(settings) {
    this.settings = settings;
    this.ctx = null;
    this.bufs = {};
    this.ready = false;
    this.loops = {};
    this.timers = [];
    this.listenerObj = null;
    this._last = {};
    this.activeSpatial = 0;
  }

  init() {
    if (this.ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC({ latencyHint: 'interactive', sampleRate: SR });
    const c = this.ctx;
    this.master = c.createGain(); this.master.gain.value = this.settings.get('volume');
    this.comp = c.createDynamicsCompressor(); this.comp.threshold.value = -14; this.comp.ratio.value = 6;
    this.master.connect(this.comp); this.comp.connect(c.destination);
    this.sfx = c.createGain(); this.sfx.connect(this.master);
    this.amb = c.createGain(); this.amb.gain.value = 0.55; this.amb.connect(this.master);
    this.ui = c.createGain(); this.ui.gain.value = 0.7; this.ui.connect(this.master);
    // short room-ish reverb for gunshots
    this.verb = c.createConvolver();
    this.verb.buffer = makeBuf(c, 1.4, (d, n) => { const r = rng(5); for (let i = 0; i < n; i++) d[i] = (r() * 2 - 1) * Math.exp(-i / (SR * 0.28)) * (1 - i / n); });
    this.verbGain = c.createGain(); this.verbGain.gain.value = 0.22;
    this.verb.connect(this.verbGain); this.verbGain.connect(this.master);
    this.synthAll();
    this.settings.on('change', (k) => { if (k === 'volume' && this.master) this.master.gain.value = this.settings.get('volume'); });
    this.ready = true;
  }

  resume() { if (this.ctx && this.ctx.state !== 'running') this.ctx.resume(); }

  synthAll() {
    const c = this.ctx, B = this.bufs, r = rng(11);
    const noise = () => r() * 2 - 1;
    // gunshots: [length, noiseDecay, thumpHz, thumpDecay, crackLP]
    const gun = (name, len, nd, hz, td, bright, gain = 1) => {
      B[name] = makeBuf(c, len, (d, n) => {
        let lp = 0;
        for (let i = 0; i < n; i++) {
          const t = i / SR;
          const nz = noise();
          lp += (nz - lp) * bright;
          const crack = lp * Math.exp(-t * nd);
          const thump = Math.sin(2 * Math.PI * hz * t * (1 - t * 2)) * Math.exp(-t * td);
          d[i] = clamp((crack * 0.9 + thump * 0.9) * gain, -1, 1);
        }
      });
    };
    gun('shot_pistol', 0.35, 38, 130, 22, 0.55);
    gun('shot_revolver', 0.6, 22, 95, 14, 0.4, 1.1);
    gun('shot_smg', 0.22, 55, 160, 32, 0.7, 0.85);
    gun('shot_rifle', 0.45, 30, 105, 18, 0.5, 1.0);
    gun('shot_shotgun', 0.7, 14, 70, 10, 0.35, 1.2);
    gun('shot_marksman', 0.9, 11, 80, 9, 0.45, 1.15);
    gun('shot_empty', 0.07, 120, 900, 90, 0.9, 0.5);
    const click = (name, hz, len = 0.06, gain = 0.8) => { B[name] = makeBuf(c, len, (d, n) => { for (let i = 0; i < n; i++) { const t = i / SR; d[i] = (noise() * 0.5 + Math.sin(2 * Math.PI * hz * t)) * Math.exp(-t * 90) * gain; } }); };
    click('mag_out', 420, 0.12, 0.9); click('mag_in', 300, 0.1, 1); click('slide', 700, 0.09, 0.8); click('cock', 520, 0.12, 0.9);
    click('shell', 3200, 0.1, 0.5); click('door_click', 260, 0.08, 1); click('button', 880, 0.07, 0.8);
    B.step = []; for (let k = 0; k < 4; k++) B.step.push(makeBuf(c, 0.14, (d, n) => { let lp = 0; const f = 0.12 + k * 0.03; for (let i = 0; i < n; i++) { lp += (noise() - lp) * f; d[i] = lp * Math.exp(-i / SR * 38) * 1.6; } }));
    B.stepMetal = [0, 1].map((k) => makeBuf(c, 0.2, (d, n) => { for (let i = 0; i < n; i++) { const t = i / SR; d[i] = (Math.sin(2 * Math.PI * (480 + k * 90) * t) * 0.5 + noise() * 0.4) * Math.exp(-t * 36); } }));
    B.land = makeBuf(c, 0.3, (d, n) => { let lp = 0; for (let i = 0; i < n; i++) { const t = i / SR; lp += (noise() - lp) * 0.08; d[i] = (lp * 2 + Math.sin(2 * Math.PI * 60 * t)) * Math.exp(-t * 14); } });
    B.jump = makeBuf(c, 0.18, (d, n) => { let lp = 0; for (let i = 0; i < n; i++) { const t = i / SR; lp += (noise() - lp) * 0.1; d[i] = lp * Math.exp(-t * 20) * 1.4 * Math.min(1, t * 80); } });
    B.slide = makeBuf(c, 0.8, (d, n) => { let lp = 0; for (let i = 0; i < n; i++) { const t = i / SR; lp += (noise() - lp) * 0.35; d[i] = lp * 0.5 * Math.min(1, t * 20) * Math.exp(-t * 2.5); } });
    B.pad = makeBuf(c, 0.9, (d, n) => { let ph = 0; for (let i = 0; i < n; i++) { const t = i / SR; const f = 180 + 900 * t * t / 0.8; ph += 2 * Math.PI * f / SR; d[i] = (Math.sin(ph) * 0.45 + Math.sin(ph * 2.01) * 0.2 + noise() * 0.15 * Math.exp(-t * 8)) * Math.exp(-t * 3.2) * Math.min(1, t * 50); } });
    B.deploy = makeBuf(c, 0.7, (d, n) => { let lp = 0; for (let i = 0; i < n; i++) { const t = i / SR; lp += (noise() - lp) * (0.05 + t * 0.4); d[i] = lp * (t < 0.1 ? t / 0.1 : Math.exp(-(t - 0.1) * 5)) * 2.2 + (t > 0.08 && t < 0.16 ? Math.sin(2 * Math.PI * 120 * t) * 0.6 : 0); } });
    B.retract = makeBuf(c, 0.45, (d, n) => { let lp = 0; for (let i = 0; i < n; i++) { const t = i / SR; lp += (noise() - lp) * (0.35 - t * 0.5 > 0.03 ? 0.35 - t * 0.5 : 0.03); d[i] = lp * Math.exp(-t * 6) * 1.8; } });
    B.pickup = makeBuf(c, 0.35, (d, n) => { for (let i = 0; i < n; i++) { const t = i / SR; const f = t < 0.1 ? 660 : 990; d[i] = (Math.sin(2 * Math.PI * f * t) * 0.5 + Math.sin(2 * Math.PI * f * 2 * t) * 0.15) * Math.exp(-t * 9); } });
    B.weaponPickup = makeBuf(c, 0.5, (d, n) => { for (let i = 0; i < n; i++) { const t = i / SR; const f = [392, 523, 659, 784][Math.min(3, Math.floor(t / 0.07))]; d[i] = Math.sin(2 * Math.PI * f * t) * Math.exp(-t * 6) * 0.6; } });
    B.hit = makeBuf(c, 0.06, (d, n) => { for (let i = 0; i < n; i++) { const t = i / SR; d[i] = Math.sin(2 * Math.PI * 1500 * t) * Math.exp(-t * 90) * 0.5; } });
    B.impact = makeBuf(c, 0.12, (d, n) => { let lp = 0; for (let i = 0; i < n; i++) { const t = i / SR; lp += (noise() - lp) * 0.3; d[i] = lp * Math.exp(-t * 40); } });
    B.hurt = makeBuf(c, 0.35, (d, n) => { for (let i = 0; i < n; i++) { const t = i / SR; d[i] = (Math.sin(2 * Math.PI * (210 - 90 * t) * t) * 0.5 + noise() * 0.1) * Math.exp(-t * 8); } });
    B.uiOk = makeBuf(c, 0.12, (d, n) => { for (let i = 0; i < n; i++) { const t = i / SR; d[i] = Math.sin(2 * Math.PI * (t < 0.05 ? 660 : 880) * t) * Math.exp(-t * 20) * 0.5; } });
    B.uiMove = makeBuf(c, 0.05, (d, n) => { for (let i = 0; i < n; i++) { const t = i / SR; d[i] = Math.sin(2 * Math.PI * 520 * t) * Math.exp(-t * 60) * 0.35; } });
    B.honk = makeBuf(c, 0.55, (d, n) => { for (let i = 0; i < n; i++) { const t = i / SR; const e = Math.min(1, t * 80) * (t > 0.45 ? Math.max(0, 1 - (t - 0.45) * 10) : 1); d[i] = (Math.sin(2 * Math.PI * 392 * t) + Math.sin(2 * Math.PI * 494 * t) * 0.8 + Math.sin(2 * Math.PI * 392 * 3 * t) * 0.15) * 0.3 * e; } });
    B.boom = makeBuf(c, 1.6, (d, n) => { let lp = 0; for (let i = 0; i < n; i++) { const t = i / SR; lp += (((r() * 2 - 1)) - lp) * 0.12; d[i] = (lp * 2.2 + Math.sin(2 * Math.PI * (70 - t * 35) * t) * 1.2) * Math.exp(-t * 3.2) * 0.9 * Math.min(1, t * 200); } });
    B.clank = makeBuf(c, 0.4, (d, n) => { for (let i = 0; i < n; i++) { const t = i / SR; d[i] = (Math.sin(2 * Math.PI * 640 * t) + Math.sin(2 * Math.PI * 1710 * t) * 0.6 + Math.sin(2 * Math.PI * 2960 * t) * 0.3) * Math.exp(-t * 12) * 0.35; } });
    B.chirp = [0, 1, 2].map((k) => makeBuf(c, 0.2, (d, n) => { for (let i = 0; i < n; i++) { const t = i / SR; const f = 3200 + k * 600 + Math.sin(t * 60) * 400 + t * 3000; d[i] = Math.sin(2 * Math.PI * f * t) * Math.exp(-Math.pow((t - 0.08) / 0.05, 2)) * 0.3; } }));
    // npc vocalisations: formant-ish blips
    const voice = (f0, dur, glide, vib, f1, f2) => makeBuf(c, dur, (d, n) => { let ph = 0; for (let i = 0; i < n; i++) { const t = i / SR; const f = f0 * (1 + glide * t / dur) * (1 + Math.sin(t * vib) * 0.04); ph += 2 * Math.PI * f / SR; let s = 0; for (let h = 1; h < 14; h++) { const hf = f * h; const g = Math.exp(-Math.pow((hf - f1) / 280, 2)) + 0.6 * Math.exp(-Math.pow((hf - f2) / 420, 2)); s += Math.sin(ph * h) * g / h; } d[i] = s * 0.55 * Math.min(1, t * 40) * Math.min(1, (dur - t) * 25); } });
    B.scream = [voice(300, 0.5, 0.35, 30, 800, 1700), voice(240, 0.6, 0.45, 26, 700, 1500), voice(420, 0.45, 0.3, 34, 900, 2000)];
    B.help = [voice(180, 0.55, 0.15, 12, 600, 1100), voice(250, 0.6, 0.2, 14, 700, 1400)];
    B.murmur = [voice(150, 0.35, 0.1, 8, 500, 1100), voice(210, 0.3, -0.1, 9, 650, 1500), voice(130, 0.4, 0.05, 7, 450, 1000)];
    B.laugh = voice(200, 0.5, -0.2, 40, 750, 1500);
    // loop sources
    B.wind = makeBuf(c, 3, (d, n) => { let lp = 0, lp2 = 0; for (let i = 0; i < n; i++) { lp += (noise() - lp) * 0.08; lp2 += (lp - lp2) * 0.3; d[i] = lp2 * 2.2; } this.loopFix(d, n); });
    B.city = makeBuf(c, 4, (d, n) => { let b = 0, b2 = 0; for (let i = 0; i < n; i++) { b = (b + 0.02 * noise()) / 1.02; b2 += (noise() - b2) * 0.02; d[i] = (b * 3.2 + b2 * 1.3 + Math.sin(i / SR * 2 * Math.PI * 55) * 0.05); } this.loopFix(d, n); });
    B.hum = makeBuf(c, 2, (d, n) => { for (let i = 0; i < n; i++) { const t = i / SR; d[i] = (Math.sin(2 * Math.PI * 100 * t) * 0.4 + Math.sin(2 * Math.PI * 200 * t) * 0.2 + Math.sin(2 * Math.PI * 300.5 * t) * 0.1) * 0.5; } });
    B.traffic = makeBuf(c, 4, (d, n) => { let lp = 0; for (let i = 0; i < n; i++) { const t = i / SR; lp += (noise() - lp) * 0.04; d[i] = lp * (1.6 + Math.sin(t * 2.0 * Math.PI * 0.4) * 0.6); } this.loopFix(d, n); });
    B.siren = makeBuf(c, 3, (d, n) => { let ph = 0; for (let i = 0; i < n; i++) { const t = i / SR; const f = 700 + 350 * Math.sin(t * 2 * Math.PI * 0.5 * 1.0); ph += 2 * Math.PI * f / SR; const w = Math.sin(ph) + Math.sin(ph * 2) * 0.3 + Math.sin(ph * 3) * 0.15; d[i] = w * 0.22 * Math.min(1, t * 6, (3 - t) * 6); } });
    B.sirenHiLo = makeBuf(c, 3, (d, n) => { let ph = 0; for (let i = 0; i < n; i++) { const t = i / SR; const f = Math.floor(t * 2.2) % 2 ? 960 : 770; ph += 2 * Math.PI * f / SR; d[i] = (Math.sin(ph) + Math.sin(ph * 3) * 0.2) * 0.18 * Math.min(1, t * 6, (3 - t) * 6); } });
    B.hammer = makeBuf(c, 0.25, (d, n) => { for (let i = 0; i < n; i++) { const t = i / SR; d[i] = (Math.sin(2 * Math.PI * 1100 * t) * 0.5 + noise() * 0.35) * Math.exp(-t * 40) * 0.5; } });
  }
  loopFix(d, n) { const k = Math.floor(SR * 0.05); for (let i = 0; i < k; i++) { const a = i / k; d[i] = d[i] * a + d[n - k + i] * (1 - a); } }

  setListener(camera) {
    if (!this.ctx) return;
    const L = this.ctx.listener;
    camera.updateWorldMatrix(true, false);
    const e = camera.matrixWorld.elements;
    const px = e[12], py = e[13], pz = e[14];
    const fx = -e[8], fy = -e[9], fz = -e[10], ux = e[4], uy = e[5], uz = e[6];
    if (L.positionX) {
      const t = this.ctx.currentTime;
      L.positionX.setTargetAtTime(px, t, 0.01); L.positionY.setTargetAtTime(py, t, 0.01); L.positionZ.setTargetAtTime(pz, t, 0.01);
      L.forwardX.setTargetAtTime(fx, t, 0.01); L.forwardY.setTargetAtTime(fy, t, 0.01); L.forwardZ.setTargetAtTime(fz, t, 0.01);
      L.upX.setTargetAtTime(ux, t, 0.01); L.upY.setTargetAtTime(uy, t, 0.01); L.upZ.setTargetAtTime(uz, t, 0.01);
    } else { L.setPosition(px, py, pz); L.setOrientation(fx, fy, fz, ux, uy, uz); }
    this.lx = px; this.ly = py; this.lz = pz;
  }

  /** Play a one-shot. pos optional {x,y,z} for spatialisation. */
  play(name, o = {}) {
    if (!this.ready) return null;
    let buf = this.bufs[name];
    if (Array.isArray(buf)) buf = buf[(Math.random() * buf.length) | 0];
    if (!buf) return null;
    const now = this.ctx.currentTime;
    // simple rate-limit per sound name to avoid spamming nodes
    if (o.minGap && this._last[name] && now - this._last[name] < o.minGap) return null;
    this._last[name] = now;
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    src.playbackRate.value = (o.rate || 1) * (1 + (Math.random() - 0.5) * (o.vary ?? 0.06));
    const g = this.ctx.createGain(); g.gain.value = o.gain ?? 1;
    let node = src; node.connect(g);
    let out = o.bus === 'ui' ? this.ui : o.bus === 'amb' ? this.amb : this.sfx;
    if (o.pos) {
      if (this.activeSpatial > 28) return null;
      const p = this.ctx.createPanner();
      p.panningModel = o.hrtf === false ? 'equalpower' : 'HRTF';
      p.distanceModel = 'inverse'; p.refDistance = o.ref ?? 2; p.maxDistance = 400; p.rolloffFactor = o.rolloff ?? 1.2;
      if (p.positionX) { p.positionX.value = o.pos.x; p.positionY.value = o.pos.y; p.positionZ.value = o.pos.z; } else p.setPosition(o.pos.x, o.pos.y, o.pos.z);
      g.connect(p); p.connect(out);
      if (o.reverb) { const s = this.ctx.createGain(); s.gain.value = o.reverb; g.connect(s); s.connect(this.verb); }
      this.activeSpatial++;
      src.onended = () => { this.activeSpatial--; try { p.disconnect(); g.disconnect(); } catch (e) { /* */ } };
    } else {
      g.connect(out);
      if (o.reverb) { const s = this.ctx.createGain(); s.gain.value = o.reverb; g.connect(s); s.connect(this.verb); }
      src.onended = () => { try { g.disconnect(); } catch (e) { /* */ } };
    }
    src.start(now + (o.delay || 0));
    return src;
  }

  /** Persistent loop with a filter and gain handle. */
  loop(name, { filter = 'lowpass', freq = 1000, q = 0.7, gain = 0, bus = 'amb', pos = null, rate = 1 } = {}) {
    if (!this.ready) return null;
    const src = this.ctx.createBufferSource(); src.buffer = this.bufs[name]; src.loop = true; src.playbackRate.value = rate;
    const f = this.ctx.createBiquadFilter(); f.type = filter; f.frequency.value = freq; f.Q.value = q;
    const g = this.ctx.createGain(); g.gain.value = gain;
    src.connect(f); f.connect(g);
    let p = null;
    if (pos) { p = this.ctx.createPanner(); p.panningModel = 'HRTF'; p.refDistance = 4; p.rolloffFactor = 1.2; this.setPannerPos(p, pos); g.connect(p); p.connect(bus === 'ui' ? this.ui : this.amb); }
    else g.connect(bus === 'ui' ? this.ui : bus === 'sfx' ? this.sfx : this.amb);
    src.start();
    return { src, filter: f, gain: g, panner: p };
  }
  setPannerPos(p, pos) { if (p.positionX) { p.positionX.value = pos.x; p.positionY.value = pos.y; p.positionZ.value = pos.z; } else p.setPosition(pos.x, pos.y, pos.z); }
  setGain(h, v, t = 0.1) { if (h) h.gain.gain.setTargetAtTime(v, this.ctx.currentTime, t); }

  startAmbience() {
    if (!this.ready || this.loops.city) return;
    this.loops.city = this.loop('city', { freq: 900, gain: 0.5 });
    this.loops.traffic = this.loop('traffic', { filter: 'bandpass', freq: 380, q: 0.5, gain: 0.35 });
    this.loops.wind = this.loop('wind', { filter: 'bandpass', freq: 500, q: 0.6, gain: 0, bus: 'sfx' });
    this.loops.hum = this.loop('hum', { freq: 600, gain: 0.0 });
    this.loops.glide = this.loop('wind', { filter: 'bandpass', freq: 900, q: 0.8, gain: 0, bus: 'sfx', rate: 1.2 });
    this.loops.slide = null;
    // random events
    const R = Math.random;
    const sched = (fn, minS, maxS) => { const go = () => { fn(); this.timers.push(setTimeout(go, (minS + R() * (maxS - minS)) * 1000)); }; this.timers.push(setTimeout(go, (minS * 0.5 + R() * maxS) * 1000)); };
    const away = (d) => { const a = R() * 6.283; return { x: this.lx + Math.cos(a) * d, y: this.ly + 10, z: this.lz + Math.sin(a) * d }; };
    sched(() => this.play(R() < 0.5 ? 'siren' : 'sirenHiLo', { pos: away(140 + R() * 100), gain: 1.4, ref: 30, rolloff: 0.9, bus: 'amb', hrtf: false }), 25, 55);
    sched(() => this.play('chirp', { pos: away(10 + R() * 25), gain: 0.8, bus: 'amb', vary: 0.3 }), 1.2, 4);
    sched(() => this.play('honk', { pos: away(30 + R() * 80), gain: 0.6, bus: 'amb', rate: 0.9 + R() * 0.3 }), 8, 20);
    sched(() => this.play('murmur', { pos: away(6 + R() * 18), gain: 0.5, bus: 'amb' }), 2, 6);
    sched(() => { if (this.constructionNear) this.play('hammer', { pos: away(15), gain: 1.2, bus: 'amb' }); }, 0.6, 1.4);
    sched(() => { if (this.constructionNear) this.play('clank', { pos: away(20), gain: 0.8, bus: 'amb' }); }, 3, 8);
  }

  stopAll() { for (const t of this.timers) clearTimeout(t); this.timers = []; for (const k in this.loops) { try { this.loops[k] && this.loops[k].src.stop(); } catch (e) { /* */ } } this.loops = {}; }

  /** Per-frame: modulate wind/glide/traffic from player state & district. */
  updateAmbient(state) {
    if (!this.ready) return;
    const L = this.loops;
    const speed = state.speed || 0, alt = state.altitude || 0;
    const w = clamp((speed - 8) / 30, 0, 1) * 0.6 + clamp(alt / 80, 0, 1) * 0.25;
    this.setGain(L.wind, w * (state.gliding ? 0.25 : 1), 0.15);
    if (L.wind) L.wind.filter.frequency.setTargetAtTime(350 + speed * 18 + alt * 4, this.ctx.currentTime, 0.2);
    this.setGain(L.glide, state.gliding ? clamp(speed / 28, 0.15, 1) * 0.55 : 0, 0.2);
    if (L.glide) L.glide.filter.frequency.setTargetAtTime(700 + speed * 40, this.ctx.currentTime, 0.2);
    const indoor = state.indoor ? 0.3 : 1;
    const high = clamp(1 - alt / 140, 0.35, 1);
    this.setGain(L.traffic, 0.34 * indoor * high, 0.4);
    this.setGain(L.city, 0.5 * indoor, 0.4);
    this.setGain(L.hum, state.nearHum ? 0.18 : 0.03, 0.4);
    this.constructionNear = state.district === 'con';
  }

  vibrate(gamepad, intensity = 0.5, ms = 40) {
    try {
      const a = gamepad && gamepad.hapticActuators && gamepad.hapticActuators[0];
      if (a && a.pulse) a.pulse(clamp(intensity, 0, 1), ms);
      else if (gamepad && gamepad.vibrationActuator) gamepad.vibrationActuator.playEffect('dual-rumble', { duration: ms, strongMagnitude: intensity, weakMagnitude: intensity });
    } catch (e) { /* ignore */ }
  }
}
