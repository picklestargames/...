import { Emitter } from './Utils.js';

const KEY = 'pickleCityVR.settings.v1';

export const DEFAULT_KEYS = {
  forward: 'KeyW', back: 'KeyS', left: 'KeyA', right: 'KeyD',
  sprint: 'ShiftLeft', jump: 'Space', crouch: 'ControlLeft',
  reload: 'KeyR', interact: 'KeyE', glider: 'KeyG', thirdPerson: 'KeyV', fps: 'F3',
};

export const DEFAULTS = {
  // VR comfort
  turnMode: 'snap',          // 'snap' | 'smooth'
  snapAngle: 30,
  smoothTurnSpeed: 120,      // deg/s
  moveSpeed: 1.0,            // multiplier
  vignette: 0.55,            // 0..1
  locomotion: 'smooth',      // 'smooth' | 'teleport'
  seated: false,
  eyeHeight: 1.65,           // calibrated standing eye height (m)
  leftHanded: false,
  showBody: true,
  aimTilt: 0,                // degrees; tilts the weapon relative to the controller
  moveRef: 'head',           // 'head' | 'hand' – what the move stick is relative to
  crouchMode: 'toggle',      // 'toggle' | 'physical' (physical always also works when standing)
  // Desktop
  mouseSens: 1.0,
  fov: 80,
  invertY: false,
  // Shared
  volume: 0.8,
  quality: 'auto',           // 'auto' | 'low' | 'medium' | 'high'
  shadows: 'auto',           // 'auto' | 'on' | 'off'
  showFps: false,
  keys: { ...DEFAULT_KEYS },
};

export class SettingsManager extends Emitter {
  constructor() {
    super();
    this.data = JSON.parse(JSON.stringify(DEFAULTS));
    try {
      const raw = typeof localStorage !== 'undefined' && localStorage.getItem(KEY);
      if (raw) {
        const o = JSON.parse(raw);
        for (const k of Object.keys(o)) {
          if (k === 'keys') Object.assign(this.data.keys, o.keys);
          else if (k in DEFAULTS) this.data[k] = o[k];
        }
      }
    } catch (e) { /* ignore */ }
  }
  get(k) { return this.data[k]; }
  set(k, v) {
    this.data[k] = v;
    this.save();
    this.emit('change', k, v);
  }
  setKey(action, code) {
    this.data.keys[action] = code;
    this.save();
    this.emit('change', 'keys', this.data.keys);
  }
  reset() {
    this.data = JSON.parse(JSON.stringify(DEFAULTS));
    this.save();
    this.emit('change', '*', null);
  }
  save() {
    try { localStorage.setItem(KEY, JSON.stringify(this.data)); } catch (e) { /* ignore */ }
  }
}
