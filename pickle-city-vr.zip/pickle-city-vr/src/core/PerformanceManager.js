// Adaptive quality: watches frame time and moves pixel ratio / shadow / NPC budgets up or down.
import { clamp } from './Utils.js';

const PRESETS = {
  low:    { pixelRatio: 0.75, shadows: false, npcs: 24, shadowMap: 1024, xrScale: 0.8 },
  medium: { pixelRatio: 1.0,  shadows: true,  npcs: 40, shadowMap: 1024, xrScale: 0.95 },
  high:   { pixelRatio: 1.0,  shadows: true,  npcs: 60, shadowMap: 2048, xrScale: 1.1 },
};

export class PerformanceManager {
  constructor(game) {
    this.game = game;
    this.level = 'medium';
    this.auto = true;
    this.frames = 0; this.acc = 0; this.fps = 60;
    this.cool = 3;
    this.shadowsOn = true;
    this.npcBudget = 40;
    this.xrScale = 1;
    this.tris = 0;
  }
  apply(renderer, world) {
    const s = this.game.settings.get('quality');
    this.auto = s === 'auto';
    if (!this.auto) this.level = s;
    const p = PRESETS[this.level];
    const isXR = renderer.xr.isPresenting;
    const pr = Math.min(window.devicePixelRatio || 1, 2) * p.pixelRatio * (isXR ? 1 : 1);
    renderer.setPixelRatio(isXR ? 1 : Math.min(pr, 1.75));
    if (renderer.xr.setFramebufferScaleFactor && !isXR) { try { renderer.xr.setFramebufferScaleFactor(p.xrScale); } catch (e) { /* */ } }
    const sh = this.game.settings.get('shadows');
    this.shadowsOn = sh === 'on' ? true : sh === 'off' ? false : (p.shadows && !(isXR && this.level === 'low'));
    renderer.shadowMap.enabled = this.shadowsOn;
    if (world && world.sun) {
      world.sun.castShadow = this.shadowsOn;
      if (world.sun.shadow.mapSize.x !== p.shadowMap) { world.sun.shadow.mapSize.set(p.shadowMap, p.shadowMap); if (world.sun.shadow.map) { world.sun.shadow.map.dispose(); world.sun.shadow.map = null; } }
    }
    this.npcBudget = p.npcs;
  }
  update(dt, renderer, world) {
    this.frames++; this.acc += dt;
    if (this.acc >= 1) {
      this.fps = this.frames / this.acc; this.frames = 0; this.acc = 0;
      this.tris = renderer.info.render.triangles;
      if (this.auto) {
        this.cool--;
        const target = renderer.xr.isPresenting ? 68 : 52;
        if (this.cool <= 0) {
          if (this.fps < target && this.level !== 'low') { this.level = this.level === 'high' ? 'medium' : 'low'; this.apply(renderer, world); this.cool = 4; }
          else if (this.fps > (renderer.xr.isPresenting ? 85 : 100) && this.level === 'low') { this.level = 'medium'; this.apply(renderer, world); this.cool = 8; }
        }
      }
    }
  }
}
