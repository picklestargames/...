// On-screen touch controls for phones/tablets (desktop mode without keyboard/mouse): floating move stick,
// drag-to-look, fire/aim/jump/crouch/reload/use/car/glide/swap/pause buttons. Buttons reuse the keyboard path
// by dispatching the same key codes as the settings, so every system works unchanged.
import { clamp } from '../core/Utils.js';

const CSS = `
#touch{position:fixed;inset:0;z-index:6;display:none;-webkit-user-select:none;user-select:none;touch-action:none;-webkit-touch-callout:none}
#touch *{touch-action:none;-webkit-tap-highlight-color:transparent}
#touch .zl{position:absolute;left:0;bottom:0;width:44%;height:70%}
#touch .zr{position:absolute;right:0;top:0;width:56%;height:100%}
#touch .jbase{position:absolute;width:120px;height:120px;margin:-60px 0 0 -60px;border-radius:50%;border:3px solid rgba(255,255,255,.35);background:rgba(255,255,255,.08);display:none;pointer-events:none}
#touch .jknob{position:absolute;left:50%;top:50%;width:54px;height:54px;margin:-27px 0 0 -27px;border-radius:50%;background:rgba(166,220,60,.7);border:2px solid rgba(255,255,255,.7)}
#touch .tb{position:absolute;display:flex;align-items:center;justify-content:center;border-radius:50%;background:rgba(10,30,14,.55);border:2px solid rgba(166,220,60,.7);color:#e8ffd0;font:700 12px system-ui,sans-serif;letter-spacing:.5px}
#touch .tb.on,#touch .tb:active{background:rgba(166,220,60,.55);color:#06200c}
#touch .fire{right:18px;bottom:26px;width:104px;height:104px;font-size:16px;border-color:#ff7a5a;background:rgba(80,20,10,.55)}
#touch .fire:active,#touch .fire.on{background:rgba(255,110,70,.6)}
#touch .grid{position:absolute;right:136px;bottom:18px;display:grid;grid-template-columns:repeat(2,60px);grid-auto-rows:60px;gap:8px}
#touch .grid .tb,#touch .aim{position:relative}
#touch .aim{position:absolute;right:46px;bottom:142px;width:60px;height:60px}
#touch .pause{left:12px;top:10px;width:44px;height:44px;font-size:18px}
body.touch #hud-bl{top:12px;bottom:auto;left:70px;width:200px;transform:scale(.8);transform-origin:top left}
body.touch #hud-br{top:12px;bottom:auto;right:150px}
body.touch #minimap{width:104px;height:104px;right:12px;top:12px}
body.touch #slots{display:none}
@media (orientation:portrait){#touch .rot{display:flex}}
#touch .rot{display:none;position:absolute;left:0;right:0;top:0;padding:8px;text-align:center;background:rgba(0,0,0,.6);color:#fff;font:600 13px system-ui;justify-content:center}
`;

export class TouchControls {
  constructor(game) {
    this.game = game; this.enabled = false;
    this.joy = { x: 0, y: 0, on: false, id: -1, cx: 0, cy: 0 };
    this.fire = false; this.ads = false; this.crouch = false; this.look = { id: -1, x: 0, y: 0 }; this.sprint = false;
    const st = document.createElement('style'); st.textContent = CSS; document.head.appendChild(st);
    const root = this.root = document.createElement('div'); root.id = 'touch';
    const zl = document.createElement('div'); zl.className = 'zl'; const zr = document.createElement('div'); zr.className = 'zr';
    const base = this.base = document.createElement('div'); base.className = 'jbase'; const knob = this.knob = document.createElement('div'); knob.className = 'jknob'; base.appendChild(knob);
    root.append(zr, zl, base);
    zl.addEventListener('pointerdown', (e) => this.joyDown(e)); zl.addEventListener('pointermove', (e) => this.joyMove(e)); zl.addEventListener('pointerup', (e) => this.joyUp(e)); zl.addEventListener('pointercancel', (e) => this.joyUp(e));
    zr.addEventListener('pointerdown', (e) => { if (this.look.id < 0) { this.look.id = e.pointerId; this.look.x = e.clientX; this.look.y = e.clientY; zr.setPointerCapture(e.pointerId); } e.preventDefault(); });
    zr.addEventListener('pointermove', (e) => this.lookMove(e)); zr.addEventListener('pointerup', (e) => { if (e.pointerId === this.look.id) this.look.id = -1; }); zr.addEventListener('pointercancel', () => { this.look.id = -1; });
    // buttons
    const mk = (cls, label, parent, down, up) => {
      const b = document.createElement('div'); b.className = 'tb ' + cls; b.textContent = label; parent.appendChild(b);
      b.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); b.setPointerCapture(e.pointerId); down && down(b); });
      const end = (e) => { e.preventDefault(); up && up(b); };
      b.addEventListener('pointerup', end); b.addEventListener('pointercancel', end);
      return b;
    };
    const key = (action) => this.game.settings.get('keys')[action];
    const tap = (action) => () => { this.key(key(action), true); setTimeout(() => this.key(key(action), false), 60); };
    mk('fire', 'FIRE', root, (b) => { this.fire = true; b.classList.add('on'); }, (b) => { this.fire = false; b.classList.remove('on'); });
    mk('aim', 'AIM', root, () => { this.ads = !this.ads; this.aimBtn.classList.toggle('on', this.ads); });
    this.aimBtn = root.lastChild;
    const grid = document.createElement('div'); grid.className = 'grid'; root.appendChild(grid);
    mk('', 'JUMP', grid, tap('jump'));
    mk('', 'CROUCH', grid, (b) => { this.crouch = !this.crouch; this.key(key('crouch'), this.crouch); b.classList.toggle('on', this.crouch); });
    mk('', 'RELOAD', grid, tap('reload'));
    mk('', 'USE', grid, tap('interact'));
    mk('', 'CAR', grid, () => { this.key('KeyF', true); setTimeout(() => this.key('KeyF', false), 60); });
    mk('', 'SWAP', grid, () => game.weapons && game.weapons.cycle(1));
    mk('', 'GLIDE', grid, tap('glider'));
    mk('', 'VIEW', grid, tap('thirdPerson'));
    mk('pause', 'II', root, () => game.pause());
    const rot = document.createElement('div'); rot.className = 'rot'; rot.textContent = 'Rotate your phone to landscape for the best view'; root.appendChild(rot);
    document.body.appendChild(root);
  }
  key(code, down) { try { window.dispatchEvent(new KeyboardEvent(down ? 'keydown' : 'keyup', { code, key: code, bubbles: true })); } catch (e) { /* */ } }

  enable(on) {
    this.enabled = on; document.body.classList.toggle('touch', on);
    if (!on) { this.fire = false; this.ads = false; this.joy.on = false; return; }
    try { const el = document.documentElement; if (el.requestFullscreen && !document.fullscreenElement) el.requestFullscreen({ navigationUI: 'hide' }).catch(() => {}); } catch (e) { /* */ }
    try { screen.orientation && screen.orientation.lock && screen.orientation.lock('landscape').catch(() => {}); } catch (e) { /* */ }
  }
  /** each frame from Game.frame: show only while playing */
  sync() { const show = this.enabled && this.game.state === 'playing' && !this.game.vr.active; this.root.style.display = show ? 'block' : 'none'; if (!show && this.fire) { this.fire = false; } }

  joyDown(e) {
    if (this.joy.id >= 0) return; e.preventDefault(); e.currentTarget.setPointerCapture(e.pointerId);
    this.joy.id = e.pointerId; this.joy.on = true; this.joy.cx = e.clientX; this.joy.cy = e.clientY; this.joy.x = this.joy.y = 0;
    this.base.style.display = 'block'; this.base.style.left = e.clientX + 'px'; this.base.style.top = e.clientY + 'px'; this.knob.style.transform = 'translate(0,0)';
  }
  joyMove(e) {
    if (e.pointerId !== this.joy.id) return; e.preventDefault();
    const R = 56; let dx = e.clientX - this.joy.cx, dy = e.clientY - this.joy.cy; const m = Math.hypot(dx, dy);
    if (m > R) { dx = dx / m * R; dy = dy / m * R; }
    this.knob.style.transform = `translate(${dx}px,${dy}px)`;
    const nx = dx / R, ny = -dy / R, mag = Math.hypot(nx, ny), dz = 0.14;
    if (mag < dz) { this.joy.x = this.joy.y = 0; } else { const k = (mag - dz) / (1 - dz) / mag; this.joy.x = nx * k; this.joy.y = ny * k; }
  }
  joyUp(e) {
    if (e.pointerId !== this.joy.id) return;
    this.joy.id = -1; this.joy.on = false; this.joy.x = this.joy.y = 0; this.base.style.display = 'none';
  }
  lookMove(e) {
    if (e.pointerId !== this.look.id) return; e.preventDefault();
    const g = this.game; if (g.state !== 'playing') return;
    const dx = e.clientX - this.look.x, dy = e.clientY - this.look.y; this.look.x = e.clientX; this.look.y = e.clientY;
    const p = g.player, s = g.settings, k = 0.0042 * s.get('mouseSens') * (1 - g.camera_ctrl.ads * 0.55);
    p.yaw -= dx * k; p.pitch = clamp(p.pitch - dy * k * (s.get('invertY') ? -1 : 1), -1.52, 1.52);
  }

  /** called by DesktopController.update after the keyboard intent was built */
  apply(I, driving, vi) {
    if (!this.enabled) return;
    const j = this.joy, mag = Math.hypot(j.x, j.y);
    if (driving) { vi.steer = j.x; vi.throttle = Math.max(0, j.y); vi.brake = Math.max(0, -j.y); return; }
    if (j.on && mag > 0) { I.moveX = j.x; I.moveZ = j.y; I.sprint = mag > 0.93 && j.y > 0.3; }
  }
}
