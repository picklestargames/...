// DOM UI: start menu, loading screen, pause, settings + controls panels (with key remapping), desktop HUD and minimap.
import { DEFAULT_KEYS } from '../core/SettingsManager.js';
import { WEAPON_LIST } from '../weapons/WeaponDefs.js';
import { DMAP, DISTRICT_COLORS, GRID, P, cx } from '../world/Constants.js';
import { clamp } from '../core/Utils.js';
import { drawMinimap } from './Minimap.js';

const $ = (id) => document.getElementById(id);
const KEY_LABELS = { forward: 'Move forward', back: 'Move back', left: 'Strafe left', right: 'Strafe right', sprint: 'Sprint', jump: 'Jump / Glide', crouch: 'Crouch / Slide', reload: 'Reload', interact: 'Interact / Grab', glider: 'Glider toggle', thirdPerson: 'Third-person view', fps: 'FPS counter' };

function prettyKey(code) {
  if (!code) return '—';
  return code.replace(/^Key/, '').replace(/^Digit/, '').replace('ShiftLeft', 'L-Shift').replace('ControlLeft', 'L-Ctrl').replace('Space', 'Space').replace('ArrowUp', '↑').replace('ArrowDown', '↓').replace('ArrowLeft', '←').replace('ArrowRight', '→');
}

export class UIManager {
  constructor(game) {
    this.game = game;
    this.el = {};
    for (const id of ['hud', 'menu', 'loading', 'pause', 'panel-settings', 'panel-controls', 'hp-fill', 'hp-num', 'sh-fill', 'sh-num', 'buffs', 'wname', 'ammo-mag', 'ammo-res', 'slots', 'minimap', 'prompt', 'toast', 'glide-hint', 'fps', 'hitmarker', 'crosshair',
      'vr-status', 'secure-warn', 'three-src', 'btn-entervr', 'btn-play', 'btn-touch', 'btn-vr-secondary', 'btn-settings', 'btn-controls', 'load-pct', 'load-assets', 'load-init', 'load-assets-n', 'load-init-n', 'load-msg', 'btn-load-vr', 'btn-load-start',
      'btn-resume', 'btn-pause-settings', 'btn-pause-controls', 'btn-quit', 'settings-body', 'settings-reset', 'settings-close', 'controls-body', 'controls-close']) this.el[id] = $(id);
    this.toastT = 0; this.hitT = 0; this.mm = this.el.minimap.getContext('2d');
    this.mmT = 0;
    this.el['three-src'].textContent = 'Three.js: ' + (window.__THREE_SOURCE || '?');
    this.bind();
    this.buildSettings();
    this.buildControls();
    game.settings.on('change', (k) => { if (k === 'keys' || k === '*') this.buildControls(); if (k === '*') this.buildSettings(); });
  }

  bind() {
    const g = this.game, e = this.el;
    e['btn-play'].onclick = () => g.start('desktop');
    const tl = () => { e['btn-touch'].textContent = 'TOUCH CONTROLS: ' + (g.touchMode ? 'ON (phone / tablet)' : 'OFF'); };
    e['btn-touch'].onclick = () => { g.touchMode = !g.touchMode; tl(); }; tl();
    e['btn-entervr'].onclick = e['btn-vr-secondary'].onclick = e['btn-load-vr'].onclick = () => g.start('vr');
    e['btn-load-start'].onclick = () => g.begin('desktop');
    e['btn-settings'].onclick = e['btn-pause-settings'].onclick = () => this.panel('settings', true);
    e['btn-controls'].onclick = e['btn-pause-controls'].onclick = () => this.panel('controls', true);
    e['settings-close'].onclick = () => this.panel('settings', false);
    e['controls-close'].onclick = () => this.panel('controls', false);
    e['settings-reset'].onclick = () => g.settings.reset();
    e['btn-resume'].onclick = () => g.resume();
    e['btn-quit'].onclick = () => g.quitToMenu();
  }

  panel(name, show) {
    this.el['panel-' + name].classList.toggle('hidden', !show);
    if (show) { this.game.audio.init(); this.game.audio.play('ui', { gain: 0.4 }); }
    if (show && name === 'controls') this.buildControls();
  }

  // ---------------------------------------------------------------- menu / loading
  setVRStatus(supported, secure, hasXR) {
    const e = this.el;
    e['btn-entervr'].classList.toggle('hidden', !supported);
    e['btn-vr-secondary'].classList.add('hidden');
    e['btn-play'].textContent = supported ? 'PLAY ON DESKTOP' : 'PLAY';
    e['secure-warn'].classList.toggle('hidden', secure);
    e['vr-status'].textContent = supported ? 'VR headset detected — click ENTER VR' : !hasXR ? 'No WebXR available — desktop mode (keyboard + mouse)' : !secure ? 'WebXR blocked: needs HTTPS — desktop mode' : 'No VR headset found — desktop mode (keyboard + mouse)';
    e['vr-status'].style.color = supported ? '#7dff7a' : '';
  }
  showMenu(v) { this.el.menu.classList.toggle('hidden', !v); }
  showLoading(v) { this.el.loading.classList.toggle('hidden', !v); if (v) { this.el['btn-load-vr'].classList.add('hidden'); this.el['btn-load-start'].classList.add('hidden'); } }
  setLoading(assets, init, msg) {
    const e = this.el, tot = clamp(assets * 0.6 + init * 0.4, 0, 1);
    e['load-pct'].textContent = Math.round(tot * 100);
    e['load-assets'].style.width = Math.round(assets * 100) + '%'; e['load-init'].style.width = Math.round(init * 100) + '%';
    e['load-assets-n'].textContent = Math.round(assets * 100) + '%'; e['load-init-n'].textContent = Math.round(init * 100) + '%';
    if (msg) e['load-msg'].textContent = msg;
  }
  loadReady(mode, vrSupported) {
    this.el['load-msg'].textContent = 'Ready!';
    if (mode === 'vr' && vrSupported) this.el['btn-load-vr'].classList.remove('hidden');
    else this.el['btn-load-start'].classList.remove('hidden');
  }
  showHUD(v) { this.el.hud.classList.toggle('hidden', !v); }
  showPause(v) { this.el.pause.classList.toggle('hidden', !v); }

  // ---------------------------------------------------------------- settings
  buildSettings() {
    const S = this.game.settings, body = this.el['settings-body'];
    body.innerHTML = '';
    const sec = (t) => { const d = document.createElement('div'); d.className = 'set-sec'; d.textContent = t; body.appendChild(d); };
    const row = (label, ctl, val) => { const r = document.createElement('div'); r.className = 'set-row'; const l = document.createElement('span'); l.textContent = label; const v = document.createElement('em'); v.style.fontStyle = 'normal'; v.textContent = val || ''; r.append(l, ctl, v); body.appendChild(r); return v; };
    const range = (key, label, min, max, step, fmt = (v) => v) => {
      const i = document.createElement('input'); i.type = 'range'; i.min = min; i.max = max; i.step = step; i.value = S.get(key);
      const v = row(label, i, fmt(S.get(key)));
      i.oninput = () => { S.set(key, +i.value); v.textContent = fmt(+i.value); };
    };
    const select = (key, label, opts) => {
      const s = document.createElement('select');
      for (const [val, txt] of opts) { const o = document.createElement('option'); o.value = String(val); o.textContent = txt; s.appendChild(o); }
      s.value = String(S.get(key));
      row(label, s);
      s.onchange = () => { const raw = s.value; const v = raw === 'true' ? true : raw === 'false' ? false : (isNaN(+raw) || raw === '' ? raw : (typeof S.get(key) === 'number' ? +raw : raw)); S.set(key, v); };
    };
    const check = (key, label) => {
      const c = document.createElement('input'); c.type = 'checkbox'; c.checked = !!S.get(key); c.style.justifySelf = 'start';
      row(label, c); c.onchange = () => S.set(key, c.checked);
    };
    sec('VR COMFORT');
    select('locomotion', 'Locomotion', [['smooth', 'Smooth (stick)'], ['teleport', 'Teleport (arc)']]);
    select('turnMode', 'Turning', [['snap', 'Snap turn'], ['smooth', 'Smooth turn']]);
    range('snapAngle', 'Snap angle', 15, 90, 15, (v) => v + '°');
    range('smoothTurnSpeed', 'Smooth turn speed', 40, 240, 10, (v) => v + '°/s');
    range('moveSpeed', 'Move speed', 0.5, 1.5, 0.05, (v) => (+v).toFixed(2) + '×');
    range('vignette', 'Comfort vignette', 0, 1, 0.05, (v) => Math.round(v * 100) + '%');
    select('moveRef', 'Move relative to', [['head', 'Head'], ['hand', 'Left controller']]);
    check('seated', 'Seated mode');
    range('eyeHeight', 'Eye height (cal.)', 1.0, 2.1, 0.01, (v) => (+v).toFixed(2) + ' m');
    check('leftHanded', 'Left-handed (swap sticks / weapon hand)');
    check('showBody', 'Show pickle body in VR');
    range('aimTilt', 'Weapon aim tilt', -30, 30, 1, (v) => v + '°');
    sec('DESKTOP');
    range('mouseSens', 'Mouse sensitivity', 0.2, 3, 0.05, (v) => (+v).toFixed(2));
    range('fov', 'Field of view', 60, 110, 1, (v) => v + '°');
    check('invertY', 'Invert Y');
    sec('AUDIO / GRAPHICS');
    range('volume', 'Master volume', 0, 1, 0.05, (v) => Math.round(v * 100) + '%');
    select('quality', 'Quality', [['auto', 'Auto (adaptive)'], ['low', 'Low'], ['medium', 'Medium'], ['high', 'High']]);
    select('shadows', 'Shadows', [['auto', 'Auto'], ['on', 'On'], ['off', 'Off']]);
    check('showFps', 'Show FPS');
    const g = this.game;
    S.on('change', (k) => { if (k === 'quality' || k === 'shadows') g.perf.apply(g.renderer, g.world); if (k === 'showFps') this.el.fps.classList.toggle('hidden', !S.get('showFps')); });
  }

  buildControls() {
    const S = this.game.settings, d = this.game.desktop, body = this.el['controls-body'];
    body.innerHTML = '';
    const mk = (tag, cls, txt) => { const x = document.createElement(tag); if (cls) x.className = cls; if (txt) x.textContent = txt; return x; };
    const grid = mk('div', 'ctl-grid');
    grid.appendChild(mk('h3', '', 'DESKTOP — click a key to remap'));
    for (const k of Object.keys(DEFAULT_KEYS)) {
      const cell = mk('div', 'keyrow'); cell.appendChild(mk('span', '', KEY_LABELS[k] || k));
      const b = mk('button', '', prettyKey(S.get('keys')[k]));
      b.onclick = () => { b.textContent = 'press a key…'; d.remapping = k; d.onRemap = () => { this.buildControls(); }; };
      cell.appendChild(b); grid.appendChild(cell);
    }
    const fixed = [['Mouse', 'Aim'], ['Left click', 'Fire'], ['Right click', 'Aim down sights'], ['1 – 6 / Q / wheel', 'Switch weapon'], ['Esc', 'Pause']];
    for (const [a, b] of fixed) { const c = mk('div'); const bb = mk('b', '', a); c.append(bb, document.createTextNode(b)); grid.appendChild(c); }
    grid.appendChild(mk('h3', '', 'VR — (right-handed layout; "left-handed" swaps sides)'));
    const vr = [
      ['Left stick', 'Move (or aim a teleport arc)'], ['Right stick', 'Snap / smooth turn'], ['Left stick click', 'Toggle sprint'],
      ['X (left)', 'Crouch toggle · while moving fast = SLIDE'], ['Y (left)', 'Pickle menu (settings)'], ['A (right)', 'Jump · in the air: open glider · gliding: close'],
      ['Trigger', 'Gun: fire · Empty hand: press UI/buttons, or point at a dropped weapon and pull to fly it into your hand'], ['Grip', 'HOLD grip to hold things. Empty hand at a hip holster (left / right pouch) + grip = draw. You keep the gun only while holding grip: let go at a holster = put away, anywhere else = DROP. Grip anything lying around, doors, crates, or ANY part of a civilian (release to throw)'],
      ['B (right)', 'Eject magazine (press again = auto reload)'], ['Off-hand grip at foregrip', 'Two-handed hold (SMG, rifle, shotgun, DMR)'], ['Off-hand grip at belt pouch, then bring to the gun', 'Manual reload: new mag / shell'],
      ['Both hands on glider bar', 'Lower right hand = turn right · reach forward = dive · pull in = flare'], ['Swing a hand fast into a civilian', 'Punch (no grab needed). Hit, shot or grabbed civilians get ANGRY and slowly chase you with fists (5 dmg per hit)'], ['Crouch physically', 'Auto-crouch; dropping into a crouch while running = slide'],
    ];
    for (const [a, b] of vr) { const c = mk('div'); c.append(mk('b', '', a), document.createTextNode(b)); grid.appendChild(c); }
    body.appendChild(grid);
  }

  // ---------------------------------------------------------------- HUD
  toast(msg, ms = 1200) {
    const t = this.el.toast; t.textContent = msg; t.classList.remove('hidden'); this.toastT = ms / 1000;
    if (this.game.vr.active && this.game.vr.ui) this.game.vr.ui.toast(msg, ms);
  }
  hitMarker() { const h = this.el.hitmarker; h.classList.add('on'); this.hitT = 0.12; }

  refreshWeapon() {
    const g = this.game, W = g.weapons;
    if (!W) return;            // called from inside WeaponSystem's constructor before game.weapons is assigned
    const h = W.holders[0];
    this.el.wname.textContent = h.def ? h.def.name : '— EMPTY HAND —';
    const s = this.el.slots; s.innerHTML = '';
    WEAPON_LIST.forEach((d, i) => {
      const sp = document.createElement('span'); sp.textContent = i + 1;
      if (W.inv.has(d.id)) sp.className = 'own' + (h.id === d.id ? ' sel' : '');
      s.appendChild(sp);
    });
    this.refreshAmmo();
  }
  refreshAmmo() {
    if (!this.game.weapons) return;
    const h = this.game.weapons.holders[0];
    this.el['ammo-mag'].textContent = h.state ? h.state.mag : 0;
    this.el['ammo-res'].textContent = h.state ? h.state.reserve : 0;
    this.el['ammo-mag'].style.color = h.state && h.state.mag === 0 ? '#ff5a4a' : '';
  }

  update(dt) {
    const g = this.game, e = this.el, h = g.health, p = g.player;
    if (this.toastT > 0) { this.toastT -= dt; if (this.toastT <= 0) e.toast.classList.add('hidden'); }
    if (this.hitT > 0) { this.hitT -= dt; if (this.hitT <= 0) e.hitmarker.classList.remove('on'); }
    if (g.vr.active) return;
    e['hp-fill'].style.width = (h.hp / h.max * 100) + '%'; e['hp-num'].textContent = Math.ceil(h.hp);
    e['sh-fill'].style.width = h.shield + '%'; e['sh-num'].textContent = Math.ceil(h.shield);
    { const cr = g.crime, v = g.vehicles; const parts = [];
      if (cr) parts.push('$' + cr.money.toLocaleString('en-US')); if (cr && cr.wanted) parts.push('WANTED');
      if (v && v.driving) parts.push(Math.round(v.speedKmh) + ' km/h');
      if (h.buffs.boost > 0) parts.push('SPEED BOOST ' + Math.ceil(h.buffs.boost) + 's');
      e.buffs.textContent = parts.join('  ·  '); }
    e.crosshair.style.opacity = g.camera_ctrl.third ? 0.5 : (g.weapons.holders[0].ads > 0.5 ? 0 : 1);
    const pr = g.interaction.promptText;
    e.prompt.textContent = pr; e.prompt.classList.toggle('hidden', !pr);
    const gh = e['glide-hint'];
    if (g.glider.canDeploy && !p.gliding) { gh.textContent = 'SPACE / G — GLIDER'; gh.classList.remove('hidden'); } else if (p.gliding) { gh.textContent = 'GLIDING — W dive · S flare · A/D bank · mouse steers'; gh.classList.remove('hidden'); } else gh.classList.add('hidden');
    if (g.settings.get('showFps')) { e.fps.classList.remove('hidden'); e.fps.textContent = Math.round(g.perf.fps) + ' fps · ' + g.perf.level + ' · ' + g.world.chunks.hi.size + '/' + g.world.chunks.lo.size + ' chunks'; }
    this.mmT -= dt; if (this.mmT <= 0) { this.drawMinimap(); this.mmT = 0.08; }
  }

  drawMinimap() {
    const p = this.game.player, c = this.mm;
    drawMinimap(this.game, c, 180, 105, true);
    c.fillStyle = '#fff'; c.font = 'bold 11px system-ui'; c.textAlign = 'center'; c.fillText(Math.round(p.pos.y) + ' m', 90, 172);
  }
}
