// VR-native UI: a wrist status display (health / shield / both weapons' ammo), a pop-up settings menu you poke with the laser,
// floating world prompts and toasts. Everything is canvas-textured quads in the scene – no DOM needed inside the headset.
import * as THREE from 'three';
import { clamp, deg } from '../core/Utils.js';
import { drawMinimap } from './Minimap.js';

const GREEN = '#7dff7a', DARK = 'rgba(8,18,10,0.88)', EDGE = '#2e6a2a';

function canvasTex(w, h) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.minFilter = THREE.LinearFilter; t.generateMipmaps = false;
  return { c, ctx: c.getContext('2d'), tex: t };
}
function rrect(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }

export class VRUIManager {
  constructor(game, vr) {
    this.game = game; this.vr = vr;
    const scene = game.world.scene;
    this.dragging = false;
    this.hover = null;
    this.frame = 0;
    // ---- wrist status
    this.wristCv = canvasTex(320, 176);
    this.wrist = new THREE.Mesh(new THREE.PlaneGeometry(0.16, 0.088), new THREE.MeshBasicMaterial({ map: this.wristCv.tex, transparent: true, toneMapped: false, depthTest: false }));
    this.wrist.renderOrder = 30; this.wrist.rotation.x = -1.2; this.wrist.position.set(0, 0.035, 0.1); this.wrist.frustumCulled = false;
    this.wristT = 0; this.wristHint = ''; this.wristToast = ''; this.wristToastT = 0;
    // ---- menu
    this.menuW = 0.9; this.menuH = 1.3; this.CW = 720; this.CH = 1040;
    this.menuCv = canvasTex(this.CW, this.CH);
    this.menu = new THREE.Mesh(new THREE.PlaneGeometry(this.menuW, this.menuH), new THREE.MeshBasicMaterial({ map: this.menuCv.tex, transparent: true, toneMapped: false, side: THREE.DoubleSide }));
    this.menu.visible = false; this.menu.frustumCulled = false; this.menu.renderOrder = 25;
    scene.add(this.menu);
    this.buttons = []; this.dirty = true; this.menuT = 0;
    // ---- prompt + toast sprites
    this.promptCv = canvasTex(512, 96);
    this.promptSpr = new THREE.Sprite(new THREE.SpriteMaterial({ map: this.promptCv.tex, transparent: true, depthTest: false, toneMapped: false, fog: false }));
    this.promptSpr.visible = false; this.promptSpr.renderOrder = 26; this.promptSpr.frustumCulled = false; this.promptText = ''; this.promptShown = ''; this.promptFrame = -1;
    this.toastCv = canvasTex(640, 96);
    this.toastSpr = new THREE.Sprite(new THREE.SpriteMaterial({ map: this.toastCv.tex, transparent: true, depthTest: false, toneMapped: false, fog: false }));
    this.toastSpr.visible = false; this.toastSpr.renderOrder = 27; this.toastSpr.frustumCulled = false; this.toastT = 0; this.toastPos = new THREE.Vector3();
    scene.add(this.promptSpr, this.toastSpr);
    this._v = new THREE.Vector3(); this._n = new THREE.Vector3(); this._p = new THREE.Vector3(); this._l = new THREE.Vector3();
  }

  setVisible(v) {
    if (!v) { this.wrist.visible = false; this.menu.visible = false; this.promptSpr.visible = false; this.toastSpr.visible = false; this.vr.menuOpen = false; }
    else this.wrist.visible = true;
  }
  attachWrist() { this.wristDirty = true; }

  // ------------------------------------------------------------ menu
  toggleMenu() { this.vr.menuOpen ? this.closeMenu() : this.openMenu(); }
  openMenu() {
    const g = this.game, vr = this.vr;
    vr.menuOpen = true;
    // holster both hands so the lasers are available
    for (let i = 0; i < 2; i++) g.weapons.holster(i);
    const hp = vr.headPos, f = vr.headForward;
    const px = hp.x + f.x * 0.85, pz = hp.z + f.z * 0.85, py = hp.y - 0.12;
    this.menu.position.set(px, py, pz);
    this.menu.rotation.set(0, Math.atan2(hp.x - px, hp.z - pz), 0);
    this.menu.visible = true; this.dirty = true;
    g.audio.play('ui', { gain: 0.5 });
  }
  closeMenu() {
    this.vr.menuOpen = false; this.menu.visible = false; this.hover = null;
    this.game.audio.play('ui', { gain: 0.4, rate: 0.8 });
    // re-equip the main-hand pistol for convenience
    const g = this.game, W = g.weapons, mi = this.vr.mainIdx;
    if (!W.holders[mi].model && W.inv.has('pistol') && !W.held('pistol')) W.equip(mi, 'pistol');
  }

  rows() {
    const S = this.game.settings, vr = this.vr;
    const step = (key, d, lo, hi, fmt, scale = 1) => ({ minus: () => S.set(key, +clamp(S.get(key) - d, lo, hi).toFixed(2)), plus: () => S.set(key, +clamp(S.get(key) + d, lo, hi).toFixed(2)), text: () => fmt(S.get(key)) });
    const choice = (key, opts, after) => ({ opts: opts.map(([v, l]) => ({ label: l, on: () => S.get(key) === v, fn: () => { S.set(key, v); after && after(); } })) });
    return [
      { label: '', full: { label: 'RESUME', fn: () => this.closeMenu() } },
      { label: 'MOVEMENT', ...choice('locomotion', [['smooth', 'SMOOTH'], ['teleport', 'TELEPORT']]) },
      { label: 'TURNING', ...choice('turnMode', [['snap', 'SNAP'], ['smooth', 'SMOOTH']]) },
      { label: 'SNAP ANGLE', ...step('snapAngle', 15, 15, 90, (v) => v + '°') },
      { label: 'TURN SPEED', ...step('smoothTurnSpeed', 20, 40, 240, (v) => v + '°/s') },
      { label: 'MOVE SPEED', ...step('moveSpeed', 0.1, 0.5, 1.5, (v) => v.toFixed(1) + '×') },
      { label: 'VIGNETTE', ...step('vignette', 0.1, 0, 1, (v) => Math.round(v * 100) + '%') },
      { label: 'STANCE', ...choice('seated', [[false, 'STANDING'], [true, 'SEATED']], () => vr.recenter()) },
      { label: 'MOVE RELATIVE TO', ...choice('moveRef', [['head', 'HEAD'], ['hand', 'HAND']]) },
      { label: 'HANDEDNESS', ...choice('leftHanded', [[false, 'RIGHT'], [true, 'LEFT']]) },
      { label: 'HEIGHT', opts: [{ label: 'CALIBRATE', on: () => false, fn: () => vr.calibrateHeight() }, { label: 'RECENTER', on: () => false, fn: () => vr.recenter() }] },
      { label: '', full: { label: 'GO HOME (APARTMENT)', fn: () => { this.closeMenu(); this.game.apartment.enter(); } } },
      { label: '', full: { label: 'EXIT VR', fn: () => { this.closeMenu(); vr.exit(); }, danger: true } },
    ];
  }

  drawMenu() {
    const { ctx } = this.menuCv, W = this.CW, H = this.CH;
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = DARK; rrect(ctx, 6, 6, W - 12, H - 12, 34); ctx.fill();
    ctx.lineWidth = 5; ctx.strokeStyle = EDGE; ctx.stroke();
    ctx.fillStyle = GREEN; ctx.font = 'bold 50px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('PICKLE MENU', W / 2, 62);
    this.buttons.length = 0;
    const rows = this.rows();
    let y = 112; const rh = 58, gap = 8;
    for (const r of rows) {
      const cy = y + rh / 2;
      if (r.full) {
        this.btn(ctx, 40, y, W - 80, rh, r.full.label, false, r.full.fn, r.full.danger);
      } else {
        ctx.fillStyle = '#b6e8b0'; ctx.font = '600 25px system-ui, sans-serif'; ctx.textAlign = 'left'; ctx.fillText(r.label, 44, cy);
        if (r.opts) {
          const bw = 150, x0 = W - 44 - bw * r.opts.length - 10 * (r.opts.length - 1);
          r.opts.forEach((o, i) => this.btn(ctx, x0 + i * (bw + 10), y, bw, rh, o.label, o.on(), o.fn));
        } else {
          const bw = 64; const xr = W - 44;
          this.btn(ctx, xr - bw, y, bw, rh, '+', false, r.plus);
          ctx.fillStyle = '#fff'; ctx.font = 'bold 27px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.fillText(r.text(), xr - bw - 80, cy);
          this.btn(ctx, xr - bw - 160, y, bw, rh, '−', false, r.minus);
        }
      }
      y += rh + gap;
    }
    ctx.fillStyle = 'rgba(180,230,175,0.7)'; ctx.font = '22px system-ui, sans-serif'; ctx.textAlign = 'center';
    ctx.fillText('Point with an empty hand · trigger to press · Y closes', W / 2, H - 38);
    this.menuCv.tex.needsUpdate = true; this.dirty = false;
  }
  btn(ctx, x, y, w, h, label, on, fn, danger) {
    const hov = this.hover && this.hover.fn === fn && this.hover.x === x && this.hover.y === y;
    const b = { x, y, w, h, fn, label };
    this.buttons.push(b);
    ctx.fillStyle = on ? '#3fae3a' : hov ? '#2b6a28' : danger ? '#6a2a24' : '#18381a';
    rrect(ctx, x, y, w, h, 14); ctx.fill();
    ctx.lineWidth = hov ? 4 : 2; ctx.strokeStyle = hov ? '#d6ffd0' : on ? '#b6ffb0' : EDGE; ctx.stroke();
    ctx.fillStyle = on ? '#07140a' : '#e8ffe4'; ctx.font = 'bold 24px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(label, x + w / 2, y + h / 2 + 1);
  }

  // ------------------------------------------------------------ ray interaction (called by VRHandController)
  rayHit(origin, dir) {
    if (!this.menu.visible) return null;
    this.menu.updateWorldMatrix(true, false);
    const n = this._n.set(0, 0, 1).transformDirection(this.menu.matrixWorld);
    const c = this._p.setFromMatrixPosition(this.menu.matrixWorld);
    const den = n.dot(dir);
    if (Math.abs(den) < 1e-4) return null;
    const t = this._v.subVectors(c, origin).dot(n) / den;
    if (t < 0.02 || t > 4) return null;
    const pt = this._l.copy(origin).addScaledVector(dir, t);
    const local = this.menu.worldToLocal(pt.clone());
    if (Math.abs(local.x) > this.menuW / 2 || Math.abs(local.y) > this.menuH / 2) return null;
    const px = (local.x / this.menuW + 0.5) * this.CW, py = (0.5 - local.y / this.menuH) * this.CH;
    let hit = null;
    for (const b of this.buttons) if (px >= b.x && px <= b.x + b.w && py >= b.y && py <= b.y + b.h) { hit = b; break; }
    if (hit !== this.hover) { this.hover = hit; this.dirty = true; if (hit) this.vr.pulseBoth(0.08, 15); }
    return { t, btn: hit };
  }
  click(hit) {
    if (!hit || !hit.btn) return;
    const g = this.game;
    g.audio.play('ui', { gain: 0.6, rate: 1.1 });
    this.vr.pulseBoth(0.3, 30);
    hit.btn.fn();
    this.dirty = true;
  }
  drag() { /* menu uses +/- buttons (no sliders) – nothing to drag */ }

  prompt(point, text) {
    if (!text) return;
    this.promptText = text; this.promptPos = (this.promptPos || new THREE.Vector3()).copy(point); this.promptFrame = this.frame;
  }
  toast(msg, ms = 1200) {
    this.toastMsg = msg; this.toastT = ms / 1000; this.toastDirty = true;
    this.wristToast = msg; this.wristToastT = ms / 1000;
  }

  // ------------------------------------------------------------ per frame
  update(dt) {
    const g = this.game, vr = this.vr, p = g.player;
    this.frame++;
    this.wrist.visible = true;
    // wrist lives on the non-weapon hand's controller
    const mh = vr.moveHand;
    if (mh && this.wrist.parent !== mh.ray) mh.ray.add(this.wrist);
    // hold the wrist panel until the player's looking at it (palm toward face) – always readable but tiny, so keep visible
    this.wristT -= dt;
    if (this.wristT <= 0 || this.wristToastT > 0) { this.drawWrist(); this.wristT = 0.12; }
    if (this.wristToastT > 0) this.wristToastT -= dt;
    // menu
    if (this.menu.visible) { if (this.dirty) this.drawMenu(); if (!vr.menuOpen) this.menu.visible = false; }
    // prompt
    const showP = this.promptFrame >= this.frame - 1 && this.promptText && !this.menu.visible;
    this.promptSpr.visible = !!showP;
    if (showP) {
      if (this.promptShown !== this.promptText) this.drawLabel(this.promptCv, this.promptText); this.promptShown = this.promptText;
      const d = vr.headPos.distanceTo(this.promptPos);
      const k = clamp(d * 0.22, 0.28, 0.9);
      this.promptSpr.position.copy(this.promptPos).y += 0.32;
      this.promptSpr.scale.set(k * 1.0, k * 0.1875, 1);
    }
    // toast follows the gaze lazily, low in the view
    if (this.toastT > 0) {
      this.toastT -= dt;
      if (this.toastDirty) { this.drawLabel(this.toastCv, this.toastMsg, true); this.toastDirty = false; }
      const hp = vr.headPos, f = vr.headForward;
      const tx = hp.x + f.x * 1.4, tz = hp.z + f.z * 1.4, ty = hp.y - 0.42;
      if (!this.toastSpr.visible) this.toastPos.set(tx, ty, tz);
      this.toastPos.x += (tx - this.toastPos.x) * Math.min(1, dt * 5); this.toastPos.y += (ty - this.toastPos.y) * Math.min(1, dt * 5); this.toastPos.z += (tz - this.toastPos.z) * Math.min(1, dt * 5);
      this.toastSpr.position.copy(this.toastPos);
      this.toastSpr.scale.set(0.8, 0.12, 1);
      this.toastSpr.visible = true;
    } else this.toastSpr.visible = false;
    // glide hint on the wrist
    this.wristHint = g.glider.canDeploy && !p.gliding ? 'A · GLIDER' : p.gliding ? 'HANDS: STEER · A: CLOSE' : '';
  }

  drawLabel(cv, text, big) {
    const { ctx, c } = cv;
    ctx.clearRect(0, 0, c.width, c.height);
    ctx.fillStyle = 'rgba(8,18,10,0.82)'; rrect(ctx, 4, 4, c.width - 8, c.height - 8, 22); ctx.fill();
    ctx.lineWidth = 3; ctx.strokeStyle = EDGE; ctx.stroke();
    ctx.fillStyle = big ? '#eaffe6' : GREEN; ctx.font = 'bold 44px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(text, c.width / 2, c.height / 2 + 2, c.width - 40);
    cv.tex.needsUpdate = true;
  }

  drawWrist() {
    const g = this.game, { ctx } = this.wristCv, W = 320, H = 176;
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = 'rgba(6,16,8,0.82)'; rrect(ctx, 2, 2, W - 4, H - 4, 18); ctx.fill();
    ctx.lineWidth = 3; ctx.strokeStyle = EDGE; ctx.stroke();
    const h = g.health, BW = 118;
    const bar = (y, frac, col, label, val) => {
      ctx.fillStyle = '#9fd29a'; ctx.font = 'bold 17px system-ui, sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(label, 12, y + 8);
      ctx.fillStyle = 'rgba(255,255,255,0.12)'; rrect(ctx, 44, y, BW, 16, 8); ctx.fill();
      ctx.fillStyle = col; rrect(ctx, 44, y, Math.max(8, BW * clamp(frac, 0, 1)), 16, 8); ctx.fill();
      ctx.fillStyle = '#fff'; ctx.textAlign = 'left'; ctx.fillText(val, 44 + BW + 6, y + 8);
    };
    bar(12, h.hp / h.max, h.hp < 30 ? '#ff5a4a' : '#47e05a', 'HP', Math.ceil(h.hp));
    bar(34, h.shield / 100, '#3ab8ff', 'SH', Math.ceil(h.shield));
    // money (under health)
    const cr = g.crime;
    ctx.textAlign = 'left'; ctx.fillStyle = '#ffe27a'; ctx.font = 'bold 22px system-ui, sans-serif';
    ctx.fillText('$' + (cr ? cr.money : 0).toLocaleString('en-US'), 12, 70);
    if (cr && cr.wanted) { ctx.fillStyle = Math.floor(g.time * 3) % 2 ? '#ff4a3a' : '#ffffff'; ctx.font = 'bold 16px system-ui, sans-serif'; ctx.textAlign = 'right'; ctx.fillText('WANTED', 196, 70); }
    // weapons (left / right hand)
    for (let i = 0; i < 2; i++) {
      const hd = g.weapons.holders[i];
      const x = 12 + i * 98, y = 88;
      ctx.fillStyle = 'rgba(255,255,255,0.07)'; rrect(ctx, x - 4, y - 4, 92, 56, 10); ctx.fill();
      ctx.textAlign = 'left'; ctx.fillStyle = '#9fd29a'; ctx.font = 'bold 12px system-ui, sans-serif'; ctx.fillText(i === 0 ? 'LEFT' : 'RIGHT', x, y + 6);
      if (hd.def && hd.state) {
        ctx.fillStyle = '#ffe27a'; ctx.font = 'bold 30px system-ui, sans-serif'; ctx.fillText(String(hd.state.mag), x, y + 34);
        ctx.fillStyle = '#c9e6c5'; ctx.font = 'bold 15px system-ui, sans-serif'; ctx.fillText('/' + hd.state.reserve, x + (hd.state.mag > 9 ? 40 : 24), y + 38);
        if (hd.reload) { ctx.fillStyle = '#ffe27a'; ctx.font = 'bold 10px system-ui, sans-serif'; ctx.fillText('RELOAD', x + 44, y + 6); }
      } else { ctx.fillStyle = 'rgba(200,230,195,0.5)'; ctx.font = '15px system-ui, sans-serif'; ctx.fillText('EMPTY', x, y + 32); }
    }
    // minimap (square, right side)
    if (!this.mmCv) this.mmCv = document.createElement('canvas'), this.mmCv.width = this.mmCv.height = 112;
    drawMinimap(g, this.mmCv.getContext('2d'), 112, 90, false);
    ctx.drawImage(this.mmCv, 204, 10);
    ctx.textAlign = 'center'; ctx.font = 'bold 13px system-ui, sans-serif'; ctx.fillStyle = '#9fd29a';
    ctx.fillText(g.vehicles && g.vehicles.driving ? Math.round(g.vehicles.speedKmh) + ' km/h' : Math.round(g.player.pos.y) + ' m', 260, 132);
    ctx.textAlign = 'center'; ctx.font = 'bold 17px system-ui, sans-serif';
    const msg = this.wristToastT > 0 ? this.wristToast : this.wristHint;
    ctx.fillStyle = this.wristToastT > 0 ? '#ffe27a' : '#7dff7a'; ctx.fillText(msg || 'Y: MENU', W / 2, H - 16, W - 20);
    this.wristCv.tex.needsUpdate = true;
  }
}
