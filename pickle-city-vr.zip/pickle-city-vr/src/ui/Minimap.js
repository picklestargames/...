// Shared minimap renderer (desktop HUD circle + VR wrist square). Heading-up, drawn with a canvas 2D context.
import { DMAP, DISTRICT_COLORS, GRID, cx } from '../world/Constants.js';

export function drawMinimap(game, c, S, R, round = true) {
  const g = game, p = g.player, k = S / 2 / R;
  c.clearRect(0, 0, S, S);
  c.save();
  c.beginPath();
  if (round) c.arc(S / 2, S / 2, S / 2 - 2, 0, 6.2832); else c.rect(2, 2, S - 4, S - 4);
  c.clip();
  c.fillStyle = '#1a1f24'; c.fillRect(0, 0, S, S);
  c.translate(S / 2, S / 2); c.rotate(p.yaw);
  c.scale(k, k); c.translate(-p.pos.x, -p.pos.z);
  for (let j = 0; j < GRID; j++) for (let i = 0; i < GRID; i++) {
    const x = cx(i), z = cx(j);
    if (Math.abs(x - p.pos.x) > R + 45 || Math.abs(z - p.pos.z) > R + 45) continue;
    c.fillStyle = DISTRICT_COLORS[DMAP[j][i]] || '#444'; c.fillRect(x - 28, z - 28, 56, 56);
  }
  c.fillStyle = '#ffe14a';
  for (const r of g.jumpPads.pads) { if (Math.abs(r.d.x - p.pos.x) < R && Math.abs(r.d.z - p.pos.z) < R) c.fillRect(r.d.x - 2.2, r.d.z - 2.2, 4.4, 4.4); }
  for (const r of g.pickups.recs) { if (!g.pickups.active(r)) continue; if (Math.abs(r.d.x - p.pos.x) > R || Math.abs(r.d.z - p.pos.z) > R) continue; c.fillStyle = r.d.type === 'weapon' ? '#ff3ad0' : '#3affd0'; c.fillRect(r.d.x - 1.6, r.d.z - 1.6, 3.2, 3.2); }
  c.fillStyle = 'rgba(255,255,255,0.85)';
  for (const n of g.npcs.positions) { if (n.cop || Math.abs(n.x - p.pos.x) > R || Math.abs(n.z - p.pos.z) > R) continue; c.fillRect(n.x - 0.9, n.z - 0.9, 1.8, 1.8); }
  // cars + police
  if (g.vehicles) for (const v of g.vehicles.cars) {
    if (!v.active || v.player || Math.abs(v.x - p.pos.x) > R || Math.abs(v.z - p.pos.z) > R) continue;
    c.fillStyle = v.cop ? (Math.floor(g.time * 4) % 2 ? '#ff4040' : '#4070ff') : 'rgba(150,170,190,0.8)';
    const s = v.cop ? 3.4 : 2.4; c.fillRect(v.x - s / 2, v.z - s / 2, s, s);
  }
  if (g.crime) g.crime.drawMarkers(c, R, p);
  c.restore();
  c.save(); c.translate(S / 2, S / 2); c.fillStyle = '#7dff7a'; c.strokeStyle = '#000'; c.lineWidth = 1.5;
  const a = S / 180;
  c.beginPath(); c.moveTo(0, -8 * a); c.lineTo(6 * a, 7 * a); c.lineTo(0, 3 * a); c.lineTo(-6 * a, 7 * a); c.closePath(); c.fill(); c.stroke(); c.restore();
  c.strokeStyle = 'rgba(125,255,122,0.7)'; c.lineWidth = 2; c.beginPath();
  if (round) c.arc(S / 2, S / 2, S / 2 - 2, 0, 6.2832); else c.rect(2, 2, S - 4, S - 4);
  c.stroke();
}
