// Vehicles: realistic detailed traffic (lanes, traffic lights, following distance, turns, brake lights, seated drivers),
// stealing (pull the driver out), real driving physics for the player (desktop + VR), crashes, shooting + explosions, police cars.
// Heading convention for a car: forward = (sin yaw, cos yaw). Traffic keeps to the LEFT lane. The driver sits on the right.
import * as THREE from 'three';
import { GRID, P, WORLD_HALF } from '../world/Constants.js';
import { moveBody } from '../world/CollisionWorld.js';
import { rng, clamp, damp, dampAngle } from '../core/Utils.js';

const LINES = Array.from({ length: GRID + 1 }, (_, k) => (k - GRID / 2) * P);     // street centre lines (-280 … 280)
const LIM = WORLD_HALF + 30;
const N_TRAFFIC = 56, N_COP = 2, N_ALL = N_TRAFFIC + N_COP;
const STOP_LINE = 13.9;       // car centre distance before the junction centre (front bumper stops at the painted line)
const PAINT = [0xb03a2e, 0x2e6fb0, 0xd8d8d8, 0x1d1f22, 0xc8902a, 0x2e8b57, 0x6c3a8e, 0xe8e0c0, 0x8a9096, 0x7a1f1f, 0x1f3a5f, 0xf0f0f0];
const SKIN = [0xf1c8a4, 0xe0ac86, 0xc58c5e, 0x9b6a45, 0x6e4529];
const SHIRT = [0xc0392b, 0x2e86c1, 0x27ae60, 0xf1c40f, 0x8e44ad, 0xecf0f1, 0x2c3e50, 0x16a085];
const TYPES = [{ sx: 1, sy: 1, sz: 1 }, { sx: 0.98, sy: 1.02, sz: 0.88 }, { sx: 1.06, sy: 1.14, sz: 1.0 }];
const SEAT = { x: -0.42, z: 0.12 };            // driver seat in car-local space (x is the car's LEFT, so negative = right side)
const CHAR = new THREE.Color(0x1b1a19);

function colored(geo, hex) {
  const g = geo.index ? geo.toNonIndexed() : geo;
  const n = g.attributes.position.count, c = new Float32Array(n * 3), col = new THREE.Color(hex);
  for (let i = 0; i < n; i++) { c[i * 3] = col.r; c[i * 3 + 1] = col.g; c[i * 3 + 2] = col.b; }
  g.setAttribute('color', new THREE.BufferAttribute(c, 3));
  return g;
}
function mergeC(geos) {
  const pos = [], nor = [], col = [];
  for (const g0 of geos) {
    const g = g0.index ? g0.toNonIndexed() : g0;
    const p = g.attributes.position.array, n = g.attributes.normal.array, c = g.attributes.color ? g.attributes.color.array : null;
    for (let i = 0; i < p.length; i++) { pos.push(p[i]); nor.push(n[i]); col.push(c ? c[i] : 1); }
  }
  const m = new THREE.BufferGeometry();
  m.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  m.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
  m.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
  return m;
}
/** a quad on a (z,y) slope, 'w' wide in x, pushed `off` along the outward normal (hint = outward direction) */
function slopeQuad(z0, y0, z1, y1, w, hint, off = 0.012) {
  const a = new THREE.Vector3(-w / 2, y0, z0), b = new THREE.Vector3(w / 2, y0, z0), c = new THREE.Vector3(w / 2, y1, z1), d = new THREE.Vector3(-w / 2, y1, z1);
  const n = new THREE.Vector3().crossVectors(b.clone().sub(a), d.clone().sub(a)).normalize();
  const flip = n.dot(hint) < 0; if (flip) n.negate();
  for (const v of [a, b, c, d]) v.addScaledVector(n, off);
  const pts = flip ? [a, d, c, b] : [a, b, c, d];
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pts.flatMap((v) => [v.x, v.y, v.z]), 3));
  g.setAttribute('normal', new THREE.Float32BufferAttribute(pts.flatMap(() => [n.x, n.y, n.z]), 3));
  g.setIndex([0, 1, 2, 0, 2, 3]);
  return g;
}
/** a quad lying in a plane x = const (side window): corners given as [z,y] */
function sideQuad(x, pts, nx) {
  const g = new THREE.BufferGeometry();
  const v = pts.flatMap(([z, y]) => [x, y, z]);
  g.setAttribute('position', new THREE.Float32BufferAttribute(v, 3));
  g.setAttribute('normal', new THREE.Float32BufferAttribute(pts.flatMap(() => [nx, 0, 0]), 3));
  g.setIndex(nx > 0 ? [0, 1, 2, 0, 2, 3] : [0, 2, 1, 0, 3, 2]);
  return g;
}

export class VehicleSystem {
  constructor(game) {
    this.game = game;
    this.R = rng(404);
    this.cars = [];
    this.driving = null;
    this.input = { throttle: 0, brake: 0, steer: 0, hand: false, horn: false };
    this.t = 0;
    this.speedKmh = 0;
    this.wheelRot = 0; this.hold = {};
    this._m = new THREE.Matrix4(); this._b = new THREE.Matrix4(); this._l = new THREE.Matrix4(); this._s = new THREE.Matrix4();
    this._q = new THREE.Quaternion(); this._q2 = new THREE.Quaternion(); this._e = new THREE.Euler(); this._p = new THREE.Vector3(); this._one = new THREE.Vector3(1, 1, 1); this._v = new THREE.Vector3();
    this._zero = new THREE.Matrix4().makeScale(0, 0, 0);
    this._c = new THREE.Color();
    this.buildMeshes();
    this.buildCockpit();
    this.buildSignals();
    for (let n = 0; n < N_ALL; n++) this.cars.push(this.makeCar(n));
    this.populate();
    game.world.cars = { list: this.cars, N: this.cars.length };
    this.engine = null;
  }

  // ------------------------------------------------------------------ models
  buildMeshes() {
    const scene = this.game.world.scene;
    // body: side profile (z,y) extruded across the width, bevelled
    const prof = [[-2.2, 0.36], [-2.23, 0.62], [-2.16, 0.92], [-1.55, 0.98], [-1.05, 1.42], [0.55, 1.44], [1.15, 1.02], [2.05, 0.92], [2.23, 0.74], [2.2, 0.36]];
    const sh = new THREE.Shape(); prof.forEach(([z, y], i) => (i ? sh.lineTo(z, y) : sh.moveTo(z, y))); sh.closePath();
    const body = new THREE.ExtrudeGeometry(sh, { depth: 1.7, bevelEnabled: true, bevelThickness: 0.07, bevelSize: 0.07, bevelSegments: 2, curveSegments: 1 });
    body.rotateY(-Math.PI / 2); body.translate(0.0, 0, 0); body.computeBoundingBox();
    const bb = body.boundingBox; body.translate(-(bb.min.x + bb.max.x) / 2, 0, 0);
    body.computeVertexNormals();
    // glass
    const gl = [
      slopeQuad(1.12, 1.04, 0.58, 1.41, 1.6, new THREE.Vector3(0, 0.6, 0.8)),            // windscreen
      slopeQuad(-1.5, 1.03, -1.07, 1.40, 1.56, new THREE.Vector3(0, 0.7, -0.7)),        // rear window
    ];
    for (const sgn of [1, -1]) {
      gl.push(sideQuad(sgn * 0.935, [[-0.12, 1.06], [0.93, 1.06], [0.6, 1.35], [-0.12, 1.37]], sgn));
      gl.push(sideQuad(sgn * 0.935, [[-1.27, 1.06], [-0.3, 1.06], [-0.3, 1.37], [-1.0, 1.34]], sgn));
    }
    const glass = mergeC(gl.map((g) => colored(g, 0xffffff)));
    // trim: bumpers, grille, mirrors, sills (dark)
    const bx = (w, h, d, x, y, z, hex = 0x15171a) => colored(new THREE.BoxGeometry(w, h, d).translate(x, y, z), hex);
    const trim = mergeC([bx(1.86, 0.2, 0.16, 0, 0.5, 2.24), bx(1.86, 0.2, 0.16, 0, 0.5, -2.24), bx(1.0, 0.16, 0.05, 0, 0.72, 2.27, 0x0c0d0e), bx(0.18, 0.1, 0.22, 0.99, 1.08, 0.72), bx(0.18, 0.1, 0.22, -0.99, 1.08, 0.72), bx(0.06, 0.2, 2.9, 0.935, 0.55, 0), bx(0.06, 0.2, 2.9, -0.935, 0.55, 0)]);
    const heads = mergeC([bx(0.3, 0.13, 0.05, 0.64, 0.8, 2.25, 0xfff6d8), bx(0.3, 0.13, 0.05, -0.64, 0.8, 2.25, 0xfff6d8)]);
    const tails = mergeC([bx(0.34, 0.13, 0.05, 0.66, 0.84, -2.25, 0xffffff), bx(0.34, 0.13, 0.05, -0.66, 0.84, -2.25, 0xffffff)]);
    const wheel = mergeC([colored(new THREE.CylinderGeometry(0.34, 0.34, 0.24, 14).rotateZ(Math.PI / 2), 0x101010), colored(new THREE.CylinderGeometry(0.2, 0.2, 0.26, 10).rotateZ(Math.PI / 2), 0x9aa0a6)]);
    const std = (o) => new THREE.MeshStandardMaterial(o);
    const mk = (geo, mat, n, shadow = true) => { const m = new THREE.InstancedMesh(geo, mat, n); m.frustumCulled = false; m.castShadow = shadow; m.count = n; for (let i = 0; i < n; i++) m.setMatrixAt(i, this._zero); scene.add(m); return m; };
    this.M = {
      body: mk(body, std({ color: 0xffffff, metalness: 0.55, roughness: 0.27 }), N_ALL),
      glass: mk(glass, std({ color: 0x0e1419, metalness: 0.9, roughness: 0.06, transparent: true, opacity: 0.66, side: THREE.DoubleSide }), N_ALL, false),
      trim: mk(trim, std({ vertexColors: true, roughness: 0.6, metalness: 0.1 }), N_ALL),
      heads: mk(heads, new THREE.MeshBasicMaterial({ vertexColors: true }), N_ALL, false),
      tails: mk(tails, new THREE.MeshBasicMaterial({ vertexColors: true }), N_ALL, false),
      wheels: mk(wheel, std({ vertexColors: true, roughness: 0.8 }), N_ALL * 4),
      torso: mk(new THREE.BoxGeometry(0.4, 0.5, 0.26).translate(0, 0.25, 0), std({ color: 0xffffff, roughness: 0.8 }), N_ALL, false),
      head: mk(new THREE.IcosahedronGeometry(0.125, 1).translate(0, 0.62, 0), std({ color: 0xffffff, roughness: 0.7 }), N_ALL, false),
      bar: mk(new THREE.BoxGeometry(1.0, 0.14, 0.3), new THREE.MeshBasicMaterial({ color: 0xffffff }), N_COP, false),
    };
    this.M.glass.renderOrder = 3;
    for (const k of ['body', 'tails', 'torso', 'head', 'bar']) { this.M[k].instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(this.M[k].count * 3).fill(1), 3); }
  }

  buildSignals() {
    const scene = this.game.world.scene;
    const n = (GRID + 1) * (GRID + 1) * 4;
    const pole = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.08, 0.1, 5.2, 6).translate(0, 2.6, 0), new THREE.MeshStandardMaterial({ color: 0x3a3d42, roughness: 0.6, metalness: 0.5 }), n);
    const lamp = new THREE.InstancedMesh(new THREE.BoxGeometry(0.46, 0.3, 0.46).translate(0, 5.3, 0), new THREE.MeshBasicMaterial({ color: 0xffffff }), n);
    const head = new THREE.InstancedMesh(new THREE.BoxGeometry(0.4, 0.9, 0.4).translate(0, 5.2, 0), new THREE.MeshStandardMaterial({ color: 0x1a1c1f, roughness: 0.6 }), n);
    pole.frustumCulled = lamp.frustumCulled = head.frustumCulled = false;
    this.lampAxis = [];
    let i = 0;
    for (let a = 0; a <= GRID; a++) for (let b = 0; b <= GRID; b++) for (let c = 0; c < 4; c++) {
      const x = LINES[a] + (c & 1 ? 10.8 : -10.8), z = LINES[b] + (c & 2 ? 10.8 : -10.8);
      this._m.makeTranslation(x, 0, z); pole.setMatrixAt(i, this._m); lamp.setMatrixAt(i, this._m); head.setMatrixAt(i, this._m);
      this.lampAxis.push(c === 0 || c === 3 ? 'x' : 'z');
      lamp.setColorAt(i, this._c.setHex(0xff2a20)); i++;
    }
    pole.castShadow = false;
    this.lamp = lamp; this.lightState = { x: '', z: '' };
    scene.add(pole, lamp, head);
  }
  /** traffic light cycle (38 s): X green, X yellow, all red, Z green, Z yellow, all red */
  signal(axis) {
    const ph = this.t % 38, a = axis === 'x' ? ph : (ph + 19) % 38;
    return a < 14 ? 'green' : a < 17 ? 'yellow' : 'red';
  }
  updateSignals() {
    const sx = this.signal('x'), sz = this.signal('z');
    if (sx === this.lightState.x && sz === this.lightState.z) return;
    this.lightState.x = sx; this.lightState.z = sz;
    const hex = { green: 0x30ff60, yellow: 0xffc020, red: 0xff2a20 };
    for (let i = 0; i < this.lampAxis.length; i++) this.lamp.setColorAt(i, this._c.setHex(hex[this.lampAxis[i] === 'x' ? sx : sz]));
    this.lamp.instanceColor.needsUpdate = true;
  }

  buildCockpit() {
    const g = new THREE.Group(); g.visible = false;
    const dark = new THREE.MeshStandardMaterial({ color: 0x1b1d20, roughness: 0.7 });
    const grey = new THREE.MeshStandardMaterial({ color: 0x4a4e55, roughness: 0.8 });
    const add = (geo, mat, x, y, z, rx = 0) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.rotation.x = rx; m.frustumCulled = false; g.add(m); return m; };
    add(new THREE.BoxGeometry(1.6, 0.22, 0.5), dark, 0, 0.98, 0.98);                       // dashboard
    add(new THREE.BoxGeometry(1.5, 0.5, 0.1), dark, 0, 0.74, 1.12);
    add(new THREE.PlaneGeometry(1.6, 2.3).rotateX(Math.PI / 2), grey, 0, 1.4, -0.1);       // headliner (faces down)
    for (const sx of [-0.88, 0.88]) { add(new THREE.BoxGeometry(0.07, 0.07, 0.7), dark, sx, 1.36, 0.8, 0.0); add(new THREE.BoxGeometry(0.07, 0.5, 0.07), dark, sx, 1.15, -0.28); }
    add(new THREE.BoxGeometry(0.5, 0.7, 0.12), grey, SEAT.x, 0.85, -0.38, -0.2);                // seat back
    add(new THREE.BoxGeometry(0.5, 0.12, 0.5), grey, SEAT.x, 0.55, -0.05);
    add(new THREE.BoxGeometry(0.5, 0.7, 0.12), grey, -SEAT.x, 0.85, -0.38, -0.2);
    this.wheelRoot = new THREE.Group(); this.wheelRoot.position.set(SEAT.x, 1.0, 0.62); this.wheelRoot.rotation.x = -1.0;
    this.wheelRoot.add(new THREE.Mesh(new THREE.TorusGeometry(0.19, 0.022, 6, 20), dark));
    const spoke = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.03, 0.03), dark); this.wheelRoot.add(spoke);
    g.add(this.wheelRoot);
    // speed display on the dash
    const cv = document.createElement('canvas'); cv.width = 192; cv.height = 96;
    this.dashTex = new THREE.CanvasTexture(cv); this.dashCtx = cv.getContext('2d'); this.dashTex.colorSpace = THREE.SRGBColorSpace;
    const sp = new THREE.Mesh(new THREE.PlaneGeometry(0.3, 0.15), new THREE.MeshBasicMaterial({ map: this.dashTex, toneMapped: false }));
    sp.position.set(SEAT.x, 1.1, 0.78); sp.rotation.x = -0.75; sp.rotation.y = Math.PI; g.add(sp);
    this.cockpit = g; this.game.world.scene.add(g);
  }

  makeCar(n) {
    const cop = n >= N_TRAFFIC;
    return {
      i: n, active: false, cop, axis: 'x', line: 0, dir: 1, off: 3.2, t: 0, cruise: 12, v: 0, speed: 12, len: 4.4, w: 1.9,
      x: 0, z: 0, y: 0, rx: 0, rz: 0, ry: 0, yaw: 0, ryaw: 0, pitch: 0, roll: 0, vx: 0, vz: 0, spin: 0, steer: 0, brake: 0, snap: true,
      turn: 0, hits: 0, hp: 100, dead: false, deadT: 0, ai: true, parked: false, player: false, driver: null, stuckT: 0, ghost: 0, fear: 0, honkT: 0, lastHitT: -9,
      paint: 0xffffff, type: TYPES[0], pos: new THREE.Vector3(), vel: new THREE.Vector3(), out: {}, grounded: true, chasing: false, minD: 1e9, smokeT: 0,
    };
  }

  populate() {
    const R = this.R;
    for (let n = 0; n < N_TRAFFIC; n++) {
      const c = this.cars[n]; this.place(c, true);
      c.cruise = R.range(8, 14.5); c.speed = c.cruise; c.v = c.cruise * 0.8;
    }
    for (let n = N_TRAFFIC; n < N_ALL; n++) { const c = this.cars[n]; c.paint = 0xf2f4f6; c.active = false; }
  }
  /** (re)place a traffic car on a random lane, avoiding overlaps */
  place(c, initial = false) {
    const R = this.R;
    for (let tries = 0; tries < 24; tries++) {
      c.axis = R() < 0.5 ? 'x' : 'z'; c.line = LINES[R.int(1, GRID - 1)]; c.dir = R() < 0.5 ? 1 : -1; c.off = c.dir * 3.2;
      c.t = initial ? R.range(-WORLD_HALF, WORLD_HALF) : -c.dir * (WORLD_HALF + 20);
      let ok = true;
      for (const o of this.cars) { if (o === c || !o.active || o.axis !== c.axis || o.line !== c.line || o.dir !== c.dir) continue; if (Math.abs(o.t - c.t) < 14) { ok = false; break; } }
      if (ok) break;
    }
    c.paint = R.pick(PAINT); c.type = R.pick(TYPES); c.hits = 0; c.hp = 100; c.dead = false; c.ai = true; c.parked = false; c.player = false; c.stuckT = 0; c.ghost = 0; c.fear = 0; c.snap = true; c.v = 0; c.chasing = false;
    c.driver = { skin: R.pick(SKIN), shirt: R.pick(SHIRT) };
    c.turn = R() < 0.3 ? (R() < 0.5 ? -1 : 1) : 0;
    c.active = true; c.cop = false;
    this.syncLogical(c); c.rx = c.x; c.rz = c.z; c.ryaw = c.yaw; c.ry = 0; c.pos.set(c.x, 0, c.z);
    this.M.body.setColorAt(c.i, this._c.setHex(c.paint));
    this.M.torso.setColorAt(c.i, this._c.setHex(c.driver.shirt)); this.M.head.setColorAt(c.i, this._c.setHex(c.driver.skin));
    this.flagColors();
  }
  flagColors() { for (const k of ['body', 'torso', 'head', 'tails', 'bar']) if (this.M[k].instanceColor) this.M[k].instanceColor.needsUpdate = true; }
  fwd(c) { return c.axis === 'x' ? [c.dir, 0] : [0, c.dir]; }
  syncLogical(c) {
    if (c.axis === 'x') { c.x = c.t; c.z = c.line + c.off; } else { c.z = c.t; c.x = c.line + c.off; }
    c.yaw = Math.atan2(...this.fwd(c));
    const [fx, fz] = this.fwd(c); c.vx = fx * c.v; c.vz = fz * c.v;
  }

  // ------------------------------------------------------------------ per frame
  update(dt) {
    const g = this.game;
    this.t += dt;
    this.updateSignals();
    this.copTimer = (this.copTimer || 0) + dt;
    for (const c of this.cars) {
      if (!c.active) continue;
      if (c.player) this.drive(c, dt);
      else if (c.dead) this.wreck(c, dt);
      else if (c.cop && c.chasing) this.copAI(c, dt);
      else if (c.ai) this.trafficAI(c, dt);
      else this.parkedUpdate(c, dt);
      this.render(c, dt);
    }
    for (const k of Object.keys(this.M)) { this.M[k].instanceMatrix.needsUpdate = true; }
    this.flagColors();
    this.updateCockpit(dt);
  }

  // limit a target speed by obstacles ahead (cars, pedestrians, the player on foot)
  obstacleLimit(c, vt, dt) {
    if (c.ghost > 0) { c.ghost -= dt; return vt; }
    const [fx, fz] = this.fwd(c), g = this.game;
    const probe = (ox, oz, ovx, ovz, len, lat) => {
      const dx = ox - c.x, dz = oz - c.z;
      const along = dx * fx + dz * fz, side = Math.abs(c.axis === 'x' ? dz : dx);
      if (along < 0.2 || along > 48 || side > lat) return;
      const gap = along - len;
      const ov = Math.max(0, ovx * fx + ovz * fz);
      vt = Math.min(vt, ov + Math.max(0, gap - 2.6) * 0.9);
    };
    for (const o of this.cars) { if (o === c || !o.active) continue; probe(o.x, o.z, o.vx, o.vz, 4.6, 2.2); }
    for (const n of g.npcs.positions) if (n.state !== 'held') probe(n.x, n.z, 0, 0, 1.6, 1.4);
    const p = g.player; if (!p.driving && p.pos.y < 12) probe(p.pos.x, p.pos.z, p.vel.x, p.vel.z, 1.8, 1.5);
    return vt;
  }

  trafficAI(c, dt) {
    const g = this.game, dir = c.dir, t = c.t;
    let vt = c.cruise * (c.fear > 0 ? 1.35 : 1);
    if (c.fear > 0) c.fear -= dt;
    // next intersection ahead
    let sNext = null;
    for (const s of LINES) { const d = (s - t) * dir; if (d > 0 && (sNext === null || d < (sNext - t) * dir)) sNext = s; }
    if (sNext !== null) {
      const dd = (sNext - t) * dir - STOP_LINE;           // distance to the stop line
      const st = this.signal(c.axis);
      if (st !== 'green' && dd > -1.5 && dd < 70) {
        const canStop = c.v * c.v / (2 * 4.6) <= dd + 1.2;
        if (st === 'red' || canStop) { if (canStop || st === 'red') vt = Math.min(vt, dd <= 0.4 ? 0 : Math.sqrt(2 * 3.0 * Math.max(0, dd))); }
      }
      if (c.turn !== 0 && (sNext - t) * dir < 24) vt = Math.min(vt, 6.5);
    }
    vt = this.obstacleLimit(c, vt, dt);
    // honk at someone blocking the road
    c.honkT -= dt;
    if (vt < 0.5 && c.v < 1 && c.honkT <= 0) { const near = Math.hypot(g.player.pos.x - c.x, g.player.pos.z - c.z); if (near < 14 && near > 2) { g.audio.play('honk', { pos: { x: c.x, y: 1, z: c.z }, gain: 0.8, minGap: 0.3 }); } c.honkT = 4 + Math.random() * 4; }
    c.stuckT = (c.v < 0.3 && vt < 0.3) ? c.stuckT + dt : 0;
    if (c.stuckT > 9) { c.ghost = 4; c.stuckT = 0; }
    this.accel(c, vt, dt);
    const tPrev = c.t;
    c.t += c.v * dir * dt;
    // turn at the junction
    if (sNext !== null && (sNext - c.t) * dir <= 0) this.crossJunction(c, sNext);
    if (c.t > LIM) { c.t = -LIM; c.snap = true; } else if (c.t < -LIM) { c.t = LIM; c.snap = true; }
    this.syncLogical(c);
  }
  accel(c, vt, dt) {
    const dv = vt - c.v;
    const dec = dv < -3 ? 9 : 6.2;
    c.v += clamp(dv, -dec * dt, 3.1 * dt);
    c.v = Math.max(0, c.v);
    c.brake = dv < -0.4 ? 1 : 0;
  }
  crossJunction(c, s) {
    const [fx, fz] = this.fwd(c);
    if (c.turn !== 0) {
      const nf = c.turn > 0 ? [-fz, fx] : [fz, -fx];        // right / left of the heading
      const newAxis = nf[0] !== 0 ? 'x' : 'z', newDir = nf[0] !== 0 ? Math.sign(nf[0]) : Math.sign(nf[1]);
      const oldLine = c.line;
      c.axis = newAxis; c.line = s; c.t = oldLine; c.dir = newDir; c.off = newDir * 3.2;
    }
    const R = this.R; c.turn = R() < 0.28 ? (R() < 0.5 ? -1 : 1) : 0;
  }

  copAI(c, dt) {
    const g = this.game, p = g.player;
    const dx = p.pos.x - c.x, dz = p.pos.z - c.z, d = Math.hypot(dx, dz);
    c.minD = Math.min(c.minD, d);
    let vt = 17.5;
    if (d < 34) vt = Math.min(vt, 7 + d * 0.3);
    vt = this.obstacleLimit(c, vt, dt) ;
    this.accel(c, Math.max(vt, 5.5 * (c.ghost > 0 ? 1 : 0)), dt);
    // arrive when close, or once we have driven past the closest approach
    if (d < 16 || (d > c.minD + 12 && d < 140 && c.t > -LIM)) { this.makeParked(c); c.arrived = true; g.crime && g.crime.onCopCarArrived(c); return; }
    // stuck behind something for a while -> push through
    c.stuckT = c.v < 0.5 ? c.stuckT + dt : 0; if (c.stuckT > 3) { c.ghost = 3; c.stuckT = 0; }
    let sNext = null;
    for (const s of LINES) { const dd = (s - c.t) * c.dir; if (dd > 0 && (sNext === null || dd < (sNext - c.t) * c.dir)) sNext = s; }
    c.t += c.v * c.dir * dt;
    if (sNext !== null && (sNext - c.t) * c.dir <= 0) {
      // choose the heading (straight / left / right) that gets closest to the player
      const [fx, fz] = this.fwd(c);
      const opts = [[fx, fz, 0], [-fz, fx, 1], [fz, -fx, -1]];
      let best = null, bs = -1e9;
      for (const [hx, hz, tn] of opts) {
        const nextPos = c.axis === 'x' ? (hx !== 0 ? c.t : c.line) : (hx !== 0 ? c.line : c.t);
        const lim = 275; const x1 = (c.axis === 'x' ? sNext : c.line) + hx * 40, z1 = (c.axis === 'x' ? c.line : sNext) + hz * 40;
        if (Math.abs(x1) > lim || Math.abs(z1) > lim) continue;
        const sc = (hx * dx + hz * dz) / (d || 1) + (tn === 0 ? 0.05 : 0);
        if (sc > bs) { bs = sc; best = tn; }
      }
      c.turn = best === null ? 0 : best; this.crossJunction(c, sNext); c.turn = 0;
    }
    if (c.t > LIM) c.t = LIM; if (c.t < -LIM) c.t = -LIM;
    this.syncLogical(c);
  }

  parkedUpdate(c, dt) {
    // coasting to a stop after the driver was pulled out / the player left
    const k = Math.exp(-2.2 * dt);
    c.vx *= k; c.vz *= k;
    c.pos.x += c.vx * dt; c.pos.z += c.vz * dt;
    c.x = c.pos.x; c.z = c.pos.z; c.v = Math.hypot(c.vx, c.vz); c.brake = c.v < 0.5 ? 1 : 0;
  }

  wreck(c, dt) {
    const g = this.game;
    c.deadT += dt; c.v = 0; c.vx = c.vz = 0; c.brake = 0;
    c.smokeT -= dt;
    const near = Math.hypot(g.player.pos.x - c.x, g.player.pos.z - c.z) < 90;
    if (near && c.smokeT <= 0 && c.deadT < 40) {
      c.smokeT = 0.12;
      g.particles.poof({ x: c.rx, y: 1.1, z: c.rz }, [0.12, 0.12, 0.12], 2, 0.8, 0.9);
      if (Math.random() < 0.5) g.particles.burst({ x: c.rx + (Math.random() - 0.5), y: 0.9, z: c.rz + (Math.random() - 0.5) }, [1, 0.5, 0.1], 3, 1.5, 0.22, 0.4);
    }
    if (c.deadT > 50 && Math.hypot(g.player.pos.x - c.x, g.player.pos.z - c.z) > 60) { c.deadT = 0; this.place(c, false); }
  }

  // ------------------------------------------------------------------ render
  render(c, dt) {
    const M = this.M, ty = c.type;
    if (c.ai && !c.player && !c.dead && !c.parked) {
      const k = c.snap ? 1 : Math.min(1, dt * 9);
      c.rx += (c.x - c.rx) * k; c.rz += (c.z - c.rz) * k; c.ryaw = c.snap ? c.yaw : dampAngle(c.ryaw, c.yaw, 7, dt);
      c.snap = false; c.ry = 0;
    } else { c.rx = c.player || c.parked || c.dead ? c.pos.x || c.x : c.x; c.rz = c.player || c.parked || c.dead ? c.pos.z || c.z : c.z; c.ryaw = c.yaw; c.ry = c.pos.y || 0; if (!c.player && !c.parked && !c.dead) { c.rx = c.x; c.rz = c.z; } }
    // body pitch (dives under braking) and roll in corners
    const tp = c.brake && c.v > 1.5 ? 0.028 : c.v < 6 && c.v > 0.5 && !c.brake ? -0.012 : 0;
    c.pitch = damp(c.pitch, c.dead ? 0.05 : tp, 7, dt);
    this._e.set(c.pitch, c.ryaw, c.roll || 0, 'YXZ'); this._q.setFromEuler(this._e);
    this._p.set(c.rx, c.ry, c.rz); this._b.compose(this._p, this._q, this._one);
    this._s.makeScale(ty.sx, ty.sy, ty.sz); this._m.multiplyMatrices(this._b, this._s);
    const i = c.i;
    M.body.setMatrixAt(i, this._m); M.glass.setMatrixAt(i, this._m); M.trim.setMatrixAt(i, this._m); M.heads.setMatrixAt(i, this._m); M.tails.setMatrixAt(i, this._m);
    const braking = c.brake || (c.player && this.input.brake > 0.1 && c.vel.length() > 0.5);
    const rev = c.player && this.input.brake > 0.1 && this.vf(c) < -0.5;
    M.tails.setColorAt(i, this._c.setHex(c.dead ? 0x000000 : rev ? 0xffffff : braking ? 0xff2a1a : 0x5a0a0a));
    // wheels
    const travelled = (c.player ? this.vf(c) : c.v * (c.parked ? 1 : 1)) * dt;
    c.spin += travelled / 0.34;
    const st = c.player ? c.steer : 0;
    for (let k = 0; k < 4; k++) {
      const front = k < 2, lx = (k & 1 ? -1 : 1) * 0.84 * ty.sx, lz = (front ? 1.38 : -1.38) * ty.sz;
      this._e.set(c.spin, front ? -st : 0, 0, 'YXZ'); this._q2.setFromEuler(this._e);
      this._p.set(lx, 0.34, lz); this._l.compose(this._p, this._q2, this._one);
      M.wheels.setMatrixAt(i * 4 + k, this._m.multiplyMatrices(this._b, this._l));
    }
    // seated driver
    const dr = c.driver && !c.dead && !c.player;
    if (dr) {
      this._p.set(SEAT.x * ty.sx, 0.52, SEAT.z * ty.sz); this._q2.identity(); this._l.compose(this._p, this._q2, this._one);
      this._m.multiplyMatrices(this._b, this._l); M.torso.setMatrixAt(i, this._m); M.head.setMatrixAt(i, this._m);
    } else { M.torso.setMatrixAt(i, this._zero); M.head.setMatrixAt(i, this._zero); }
    // police light bar
    if (c.cop) {
      const bi = i - N_TRAFFIC; this._p.set(0, 1.5 * ty.sy, -0.1); this._l.compose(this._p, this._q2.identity(), this._one);
      M.bar.setMatrixAt(bi, this._m.multiplyMatrices(this._b, this._l));
      const fl = Math.floor(this.t * 6) % 2 === 0;
      M.bar.setColorAt(bi, this._c.setHex(fl ? 0xff1a1a : 0x1a4aff));
    }
    // siren
    if (c.cop && c.active && !c.dead) { c.sirenT = (c.sirenT || 0) - dt; if (c.sirenT <= 0) { this.game.audio.play('sirenHiLo', { pos: { x: c.rx, y: 2, z: c.rz }, gain: 1.3, ref: 25, rolloff: 0.8, bus: 'amb', hrtf: false }); c.sirenT = 2.6; } }
  }
  vf(c) { return c.vel.x * Math.sin(c.yaw) + c.vel.z * Math.cos(c.yaw); }

  // ------------------------------------------------------------------ player driving
  drive(c, dt) {
    const g = this.game, w = g.world.collision, p = g.player, I = this.input;
    const fx = Math.sin(c.yaw), fz = Math.cos(c.yaw);
    let vf = c.vel.x * fx + c.vel.z * fz;
    const sp = Math.abs(vf);
    // steering: angle shrinks with speed; positive input = turn right
    const maxSteer = 0.5 / (1 + sp * 0.18);
    c.steer += (I.steer * maxSteer - c.steer) * Math.min(1, dt * 7);
    const yawRate = -vf * Math.tan(c.steer) / 2.7 * (I.hand ? 1.35 : 1);
    c.yaw += yawRate * dt;
    const gfx = Math.sin(c.yaw), gfz = Math.cos(c.yaw), rx = -Math.cos(c.yaw), rz = Math.sin(c.yaw);
    vf = c.vel.x * gfx + c.vel.z * gfz;
    let vl = c.vel.x * rx + c.vel.z * rz;
    let acc = 0;
    if (I.throttle > 0 && c.hp > 0) acc += I.throttle * 11.5 * (1 - clamp(vf / 40, 0, 1));
    if (I.brake > 0) acc += vf > 0.8 ? -I.brake * 21 : -I.brake * 6.5 * (1 - clamp(-vf / 11, 0, 1));
    acc -= vf * 0.1 + Math.sign(vf) * 0.5;
    const vf0 = vf; vf += acc * dt;
    if (I.throttle <= 0 && I.brake <= 0 && Math.sign(vf0) !== Math.sign(vf)) vf = 0;
    if (I.hand) vf *= Math.exp(-1.3 * dt);
    const grip = I.hand ? 1.7 : (sp < 3 ? 14 : 7.5);
    vl *= Math.exp(-grip * dt);
    c.vel.x = gfx * vf + rx * vl; c.vel.z = gfz * vf + rz * vl;
    if (!c.grounded) c.vel.y -= 22 * dt;
    const sp0 = Math.hypot(c.vel.x, c.vel.z);
    // collide with the world (circle of radius 1.15, height 1.4)
    const hasCh = w.hasChunkAt ? w.hasChunkAt(c.pos.x, c.pos.z) : true;
    if (hasCh) moveBody(w, c.pos, c.vel, dt, 1.15, 1.4, 0.35, c.out, c.grounded);
    c.grounded = !!c.out.grounded;
    const sp1 = Math.hypot(c.vel.x, c.vel.z);
    if ((c.out.hitX || c.out.hitZ) && sp0 - sp1 > 4) this.crash(c, sp0 - sp1, true);
    if (c.pos.y < -30) { c.pos.y = 0; c.vel.set(0, 0, 0); }
    c.x = c.pos.x; c.z = c.pos.z; c.y = c.pos.y; c.v = Math.hypot(c.vel.x, c.vel.z); c.vx = c.vel.x; c.vz = c.vel.z;
    // traffic, pedestrians
    for (const o of this.cars) {
      if (o === c || !o.active) continue;
      const dx = o.x - c.x, dz = o.z - c.z; const d = Math.hypot(dx, dz);
      if (d < 2.9 && d > 0.01) {
        const rel = Math.hypot(c.vel.x - o.vx, c.vel.z - o.vz);
        const push = (2.9 - d) * 0.5; c.pos.x -= (dx / d) * push; c.pos.z -= (dz / d) * push;
        if (o.ai && !o.cop) { o.v = 0; o.ghost = 0; o.honkT = 0; o.fear = 6; } else if (!o.player) { o.pos.x += (dx / d) * push * 0.5; o.pos.z += (dz / d) * push * 0.5; o.vx += (dx / d) * 3; o.vz += (dz / d) * 3; }
        c.vel.x *= 0.7; c.vel.z *= 0.7;
        if (rel > 4) { this.crash(c, rel * 0.7, true); o.hp -= rel * 2; if (o.hp <= 0 && !o.dead) this.explode(o); }
      }
    }
    for (const n of g.npcs.positions) {
      if (n.state === 'thrown' || n.state === 'held') continue;
      const dx = n.x - c.x, dz = n.z - c.z;
      if (Math.abs(dx) > 3 || Math.abs(dz) > 3) continue;
      const along = dx * gfx + dz * gfz, side = dx * rx + dz * rz;
      if (Math.abs(along) < 2.5 && Math.abs(side) < 1.2 && c.v > 3.5 && Math.abs(n.y - c.y) < 1.5) {
        g.npcs.launch(n, c.vel.x * 1.1 + rx * side * 2, 3 + c.v * 0.25, c.vel.z * 1.1 + rz * side * 2);
        n.angry = true; n.maxImpact = c.v > 10 ? 9 : 0;
        g.audio.play('impact', { pos: { x: n.x, y: 1, z: n.z }, gain: 0.8, hrtf: false, minGap: 0.1 });
        if (c.v > 10 && g.crime) g.crime.onInnocentDown(n);
        c.vel.x *= 0.92; c.vel.z *= 0.92;
      }
    }
    // pitch/roll cosmetics and skids
    const accel = (vf - vf0) / Math.max(dt, 1e-3);
    c.brake = I.brake > 0.1 && vf > 1 ? 1 : 0;
    c.roll = damp(c.roll || 0, clamp(vl * 0.012, -0.08, 0.08), 6, dt);
    c.pitch = damp(c.pitch, clamp(-accel * 0.0022, -0.04, 0.05), 6, dt);
    if (Math.abs(vl) > 4.5 && c.grounded && c.v > 6) { g.audio.play('slide', { pos: { x: c.x, y: 0.3, z: c.z }, gain: 0.35, rate: 1.7, minGap: 0.28, hrtf: false }); g.particles.poof({ x: c.x - gfx * 1.4, y: 0.15, z: c.z - gfz * 1.4 }, [0.8, 0.8, 0.8], 1, 0.6, 0.5); }
    if (I.horn) g.audio.play('honk', { pos: { x: c.x, y: 1, z: c.z }, gain: 1.1, minGap: 0.3, hrtf: false });
    // park the player's body at the driver's seat
    const sx = SEAT.x * c.type.sx, sz = SEAT.z * c.type.sz, cs = Math.cos(c.yaw), sn = Math.sin(c.yaw);
    p.pos.set(c.x + sx * cs + sz * sn, c.y, c.z - sx * sn + sz * cs);
    p.vel.copy(c.vel); p.grounded = true; p.groundY = c.y; p.sprinting = false; p.sliding = false; p.crouching = false; p.height = p.standH;
    p.yaw = c.yaw + Math.PI;
    this.speedKmh = c.v * 3.6;
    this.updateEngine(c);
    if (c.hp <= 0 && !c.dead) this.explode(c);
  }

  crash(c, loss, fromPlayer) {
    const g = this.game;
    g.audio.play('clank', { pos: { x: c.x, y: 1, z: c.z }, gain: clamp(loss / 14, 0.3, 1.2), rate: 0.7, hrtf: false, minGap: 0.2 });
    g.audio.play('impact', { pos: { x: c.x, y: 1, z: c.z }, gain: clamp(loss / 10, 0.3, 1), hrtf: false, minGap: 0.2 });
    g.particles.hit({ x: c.x, y: 0.8, z: c.z }, { x: 0, y: 1, z: 0 }, [1, 0.85, 0.5], 8);
    c.hp -= loss * 2.6;
    if (c.player) {
      g.camera_ctrl && g.camera_ctrl.punch(clamp(loss / 12, 0.3, 1.2));
      if (loss > 8) g.health.damage(Math.round((loss - 7) * 1.7), 'crash');
      if (g.vr.active) g.vr.pulseBoth(clamp(loss / 18, 0.3, 1), 90);
    }
    if (c.hp < 35 && !c.smoking) c.smoking = true;
  }

  // ------------------------------------------------------------------ enter / exit / steal
  seatWorld(c, out) {
    const ty = c.type, cs = Math.cos(c.player || c.parked || c.dead ? c.yaw : c.ryaw), sn = Math.sin(c.player || c.parked || c.dead ? c.yaw : c.ryaw);
    const sx = SEAT.x * ty.sx, sz = SEAT.z * ty.sz;
    const bx = c.player || c.parked ? c.pos.x : c.rx, bz = c.player || c.parked ? c.pos.z : c.rz;
    return out.set(bx + sx * cs + sz * sn, (c.ry || 0) + 1.15, bz - sx * sn + sz * cs);
  }
  /** a car with a driver whose seat is within r of pos (hand) */
  driverAt(pos, r = 0.6) {
    let best = null, bd = r;
    for (const c of this.cars) {
      if (!c.active || !c.driver || c.dead || c.cop || c.player) continue;
      const d = this.seatWorld(c, this._v).distanceTo(pos);
      if (d < bd) { bd = d; best = c; }
    }
    return best;
  }
  nearestDrivable(pos, r = 4.6, allowDriver = false) {
    let best = null, bd = r;
    for (const c of this.cars) {
      if (!c.active || c.dead || c.cop || c.player) continue;
      if (c.driver && !allowDriver) continue;
      const bx = c.player || c.parked ? c.pos.x : c.rx, bz = c.player || c.parked ? c.pos.z : c.rz;
      const d = Math.hypot(bx - pos.x, bz - pos.z);
      if (d < bd && Math.abs((c.ry || 0) - pos.y) < 2.5) { bd = d; best = c; }
    }
    return best;
  }
  /** yank the driver out: the car stops, the driver becomes an angry civilian (returned) */
  pullDriver(c) {
    const g = this.game; if (!c.driver) return null;
    const d = c.driver; c.driver = null;
    this.makeParked(c);
    const seat = this.seatWorld(c, new THREE.Vector3());
    const n = g.npcs.spawnAt(seat.x, seat.z, c.ry || 0, d);
    g.audio.play('honk', { pos: { x: c.x, y: 1, z: c.z }, gain: 0.7, minGap: 0.3 });
    g.audio.play('help', { pos: { x: seat.x, y: 1.4, z: seat.z }, gain: 0.9, ref: 4, hrtf: false });
    return n;
  }
  makeParked(c) {
    // convert lane-following state into free physical state
    c.pos.set(c.rx, c.ry || 0, c.rz); c.yaw = c.ryaw; c.ai = false; c.parked = true; c.vel.set(c.vx, 0, c.vz); c.chasing = false;
  }
  tryEnter(allowPull = true) {
    const g = this.game, p = g.player;
    if (this.driving) return false;
    const c = this.nearestDrivable(g.vr.active ? g.vr.headPos : p.pos, 4.6, allowPull);
    if (!c) return false;
    if (c.driver) {
      const n = this.pullDriver(c);
      if (n) { const cs = Math.cos(c.yaw), sn = Math.sin(c.yaw); n.x += -cs * 1.6; n.z += sn * 1.6; g.npcs.launch(n, -cs * 3, 3, sn * 3); n.angry = true; n.maxImpact = 0; }
    }
    this.enter(c);
    return true;
  }
  enter(c) {
    const g = this.game, p = g.player;
    if (c.ai) this.makeParked(c);
    c.parked = false; c.player = true; c.ai = false; c.driver = null; c.steer = 0; c.grounded = true; c.out = {};
    this.driving = c; p.driving = c;
    for (let i = 0; i < 2; i++) g.weapons.holster(i);
    if (g.glider.active) g.glider.retract();
    p.vel.set(0, 0, 0);
    this.startEngine();
    g.ui && g.ui.toast('DRIVING — ' + (g.vr.active ? 'GRIP the wheel & turn it · right trigger gas · left trigger brake · A handbrake · stick click exit' : 'W/S gas & brake · A/D steer · Space handbrake · F exit'), 4000);
    if (g.vr.active) g.vr.onEnterCar(c); else { g.camera_ctrl.third = true; g.camera_ctrl.dist = 7.5; }
    this.cockpit.visible = g.vr.active;
    g.audio.play('slide', { gain: 0.3, rate: 0.8 });
  }
  exit() {
    const g = this.game, p = g.player, c = this.driving; if (!c) return;
    const cs = Math.cos(c.yaw), sn = Math.sin(c.yaw);
    const w = g.world.collision;
    const cands = [[cs, -sn], [-cs, sn], [-sn, -cs], [sn, cs]];
    let spot = null;
    for (const [dx, dz] of cands) {
      const x = c.x + dx * 2.2, z = c.z + dz * 2.2, y = w.groundBelow(x, c.y + 1, z, 0.3, 0.6);
      if (y > -1e8 && !w.blockedAt(x, y + 0.05, z, p.radius, p.standH * 0.9)) { spot = [x, y, z]; break; }
    }
    if (!spot) spot = [c.x + cs * 2.2, c.y, c.z - sn * 2.2];
    p.pos.set(spot[0], spot[1], spot[2]); p.vel.set(0, 0, 0); p.driving = null; p.grounded = true;
    c.player = false; c.parked = true; c.vel.multiplyScalar(0.98);
    c.vx = c.vel.x; c.vz = c.vel.z;
    this.driving = null; this.cockpit.visible = false; this.speedKmh = 0; this.wheelRot = 0; this.hold = {};
    this.stopEngine();
    this.input.throttle = this.input.brake = this.input.steer = 0; this.input.hand = false;
    if (g.vr.active) g.vr.onExitCar(); else { g.camera_ctrl.dist = 0; }
    g.audio.play('slide', { gain: 0.3, rate: 1.1 });
  }

  // ------------------------------------------------------------------ engine sound
  startEngine() {
    const a = this.game.audio; if (!a.ctx || this.engine) return;
    const ctx = a.ctx, o1 = ctx.createOscillator(), o2 = ctx.createOscillator(), lp = ctx.createBiquadFilter(), gn = ctx.createGain();
    o1.type = 'sawtooth'; o2.type = 'square'; lp.type = 'lowpass'; lp.frequency.value = 700; gn.gain.value = 0.0;
    o1.connect(lp); o2.connect(lp); lp.connect(gn); gn.connect(a.sfx || a.master || ctx.destination);
    o1.start(); o2.start();
    this.engine = { o1, o2, lp, gn };
  }
  updateEngine(c) {
    const e = this.engine; if (!e) return;
    const t = this.game.audio.ctx.currentTime, I = this.input, sp = Math.abs(this.vf(c));
    const gear = Math.min(5, Math.floor(sp / 9)), rpm = 800 + (sp - gear * 9) * 260 + I.throttle * 700;
    const f = rpm / 60 * 2;
    e.o1.frequency.setTargetAtTime(f, t, 0.05); e.o2.frequency.setTargetAtTime(f * 0.5, t, 0.05);
    e.lp.frequency.setTargetAtTime(500 + I.throttle * 900 + sp * 25, t, 0.08);
    e.gn.gain.setTargetAtTime(0.05 + I.throttle * 0.08, t, 0.06);
  }
  stopEngine() { const e = this.engine; if (!e) return; try { e.gn.gain.setTargetAtTime(0, this.game.audio.ctx.currentTime, 0.05); setTimeout(() => { try { e.o1.stop(); e.o2.stop(); } catch (x) { /* */ } }, 300); } catch (x) { /* */ } this.engine = null; }

  /** VR: grab the steering wheel (grip) and turn it with your hand; otherwise the stick steers. Returns steer -1..1 */
  updateWheel(dt, hands, stickX) {
    const c = this.driving, MAXR = 2.6;
    if (!c) return 0;
    let held = false;
    for (const h of hands) {
      if (!h) continue;
      const id = h.idx;
      if (!h.b.grip) { delete this.hold[id]; continue; }
      const lp = this.cockpit.worldToLocal(this._v.copy(h.palm));
      const ox = lp.x - SEAT.x * c.type.sx, oy = lp.y - 1.0, oz = lp.z - 0.62 * c.type.sz;
      const dist = Math.hypot(ox, oy, oz);
      if (this.hold[id] === undefined && dist > 0.34) continue;
      if (dist > 0.65) { delete this.hold[id]; continue; }
      const a = Math.atan2(oy * 0.54 - oz * 0.84, ox);
      if (this.hold[id] !== undefined) {
        let d = a - this.hold[id]; while (d > Math.PI) d -= 6.2832; while (d < -Math.PI) d += 6.2832;
        this.wheelRot = clamp(this.wheelRot + d, -MAXR, MAXR);
      } else if (h.pulse) h.pulse(0.4, 40);
      this.hold[id] = a; held = true;
    }
    if (!held) this.wheelRot += (stickX * MAXR - this.wheelRot) * Math.min(1, dt * (Math.abs(stickX) > 0.05 ? 8 : 4));
    return clamp(this.wheelRot / MAXR, -1, 1);
  }

  updateCockpit(dt) {
    const c = this.driving, g = this.cockpit;
    if (!c || !g.visible) return;
    g.position.set(c.pos.x, c.pos.y, c.pos.z);
    this._e.set(c.pitch, c.yaw, c.roll || 0, 'YXZ'); g.rotation.copy(this._e);
    this.wheelRoot.rotation.z = this.wheelRot;
    this._dashT = (this._dashT || 0) - dt;
    if (this._dashT <= 0) {
      this._dashT = 0.1; const x = this.dashCtx; x.fillStyle = '#05100a'; x.fillRect(0, 0, 192, 96);
      x.fillStyle = '#7dff7a'; x.font = 'bold 54px monospace'; x.textAlign = 'center'; x.fillText(String(Math.round(this.speedKmh)), 96, 58);
      x.font = 'bold 20px monospace'; x.fillStyle = '#9bd89a'; x.fillText('KM/H', 96, 86);
      const hp = clamp(c.hp / 100, 0, 1); x.fillStyle = hp > 0.4 ? '#3fae3a' : '#ff5a4a'; x.fillRect(10, 8, 172 * hp, 8);
      this.dashTex.needsUpdate = true;
    }
  }

  // ------------------------------------------------------------------ shooting & explosions
  rayCars(o, d, maxT) {
    let best = null, bt = maxT;
    for (const c of this.cars) {
      if (!c.active || c.player) continue;
      const bx = c.player || c.parked || c.dead ? (c.pos.x || c.x) : c.rx, bz = c.player || c.parked || c.dead ? (c.pos.z || c.z) : c.rz;
      if (Math.abs(bx - o.x) > maxT + 4 || Math.abs(bz - o.z) > maxT + 4) continue;
      const yaw = c.parked || c.dead ? c.yaw : c.ryaw, cs = Math.cos(yaw), sn = Math.sin(yaw), ty = c.type;
      const dx = o.x - bx, dz = o.z - bz;
      const lo = [dx * cs - dz * sn, o.y - (c.ry || 0), dx * sn + dz * cs], ld = [d.x * cs - d.z * sn, d.y, d.x * sn + d.z * cs];
      const lo_ = [-0.95 * ty.sx, 0.3, -2.25 * ty.sz], hi_ = [0.95 * ty.sx, 1.45 * ty.sy, 2.25 * ty.sz];
      let t0 = 0, t1 = bt, ok = true;
      for (let a = 0; a < 3; a++) {
        if (Math.abs(ld[a]) < 1e-8) { if (lo[a] < lo_[a] || lo[a] > hi_[a]) { ok = false; break; } continue; }
        let a0 = (lo_[a] - lo[a]) / ld[a], a1 = (hi_[a] - lo[a]) / ld[a]; if (a0 > a1) { const s = a0; a0 = a1; a1 = s; }
        t0 = Math.max(t0, a0); t1 = Math.min(t1, a1); if (t0 > t1) { ok = false; break; }
      }
      if (ok && t0 < bt) { bt = t0; best = c; }
    }
    return best ? { car: best, t: bt } : null;
  }
  hitCar(c, point, dmg = 20) {
    const g = this.game;
    g.particles.hit(point, { x: 0, y: 1, z: 0 }, [1, 0.8, 0.4], 6);
    g.audio.play('clank', { pos: point, gain: 0.5, rate: 1.6, hrtf: false, minGap: 0.05 });
    if (g.time - c.lastHitT < 0.06) return;                 // shotgun pellets count as one shot
    c.lastHitT = g.time; c.hits++;
    if (c.driver && c.ai) c.fear = 12;
    g.npcs.alertShot(point, 40);
    if (c.hits >= 3 && !c.dead) c.smoking = true;
    if (c.hits >= 5 && !c.dead) this.explode(c);
  }
  explode(c) {
    const g = this.game, p = g.player;
    if (c.dead) return;
    const pos = { x: c.player || c.parked ? c.pos.x : c.rx, y: 1, z: c.player || c.parked ? c.pos.z : c.rz };
    if (c.player) this.exit();
    c.dead = true; c.deadT = 0; c.ai = false; c.chasing = false; c.parked = true; c.player = false; c.v = 0; c.vx = c.vz = 0; c.driver = null;
    c.pos.set(pos.x, c.ry || 0, pos.z); c.yaw = c.ryaw;
    this.M.body.setColorAt(c.i, CHAR); this.flagColors();
    g.audio.play('boom', { pos, gain: 1.6, ref: 12, rolloff: 0.7, hrtf: false });
    g.particles.burst(pos, [1, 0.55, 0.1], 70, 9, 0.5, 0.9);
    g.particles.burst(pos, [1, 0.9, 0.5], 40, 14, 0.25, 0.5);
    g.particles.poof(pos, [0.1, 0.1, 0.1], 24, 4, 1.4);
    if (g.camera_ctrl) g.camera_ctrl.punch(0.8);
    // blast: throws people, hurts the player, scares everyone
    const dP = Math.hypot(p.pos.x - pos.x, p.pos.z - pos.z);
    if (dP < 9 && !p.driving) { g.health.damage(Math.round(45 * (1 - dP / 9)), 'explosion'); const k = 9 * (1 - dP / 9); p.vel.x += ((p.pos.x - pos.x) / (dP || 1)) * k; p.vel.z += ((p.pos.z - pos.z) / (dP || 1)) * k; p.vel.y = Math.max(p.vel.y, 5); p.grounded = false; p.launched = 0.3; if (g.vr.active) g.vr.pulseBoth(1, 200); }
    for (const n of g.npcs.positions) {
      const d = Math.hypot(n.x - pos.x, n.z - pos.z); if (d > 10 || n.state === 'held') continue;
      const k = (1 - d / 10) * 12;
      g.npcs.launch(n, ((n.x - pos.x) / (d || 1)) * k, 4 + k * 0.4, ((n.z - pos.z) / (d || 1)) * k); n.maxImpact = k > 6 ? 9 : 0;
      if (k > 6 && g.crime) g.crime.onInnocentDown(n);
    }
    g.npcs.alertShot(pos, 60);
    for (const o of this.cars) { if (o === c || !o.active || o.dead) continue; const d = Math.hypot(o.x - pos.x, o.z - pos.z); if (d < 8) { o.fear = 10; if (o.ai) o.v = 0; } if (d < 4.5 && !o.player) { o.hp -= 60; o.hits += 2; if (o.hits >= 5) this.explode(o); } }
  }

  // ------------------------------------------------------------------ collisions with people on foot
  carHit(px, py, pz, r) {
    for (const c of this.cars) {
      if (!c.active || c.player) continue;
      const bx = c.parked || c.dead ? c.pos.x : c.rx, bz = c.parked || c.dead ? c.pos.z : c.rz;
      if (Math.abs(bx - px) > 4 || Math.abs(bz - pz) > 4) continue;
      if (py > (c.ry || 0) + 1.55) continue;
      const yaw = c.parked || c.dead ? c.yaw : c.ryaw, cs = Math.cos(yaw), sn = Math.sin(yaw), ty = c.type;
      const dx = px - bx, dz = pz - bz, lx = dx * cs - dz * sn, lz = dx * sn + dz * cs;
      const hx = 0.95 * ty.sx + r, hz = 2.25 * ty.sz + r;
      if (Math.abs(lx) < hx && Math.abs(lz) < hz) {
        // push out along the shallow axis (local), back to world
        let nx, nz; if (hx - Math.abs(lx) < hz - Math.abs(lz)) { nx = Math.sign(lx) || 1; nz = 0; } else { nx = 0; nz = Math.sign(lz) || 1; }
        const kx = nx * cs + nz * sn, kz = -nx * sn + nz * cs;
        return { kx, kz, speed: c.v || 0, car: c };
      }
    }
    return null;
  }
  nearestCarDistance(px, pz) {
    let best = 1e9;
    for (const c of this.cars) if (c.active) { const d = Math.hypot(c.x - px, c.z - pz); if (d < best) best = d; }
    return best;
  }

  // ------------------------------------------------------------------ police cars (dispatched by CrimeSystem)
  dispatchCop(target) {
    const c = this.cars.find((q) => q.cop && !q.active); if (!c) return null;
    const R = this.R; let best = null;
    for (let tries = 0; tries < 30; tries++) {
      const a = LINES[R.int(0, GRID)], b = LINES[R.int(0, GRID)];
      const d = Math.hypot(a - target.x, b - target.z);
      if (d > 110 && d < 230) { best = [a, b]; break; }
    }
    if (!best) best = [LINES[0], LINES[0]];
    c.active = true; c.cop = true; c.ai = true; c.chasing = true; c.parked = false; c.dead = false; c.player = false; c.driver = { skin: 0xe0ac86, shirt: 0x1c2a4a };
    c.hits = 0; c.hp = 140; c.arrived = false; c.minD = 1e9; c.ghost = 0; c.stuckT = 0; c.turn = 0; c.v = 6; c.sirenT = 0;
    // start on the street line through that intersection, heading roughly toward the player
    const toX = target.x - best[0], toZ = target.z - best[1];
    if (Math.abs(toX) > Math.abs(toZ)) { c.axis = 'x'; c.line = best[1]; c.dir = Math.sign(toX) || 1; c.t = best[0] - c.dir * 20; }
    else { c.axis = 'z'; c.line = best[0]; c.dir = Math.sign(toZ) || 1; c.t = best[1] - c.dir * 20; }
    c.off = c.dir * 3.2; c.type = TYPES[0]; c.paint = 0xf2f4f6; c.snap = true;
    this.M.body.setColorAt(c.i, this._c.setHex(0xf2f4f6)); this.M.torso.setColorAt(c.i, this._c.setHex(0x1c2a4a)); this.M.head.setColorAt(c.i, this._c.setHex(0xe0ac86)); this.flagColors();
    this.syncLogical(c); c.rx = c.x; c.rz = c.z; c.ryaw = c.yaw; c.pos.set(c.x, 0, c.z);
    return c;
  }
  retireCop(c) {
    c.active = false; c.chasing = false; c.parked = false; c.dead = false;
    for (const k of ['body', 'glass', 'trim', 'heads', 'tails', 'torso', 'head']) this.M[k].setMatrixAt(c.i, this._zero);
    for (let k = 0; k < 4; k++) this.M.wheels.setMatrixAt(c.i * 4 + k, this._zero);
    this.M.bar.setMatrixAt(c.i - N_TRAFFIC, this._zero);
  }
}
