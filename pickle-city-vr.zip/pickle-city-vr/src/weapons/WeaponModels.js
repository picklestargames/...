// Low-poly, original firearm models built from simple primitives. Origin = centre of the pistol grip (where the palm sits),
// barrel points along -Z. Each model exposes muzzle / eject / magwell / foregrip anchors and animated parts.
import * as THREE from 'three';

const B = (w, h, d, mat, x = 0, y = 0, z = 0, rx = 0) => { const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat); m.position.set(x, y, z); m.rotation.x = rx; m.castShadow = false; return m; };
const Cz = (r, len, mat, x = 0, y = 0, z = 0, n = 16) => { const g = new THREE.CylinderGeometry(r, r, len, n); g.rotateX(Math.PI / 2); const m = new THREE.Mesh(g, mat); m.position.set(x, y, z); return m; };

function canvasTex(w, h, draw, rep = 1) {
  if (typeof document === 'undefined') return null;
  const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(rep, rep); return t;
}

export function createWeaponMaterials(mats) {
  // smooth PBR materials: brushed steel, blued metal, stippled polymer, grained wood
  const brushed = canvasTex(128, 128, (x, w, h) => { x.fillStyle = '#808080'; x.fillRect(0, 0, w, h); for (let i = 0; i < 260; i++) { const v = 90 + (i * 53 % 90); x.fillStyle = `rgb(${v},${v},${v})`; x.fillRect(0, (i * 37) % h, w, 1); } });
  const stipple = canvasTex(64, 64, (x, w, h) => { x.fillStyle = '#707070'; x.fillRect(0, 0, w, h); for (let i = 0; i < 420; i++) { const v = (i * 97) % 255; x.fillStyle = `rgb(${v},${v},${v})`; x.fillRect((i * 31) % w, (i * 57) % h, 2, 2); } }, 3);
  const grain = canvasTex(128, 128, (x, w, h) => { x.fillStyle = '#7a5030'; x.fillRect(0, 0, w, h); for (let i = 0; i < 70; i++) { x.fillStyle = `rgba(${40 + (i * 13 % 40)},${22 + (i * 7 % 20)},10,0.35)`; x.fillRect(0, (i * 19) % h, w, 1 + i % 3); } });
  const M = (o) => new THREE.MeshStandardMaterial(o);
  return {
    steel: M({ color: 0x3a3e45, roughness: 0.3, metalness: 0.92, roughnessMap: brushed, bumpMap: brushed, bumpScale: 0.4 }),
    dark: M({ color: 0x14161a, roughness: 0.42, metalness: 0.75 }),
    poly: M({ color: 0x23262b, roughness: 0.82, metalness: 0.05, bumpMap: stipple, bumpScale: 1.2 }),
    wood: M({ color: 0xffffff, map: grain, roughness: 0.55, metalness: 0.0 }),
    brass: M({ color: 0xc8963c, roughness: 0.3, metalness: 1.0 }),
    accent: M({ color: 0xd8582a, roughness: 0.45, metalness: 0.1 }),
    glass: M({ color: 0x3a8ad8, emissive: 0x1a4a9a, emissiveIntensity: 0.5, roughness: 0.05, metalness: 0.5 }),
    olive: M({ color: 0x4a5a2a, roughness: 0.75, metalness: 0.1, bumpMap: stipple, bumpScale: 0.6 }),
    dot: M({ color: 0xfff2c0, emissive: 0xffe08a, emissiveIntensity: 1.0, roughness: 0.4 }),
    flash: new THREE.MeshBasicMaterial({ color: 0xffd070, transparent: true, opacity: 0.95, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }),
  };
}

/** extra fine detail on top of the base shapes: serrations, sights, rails, vents, turrets, flutes ... (anchors/animated parts are untouched) */
function addDetails(id, W, add) {
  const serr = (n, x, y, z0, dz, h, d, mat) => { const o = []; for (let i = 0; i < n; i++) o.push(B(0.0366, h, d, mat, x, y, z0 + i * dz)); return o; };
  const rail = (n, x, y, z0, dz, mat) => { const o = []; for (let i = 0; i < n; i++) o.push(B(0.03, 0.006, 0.006, mat, x, y, z0 + i * dz)); return o; };
  const vents = (n, side, y, z0, dz, h, mat) => { const o = []; for (let i = 0; i < n; i++) o.push(B(0.004, h, 0.012, mat, side, y, z0 + i * dz)); return o; };
  switch (id) {
    case 'pistol':
      add(...serr(6, 0, 0.088, 0.0, 0.0125, 0.03, 0.004, W.dark), ...serr(4, 0, 0.088, -0.115, 0.01, 0.03, 0.003, W.dark));
      add(B(0.036, 0.004, 0.14, W.dark, 0, 0.1055, -0.06), B(0.006, 0.014, 0.006, W.dot, 0, 0.116, -0.137), B(0.003, 0.012, 0.003, W.dot, -0.008, 0.115, 0.02), B(0.003, 0.012, 0.003, W.dot, 0.008, 0.115, 0.02));
      add(B(0.034, 0.03, 0.01, W.dark, 0, 0.05, -0.12, 0), B(0.02, 0.012, 0.02, W.steel, 0, 0.056, 0.005), Cz(0.003, 0.02, W.brass, 0.0185, 0.093, -0.04, 8));
      add(B(0.033, 0.006, 0.052, W.dark, 0, -0.0545, 0.012, 0.2), B(0.036, 0.012, 0.016, W.dark, 0, 0.04, -0.075));
      break;
    case 'revolver':
      for (let i = 0; i < 6; i++) { const a = i / 6 * Math.PI * 2; add(Cz(0.0045, 0.055, W.dark, Math.sin(a) * 0.029, 0.065 + Math.cos(a) * 0.029, -0.045, 6)); }
      add(B(0.011, 0.01, 0.2, W.steel, 0, 0.0975, -0.17), B(0.008, 0.016, 0.01, W.dark, 0, 0.113, -0.255), B(0.012, 0.008, 0.02, W.dark, 0, 0.104, 0.0), Cz(0.011, 0.02, W.dark, 0, 0.075, -0.275, 14));
      add(B(0.036, 0.062, 0.012, W.brass, 0, -0.07, 0.036, 0.28), B(0.01, 0.02, 0.01, W.dark, 0, 0.052, 0.03), Cz(0.012, 0.01, W.brass, 0, 0.065, 0.016, 12));
      break;
    case 'smg':
      add(...vents(6, 0.0205, 0.065, -0.2, 0.028, 0.03, W.dark), ...vents(6, -0.0205, 0.065, -0.2, 0.028, 0.03, W.dark));
      add(...rail(10, 0, 0.1085, -0.16, 0.02, W.steel), B(0.034, 0.012, 0.016, W.dark, 0, 0.074, -0.265), B(0.01, 0.026, 0.014, W.dark, 0, 0.083, -0.19), B(0.012, 0.012, 0.14, W.steel, 0.0, 0.0, -0.2));
      add(B(0.034, 0.008, 0.07, W.dark, 0, 0.034, -0.11), Cz(0.0235, 0.012, W.steel, 0, 0.065, -0.39, 16), Cz(0.0235, 0.012, W.steel, 0, 0.065, -0.29, 16), Cz(0.0225, 0.1, W.dark, 0, 0.065, -0.34, 16));
      add(B(0.036, 0.012, 0.03, W.dark, 0, 0.004, -0.2), B(0.052, 0.052, 0.01, W.dark, 0, 0.065, 0.256));
      break;
    case 'rifle':
      add(...rail(18, 0, 0.1165, -0.2, 0.0155, W.steel), ...vents(7, 0.0275, 0.062, -0.28, 0.034, 0.035, W.dark), ...vents(7, -0.0275, 0.062, -0.28, 0.034, 0.035, W.dark));
      add(B(0.05, 0.012, 0.02, W.dark, 0, 0.1, -0.26), B(0.012, 0.012, 0.06, W.dark, 0.0, 0.0145 + 0.1, -0.64));
      add(Cz(0.02, 0.035, W.dark, 0, 0.068, -0.8, 6), Cz(0.019, 0.012, W.dark, 0, 0.068, -0.765, 14), Cz(0.006, 0.04, W.steel, 0.026, 0.1, -0.1, 8), B(0.01, 0.018, 0.01, W.accent, 0.0245, 0.07, -0.01));
      add(B(0.048, 0.092, 0.012, W.dark, 0, 0.044, 0.335), B(0.034, 0.006, 0.14, W.poly, 0, 0.098, 0.2), B(0.02, 0.026, 0.02, W.steel, 0, 0.037, 0.0));
      add(B(0.04, 0.012, 0.012, W.steel, 0, 0.082, -0.255));
      break;
    case 'shotgun':
      add(B(0.01, 0.012, 0.5, W.dark, 0, 0.0935, -0.4), Cz(0.0155, 0.014, W.dark, 0, 0.035, -0.55, 14), Cz(0.0075, 0.06, W.steel, 0.0, 0.05, -0.12, 8));
      add(...[0, 1, 2, 3, 4].map((i) => B(0.0455, 0.004, 0.006, W.dark, 0, 0.038, -0.34 + i * 0.026)), B(0.046, 0.012, 0.03, W.steel, 0, 0.02, -0.19), B(0.024, 0.006, 0.08, W.dark, 0.0, 0.098, -0.07));
      add(Cz(0.016, 0.008, W.brass, 0, 0.075, -0.4, 14), B(0.046, 0.012, 0.01, W.dark, 0.0, 0.0, 0.346), B(0.032, 0.02, 0.05, W.steel, 0, 0.022, 0.07), B(0.03, 0.006, 0.07, W.dark, 0, -0.012, 0.02));
      for (let i = 0; i < 4; i++) add(Cz(0.0082, 0.04, W.accent, 0.0235, 0.062 - i * 0.002, -0.1 - i * 0.012 + 0.05, 8));
      break;
    case 'marksman':
      add(...rail(20, 0, 0.1085, -0.28, 0.0175, W.steel), ...vents(8, 0.0235, 0.058, -0.5, 0.034, 0.03, W.dark), ...vents(8, -0.0235, 0.058, -0.5, 0.034, 0.03, W.dark));
      add(Cz(0.0095, 0.03, W.steel, 0.0, 0.178, -0.1, 10), Cz(0.0095, 0.03, W.steel, 0.031, 0.145, -0.1, 10), B(0.04, 0.008, 0.16, W.dark, 0, 0.17, 0.0));
      add(Cz(0.0295, 0.01, W.dark, 0, 0.145, -0.14, 14), Cz(0.0295, 0.01, W.steel, 0, 0.145, -0.05, 14), Cz(0.0355, 0.012, W.steel, 0, 0.145, -0.28, 14), Cz(0.0315, 0.012, W.steel, 0, 0.145, 0.065, 14), B(0.012, 0.012, 0.022, W.dot, 0.0, 0.145, -0.268));
      add(Cz(0.0225, 0.07, W.dark, 0, 0.072, -0.99, 14), Cz(0.0235, 0.012, W.steel, 0, 0.072, -0.97, 14), Cz(0.0235, 0.012, W.steel, 0, 0.072, -1.01, 14), B(0.034, 0.012, 0.13, W.dark, 0, 0.012, -0.5, 0));
      add(B(0.044, 0.1, 0.012, W.dark, 0, 0.04, 0.38), B(0.014, 0.034, 0.18, W.olive, 0, 0.0, 0.2), B(0.012, 0.03, 0.01, W.dark, 0, 0.038, -0.3));
      break;
  }
}

function flashMesh(m) {
  const g = new THREE.Group();
  const s = new THREE.Shape(); const n = 5;
  for (let i = 0; i < n * 2; i++) { const r = i % 2 ? 0.025 : 0.09, a = (i / (n * 2)) * Math.PI * 2; (i ? s.lineTo : s.moveTo).call(s, Math.cos(a) * r, Math.sin(a) * r); }
  const geo = new THREE.ShapeGeometry(s);
  const a = new THREE.Mesh(geo, m.flash); const b = a.clone(); b.rotation.y = Math.PI / 2;
  const c = new THREE.Mesh(new THREE.ConeGeometry(0.03, 0.14, 5), m.flash); c.rotation.x = -Math.PI / 2; c.position.z = -0.07;
  g.add(a, b, c); g.visible = false; g.renderOrder = 6;
  return g;
}

export function buildWeapon(id, W) {
  const root = new THREE.Group(); root.name = id;
  const parts = {};
  const anchors = {};
  let muzzleZ = -0.2, sightH = 0.08;
  const add = (...o) => { for (const x of o) root.add(x); };
  switch (id) {
    case 'pistol': {
      const grip = B(0.032, 0.115, 0.05, W.poly, 0, -0.01, 0.0, 0.2);
      const frame = B(0.03, 0.026, 0.15, W.steel, 0, 0.06, -0.05);
      const slide = B(0.034, 0.036, 0.17, W.steel, 0, 0.086, -0.055); slide.name = 'slide';
      const bar = Cz(0.009, 0.03, W.dark, 0, 0.085, -0.15);
      const guard = new THREE.Group();
      guard.add(B(0.012, 0.01, 0.07, W.steel, 0, 0.032, -0.07), B(0.012, 0.03, 0.01, W.steel, 0, 0.045, -0.105), B(0.012, 0.012, 0.045, W.steel, 0, 0.022, -0.085));
      const trig = B(0.008, 0.026, 0.01, W.dark, 0, 0.05, -0.05, 0.3);
      const fs = B(0.008, 0.01, 0.01, W.dark, 0, 0.108, -0.135), rs = B(0.014, 0.01, 0.01, W.dark, 0, 0.108, 0.02);
      const mag = B(0.026, 0.1, 0.04, W.dark, 0, -0.075, 0.012, 0.2); mag.name = 'mag';
      const butt = B(0.034, 0.012, 0.05, W.steel, 0, -0.062, 0.013, 0.2);
      add(grip, frame, slide, bar, guard, trig, fs, rs, mag, butt);
      parts.slide = slide; parts.mag = mag; parts.slideRest = slide.position.z;
      muzzleZ = -0.17; sightH = 0.115; anchors.mag = [0, -0.1, 0.02]; anchors.eject = [0.02, 0.092, -0.04];
      break;
    }
    case 'revolver': {
      const grip = B(0.034, 0.12, 0.05, W.wood, 0, -0.01, 0.01, 0.28);
      const frame = B(0.032, 0.06, 0.11, W.steel, 0, 0.055, -0.04);
      const barrel = B(0.026, 0.03, 0.2, W.steel, 0, 0.075, -0.17);
      const rib = B(0.012, 0.012, 0.2, W.dark, 0, 0.1, -0.17);
      const rod = Cz(0.008, 0.14, W.dark, 0, 0.05, -0.17);
      const cyl = Cz(0.032, 0.062, W.steel, 0, 0.065, -0.045, 6); cyl.name = 'cylinder';
      const hammer = B(0.01, 0.03, 0.016, W.dark, 0, 0.095, 0.03, -0.3); hammer.name = 'hammer';
      const guard = new THREE.Group(); guard.add(B(0.012, 0.01, 0.06, W.steel, 0, 0.02, -0.04), B(0.012, 0.026, 0.01, W.steel, 0, 0.033, -0.07));
      const fs = B(0.008, 0.014, 0.01, W.accent, 0, 0.105, -0.255);
      add(grip, frame, barrel, rib, rod, cyl, hammer, guard, fs);
      parts.cylinder = cyl; parts.hammer = hammer;
      muzzleZ = -0.275; sightH = 0.115; anchors.eject = [0.0, 0.06, -0.04];
      break;
    }
    case 'smg': {
      const recv = B(0.04, 0.062, 0.24, W.steel, 0, 0.06, -0.1);
      const top = B(0.028, 0.014, 0.2, W.dark, 0, 0.1, -0.1);
      const grip = B(0.032, 0.11, 0.045, W.poly, 0, -0.01, 0.0, 0.25);
      const fgrip = B(0.03, 0.09, 0.034, W.poly, 0, 0.0, -0.2, 0.15);
      const barrel = Cz(0.012, 0.1, W.dark, 0, 0.065, -0.27); const supp = Cz(0.021, 0.12, W.dark, 0, 0.065, -0.33, 8);
      const mag = B(0.028, 0.14, 0.036, W.dark, 0, -0.04, -0.1, 0.08); mag.name = 'mag';
      const stockA = B(0.01, 0.01, 0.16, W.steel, 0.02, 0.07, 0.17), stockB = B(0.01, 0.01, 0.16, W.steel, -0.02, 0.07, 0.17), stockC = B(0.05, 0.05, 0.012, W.poly, 0, 0.065, 0.25);
      const guard = B(0.012, 0.01, 0.06, W.steel, 0, 0.026, -0.03);
      const bolt = B(0.016, 0.014, 0.05, W.steel, 0.026, 0.085, -0.04); bolt.name = 'bolt';
      const fs = B(0.008, 0.018, 0.008, W.dark, 0, 0.11, -0.2), rs = B(0.02, 0.018, 0.008, W.dark, 0, 0.11, 0.01);
      add(recv, top, grip, fgrip, barrel, supp, mag, stockA, stockB, stockC, guard, bolt, fs, rs);
      parts.mag = mag; parts.bolt = bolt; parts.boltRest = bolt.position.z;
      muzzleZ = -0.395; sightH = 0.12; anchors.fore = [0, -0.02, -0.2]; anchors.mag = [0, -0.1, -0.1]; anchors.eject = [0.03, 0.085, -0.04];
      break;
    }
    case 'rifle': {
      const recv = B(0.046, 0.075, 0.3, W.steel, 0, 0.065, -0.1);
      const rail = B(0.024, 0.014, 0.4, W.dark, 0, 0.11, -0.14);
      const hand = B(0.054, 0.058, 0.26, W.poly, 0, 0.062, -0.37);
      const barrel = Cz(0.0105, 0.28, W.dark, 0, 0.068, -0.64); const brake = Cz(0.017, 0.05, W.dark, 0, 0.068, -0.775, 6);
      const gas = B(0.016, 0.03, 0.04, W.steel, 0, 0.12, -0.46);
      const grip = B(0.034, 0.115, 0.05, W.poly, 0, -0.01, 0.0, 0.28);
      const mag1 = B(0.032, 0.09, 0.05, W.dark, 0, -0.04, -0.14, 0.0), mag2 = B(0.032, 0.07, 0.05, W.dark, 0, -0.11, -0.115, 0.28);
      const mag = new THREE.Group(); mag.add(mag1, mag2); mag.name = 'mag';
      const stock = B(0.042, 0.085, 0.2, W.poly, 0, 0.05, 0.2); const butt = B(0.046, 0.1, 0.03, W.dark, 0, 0.04, 0.31);
      const tube = B(0.026, 0.026, 0.1, W.steel, 0, 0.07, 0.1);
      const guard = B(0.012, 0.01, 0.06, W.steel, 0, 0.02, -0.04);
      const fs = B(0.006, 0.04, 0.006, W.dark, 0, 0.14, -0.55), fbase = B(0.016, 0.02, 0.02, W.dark, 0, 0.126, -0.55);
      const rs = B(0.026, 0.026, 0.008, W.dark, 0, 0.14, 0.04);
      const bolt = B(0.018, 0.014, 0.04, W.steel, 0.026, 0.09, -0.06); bolt.name = 'bolt';
      add(recv, rail, hand, barrel, brake, gas, grip, mag, stock, butt, tube, guard, fs, fbase, rs, bolt);
      parts.mag = mag; parts.bolt = bolt; parts.boltRest = bolt.position.z;
      muzzleZ = -0.81; sightH = 0.15; anchors.fore = [0, 0.0, -0.37]; anchors.mag = [0, -0.1, -0.13]; anchors.eject = [0.03, 0.09, -0.05];
      break;
    }
    case 'shotgun': {
      const recv = B(0.044, 0.07, 0.2, W.steel, 0, 0.06, -0.06);
      const barrel = Cz(0.0155, 0.52, W.steel, 0, 0.075, -0.4); const tube = Cz(0.0145, 0.42, W.dark, 0, 0.035, -0.34);
      const pump = new THREE.Group(); pump.name = 'pump';
      pump.add(B(0.044, 0.04, 0.16, W.wood, 0, 0.035, -0.3), B(0.008, 0.01, 0.16, W.dark, 0, 0.055, -0.3));
      const grip = B(0.034, 0.115, 0.05, W.wood, 0, -0.01, 0.0, 0.3);
      const stock = B(0.04, 0.085, 0.24, W.wood, 0, 0.035, 0.22, -0.05); const pad = B(0.044, 0.1, 0.02, W.dark, 0, 0.03, 0.345);
      const guard = B(0.012, 0.01, 0.06, W.steel, 0, 0.018, -0.03);
      const bead = B(0.008, 0.012, 0.008, W.accent, 0, 0.1, -0.64);
      const port = B(0.046, 0.02, 0.06, W.dark, 0, 0.088, -0.02);
      const mfoot = Cz(0.0175, 0.04, W.dark, 0, 0.075, -0.66, 8);
      add(recv, barrel, tube, pump, grip, stock, pad, guard, bead, port, mfoot);
      parts.pump = pump; parts.pumpRest = pump.position.z;
      muzzleZ = -0.68; sightH = 0.115; anchors.fore = [0, 0.035, -0.3]; anchors.mag = [0, -0.03, -0.1]; anchors.eject = [0.03, 0.08, -0.03];
      break;
    }
    case 'marksman': {
      const recv = B(0.044, 0.07, 0.3, W.steel, 0, 0.065, -0.08);
      const stock = B(0.04, 0.09, 0.28, W.olive, 0, 0.045, 0.24, -0.06); const riser = B(0.036, 0.04, 0.12, W.olive, 0, 0.1, 0.24);
      const hand = B(0.046, 0.05, 0.3, W.olive, 0, 0.055, -0.38);
      const barrel = Cz(0.0125, 0.42, W.dark, 0, 0.072, -0.76); const brake = Cz(0.02, 0.07, W.dark, 0, 0.072, -0.99, 6);
      const grip = B(0.034, 0.115, 0.05, W.olive, 0, -0.01, 0.0, 0.3);
      const mag = B(0.03, 0.09, 0.07, W.dark, 0, -0.035, -0.13); mag.name = 'mag';
      const scope = Cz(0.026, 0.26, W.dark, 0, 0.145, -0.1, 10);
      const bell = Cz(0.034, 0.05, W.dark, 0, 0.145, -0.25, 10), eye = Cz(0.03, 0.04, W.dark, 0, 0.145, 0.04, 10);
      const lens = Cz(0.026, 0.004, W.glass, 0, 0.145, -0.277, 10);
      const m1 = B(0.014, 0.04, 0.02, W.steel, 0, 0.11, -0.04), m2 = B(0.014, 0.04, 0.02, W.steel, 0, 0.11, -0.17);
      const guard = B(0.012, 0.01, 0.06, W.steel, 0, 0.02, -0.04);
      const bolt = B(0.012, 0.012, 0.05, W.steel, 0.03, 0.095, 0.0); bolt.name = 'bolt'; const knob = new THREE.Mesh(new THREE.SphereGeometry(0.012, 6, 5), W.dark); knob.position.set(0.045, 0.085, 0.02);
      add(recv, stock, riser, hand, barrel, brake, grip, mag, scope, bell, eye, lens, m1, m2, guard, bolt, knob);
      parts.mag = mag; parts.bolt = bolt; parts.boltRest = bolt.position.z;
      muzzleZ = -1.025; sightH = 0.175; anchors.fore = [0, 0.0, -0.4]; anchors.mag = [0, -0.08, -0.13]; anchors.eject = [0.03, 0.09, -0.02];
      break;
    }
    default: throw new Error('unknown weapon ' + id);
  }
  addDetails(id, W, add);
  const muzzle = new THREE.Object3D(); muzzle.position.set(0, 0.07 + (id === 'pistol' ? 0.015 : 0), muzzleZ);
  if (id === 'revolver') muzzle.position.y = 0.075;
  const flash = flashMesh(W); muzzle.add(flash);
  root.add(muzzle);
  const eject = new THREE.Object3D(); eject.position.set(...(anchors.eject || [0.03, 0.08, -0.03])); root.add(eject);
  root.traverse((o) => { if (o.isMesh) o.matrixAutoUpdate = true; });
  return {
    id, root, parts, muzzle, flash, eject, sightH,
    magwell: new THREE.Vector3(...(anchors.mag || [0, -0.08, 0.0])),
    foregrip: anchors.fore ? new THREE.Vector3(...anchors.fore) : null,
    length: Math.abs(muzzleZ),
  };
}
