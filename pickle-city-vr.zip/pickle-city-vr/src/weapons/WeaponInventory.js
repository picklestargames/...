import { WEAPONS, WEAPON_LIST } from './WeaponDefs.js';
import { Emitter } from '../core/Utils.js';

// Owned weapons and their ammo. Ammo state lives here (per weapon type), holders only reference it.
export class WeaponInventory extends Emitter {
  constructor() {
    super();
    this.owned = new Map();
    this.give('pistol', true);
    this.owned.get('pistol').reserve = 60;
  }
  has(id) { return this.owned.has(id); }
  get(id) { return this.owned.get(id); }
  give(id, silent = false) {
    const d = WEAPONS[id];
    if (!d) return false;
    if (this.owned.has(id)) {
      const w = this.owned.get(id);
      const room = d.reserve * 1.5 - w.reserve;
      if (room <= 0 && w.mag >= d.mag) return false;
      w.reserve = Math.min(d.reserve * 1.5, w.reserve + d.mag * 2);
      if (!silent) this.emit('ammo', id);
      return true;
    }
    this.owned.set(id, { id, mag: d.mag, reserve: Math.floor(d.reserve * 0.6) });
    if (!silent) this.emit('new', id);
    return true;
  }
  /** add ammo to every owned weapon; returns true if anything changed */
  addAmmo(mags = 2) {
    let changed = false;
    for (const [id, w] of this.owned) {
      const d = WEAPONS[id], cap = d.reserve * 1.5;
      if (w.reserve < cap) { w.reserve = Math.min(cap, w.reserve + Math.ceil(d.mag * mags)); changed = true; }
    }
    if (changed) this.emit('ammo');
    return changed;
  }
  list() { return WEAPON_LIST.filter((d) => this.owned.has(d.id)); }
  next(id, dir = 1) {
    const l = this.list(); if (!l.length) return null;
    let i = l.findIndex((d) => d.id === id);
    i = i < 0 ? 0 : (i + dir + l.length) % l.length;
    return l[i].id;
  }
}
