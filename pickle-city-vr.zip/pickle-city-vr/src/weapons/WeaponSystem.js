// Weapon logic shared by desktop and VR: holders (one per hand in VR, one in desktop), hitscan, spread, recoil,
// reload behaviours, effects, tracers, holster visuals.
import * as THREE from 'three';
import { WEAPONS, HOLSTERS } from './WeaponDefs.js';
import { HandModel } from '../player/HandModel.js';
import { buildWeapon, createWeaponMaterials } from './WeaponModels.js';
import { WeaponInventory } from './WeaponInventory.js';
import { clamp, damp } from '../core/Utils.js';

const DECALS = 96;
const TRACERS = 28;

class Holder {
  constructor(i) {
    this.i = i; this.id = null; this.def = null; this.model = null; this.state = null;
    this.trigger = false; this.prevTrigger = false;
    this.cd = 0; this.bloom = 0; this.kickZ = 0; this.kickP = 0; this.slideK = 0; this.pumpT = 0;
    this.reload = null; this.ads = 0; this.adsTarget = 0; this.twoHand = false; this.empty = false;
    this.flashT = 0; this.cylRot = 0; this.hammerK = 0; this.rackT = 0;
    this.quick = false; this.magOut = false;
  }
}

export class WeaponSystem {
  constructor(game) {
    this.game = game;
    this.inv = new WeaponInventory();
    this.W = createWeaponMaterials(game.world.mats);
    this.models = {};                        // id -> template model (clones are used for holders/holsters/pickups)
    this.holders = [new Holder(0), new Holder(1)];
    this.mode = 'desktop';
    this.holsterModels = {};
    this.dropped = [];                       // weapons lying in the world (dropped by the player, can be summoned back)
    this.adsFovDrop = 0;
    this._v = [new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3()];
    this._q = new THREE.Quaternion();
    this.tracerMesh = new THREE.InstancedMesh(new THREE.BoxGeometry(0.01, 0.01, 1), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending, depthWrite: false }), TRACERS);
    this.tracerMesh.frustumCulled = false; this.tracerMesh.count = TRACERS;
    this.tracers = Array.from({ length: TRACERS }, () => ({ life: 0, a: new THREE.Vector3(), b: new THREE.Vector3(), w: 1, c: new THREE.Color() }));
    this.tracerHead = 0;
    game.world.scene.add(this.tracerMesh);
    // bullet-hole decals (ring buffer)
    { const c = document.createElement('canvas'); c.width = c.height = 64; const x = c.getContext('2d');
      const gr = x.createRadialGradient(32, 32, 1, 32, 32, 30); gr.addColorStop(0, 'rgba(8,8,8,0.95)'); gr.addColorStop(0.28, 'rgba(15,15,15,0.85)'); gr.addColorStop(0.5, 'rgba(40,38,35,0.35)'); gr.addColorStop(1, 'rgba(40,38,35,0)');
      x.fillStyle = gr; x.fillRect(0, 0, 64, 64); x.strokeStyle = 'rgba(20,20,20,0.5)'; x.lineWidth = 1;
      for (let i = 0; i < 7; i++) { const a = i * 0.9 + 0.3, l = 9 + (i * 5 % 14); x.beginPath(); x.moveTo(32, 32); x.lineTo(32 + Math.cos(a) * l, 32 + Math.sin(a) * l); x.stroke(); }
      const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace;
      this.decals = new THREE.InstancedMesh(new THREE.PlaneGeometry(0.1, 0.1), new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -4 }), DECALS);
      this.decals.frustumCulled = false; this.decals.count = DECALS; this.decalHead = 0;
      const zero = new THREE.Matrix4().makeScale(0, 0, 0); for (let i = 0; i < DECALS; i++) this.decals.setMatrixAt(i, zero);
      game.world.scene.add(this.decals); this._dq = new THREE.Quaternion(); this._dz = new THREE.Vector3(0, 0, 1); this._dm = new THREE.Matrix4(); this._dp = new THREE.Vector3(); this._ds = new THREE.Vector3(); this._dr = new THREE.Quaternion(); }
    this._m = new THREE.Matrix4(); this._s = new THREE.Vector3();
    this.hitT = 0;
    this.lastShotT = -10;
    this.fallen = [];                        // ejected magazines tumbling to the floor
    this._magGeo = new THREE.BoxGeometry(0.026, 0.1, 0.045); this._magMat = new THREE.MeshStandardMaterial({ color: 0x23262b, roughness: 0.5, metalness: 0.6 });
    this._shellGeo = new THREE.CylinderGeometry(0.0095, 0.0095, 0.07, 10); this._shellMat = new THREE.MeshStandardMaterial({ color: 0xb02a1c, roughness: 0.5 });
    this.inv.on('new', (id) => { this.game.ui && this.game.ui.toast('NEW WEAPON: ' + WEAPONS[id].name, 1600); this.ensureHolsterModel(id); });
    for (const id of this.inv.owned.keys()) this.ensureHolsterModel(id);
    this.setMode('desktop');
  }

  create(id) { return buildWeapon(id, this.W); }
  ensureHolsterModel(id) {
    if (this.holsterModels[id]) return;
    const m = this.create(id); m.root.scale.setScalar(0.9); m.root.visible = false; m.flash.visible = false;
    this.game.world.scene.add(m.root); this.holsterModels[id] = m;
  }

  get main() { return this.holders[this.mode === 'vr' ? (this.game.settings.get('leftHanded') ? 0 : 1) : 0]; }
  held(id) { return this.holders.find((h) => h.id === id); }

  setMode(mode) {
    this.mode = mode;
    const parent = mode === 'desktop' ? this.game.camera : this.game.world.scene;
    for (const h of this.holders) if (h.model) { parent.add(h.model.root); }
    if (mode === 'desktop' && this.game.camera.parent !== this.game.rig) this.game.rig.add(this.game.camera);
  }

  equip(hi, id) {
    const h = this.holders[hi];
    if (h.id === id) return true;
    this.seatMag(h);
    const other = this.held(id); if (other && other !== h) return false;
    if (id && !this.inv.has(id)) return false;
    if (h.model) { h.model.root.removeFromParent(); h.model.flash.visible = false; }
    h.reload = null; h.cd = 0.18; h.id = id; h.twoHand = false;
    if (!id) { h.def = null; h.model = null; h.state = null; return true; }
    h.def = WEAPONS[id]; h.state = this.inv.get(id);
    h.model = this.create(id);
    (this.mode === 'desktop' ? this.game.camera : this.game.world.scene).add(h.model.root);
    h.model.root.traverse((o) => { o.frustumCulled = false; });
    this.game.audio.play('slide', { gain: 0.35, rate: 1.4 });
    this.game.ui && this.game.ui.refreshWeapon();
    return true;
  }
  holster(hi) { this.equip(hi, null); }

  // ---------------------------------------------------------------- manual reload (VR)
  /** a small prop: magazine (mag guns) or shell (single-load guns) */
  makeAmmoProp(def) {
    const m = new THREE.Mesh(def.reload === 'single' ? this._shellGeo : this._magGeo, def.reload === 'single' ? this._shellMat : this._magMat);
    m.frustumCulled = false; return m;
  }
  /** magazine guns: drop the magazine out of the gun (the chambered round stays) */
  ejectMag(h) {
    const d = h.def; if (!h.model || !d || d.reload !== 'mag' || h.magOut || h.reload) return false;
    const st = h.state, keep = Math.min(1, st.mag), back = st.mag - keep;
    if (back + st.reserve <= 0) { this.game.ui && this.game.ui.toast('NO SPARE AMMO', 900); return false; }
    st.reserve += back; st.mag = keep; h.magOut = true;
    const pos = h.model.root.localToWorld(h.model.magwell.clone());
    this.dropProp(pos, d, this.game.vr.active ? this.game.vr.headPos.y : 1.5);
    this.game.audio.play('mag_out', { pos, gain: 0.8, ref: 1.5 });
    this.game.vr.active && this.game.vr.pulseHand(this.holders.indexOf(h), 0.3, 35);
    this.game.ui && this.game.ui.refreshAmmo();
    return true;
  }
  dropProp(pos, d) {
    const m = this.makeAmmoProp(d); m.position.copy(pos); this.game.world.scene.add(m);
    this.fallen.push({ m, v: new THREE.Vector3((Math.random() - 0.5) * 0.4, -0.2, (Math.random() - 0.5) * 0.4), w: (Math.random() - 0.5) * 8, t: 0, bounced: false });
  }
  /** take ammo from the belt pouch with the off-hand: returns rounds in hand (0 = none available) */
  pouchTake(h) {
    const d = h.def, st = h.state; if (!d || !st || st.reserve <= 0) return 0;
    if (d.reload === 'mag') { if (!h.magOut) return 0; const n = Math.min(d.mag, st.reserve); st.reserve -= n; this.game.ui && this.game.ui.refreshAmmo(); return n; }
    if (st.mag >= d.mag) return 0;
    st.reserve -= 1; this.game.ui && this.game.ui.refreshAmmo(); return 1;
  }
  /** put the ammo in hand into the gun */
  seatAmmo(h, n) {
    const d = h.def, st = h.state, g = this.game, pos = this.muzzlePos(h, new THREE.Vector3());
    if (d.reload === 'mag') {
      const wasEmpty = st.mag <= 0; st.mag += n; h.magOut = false;
      g.audio.play('mag_in', { pos, gain: 0.9, ref: 1.5 });
      if (wasEmpty) setTimeout(() => { g.audio.play('cock', { pos: this.muzzlePos(h, new THREE.Vector3()), gain: 0.9, ref: 1.5 }); h.rackT = 0.15; }, 220);
    } else {
      st.mag += n; g.audio.play('shell', { pos, gain: 0.9, ref: 1.5, rate: 0.7 });
      if (st.mag >= d.mag) { g.audio.play('cock', { pos, gain: 0.8, ref: 1.5 }); if (d.pump) h.pumpT = d.pump; }
    }
    g.ui && g.ui.refreshAmmo();
  }
  /** the player let go of ammo that wasn't put in a gun */
  returnAmmo(h, n, pos) {
    if (!h || !h.state || n <= 0) return;
    h.state.reserve += n; this.dropProp(pos, h.def);
    this.game.ui && this.game.ui.refreshAmmo();
  }
  /** weapon swapped / holstered / dropped while the magazine is out: seat a fresh one automatically */
  seatMag(h) {
    if (!h.magOut || !h.state) { h.magOut = false; return; }
    const n = Math.min(h.def.mag, h.state.reserve); h.state.mag += n; h.state.reserve -= n; h.magOut = false;
  }
  updateFallen(dt) {
    const floor = this.game.player.pos.y + 0.03, sc = this.game.world.scene;
    for (let i = this.fallen.length - 1; i >= 0; i--) {
      const f = this.fallen[i]; f.t += dt; f.v.y -= 9.81 * dt; f.m.position.addScaledVector(f.v, dt); f.m.rotation.x += f.w * dt;
      if (f.m.position.y < floor) { f.m.position.y = floor; if (!f.bounced) { f.bounced = true; f.v.set(f.v.x * 0.3, 1.2, f.v.z * 0.3); this.game.audio.play('shell', { pos: f.m.position, gain: 0.5, ref: 1.5, rate: 0.9 }); } else { f.v.set(0, 0, 0); f.w = 0; } }
      if (f.t > 4) { sc.remove(f.m); this.fallen.splice(i, 1); }
    }
  }
  selectSlot(slot) {
    const d = this.inv.list().find((x) => x.slot === slot) || this.inv.list()[slot];
    if (d) this.equip(this.mode === 'vr' ? this.holders.indexOf(this.main) : 0, d.id);
  }
  cycle(dir) { const h = this.main; const n = this.inv.next(h.id, dir); if (n && n !== h.id) this.equip(this.holders.indexOf(h), n); }

  setTrigger(hi, v) { this.holders[hi].trigger = v; }
  setAds(v) { this.holders[0].adsTarget = v ? 1 : 0; }
  reloadPressed(hi) {
    const h = this.holders[hi === undefined ? (this.mode === 'vr' ? this.holders.indexOf(this.main) : 0) : hi];
    if (this.game.vr.active && h.def && h.def.reload === 'mag' && !h.magOut && !h.reload) { this.ejectMag(h); return; }   // VR: B drops the magazine; the other hand brings a new one
    this.startReload(h, false);                                                                                          // second press with the mag out = assisted reload
  }

  startReload(h, quick) {
    if (!h.def || h.reload || h.state.mag >= h.def.mag || h.state.reserve <= 0) return false;
    h.quick = quick; h.magOut = false;
    const d = h.def;
    if (d.reload === 'single') h.reload = { t: -(d.reloadIntro || 0.3) * (quick ? 0.6 : 1), n: 0, single: true, dur: d.reloadTime * (quick ? 0.65 : 1) };
    else h.reload = { t: 0, dur: d.reloadTime * (quick ? 0.55 : 1), phase: 0, single: false };
    this.game.audio.play('mag_out', { pos: this.muzzlePos(h), gain: 0.7, ref: 1.5 });
    this.game.vr.active && this.game.vr.pulseHand(this.holders.indexOf(h), 0.25, 30);
    this.game.player.reloadFlag = true;
    return true;
  }

  muzzlePos(h, out = this._v[0]) { if (!h.model) return out.set(0, 0, 0); return h.model.muzzle.getWorldPosition(out); }

  // ---------------------------------------------------------------- firing
  spreadFor(h) {
    const g = this.game, p = g.player, d = h.def;
    let s = d.spread + d.moveSpread * clamp(p.speedH / 10, 0, 1) + h.bloom;
    if (!p.grounded) s *= 1.8;
    if (p.crouching) s *= 0.8;
    s *= 1 - h.ads * 0.55;
    if (g.vr.active && h.twoHand) s *= 0.65;
    return s;
  }

  tryFire(h) {
    const g = this.game, d = h.def;
    if (h.cd > 0 || h.reload && !h.reload.single || g.health.dead || g.state !== 'playing') return false;
    if (h.reload && h.reload.single) { if (h.state.mag > 0) h.reload = null; else return false; }
    if (h.state.mag <= 0) {
      if (!h.empty) { g.audio.play('shot_empty', { pos: this.muzzlePos(h), gain: 0.6, ref: 1.5 }); h.empty = true; }
      h.cd = 0.25;
      if (!g.vr.active) this.startReload(h, false);     // VR: dry click only — reload by hand
      return false;
    }
    this.fire(h);
    return true;
  }

  fire(h) {
    const g = this.game, d = h.def, p = g.player;
    h.state.mag--; h.cd = 60 / d.rpm + (d.pump ? d.pump : 0); h.empty = false;
    h.bloom = Math.min(d.bloomMax, h.bloom + d.bloom);
    this.lastShotT = g.time;
    // aim ray
    const muzzle = this.muzzlePos(h, new THREE.Vector3());
    const origin = new THREE.Vector3(), dir = new THREE.Vector3();
    if (this.mode === 'desktop') {
      g.camera.getWorldPosition(origin); g.camera.getWorldDirection(dir);
    } else {
      origin.copy(muzzle); h.model.root.getWorldQuaternion(this._q); dir.set(0, 0, -1).applyQuaternion(this._q);
    }
    const sp = this.spreadFor(h);
    const right = new THREE.Vector3().crossVectors(dir, new THREE.Vector3(0, 1, 0)).normalize();
    const up = new THREE.Vector3().crossVectors(right, dir).normalize();
    for (let n = 0; n < d.pellets; n++) {
      const rr = Math.sqrt(Math.random()) * sp, a = Math.random() * Math.PI * 2;
      const dd = dir.clone().addScaledVector(right, Math.cos(a) * rr).addScaledVector(up, Math.sin(a) * rr).normalize();
      this.hitscan(origin, dd, d, muzzle);
    }
    g.net && g.net.afterFire(origin, dir, d);
    // effects
    const mdir = new THREE.Vector3(0, 0, -1).applyQuaternion(h.model.root.getWorldQuaternion(this._q));
    g.particles.muzzleFlash(muzzle, mdir, d.pellets > 1 ? 1.5 : d.id === 'marksman' ? 1.3 : 1);
    h.flashT = 0.045; h.model.flash.visible = true; h.model.flash.rotation.z = Math.random() * 6.28; h.model.flash.scale.setScalar(0.8 + Math.random() * 0.5);
    const ej = h.model.eject.getWorldPosition(new THREE.Vector3());
    if (d.pellets === 1 || !d.pump) {
      const rdir = new THREE.Vector3(1, 0.2, 0).applyQuaternion(this._q);
      if (d.id !== 'revolver') g.particles.shell(ej, rdir, new THREE.Vector3(0, 1, 0));
    }
    g.particles.poof(muzzle, [0.75, 0.75, 0.75], 1, 0.25, d.pellets > 1 ? 0.22 : 0.12);          // muzzle smoke
    g.audio.play(d.sound, { pos: muzzle, gain: 1.0, ref: 3, reverb: 0.5, hrtf: false, vary: 0.05 });
    g.npcs.alertShot(muzzle, 55);
    // recoil: view kick (desktop) or hand kick (VR, never the head)
    h.kickZ += d.handKick; h.kickP += d.kickV * 2.2; h.slideK = 1;
    if (d.id === 'revolver') { h.cylRot += Math.PI / 3; h.hammerK = 1; }
    if (d.pump) h.pumpT = d.pump;
    if (this.mode === 'desktop') {
      const k = 1 - h.ads * 0.4;
      g.camera_ctrl.addRecoil(d.kickV * k, (Math.random() - 0.5) * 2 * d.kickH * k);
      g.camera_ctrl.shake = Math.max(g.camera_ctrl.shake, d.kickV * 6);
      p.shootFlag = true;
    } else {
      g.vr.pulseHand(this.holders.indexOf(h), d.haptic * (h.twoHand ? 0.7 : 1), 55);
      if (h.twoHand) g.vr.pulseHand(1 - this.holders.indexOf(h), d.haptic * 0.4, 45);
    }
    g.ui && g.ui.refreshAmmo();
    if (h.state.mag <= 0) { /* slide locks back */ }
  }

  /** one straight segment of the bullet's flight; returns the end point if it hit something */
  hitSeg(origin, dir, len, dist0, d) {
    const g = this.game, W = g.world.collision;
    const wr = W.raycast(origin.x, origin.y, origin.z, dir.x, dir.y, dir.z, len, {});
    const nr = g.npcs.raycast(origin, dir, wr ? wr.t : len);
    const cr = g.vehicles ? g.vehicles.rayCars(origin, dir, Math.min(wr ? wr.t : len, nr ? nr.t : len)) : null;
    const pr = g.net && g.net.online && !cr ? g.net.raycast(origin, dir, Math.min(wr ? wr.t : len, nr ? nr.t : len)) : null;
    let end;
    if (pr) {
      end = origin.clone().addScaledVector(dir, pr.t);
      const fr = (pr.t + dist0) / d.range;
      g.net.hitPlayer(pr, d.dmg, fr < 0.3 ? 1 : 1 - 0.55 * Math.min(1, (fr - 0.3) / 0.7));
      g.particles.burst(end, [0.9, 0.15, 0.1], 6, 2, 0.07, 0.4);
    } else if (cr) {
      end = origin.clone().addScaledVector(dir, cr.t);
      g.vehicles.hitCar(cr.car, end, d.dmg);
      g.ui && g.ui.hitMarker();
    } else if (nr && (!wr || nr.t < wr.t)) {
      end = origin.clone().addScaledVector(dir, nr.t);
      const fr = (nr.t + dist0) / d.range, fall = fr < 0.3 ? 1 : 1 - 0.55 * Math.min(1, (fr - 0.3) / 0.7);          // damage falls off with distance
      const hy = (end.y - nr.npc.y) / nr.npc.h, head = nr.npc.state !== 'fall' && hy > 0.84, legs = hy < 0.45 && nr.npc.state !== 'fall';
      g.npcs.hit(nr.npc, d.dmg * fall * (head ? 2.4 : legs ? 0.75 : 1), dir, end);
      if (head) { g.audio.play('hit', { gain: 0.5, rate: 1.5, bus: 'ui' }); g.particles.burst(end, [0.9, 0.15, 0.1], 6, 2, 0.07, 0.4); }
      g.particles.burst(end, [1, 1, 0.8], 5, 2.5, 0.08, 0.3);
      g.audio.play('hit', { gain: 0.55, bus: 'ui' });
      g.ui && g.ui.hitMarker();
      this.hitT = 0.12;
      if (g.vr.active) g.vr.pulseBoth(0.15, 25);
    } else if (wr) {
      end = origin.clone().addScaledVector(dir, wr.t);
      const n = new THREE.Vector3(wr.nx, wr.ny, wr.nz);
      g.particles.hit(end, n, [1, 0.85, 0.5], d.pellets > 1 ? 3 : 6);
      this.addDecal(end, n, d.pellets > 1 ? 0.6 : 1);
      g.audio.play('impact', { pos: end, gain: 0.5, ref: 3, hrtf: false, minGap: d.pellets > 1 ? 0.04 : 0 });
      g.interaction && g.interaction.onBulletHit(end, dir);
    } else return null;
    return end;
  }

  /** ballistic flight: the bullet travels at d.vel m/s and drops under gravity, checked in segments */
  hitscan(origin, dir, d, muzzle) {
    const v = d.vel || 500, G = 9.81, P = this._hp || (this._hp = [new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3()]);
    const at = (dd, out) => out.copy(origin).addScaledVector(dir, dd).setY(origin.y + dir.y * dd - 0.5 * G * (dd / v) * (dd / v));
    let dist = 0, end = null;
    while (dist < d.range && !end) {
      const L = Math.min(dist < 40 ? 20 : 40, d.range - dist);
      at(dist, P[0]); at(dist + L, P[1]);
      P[2].subVectors(P[1], P[0]); const len = P[2].length(); P[2].multiplyScalar(1 / len);
      end = this.hitSeg(P[0], P[2], len, dist, d);
      dist += L;
    }
    if (!end) end = at(Math.min(d.range, 150), new THREE.Vector3());
    this.addTracer(muzzle, end, d);
  }

  addDecal(p, n, s = 1) {
    this._dq.setFromUnitVectors(this._dz, n);
    this._dr.setFromAxisAngle(this._dz, Math.random() * 6.28); this._dq.multiply(this._dr);
    this._dp.copy(p).addScaledVector(n, 0.012); this._ds.setScalar(s * (0.8 + Math.random() * 0.5));
    this._dm.compose(this._dp, this._dq, this._ds);
    this.decals.setMatrixAt(this.decalHead, this._dm); this.decals.instanceMatrix.needsUpdate = true;
    this.decalHead = (this.decalHead + 1) % DECALS;
  }

  addTracer(a, b, d) {
    if (a.distanceTo(b) < 1.2) return;
    const t = this.tracers[this.tracerHead]; this.tracerHead = (this.tracerHead + 1) % TRACERS;
    t.life = 0.07; t.a.copy(a); t.b.copy(b); t.w = d.tracer; t.c.setHex(d.color);
  }

  // ---------------------------------------------------------------- per-frame
  update(dt) {
    const g = this.game;
    this.hitT = Math.max(0, this.hitT - dt);
    let adsDrop = 0;
    for (const h of this.holders) {
      if (!h.def) continue;
      h.cd = Math.max(0, h.cd - dt);
      h.bloom = Math.max(0, h.bloom - dt * 0.05);
      h.kickZ = damp(h.kickZ, 0, 16, dt); h.kickP = damp(h.kickP, 0, 14, dt);
      h.slideK = Math.max(0, h.slideK - dt * 14);
      h.hammerK = Math.max(0, h.hammerK - dt * 9);
      h.ads = damp(h.ads, h.adsTarget, 14, dt);
      if (h === this.holders[0] && this.mode === 'desktop') adsDrop = (1 - 1 / h.def.zoom) * g.settings.get('fov') * h.ads;
      // trigger handling
      if (h.trigger && (h.def.auto || !h.prevTrigger)) this.tryFire(h);
      if (!h.trigger) h.empty = false;
      h.prevTrigger = h.trigger;
      if (h.flashT > 0) { h.flashT -= dt; if (h.flashT <= 0) h.model.flash.visible = false; }
      this.updateReload(h, dt);
      this.animateModel(h, dt);
    }
    this.adsFovDrop = adsDrop > 0 ? adsDrop / Math.max(0.001, 1) : 0;
    g.camera_ctrl.ads = this.holders[0].ads;
    // tracers
    let k = 0;
    for (const t of this.tracers) {
      if (t.life > 0) {
        t.life -= dt;
        const len = t.a.distanceTo(t.b);
        const head = Math.min(1, (0.07 - t.life) / 0.035), tail = Math.max(0, 1 - t.life / 0.035 - 0.0);
        const a = t.a.clone().lerp(t.b, 0.0), b = t.b;
        const mid = a.clone().lerp(b, 0.5);
        const L = Math.min(len, 14 + len * 0.05);
        const pos = Math.min(len - L, (0.07 - t.life) / 0.07 * len);
        const dirv = b.clone().sub(a).normalize();
        const center = a.clone().addScaledVector(dirv, Math.max(0, pos) + L / 2);
        this._m.lookAt(center, center.clone().add(dirv), new THREE.Vector3(0, 1, 0));
        this._m.setPosition(center);
        this._s.set(t.w, t.w, L);
        this._m.scale(this._s);
        this.tracerMesh.setMatrixAt(k, this._m); this.tracerMesh.setColorAt(k, t.c); k++;
      }
    }
    for (let i = k; i < TRACERS; i++) { this._m.makeScale(0, 0, 0); this.tracerMesh.setMatrixAt(i, this._m); }
    this.tracerMesh.instanceMatrix.needsUpdate = true; if (this.tracerMesh.instanceColor) this.tracerMesh.instanceColor.needsUpdate = true;
    if (this.mode === 'desktop') this.updateDesktopViewmodel(dt);
    this.updateDropped(dt);
    this.updateFallen(dt);
  }

  updateReload(h, dt) {
    const r = h.reload; if (!r) return;
    const d = h.def, st = h.state, g = this.game;
    r.t += dt;
    if (r.single) {
      if (r.t >= r.dur) {
        r.t -= r.dur;
        if (st.mag < d.mag && st.reserve > 0) {
          st.mag++; st.reserve--; r.n++;
          g.audio.play('shell', { pos: this.muzzlePos(h), gain: 0.9, ref: 1.5, rate: 0.7 });
          g.ui && g.ui.refreshAmmo();
          if (g.vr.active) g.vr.pulseHand(this.holders.indexOf(h), 0.2, 25);
        }
        if (st.mag >= d.mag || st.reserve <= 0) {
          h.reload = null; g.audio.play('cock', { pos: this.muzzlePos(h), gain: 0.8, ref: 1.5 });
          if (d.pump) h.pumpT = d.pump;
        }
      }
      return;
    }
    const k = r.t / r.dur;
    if (r.phase === 0 && k > 0.55) { r.phase = 1; g.audio.play('mag_in', { pos: this.muzzlePos(h), gain: 0.9, ref: 1.5 }); }
    if (r.phase === 1 && k > 0.85) { r.phase = 2; g.audio.play('cock', { pos: this.muzzlePos(h), gain: 0.9, ref: 1.5 }); h.rackT = 0.15; }
    if (k >= 1) {
      const need = d.mag + (st.mag > 0 ? 1 : 0) - st.mag; const take = Math.min(need, st.reserve);          // round left in the chamber on a tactical reload
      st.mag += take; st.reserve -= take; h.reload = null;
      g.ui && g.ui.refreshAmmo();
    }
  }

  animateModel(h, dt) {
    const m = h.model, p = m.parts, d = h.def;
    if (p.slide) { const empty = h.state.mag <= 0 && !h.reload; const rack = h.rackT > 0 ? Math.sin((h.rackT / 0.15) * Math.PI) : 0; p.slide.position.z = p.slideRest + (empty ? 0.045 : h.slideK * 0.04 + rack * 0.035); }
    if (p.bolt) { const rack = h.rackT > 0 ? Math.sin((h.rackT / 0.15) * Math.PI) : 0; p.bolt.position.z = p.boltRest + h.slideK * 0.035 + rack * 0.04; }
    if (h.rackT > 0) h.rackT -= dt;
    if (p.cylinder) { p.cylinder.rotation.z = damp(p.cylinder.rotation.z, h.cylRot, 24, dt); }
    if (p.hammer) p.hammer.rotation.x = -0.3 + h.hammerK * 0.5;
    if (p.pump) {
      if (h.pumpT > 0) { h.pumpT -= dt; const k = 1 - h.pumpT / d.pump; const s = Math.sin(clamp(k, 0, 1) * Math.PI); p.pump.position.z = p.pumpRest + s * 0.1; if (k > 0.45 && !h.pumped) { h.pumped = true; this.game.audio.play('cock', { pos: this.muzzlePos(h), gain: 0.8, ref: 1.5 }); } }
      else { p.pump.position.z = p.pumpRest; h.pumped = false; }
    }
    // magazine drop / insert animation
    if (p.mag) {
      const r = h.reload && !h.reload.single ? h.reload : null;
      const rest = p.mag.userData.rest || (p.mag.userData.rest = p.mag.position.clone());
      if (r) {
        const k = r.t / r.dur;
        let off = 0, vis = true;
        if (k < 0.25) off = k / 0.25; else if (k < 0.55) { off = 1; vis = false; } else if (k < 0.8) { off = 1 - (k - 0.55) / 0.25; } else off = 0;
        p.mag.position.set(rest.x, rest.y - off * 0.2, rest.z + off * 0.03); p.mag.visible = vis;
      } else { p.mag.position.copy(rest); p.mag.visible = !h.magOut; }
    }
  }

  // ---------------------------------------------------------------- desktop viewmodel
  updateDesktopViewmodel(dt) {
    const g = this.game, h = this.holders[0], p = g.player;
    const av = g.avatar;
    const visible = !g.camera_ctrl.third && !g.vr.active && !g.health.dead;
    if (!h.model) { av.ik.forEach((a) => { a.up.visible = a.fo.visible = a.elbow.visible = false; }); return; }
    h.model.root.visible = visible;
    const d = h.def;
    const hip = d.hip, ads = d.adsPos;
    const k = h.ads;
    const sprintLower = p.sprinting ? 1 : 0;
    this._sprintK = damp(this._sprintK || 0, sprintLower, 8, dt);
    const reloadK = h.reload ? 1 : 0; this._reloadK = damp(this._reloadK || 0, reloadK, 8, dt);
    const t = performance.now() * 0.001;
    const sway = Math.sin(t * (1.5 + p.speedH * 0.5)) * 0.004 * Math.min(1, p.speedH / 8) * (1 - k);
    const x = hip[0] * (1 - k) + ads[0] * k + sway, y = hip[1] * (1 - k) + ads[1] * k + Math.abs(sway) * 1.5 - this._sprintK * 0.05 - this._reloadK * 0.05, z = hip[2] * (1 - k) + ads[2] * k + h.kickZ;
    h.model.root.position.set(x, y, z);
    h.model.root.rotation.set(h.kickP * 0.9 + this._sprintK * 0.45 - this._reloadK * 0.25, this._sprintK * 0.55 * 0 + (-this._sprintK * 0.4), this._reloadK * 0.3 + this._sprintK * -0.1);
    // arms (IK from camera-relative shoulders to the grips)
    const cam = g.camera; cam.updateWorldMatrix(true, false);
    h.model.root.updateWorldMatrix(true, true);
    const sh = (sx) => new THREE.Vector3(sx, -0.26, 0.06).applyMatrix4(cam.matrixWorld);
    const gripR = h.model.root.localToWorld(new THREE.Vector3(0.035, -0.01, 0.01));
    const pole = (sx) => new THREE.Vector3(sx * 1.5, -0.7, 0.35).applyMatrix4(cam.matrixWorld);
    if (!g.camera_ctrl.third) av.setMode('fps');
    av.ik[1].up.visible = av.ik[1].fo.visible = av.ik[1].elbow.visible = visible;
    av.solveArm(1, sh(0.2), gripR, pole(0.2));
    // left arm on the foregrip for two-handed weapons, otherwise tucked
    const lv = visible;
    av.ik[0].up.visible = av.ik[0].fo.visible = av.ik[0].elbow.visible = lv;
    const fg = h.model.foregrip ? h.model.root.localToWorld(h.model.foregrip.clone().add(new THREE.Vector3(-0.035, -0.02, 0))) : new THREE.Vector3(-0.2, -0.34, -0.3).applyMatrix4(cam.matrixWorld);
    av.solveArm(0, sh(-0.2), fg, pole(-0.2));
    // desktop hands
    this.setDesktopHands(h, gripR, fg, visible);
  }

  setDesktopHands(h, gripR, fg, visible) {
    if (!this._dh) {
      this._dh = [new HandModel(this.game.world.mats), new HandModel(this.game.world.mats)];
      this._dh[0].root.scale.x = -1;
      for (const x of this._dh) { this.game.world.scene.add(x.root); x.root.traverse((o) => { o.frustumCulled = false; }); }
    }
    const [L, R] = this._dh;
    L.root.visible = R.root.visible = visible && !!h.model;
    if (!h.model) return;
    h.model.root.updateWorldMatrix(true, false);
    const q = h.model.root.getWorldQuaternion(new THREE.Quaternion());
    R.root.position.copy(h.model.root.localToWorld(new THREE.Vector3(0.045, -0.005, 0.02))); R.root.quaternion.copy(q);
    R.curl(h.trigger ? 0.7 : 0.25, 0.95, 0.4);
    if (h.model.foregrip) {
      L.root.position.copy(h.model.root.localToWorld(h.model.foregrip.clone().add(new THREE.Vector3(-0.045, -0.01, 0.0)))); L.root.quaternion.copy(q);
      L.curl(0.9, 0.95, 0.5);
    } else L.root.visible = false;
  }


  // ---------------------------------------------------------------- dropping & summoning (VR)
  /** Drop the weapon in hand `hi` into the world with the hand's velocity. It stays in the inventory and can be summoned back. */
  dropWeapon(hi, pos, quat, vel) {
    const h = this.holders[hi]; if (!h.model) return false;
    const id = h.id, m = h.model;
    const root = m.root;
    this.equip(hi, null);
    m.flash.visible = false;
    // equip(null) removed the model from its parent; re-add as a free object
    this.game.world.scene.add(root); root.visible = true;
    root.position.copy(pos); root.quaternion.copy(quat);
    root.traverse((o) => { o.frustumCulled = false; });
    const d = { id, model: m, root, vel: vel.clone().multiplyScalar(0.9), spin: new THREE.Vector3((Math.random() - 0.5) * 6, (Math.random() - 0.5) * 6, (Math.random() - 0.5) * 6), grounded: false, summon: -1, t: 0 };
    this.dropped.push(d);
    while (this.dropped.length > 6) this.discardDropped(this.dropped[0]);
    this.game.audio.play('clank', { pos, gain: 0.35, rate: 1.5, hrtf: false });
    return true;
  }
  discardDropped(d) { d.root.removeFromParent(); const i = this.dropped.indexOf(d); if (i >= 0) this.dropped.splice(i, 1); }

  /** closest dropped weapon to the hand: either within reach or along the pointing ray */
  findDropped(origin, dir, palm, maxD = 14) {
    let best = null, bs = 1e9;
    for (const d of this.dropped) {
      if (d.summon >= 0) continue;
      const to = new THREE.Vector3().subVectors(d.root.position, origin);
      const dist = to.length();
      const near = palm.distanceTo(d.root.position) < 0.5;
      if (!near) {
        if (dist > maxD || dist < 0.05) continue;
        const ang = Math.acos(THREE.MathUtils.clamp(to.dot(dir) / dist, -1, 1));
        if (ang > 0.22) continue;                      // ~12.5 degree cone
        if (ang * dist < bs) { bs = ang * dist; best = d; }
      } else return d;
    }
    return best;
  }
  summon(d, hi) { d.summon = hi; d.grounded = false; d.t = 0; this.game.audio.play('slide', { gain: 0.5, rate: 1.7, hrtf: false }); }

  updateDropped(dt) {
    const g = this.game, w = g.world.collision, vr = g.vr;
    for (const d of this.dropped.slice()) {
      const r = d.root; d.t += dt;
      if (d.summon >= 0) {
        // fly into the hand: ease toward the palm, spin to match the hand orientation, equip on arrival
        const hand = vr.hands[d.summon];
        if (!hand || !vr.active || hand.holder.model) { d.summon = -1; continue; }
        const target = hand.palm;
        const to = new THREE.Vector3().subVectors(target, r.position); const dist = to.length();
        const sp = Math.min(dist / Math.max(dt, 1e-3), 6 + d.t * 28 + dist * 5);
        if (dist < 0.1 || sp * dt >= dist) {
          g.weapons.discardDropped(d);
          if (this.equip(d.summon, d.id)) { g.audio.play('weaponPickup', { gain: 0.5, rate: 1.4, hrtf: false }); vr.pulseHand(d.summon, 0.6, 50); }
          continue;
        }
        d.vel.copy(to).multiplyScalar(sp / dist);
        r.position.addScaledVector(d.vel, dt);
        r.quaternion.slerp(hand.quat, Math.min(1, dt * 10));
        continue;
      }
      if (!d.grounded) {
        d.vel.y -= 22 * dt;
        const nx = r.position.x + d.vel.x * dt, ny = r.position.y + d.vel.y * dt, nz = r.position.z + d.vel.z * dt;
        const gy = w.groundBelow(nx, ny + 0.4, nz, 0.1, 0.3);
        r.position.set(nx, ny, nz);
        if (gy > -1e8 && ny < gy + 0.05 && d.vel.y < 0) {
          r.position.y = gy + 0.05;
          if (d.vel.y < -3) { d.vel.y *= -0.3; d.vel.x *= 0.6; d.vel.z *= 0.6; d.spin.multiplyScalar(0.5); g.audio.play('clank', { pos: r.position, gain: 0.4, rate: 1.2, hrtf: false, minGap: 0.1 }); }
          else { d.grounded = true; d.vel.set(0, 0, 0); }
        }
        r.rotation.x += d.spin.x * dt; r.rotation.y += d.spin.y * dt; r.rotation.z += d.spin.z * dt;
      } else {
        // lie flat-ish on its side
        r.rotation.x += (0 - r.rotation.x) * Math.min(1, dt * 6); r.rotation.z += (Math.PI / 2 - r.rotation.z) * Math.min(1, dt * 6);
      }
      // wandered too far from the player: send it back to the holster
      if (d.t > 1 && Math.hypot(r.position.x - g.player.pos.x, r.position.z - g.player.pos.z) > 90) this.discardDropped(d);
      if (r.position.y < -40) this.discardDropped(d);
    }
  }

  // ---------------------------------------------------------------- holsters (VR)
  updateHolsters(head, yaw, hidden) {
    const sy = Math.sin(yaw), cy = Math.cos(yaw);
    for (const id of Object.keys(this.holsterModels)) {
      const m = this.holsterModels[id];
      const held = this.held(id) || this.dropped.some((d) => d.id === id);
      const show = !hidden && this.inv.has(id) && !held;
      m.root.visible = show;
      if (!show) continue;
      const z = HOLSTERS[WEAPONS[id].holster];
      // body-yaw frame: x right, z back
      const wx = head.x + z[0] * cy + z[2] * sy, wz = head.z - z[0] * sy + z[2] * cy;
      m.root.position.set(wx, head.y + z[1], wz);
      const back = ['backR', 'backL'].includes(WEAPONS[id].holster), chest = ['chestL', 'chestR'].includes(WEAPONS[id].holster);
      m.root.rotation.set(back ? 0.0 : chest ? 0.1 : 0, yaw + (back ? Math.PI * 0 : 0), back ? Math.PI / 2 - 0.2 : 0);
      if (back) m.root.rotation.order = 'YXZ';
    }
  }
  holsterWorldPos(id) { const m = this.holsterModels[id]; return m && m.root.visible ? m.root.getWorldPosition(new THREE.Vector3()) : null; }
}
