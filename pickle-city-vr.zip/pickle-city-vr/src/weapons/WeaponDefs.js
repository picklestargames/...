// Weapon definitions. Names/designs are original; numbers tuned so each weapon plays differently.
// Units: dmg per pellet, rpm, spread in radians (cone half-angle), recoil kicks in radians (desktop view) / metres (VR hand).
export const WEAPONS = {
  pistol: {
    id: 'pistol', vel: 210, name: 'PEBBLE-9 COMPACT', slot: 0, auto: false, rpm: 420, dmg: 24, pellets: 1, spread: 0.007, moveSpread: 0.018, bloom: 0.0025, bloomMax: 0.02,
    mag: 12, reserve: 96, reload: 'mag', reloadTime: 1.35, range: 150, sound: 'shot_pistol', haptic: 0.55, twoHand: false,
    kickV: 0.017, kickH: 0.004, handKick: 0.022, zoom: 1.1, adsPos: [0, -0.071, -0.28], hip: [0.17, -0.17, -0.34], holster: 'hipR', color: 0xffd36a, tracer: 0.7,
  },
  revolver: {
    id: 'revolver', vel: 260, name: 'BIG DILL .44', slot: 1, auto: false, rpm: 150, dmg: 64, pellets: 1, spread: 0.0035, moveSpread: 0.016, bloom: 0.006, bloomMax: 0.03,
    mag: 6, reserve: 48, reload: 'single', reloadTime: 0.42, reloadIntro: 0.5, range: 190, sound: 'shot_revolver', haptic: 0.9, twoHand: false,
    kickV: 0.05, kickH: 0.01, handKick: 0.05, zoom: 1.15, adsPos: [0, -0.078, -0.31], hip: [0.17, -0.18, -0.36], holster: 'hipL', color: 0xffb04a, tracer: 0.9,
  },
  smg: {
    id: 'smg', vel: 230, name: 'BRINE-9 SMG', slot: 2, auto: true, rpm: 880, dmg: 11, pellets: 1, spread: 0.014, moveSpread: 0.03, bloom: 0.0035, bloomMax: 0.05,
    mag: 32, reserve: 192, reload: 'mag', reloadTime: 1.7, range: 110, sound: 'shot_smg', haptic: 0.3, twoHand: true,
    kickV: 0.007, kickH: 0.005, handKick: 0.012, zoom: 1.25, adsPos: [0, -0.082, -0.34], hip: [0.18, -0.17, -0.36], holster: 'chestL', color: 0xffe08a, tracer: 0.5,
  },
  rifle: {
    id: 'rifle', vel: 420, name: 'GHERKIN AR-30', slot: 3, auto: true, rpm: 640, dmg: 19, pellets: 1, spread: 0.0075, moveSpread: 0.025, bloom: 0.002, bloomMax: 0.03,
    mag: 30, reserve: 210, reload: 'mag', reloadTime: 2.1, range: 220, sound: 'shot_rifle', haptic: 0.5, twoHand: true,
    kickV: 0.012, kickH: 0.006, handKick: 0.018, zoom: 1.45, adsPos: [0, -0.09, -0.36], hip: [0.19, -0.18, -0.38], holster: 'backR', color: 0xffcf70, tracer: 0.8,
  },
  shotgun: {
    id: 'shotgun', vel: 200, name: 'BRINE-BUSTER 12', slot: 4, auto: false, rpm: 75, dmg: 9, pellets: 9, spread: 0.055, moveSpread: 0.012, bloom: 0, bloomMax: 0.0,
    mag: 6, reserve: 42, reload: 'single', reloadTime: 0.48, reloadIntro: 0.35, pump: 0.42, range: 60, sound: 'shot_shotgun', haptic: 1.0, twoHand: true,
    kickV: 0.045, kickH: 0.012, handKick: 0.06, zoom: 1.15, adsPos: [0, -0.085, -0.34], hip: [0.19, -0.2, -0.4], holster: 'backL', color: 0xffa84a, tracer: 0.45,
  },
  marksman: {
    id: 'marksman', vel: 500, name: 'LONG-HAUL DMR', slot: 5, auto: false, rpm: 120, dmg: 78, pellets: 1, spread: 0.0012, moveSpread: 0.03, bloom: 0.004, bloomMax: 0.02,
    mag: 8, reserve: 56, reload: 'mag', reloadTime: 2.4, range: 420, sound: 'shot_marksman', haptic: 0.85, twoHand: true, scope: true,
    kickV: 0.03, kickH: 0.006, handKick: 0.035, zoom: 3.2, adsPos: [0, -0.108, -0.42], hip: [0.19, -0.19, -0.42], holster: 'chestR', color: 0xffe9b0, tracer: 1.0,
  },
};
export const WEAPON_LIST = Object.values(WEAPONS).sort((a, b) => a.slot - b.slot);

// holster zones relative to the head in the body-yaw frame: [x, y, z] metres (-z = in front)
export const HOLSTERS = {
  hipR: [0.26, -0.78, 0.04], hipL: [-0.26, -0.78, 0.04],
  chestL: [-0.2, -0.34, -0.12], chestR: [0.2, -0.34, -0.12],
  backR: [0.22, 0.12, 0.2], backL: [-0.22, 0.12, 0.2],
};
