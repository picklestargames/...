// Your apartment: you start the game here. It floats high above the spawn intersection (collision boxes via the dynamic list);
// walk out the door, down the hall and through the EXIT to arrive on the street of Pickle City.
import * as THREE from 'three';
import { SPAWN } from '../world/Constants.js';
import { clamp } from '../core/Utils.js';

const AX = SPAWN.x, AZ = SPAWN.z, AY = 300;
const HALL = { x0: 3.05, x1: 4.15, z1: 6.6 };

function woodTexture() {
  const c = document.createElement('canvas'); c.width = c.height = 512; const x = c.getContext('2d');
  for (let i = 0; i < 8; i++) {
    const h = 28 + (i * 37 % 14); x.fillStyle = `hsl(${28 + (i * 7 % 6)},${38 + (i % 3) * 4}%,${38 + (i * 13 % 10)}%)`; x.fillRect(0, i * 64, 512, 62);
    for (let k = 0; k < 40; k++) { x.fillStyle = `rgba(60,30,10,${0.04 + (k % 5) * 0.015})`; x.fillRect((k * 53 + i * 91) % 512, i * 64 + (k * 17 % 60), 60 + (k * 31 % 120), 1); }
    x.fillStyle = 'rgba(20,10,0,0.55)'; x.fillRect(0, i * 64 + 62, 512, 2);
    for (let j = 0; j < 3; j++) { x.fillRect(((i * 211 + j * 173) % 512), i * 64, 2, 62); }
  }
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; return t;
}
function labelTexture(text, bg, fg, w = 256, h = 96, size = 64) {
  const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d');
  x.fillStyle = bg; x.fillRect(0, 0, w, h); x.fillStyle = fg; x.font = `bold ${size}px system-ui, sans-serif`; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(text, w / 2, h / 2 + 2);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}

export class ApartmentSystem {
  constructor(game) {
    this.game = game;
    this.inside = false; this.exitT = -1; this.welcomeT = 0;
    this.boxes = [];            // visual boxes: [cx,cy,cz,sx,sy,sz,color]
    this.build();
  }

  col(x0, y0, z0, x1, y1, z1) { this.game.world.collision.addDyn(AX + x0, AY + y0, AZ + z0, AX + x1, AY + y1, AZ + z1); }
  /** visible + solid box in apartment-local coords */
  solid(x0, y0, z0, x1, y1, z1, color, collide = true) {
    this.boxes.push([(x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2, x1 - x0, y1 - y0, z1 - z0, color]);
    if (collide) this.col(x0, y0, z0, x1, y1, z1);
  }

  build() {
    const g = this.game, scene = g.world.scene, W = 0xece6da, T = 0.2, H = 2.8;
    const root = this.root = new THREE.Group(); root.position.set(AX, AY, AZ); scene.add(root);
    // ---- shell: floor / ceiling / walls (with window and door openings)
    this.col(-5.4, -0.6, -4.4, 5.4, 0, 4.4); this.col(HALL.x0 - 0.2, -0.6, 4, HALL.x1 + 0.2, 0, HALL.z1 + 0.2);
    this.solid(-5.2, H, -4.2, 5.2, H + 0.2, 4.2, 0xf4f0e8);                                  // ceiling
    this.solid(HALL.x0, H, 4, HALL.x1, H + 0.2, HALL.z1, 0xf4f0e8);                         // hall ceiling
    // north wall (z=-4) with two windows x∈[-4,-1.5],[1.5,4], sill .9 – head 2.3
    const nz0 = -4.2, nz1 = -4.0;
    this.solid(-5.2, 0, nz0, -4, H, nz1, W); this.solid(-1.5, 0, nz0, 1.5, H, nz1, W); this.solid(4, 0, nz0, 5.2, H, nz1, W);
    for (const [a, b] of [[-4, -1.5], [1.5, 4]]) { this.solid(a, 0, nz0, b, 0.9, nz1, W); this.solid(a, 2.3, nz0, b, H, nz1, W); this.col(a, 0.9, nz0, b, 2.3, nz1); this.solid(a - 0.05, 0.86, nz0 - 0.05, b + 0.05, 0.94, nz1 + 0.15, 0xffffff, false); }
    this.solid(-5.2, 0, -4.2, -5.0, H, 4.2, W);                                              // west wall
    this.solid(5.0, 0, -4.2, 5.2, H, 4.2, W);                                                // east wall
    // south wall (z=4) with the door opening x∈[3.05,4.15]
    this.solid(-5.2, 0, 4.0, HALL.x0, H, 4.2, W); this.solid(HALL.x1, 0, 4.0, 5.2, H, 4.2, W); this.solid(HALL.x0, 2.15, 4.0, HALL.x1, H, 4.2, W);
    // door frame + open door leaf swung against the wall
    this.solid(HALL.x0 - 0.06, 0, 3.95, HALL.x0, 2.15, 4.25, 0x4a3524, false); this.solid(HALL.x1, 0, 3.95, HALL.x1 + 0.06, 2.15, 4.25, 0x4a3524, false);
    this.solid(HALL.x1 + 0.0, 0, 4.25, HALL.x1 + 0.05, 2.05, 5.2, 0x6b4a2f, false);
    // hallway walls + end wall
    this.solid(HALL.x0 - 0.2, 0, 4.2, HALL.x0, H, HALL.z1 + 0.2, W); this.solid(HALL.x1, 0, 4.2, HALL.x1 + 0.2, H, HALL.z1 + 0.2, W); this.solid(HALL.x0, 0, HALL.z1, HALL.x1, H, HALL.z1 + 0.2, W);
    // baseboards
    for (const [x0, z0, x1, z1] of [[-5, -4, 5, -3.92], [-5, 3.92, 3.05, 4], [4.15, 3.92, 5, 4], [-5, -4, -4.92, 4], [4.92, -4, 5, 4]]) this.solid(x0, 0, z0, x1, 0.12, z1, 0x3a2c22, false);
    // ---- furniture
    const col = { sofa: 0x4f6d7a, cush: 0x5d7f8d, wood: 0x7a5233, dark: 0x2a2a2e, white: 0xf2f2f2, steel: 0x9aa3ab, bed: 0xd9d4ea, plant: 0x2f7d32, pot: 0xb5654a };
    // sofa (faces west toward the TV)
    this.solid(-2.3, 0.0, -1.5, -1.3, 0.42, 1.5, col.sofa); this.solid(-1.45, 0.42, -1.5, -1.25, 0.95, 1.5, col.sofa); this.solid(-2.3, 0.42, -1.5, -1.3, 0.62, -1.2, col.cush, false); this.solid(-2.3, 0.42, 1.2, -1.3, 0.62, 1.5, col.cush, false);
    this.solid(-2.25, 0.42, -1.2, -1.45, 0.58, 1.2, col.cush, false);
    // coffee table + things on it
    this.solid(-3.6, 0.0, -0.6, -2.8, 0.42, 0.6, col.wood); this.solid(-3.5, 0.42, -0.2, -3.2, 0.5, 0.15, 0xc9a24a, false);
    // TV unit + TV
    this.solid(-4.95, 0, -1.4, -4.55, 0.5, 1.4, col.wood); this.solid(-4.9, 0.5, -0.9, -4.86, 1.35, 0.9, col.dark, false);
    // bookshelf (south wall) with coloured books
    this.solid(-1.6, 0, 3.6, 0.6, 2.0, 3.95, col.wood);
    for (let s = 0; s < 4; s++) for (let k = 0; k < 9; k++) this.solid(-1.5 + k * 0.23, 0.15 + s * 0.45, 3.5, -1.5 + k * 0.23 + 0.17, 0.5 + s * 0.45 - (k % 3) * 0.03, 3.6, [0xb03a2e, 0x2e6fb0, 0xc8902a, 0x2e8b57, 0x6c3a8e][(k + s) % 5], false);
    // bed in the south-west corner
    this.solid(-4.85, 0.0, 1.9, -2.85, 0.4, 3.9, 0x5a4332); this.solid(-4.8, 0.4, 2.0, -2.9, 0.62, 3.85, col.bed); this.solid(-4.8, 0.62, 3.3, -3.9, 0.75, 3.8, col.white, false); this.solid(-3.8, 0.62, 3.3, -2.9, 0.75, 3.8, col.white, false); this.solid(-4.85, 0.4, 3.85, -2.85, 1.2, 3.95, 0x5a4332);
    // nightstand
    this.solid(-2.7, 0, 3.4, -2.25, 0.5, 3.9, col.wood); this.solid(-2.58, 0.5, 3.55, -2.4, 0.58, 3.75, 0xffd88a, false);
    // kitchen: counter along the east wall, fridge, sink, stove
    this.solid(4.4, 0, -3.0, 5.0, 0.9, 0.0, 0xd9d4c8); this.solid(4.35, 0.9, -3.0, 5.0, 0.95, 0.0, 0x3b3f44); this.solid(4.4, 0, -3.95, 5.0, 2.0, -3.1, col.steel);
    this.solid(4.6, 0.95, -2.4, 4.95, 1.0, -1.7, 0x2a2e33, false); this.solid(4.55, 0.95, -0.9, 4.95, 1.0, -0.2, 0x151515, false);
    this.solid(4.4, 1.5, -3.0, 5.0, 2.2, 0.0, 0xe8e2d4, false);
    // dining table + chairs
    this.solid(1.8, 0.7, -2.2, 3.2, 0.78, -0.8, col.wood); for (const [x, z] of [[1.95, -2.05], [3.05, -2.05], [1.95, -0.95], [3.05, -0.95]]) this.solid(x - 0.04, 0, z - 0.04, x + 0.04, 0.7, z + 0.04, col.dark, false);
    this.col(1.8, 0, -2.2, 3.2, 0.78, -0.8);
    for (const [x, z] of [[2.2, -2.6], [2.8, -2.6], [2.2, -0.4], [2.8, -0.4]]) { this.solid(x - 0.22, 0.42, z - 0.22, x + 0.22, 0.48, z + 0.22, 0x8a8f96, false); this.solid(x - 0.22, 0.48, z + (z < -1.5 ? -0.22 : 0.18), x + 0.22, 0.95, z + (z < -1.5 ? -0.18 : 0.22), 0x8a8f96, false); this.col(x - 0.22, 0, z - 0.22, x + 0.22, 0.5, z + 0.22); }
    // plant, floor lamp, wall art, desk
    this.solid(-4.8, 0, -3.8, -4.3, 0.38, -3.3, col.pot); this.solid(-4.95, 0.38, -3.95, -4.15, 1.3, -3.15, col.plant, false);
    this.solid(-0.9, 0, -1.6, -0.8, 1.55, -1.5, col.dark, false); this.solid(-1.05, 1.55, -1.75, -0.65, 1.85, -1.35, 0xfff1c9, false);
    this.solid(-3.5, 1.2, -4.0, -2.0, 2.0, -3.96, 0xffffff, false); this.solid(-3.4, 1.28, -3.99, -2.1, 1.92, -3.95, 0x3d8a3a, false);
    this.solid(4.9, 1.2, 1.0, 4.98, 2.0, 2.4, 0xc86a2c, false);
    this.solid(0.8, 0.72, 2.9, 2.2, 0.78, 3.7, col.wood); this.solid(0.85, 0, 2.95, 0.93, 0.72, 3.0, col.dark, false); this.solid(2.07, 0, 3.6, 2.15, 0.72, 3.65, col.dark, false); this.col(0.8, 0, 2.9, 2.2, 0.78, 3.7);
    this.solid(1.1, 0.78, 3.05, 1.7, 0.80, 3.55, 0x2a2a2e, false); this.solid(1.2, 0.8, 3.45, 1.6, 1.15, 3.5, 0x111418, false);
    this.solid(1.5, 0, 2.2, 2.0, 0.45, 2.7, 0x3a3f46, false); this.col(1.5, 0, 2.2, 2.0, 0.45, 2.7);
    // ---- realism pass: trim, window dressing, a proper kitchen, workspace, bedroom and entry details
    const mats = {}, M = (c, r = 0.7, m = 0.05, e = 0) => mats[c + '_' + r + '_' + m + '_' + e] || (mats[c + '_' + r + '_' + m + '_' + e] = new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m, emissive: e ? c : 0x000000, emissiveIntensity: e }));
    const cyl = (r, h, c, x, y, z, o = {}) => { const me = new THREE.Mesh(new THREE.CylinderGeometry(o.r2 ?? r, r, h, o.n || 16), M(c, o.rough ?? 0.6, o.metal ?? 0.1, o.em || 0)); me.position.set(x, y + h / 2, z); if (o.rx) me.rotation.x = o.rx; if (o.rz) me.rotation.z = o.rz; root.add(me); return me; };
    const sph = (r, c, x, y, z, sy = 1, o = {}) => { const me = new THREE.Mesh(new THREE.SphereGeometry(r, 14, 10), M(c, o.rough ?? 0.8, 0)); me.position.set(x, y, z); me.scale.y = sy; root.add(me); return me; };
    // crown moulding, ceiling coffer beams, accent wall
    for (const [x0, z0, x1, z1] of [[-5, -4, 5, -3.9], [-5, 3.9, 3.05, 4], [4.15, 3.9, 5, 4], [-5, -4, -4.9, 4], [4.9, -4, 5, 4]]) this.solid(x0, H - 0.14, z0, x1, H, z1, 0xfaf7f0, false);
    for (const x of [-3.5, 0, 3.5]) this.solid(x - 0.12, H - 0.16, -4, x + 0.12, H, 4, 0xf0ebe0, false);
    this.solid(-5.0, 0.12, -3.9, -4.97, H - 0.14, 3.9, 0x4e6f80, false);                       // teal accent wall behind the TV
    this.solid(-5.0, 1.05, -3.9, -4.96, 1.1, 3.9, 0xf2ede2, false);                            // chair rail
    // windows: frames, mullions, sills, curtains + rods, radiators
    for (const [a, b] of [[-4, -1.5], [1.5, 4]]) {
      const m2 = (a + b) / 2;
      this.solid(a, 0.9, -4.02, a + 0.06, 2.3, -3.95, 0xf4f1ea, false); this.solid(b - 0.06, 0.9, -4.02, b, 2.3, -3.95, 0xf4f1ea, false);
      this.solid(a, 2.24, -4.02, b, 2.3, -3.95, 0xf4f1ea, false); this.solid(a, 0.9, -4.02, b, 0.96, -3.95, 0xf4f1ea, false);
      this.solid(m2 - 0.025, 0.96, -4.04, m2 + 0.025, 2.24, -3.96, 0xf4f1ea, false); this.solid(a, 1.55, -4.04, b, 1.6, -3.96, 0xf4f1ea, false);
      this.solid(a - 0.4, 0.0, -3.9, a - 0.05, 2.4, -3.8, 0xb8a58a, false); this.solid(b + 0.05, 0.0, -3.9, b + 0.4, 2.4, -3.8, 0xb8a58a, false);
      for (let k = 0; k < 6; k++) { this.solid(a - 0.4 + (k % 2) * 0.02, 0.0, -3.9 - (k % 2) * 0.02, a - 0.05, 2.4, -3.8, 0xc4b194, false); }
      this.solid(a - 0.5, 2.38, -3.95, b + 0.5, 2.43, -3.9, 0x3a3128, false);                    // rod
      this.solid(m2 - 0.6, 0.12, -3.9, m2 + 0.6, 0.78, -3.8, 0xeeeeea, false);                   // radiator
      for (let k = 0; k < 9; k++) this.solid(m2 - 0.55 + k * 0.125, 0.14, -3.905, m2 - 0.5 + k * 0.125, 0.76, -3.8, 0xdcdcd6, false);
    }
    // entry: door leaf detail, handle, peephole, coat rack, shoe rack, mirror, console, switches
    this.solid(HALL.x1 + 0.0, 1.0, 4.26, HALL.x1 + 0.07, 1.06, 4.4, 0xc9a24a, false);
    this.solid(3.15, 0.0, 3.2, 3.9, 0.22, 3.7, 0x2a2420, false); for (let k = 0; k < 3; k++) this.solid(3.2 + k * 0.22, 0.22, 3.3, 3.3 + k * 0.22, 0.3, 3.55, [0xb03a2e, 0x1f1f22, 0x4a6a8a][k], false);
    this.solid(4.3, 1.5, 3.5, 4.34, 1.7, 3.95, 0x6b4a2f, false); for (let k = 0; k < 4; k++) { this.solid(4.3 + 0.0, 1.55, 3.55 + k * 0.1, 4.45, 1.6, 3.57 + k * 0.1, 0xc9a24a, false); }
    this.solid(4.38, 1.1, 3.55, 4.48, 1.5, 3.62, 0x35506a, false); this.solid(4.38, 1.08, 3.8, 4.5, 1.52, 3.86, 0xb03a2e, false);
    this.solid(3.3, 1.2, 3.97, 4.0, 2.1, 3.99, 0xdfe6ea, false); this.solid(3.27, 1.17, 3.96, 4.03, 2.13, 3.975, 0x4a3524, false);   // mirror + frame
    this.solid(3.35, 0.0, 3.55, 4.0, 0.8, 3.95, 0x7a5233, true); this.solid(3.5, 0.8, 3.7, 3.6, 0.95, 3.8, 0xc9a24a, false);
    this.solid(3.0, 1.2, 3.8, 3.04, 1.32, 3.88, 0xf4f4f4, false); this.solid(3.0, 0.3, 3.2, 3.04, 0.4, 3.28, 0xf4f4f4, false);
    // kitchen: cabinet doors + handles, worktop edge, splashback, sink, hob, hood, microwave, kettle, toaster, fruit bowl, fridge handles
    for (let z = -3.0; z < -0.01; z += 0.5) { this.solid(4.38, 0.08, z + 0.02, 4.4, 0.86, z + 0.48, 0xd2ccbe, false); this.solid(4.355, 0.55, z + 0.4, 4.385, 0.7, z + 0.43, 0x9aa3ab, false); }
    for (let z = -3.0; z < -0.01; z += 0.75) { this.solid(4.38, 1.5, z + 0.02, 4.42, 2.2, z + 0.73, 0xe2dccf, false); this.solid(4.355, 1.55, z + 0.62, 4.385, 1.7, z + 0.65, 0x9aa3ab, false); }
    this.solid(4.95, 0.95, -3.0, 5.0, 1.5, 0.0, 0xcfe0e4, false);
    this.solid(4.55, 0.945, -2.4, 4.95, 0.975, -1.7, 0xbfc5cb, false); cyl(0.2, 0.01, 0x1a1c1f, 4.75, 0.95, -2.05, { metal: 0.6 });
    cyl(0.018, 0.26, 0xaab2b8, 4.9, 0.97, -2.05, { metal: 0.9, n: 8 }); this.solid(4.82, 1.22, -2.05, 4.9, 1.26, -2.05 + 0.2, 0xaab2b8, false);
    for (const [bx, bz] of [[4.65, -0.7], [4.65, -0.4], [4.85, -0.7], [4.85, -0.4]]) cyl(0.07, 0.015, 0x111111, bx, 0.96, bz, { metal: 0.4, n: 14 });
    this.solid(4.55, 1.45, -1.0, 4.98, 1.9, -0.1, 0x9aa0a6, false);                                  // hood
    this.solid(4.55, 0.95, -2.9, 5.0, 1.25, -2.4, 0x25282c, false); this.solid(4.58, 1.0, -2.88, 4.7, 1.2, -2.42, 0x0d1013, false); this.solid(4.52, 1.05, -2.8, 4.56, 1.1, -2.7, 0x444a50, false);   // microwave
    cyl(0.07, 0.2, 0xd8d8d4, 4.75, 0.95, -1.4, { metal: 0.5 }); this.solid(4.8, 0.95, -1.15, 4.95, 1.07, -0.95, 0xb0b6bc, false);
    sph(0.13, 0xc84a2a, 4.7, 1.0, -0.5 + -0.1, 0.8); sph(0.1, 0xe8c030, 4.78, 1.0, -0.62, 0.8); cyl(0.15, 0.05, 0x2f6a8a, 4.74, 0.95, -0.55, { n: 14 });
    this.solid(4.38, 0.9, -3.5, 4.4, 1.8, -3.49, 0x555b61, false); this.solid(4.36, 1.0, -3.2, 4.4, 1.5, -3.15, 0x1a1c1f, false); this.solid(4.36, 0.5, -3.2, 4.4, 0.9, -3.15, 0x1a1c1f, false);     // fridge handles
    // dining: place settings, vase with flowers, pendant lamp
    for (const [x, z] of [[2.2, -2.0], [2.8, -2.0], [2.2, -1.0], [2.8, -1.0]]) { cyl(0.12, 0.012, 0xf4f4f4, x, 0.78, z, { n: 14 }); this.solid(x - 0.22, 0.78, z - 0.16, x - 0.18, 0.795, z + 0.16, 0xb8a58a, false); }
    cyl(0.05, 0.2, 0x3a6a8a, 2.5, 0.78, -1.5, { n: 10, rough: 0.2 }); for (let k = 0; k < 5; k++) sph(0.05, [0xe84a6a, 0xf0c030, 0xf4f4f4, 0xe84a6a, 0xc050d0][k], 2.5 + (k - 2) * 0.03, 1.02 + (k % 2) * 0.04, -1.5 + ((k * 7) % 3 - 1) * 0.03, 1);
    cyl(0.004, 0.55, 0x222222, 2.5, 2.25, -1.5, { n: 4 }); cyl(0.3, 0.25, 0xe8d8a8, 2.5, 1.98, -1.5, { r2: 0.1, n: 18, rough: 0.5 }); cyl(0.07, 0.04, 0xfff2c0, 2.5, 1.97, -1.5, { em: 1, n: 10 });
    // living room: cushions, throw, TV details, console, books, mug, plant, lamp shade, wall art + shelf
    for (const [z, c] of [[-1.2, 0xc9a24a], [1.2, 0xb04a3a], [-0.1, 0xe8e0d0]]) this.solid(-2.25, 0.62, z - 0.2, -1.95, 0.9, z + 0.2, c, false);
    this.solid(-2.2, 0.62, 0.5, -1.4, 0.66, 1.3, 0x8a3a3a, false);
    this.solid(-4.9, 1.35, -0.95, -4.84, 1.4, 0.95, 0x16181b, false); this.solid(-4.9, 0.5, -0.45, -4.78, 0.6, 0.45, 0x1a1a1e, false); this.solid(-4.9, 0.6, 0.55, -4.76, 0.7, 0.85, 0x2f3338, false);
    this.solid(-3.5, 0.5, -0.45, -3.35, 0.56, -0.1, 0x2e6fb0, false); this.solid(-3.4, 0.5, 0.05, -3.2, 0.54, 0.4, 0xb03a2e, false); cyl(0.045, 0.09, 0xf0eee8, -3.1, 0.5, 0.35, { n: 10 }); this.solid(-3.3, 0.5, 0.0, -3.2, 0.52, 0.15, 0x1a1a1e, false);
    this.solid(-4.95, 0, 1.8, -4.6, 0.45, 2.1, 0x7a5233, false); sph(0.2, 0x2f7d32, -4.78, 0.75, 1.95, 1.2);
    cyl(0.17, 0.3, 0xf4e6c0, -0.85, 1.55, -1.55, { r2: 0.12, n: 18, em: 0.25, rough: 0.7 }); cyl(0.12, 0.03, 0x222222, -0.85, 0.0, -1.55, { n: 12 });
    this.solid(-0.2, 1.1, -3.97, 0.9, 1.9, -3.95, 0x3a3128, false); this.solid(-0.15, 1.15, -3.96, 0.85, 1.85, -3.94, 0xc8a050, false); this.solid(0.1, 1.3, -3.95, 0.6, 1.7, -3.93, 0x3a6a8a, false);
    this.solid(-1.3, 1.5, 3.75, -0.3, 1.55, 3.95, 0x7a5233, false);                                 // shelf
    this.solid(-4.5, 2.0, -3.98, -3.5, 2.5, -3.96, 0xf0ebe0, false); this.solid(-4.45, 2.05, -3.97, -3.55, 2.45, -3.95, 0xd08040, false);
    // bedroom: headboard, pillows, folded blanket, lamp + clock, rug
    this.solid(-4.85, 0.4, 3.85, -2.85, 1.35, 3.97, 0x6a5240, false); this.solid(-4.7, 0.75, 3.55, -3.95, 0.86, 3.8, 0xf6f4ee, false); this.solid(-3.85, 0.75, 3.55, -3.0, 0.86, 3.8, 0xf6f4ee, false);
    this.solid(-4.8, 0.62, 2.0, -2.9, 0.7, 2.7, 0x3d5a72, false); this.solid(-4.8, 0.7, 2.0, -2.9, 0.74, 2.12, 0xc9a24a, false);
    cyl(0.07, 0.03, 0x222222, -2.5, 0.5, 3.65, { n: 10 }); cyl(0.012, 0.18, 0x222222, -2.5, 0.53, 3.65, { n: 6 }); cyl(0.12, 0.14, 0xf4e6c0, -2.5, 0.71, 3.65, { r2: 0.08, n: 14, em: 0.55 });
    this.solid(-2.65, 0.5, 3.45, -2.5, 0.58, 3.55, 0x16181b, false); this.solid(-2.63, 0.51, 3.545, -2.52, 0.57, 3.552, 0xff4a3a, false);
    this.solid(-3.7, 0.012, 1.2, -2.2, 0.02, 1.9, 0xc9bfa8, false);
    // desk: monitor, keyboard, mug, lamp, pens, chair
    this.solid(1.2, 0.8, 3.4, 1.6, 1.15, 3.44, 0x111418, false); this.solid(1.37, 0.8, 3.42, 1.43, 0.9, 3.48, 0x2a2a2e, false); this.solid(1.2, 0.88, 3.38, 1.6, 1.15, 3.395, 0x2d4a6a, false);
    this.solid(1.2, 0.8, 3.1, 1.6, 0.82, 3.25, 0x25282c, false); cyl(0.04, 0.09, 0xc84a2a, 1.85, 0.78, 3.2, { n: 10 }); cyl(0.05, 0.12, 0x2a2a2e, 0.95, 0.78, 3.45, { n: 8 });
    cyl(0.06, 0.02, 0x222222, 2.0, 0.78, 3.5, { n: 10 }); cyl(0.01, 0.3, 0x222222, 2.0, 0.8, 3.5, { n: 5, rz: 0.4 }); cyl(0.07, 0.07, 0xf0f0e8, 2.1, 1.05, 3.5, { n: 10, r2: 0.03, em: 0.4 });
    this.solid(1.1, 0.78, 2.9, 1.4, 0.8, 3.0, 0xe8e4d8, false);
    cyl(0.25, 0.06, 0x2a2a2e, 1.4, 0.45, 2.55, { n: 14 }); cyl(0.025, 0.4, 0x555a60, 1.4, 0.05, 2.55, { n: 6, metal: 0.8 }); cyl(0.25, 0.05, 0x2a2a2e, 1.4, 0.0, 2.55, { n: 5 });
    // entry/utility details: smoke detector, thermostat, vent, wall sockets
    cyl(0.07, 0.03, 0xf4f4f0, 1.0, H - 0.04, 1.5, { n: 12 }); this.solid(4.9, 1.4, 1.6, 4.94, 1.55, 1.75, 0xe8e8e4, false); this.solid(-0.3, H - 0.03, 2.4, 0.4, H, 2.6, 0xdcdcd6, false);
    for (const [x, z] of [[-4.95, -2.3], [-4.95, 2.2], [1.8, -3.95], [4.95, 1.5]]) this.solid(x - 0.0, 0.3, z - 0.05, x + 0.04, 0.4, z + 0.05, 0xf4f4f0, false);
    // ---- one instanced mesh for every solid
    const inst = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.82, metalness: 0.02 }), this.boxes.length);
    const m = new THREE.Matrix4(), c = new THREE.Color(), q = new THREE.Quaternion(), s = new THREE.Vector3(), p = new THREE.Vector3();
    this.boxes.forEach((b, i) => { p.set(b[0], b[1], b[2]); s.set(b[3], b[4], b[5]); m.compose(p, q, s); inst.setMatrixAt(i, m); inst.setColorAt(i, c.setHex(b[6])); });
    inst.frustumCulled = false; root.add(inst);
    // ---- wood floor, rug, hall floor
    const wt = woodTexture(); wt.repeat.set(5, 4);
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(10.4, 8.4).rotateX(-Math.PI / 2), new THREE.MeshStandardMaterial({ map: wt, roughness: 0.55 })); floor.position.y = 0.002; root.add(floor);
    const wt2 = wt.clone(); wt2.repeat.set(1, 3); wt2.needsUpdate = true;
    const hf = new THREE.Mesh(new THREE.PlaneGeometry(1.5, 2.8).rotateX(-Math.PI / 2), new THREE.MeshStandardMaterial({ map: wt2, roughness: 0.55 })); hf.position.set((HALL.x0 + HALL.x1) / 2, 0.002, 5.4); root.add(hf);
    const rc = document.createElement('canvas'); rc.width = rc.height = 128; const rx = rc.getContext('2d'); rx.fillStyle = '#7a3b3b'; rx.fillRect(0, 0, 128, 128); rx.strokeStyle = '#e8d9a8'; rx.lineWidth = 6; rx.strokeRect(10, 10, 108, 108); rx.strokeStyle = '#c9a24a'; rx.lineWidth = 3; rx.strokeRect(24, 24, 80, 80);
    const rt = new THREE.CanvasTexture(rc); rt.colorSpace = THREE.SRGBColorSpace;
    const rug = new THREE.Mesh(new THREE.PlaneGeometry(3.4, 2.6).rotateX(-Math.PI / 2), new THREE.MeshStandardMaterial({ map: rt, roughness: 1 })); rug.position.set(-2.9, 0.012, 0); root.add(rug);
    // ---- glass in the windows, TV screen, lights, exit sign
    const gl = new THREE.MeshStandardMaterial({ color: 0x9cc7e8, transparent: true, opacity: 0.16, roughness: 0.05, metalness: 0.2, depthWrite: false });
    for (const [a, b] of [[-4, -1.5], [1.5, 4]]) { const w = new THREE.Mesh(new THREE.PlaneGeometry(b - a, 1.4), gl); w.position.set((a + b) / 2, 1.6, -4.1); root.add(w); }
    // the TV is the server browser: aim + trigger (VR) / click or E (desktop) on JOIN SERVER to go out into the city
    this.tvCanvas = document.createElement('canvas'); this.tvCanvas.width = 1024; this.tvCanvas.height = 576;
    this.tvTex = new THREE.CanvasTexture(this.tvCanvas); this.tvTex.colorSpace = THREE.SRGBColorSpace; this.tvTex.anisotropy = 4;
    this.hover = false; this.connecting = false; this._drawn = '';
    this.drawTV();
    const tv = new THREE.Mesh(new THREE.PlaneGeometry(1.7, 0.95), new THREE.MeshBasicMaterial({ map: this.tvTex, toneMapped: false })); tv.position.set(-4.85, 0.9, 0); tv.rotation.y = Math.PI / 2; root.add(tv);
    this._click = false;
    addEventListener('mousedown', () => { this._click = true; });
    addEventListener('keydown', (e) => { if (e.code === 'KeyE' || e.code === 'Enter') this._click = true; });
    this._o = new THREE.Vector3(); this._d = new THREE.Vector3(); this._q = new THREE.Quaternion();
    const em = new THREE.MeshBasicMaterial({ color: 0xfff6dc });
    for (const [x, z] of [[-2.5, -2], [2.5, -2], [-2.5, 2], [2.5, 2], [0, 0]]) { const l = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.04, 0.9), em); l.position.set(x, H - 0.02, z); root.add(l); }
    const hl = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.04, 0.5), em); hl.position.set((HALL.x0 + HALL.x1) / 2, H - 0.02, 5.3); root.add(hl);
    const light = new THREE.PointLight(0xfff0d8, 22, 15, 1.6); light.position.set(0, 2.4, 0); root.add(light);
    const light2 = new THREE.PointLight(0xffe2b8, 6, 7, 1.8); light2.position.set((HALL.x0 + HALL.x1) / 2, 2.3, 5.2); root.add(light2);
    const mat = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 0.5).rotateX(-Math.PI / 2), new THREE.MeshStandardMaterial({ map: labelTexture('HOME', '#3a2a1a', '#d9c9a8', 256, 128, 60), roughness: 1 })); mat.position.set((HALL.x0 + HALL.x1) / 2, 0.012, 4.6); root.add(mat);
    // a beam of light outside the exit so it reads as "the way out"
    this.root.visible = true;
  }

  drawTV() {
    const net = this.game.net, on = !!(net && net.online), cnt = on ? net.count : 1;
    const key = (this.connecting ? 'c' : '') + (this.hover ? 'h' : '') + (on ? 'o' + cnt + net.names.join(',') : 'x');
    if (key === this._drawn) return; this._drawn = key;
    const c = this.tvCanvas, g = c.getContext('2d'), W = c.width, H = c.height;
    const bg = g.createLinearGradient(0, 0, 0, H); bg.addColorStop(0, '#0c2238'); bg.addColorStop(1, '#06111c'); g.fillStyle = bg; g.fillRect(0, 0, W, H);
    g.fillStyle = 'rgba(125,255,122,0.07)'; for (let y = 0; y < H; y += 6) g.fillRect(0, y, W, 2);
    g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillStyle = '#7dff7a'; g.font = 'bold 84px system-ui, sans-serif'; g.fillText('PICKLE CITY', W / 2, 105);
    g.fillStyle = '#9ec7e6'; g.font = '30px system-ui, sans-serif'; g.fillText('SERVER BROWSER', W / 2, 170);
    g.fillStyle = 'rgba(255,255,255,0.08)'; g.fillRect(150, 215, W - 300, 70);
    g.fillStyle = '#e8f4ff'; g.font = '30px system-ui, sans-serif'; g.textAlign = 'left'; g.fillText('PICKLE-CITY-01', 175, 250);
    g.textAlign = 'right'; g.fillStyle = on ? '#7dff7a' : '#ffb04a'; g.fillText(on ? 'ONLINE  ·  ' + cnt + (cnt === 1 ? ' player' : ' players') : 'OFFLINE  ·  single player', W - 175, 250);
    if (on && net.names.length) { g.fillStyle = '#9ec7e6'; g.font = '24px system-ui, sans-serif'; g.textAlign = 'center'; g.fillText('Also here: ' + net.names.slice(0, 4).join('  ·  '), W / 2, 305); }
    const bx = 262, by = 335, bw = 500, bh = 130;
    g.fillStyle = this.connecting ? '#c9a24a' : this.hover ? '#58ff6a' : '#2fbf4a'; g.fillRect(bx, by, bw, bh);
    g.strokeStyle = '#ffffff'; g.lineWidth = this.hover ? 8 : 4; g.strokeRect(bx, by, bw, bh);
    g.textAlign = 'center'; g.fillStyle = '#04200c'; g.font = 'bold 62px system-ui, sans-serif'; g.fillText(this.connecting ? 'CONNECTING…' : 'JOIN SERVER', W / 2, by + bh / 2 + 3);
    g.fillStyle = '#7f9db5'; g.font = '26px system-ui, sans-serif'; g.fillText(this.connecting ? 'Entering Pickle City' : 'Aim at the button and pull the trigger / click', W / 2, 520);
    this.tvTex.needsUpdate = true;
  }
  /** where the aiming ray hits the TV screen, as canvas pixels (or null) */
  tvHit(o, d, maxT = 8) {
    const px = AX - 4.85;
    if (d.x > -0.05) return null;
    const t = (px - o.x) / d.x; if (t < 0 || t > maxT) return null;
    const zl = o.z + d.z * t - AZ, yl = o.y + d.y * t - AY;
    const u = (0.85 - zl) / 1.7, v = (yl - 0.425) / 0.95;
    if (u < 0 || u > 1 || v < 0 || v > 1) return null;
    return { x: u * 1024, y: (1 - v) * 576, t };
  }
  join() {
    if (this.connecting) return;
    this.connecting = true; this.drawTV(); this.exitT = 1.1;
    const g = this.game; g.audio.play('ui', { gain: 0.7, rate: 1.2 });
    if (g.vr.active) { g.vr.fadeTarget = 1; for (const h of g.vr.hands) h && h.pulse(0.5, 60); }
  }

  /** put the player in the apartment (facing the windows) */
  enter(first = false) {
    const g = this.game, p = g.player;
    this.inside = true; this.exitT = -1;
    p.teleport(AX - 0.4, AY + 0.03, AZ + 1.3);
    p.yaw = 0; p.pitch = 0;
    const vr = g.vr; if (vr.active) { vr.yaw += wrap(0 - vr.headYaw); vr.fadeTarget = 0; }
    this.welcomeT = first ? 0.8 : 0.2;
  }
  exitToCity() {
    const g = this.game, p = g.player, vr = g.vr;
    this.inside = false; this.exitT = -1;
    p.teleport(SPAWN.x, SPAWN.y + 0.05, SPAWN.z);
    p.yaw = SPAWN.yaw; p.pitch = 0;
    if (vr.active) { vr.yaw += wrap(SPAWN.yaw - vr.headYaw); vr.fadeTarget = 0; }
    g.ui.toast('Welcome to Pickle City!', 2200);
    g.audio.play('ui', { gain: 0.6, rate: 0.9 });
  }

  update(dt) {
    const g = this.game, p = g.player;
    if (this.welcomeT > 0) { this.welcomeT -= dt; if (this.welcomeT <= 0 && this.inside) g.ui.toast('Home sweet jar. Use the TV and press JOIN SERVER to enter Pickle City', 5200); }
    const click = this._click; this._click = false;
    if (!this.inside) return;
    if (this.exitT >= 0) { this.exitT -= dt; if (this.exitT < 0) { this.connecting = false; this.hover = false; this.drawTV(); this.exitToCity(); } return; }
    // ---- TV server browser: hover + click
    this.drawTV();
    let hover = false, pressed = false;
    const inBtn = (h) => h && h.x > 262 && h.x < 762 && h.y > 335 && h.y < 465;
    if (g.vr.active) {
      for (const hd of g.vr.hands) {
        if (!hd || hd.holder.model || g.vr.menuOpen) continue;
        this._o.copy(hd.pos); this._d.set(0, 0, -1).applyQuaternion(hd.quat);
        const h = this.tvHit(this._o, this._d, 5);
        if (h) {
          if (hd.laser) { hd.laser.visible = true; hd.laser.position.copy(hd.pos); hd.laser.quaternion.copy(hd.quat); hd.laser.scale.set(1, 1, h.t); hd.laser.material.color.setHex(inBtn(h) ? 0x58ff6a : 0x8cff6a); }
          if (inBtn(h)) { hover = true; if (hd.pressed('trigger')) pressed = true; }
        }
      }
    } else if (g.camera) {
      g.camera.getWorldPosition(this._o); g.camera.getWorldDirection(this._d);
      const h = this.tvHit(this._o, this._d, 6);
      if (inBtn(h)) { hover = true; if (click) pressed = true; }
    }
    if (hover !== this.hover) { this.hover = hover; this.drawTV(); }
    if (pressed) { this.join(); return; }
    // keep the player from ever dropping out of the room (e.g. launched by something)
    if (p.pos.y < AY - 3) p.teleport(AX - 0.4, AY + 0.03, AZ + 1.3);
  }
}
function wrap(a) { while (a > Math.PI) a -= 6.2832; while (a < -Math.PI) a += 6.2832; return a; }
