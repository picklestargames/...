// World interactions: doors, switches/buttons, grabbable crates, bullet-triggered buttons, prompts. Works for desktop (E) and VR (ray/poke/grab).
import * as THREE from 'three';
import { moveBody } from '../world/CollisionWorld.js';
import { rng } from '../core/Utils.js';

class Door {
  constructor(sys, chunk, d) {
    this.sys = sys; this.chunk = chunk; this.d = d; this.open = 0; this.target = 0; this.t = 0;
    const M = sys.game.world.mats;
    this.pivot = new THREE.Group();
    const hw = d.w / 2;
    const frame = new THREE.Mesh(new THREE.BoxGeometry(d.w, d.h, 0.08), new THREE.MeshStandardMaterial({ color: 0x9fc4d8, roughness: 0.05, metalness: 0.9, transparent: true, opacity: 0.4 }));
    frame.position.x = hw;
    const bar = new THREE.Mesh(new THREE.BoxGeometry(d.w, 0.08, 0.1), M.flat(0x303338, 0.4, 0.8)); bar.position.set(hw, d.h - 0.04, 0);
    const bar2 = bar.clone(); bar2.position.y = 0.04;
    const side = new THREE.Mesh(new THREE.BoxGeometry(0.06, d.h, 0.1), M.flat(0x303338, 0.4, 0.8)); side.position.set(0.03, d.h / 2, 0); const side2 = side.clone(); side2.position.x = d.w - 0.03;
    const handle = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.4, 0.05), M.flat(0xd0d0d0, 0.3, 0.9)); handle.position.set(d.w - 0.18, 1.1, 0.06);
    frame.position.y = d.h / 2;
    this.pivot.add(frame, bar, bar2, side, side2, handle);
    this.pivot.position.set(d.x - hw, d.y, d.z);
    sys.game.world.scene.add(this.pivot);
    this.world = sys.game.world.collision;
    this.dyn = this.world.addDyn(d.x - hw, d.y, d.z - 0.07, d.x + hw, d.y + d.h, d.z + 0.07);
    this.center = new THREE.Vector3(d.x, d.y + 1.2, d.z);
    this.prompt = 'OPEN DOOR';
    this.autoT = 0;
  }
  toggle() { this.target = this.target ? 0 : 1; this.autoT = 9; this.sys.game.audio.play('door_click', { pos: this.center, gain: 0.9, ref: 3, hrtf: false }); }
  update(dt) {
    if (this.target === 1) { this.autoT -= dt; const p = this.sys.game.player.pos; if (this.autoT <= 0 && (p.x - this.d.x) ** 2 + (p.z - this.d.z) ** 2 > 36) this.target = 0; }
    if (Math.abs(this.open - this.target) > 0.001) {
      this.open += Math.sign(this.target - this.open) * Math.min(Math.abs(this.target - this.open), dt * 2.6);
      this.pivot.rotation.y = -this.open * 1.75;
      const hw = this.d.w / 2;
      if (this.open > 0.12) this.world.disableDyn(this.dyn); else this.world.setDyn(this.dyn, this.d.x - hw, this.d.y, this.d.z - 0.07, this.d.x + hw, this.d.y + this.d.h, this.d.z + 0.07);
    }
    this.prompt = this.target ? 'CLOSE DOOR' : 'OPEN DOOR';
  }
  dispose() { this.world.freeDyn(this.dyn); this.pivot.removeFromParent(); this.pivot.traverse((o) => { if (o.geometry) o.geometry.dispose(); }); }
}

class Switch {
  constructor(sys, chunk, d) {
    this.sys = sys; this.chunk = chunk; this.d = d;
    this.pressed = sys.game.pickups && sys.game.jumpPads.unlocked.has(d.id);
    const M = sys.game.world.mats;
    this.group = new THREE.Group();
    const ped = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.95, 0.34), M.flat(0x3a3d44, 0.5, 0.6));
    ped.position.y = 0.475;
    this.btnMat = new THREE.MeshStandardMaterial({ color: this.pressed ? 0x30ff70 : 0xff3030, emissive: this.pressed ? 0x30ff70 : 0xff2020, emissiveIntensity: 1.0, roughness: 0.3 });
    this.btn = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.12, 0.08, 10), this.btnMat); this.btn.position.y = 1.0;
    this.group.add(ped, this.btn);
    this.group.position.set(d.x, d.y, d.z);
    sys.game.world.scene.add(this.group);
    this.center = new THREE.Vector3(d.x, d.y + 1.0, d.z);
    this.prompt = 'PRESS: ' + d.label;
    this.press_t = 0;
  }
  press() {
    if (this.pressed) return;
    this.pressed = true; this.press_t = 0.3;
    this.btnMat.color.setHex(0x30ff70); this.btnMat.emissive.setHex(0x30ff70);
    const g = this.sys.game;
    g.jumpPads.unlock(this.d.id);
    g.audio.play('button', { pos: this.center, gain: 1.0, ref: 3, hrtf: false });
    g.ui && g.ui.toast('SECRET BOOST PAD UNLOCKED!', 1600);
    g.particles.burst(this.center, [0.2, 1, 0.5], 20, 4, 0.12, 0.8);
    if (g.vr.active) g.vr.pulseBoth(0.5, 80);
  }
  update(dt) { if (this.press_t > 0) { this.press_t -= dt; this.btn.position.y = 0.96; } else this.btn.position.y = 1.0; this.prompt = this.pressed ? '' : 'PRESS: ' + this.d.label; }
  dispose() { this.group.removeFromParent(); }
}

class Crate {
  constructor(sys, x, y, z) {
    this.sys = sys;
    const M = sys.game.world.mats;
    this.mesh = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.32, 0.32), M.flat(0xb8844a, 0.8, 0));
    const band = new THREE.Mesh(new THREE.BoxGeometry(0.335, 0.06, 0.335), M.flat(0x5a3a1a, 0.9, 0)); this.mesh.add(band);
    this.mesh.castShadow = true;
    this.pos = new THREE.Vector3(x, y, z); this.vel = new THREE.Vector3(); this.held = null;
    this.out = {}; this.home = new THREE.Vector3(x, y, z);
    this.prompt = 'GRAB CRATE';
    this.center = this.pos;
    sys.game.world.scene.add(this.mesh);
  }
  update(dt) {
    if (this.held !== null) return;
    const w = this.sys.game.world.collision;
    if (!w.hasChunkAt(this.pos.x, this.pos.z)) return;
    this.vel.y -= 22 * dt;
    const p = this.pos;
    // treat the crate as a tiny body
    p.y -= 0.0;
    moveBody(w, p, this.vel, dt, 0.16, 0.32, 0.1, this.out, false);
    if (this.out.landed) { if (this.vel.y === 0) { this.vel.x *= 0.7; this.vel.z *= 0.7; } }
    if (this.out.grounded) { this.vel.x *= Math.max(0, 1 - dt * 5); this.vel.z *= Math.max(0, 1 - dt * 5); }
    if (this.out.hitX) this.vel.x *= -0.4; if (this.out.hitZ) this.vel.z *= -0.4;
    if (p.y < -30) { p.copy(this.home); this.vel.set(0, 0, 0); }
    this.mesh.position.set(p.x, p.y + 0.16, p.z);
    this.mesh.rotation.y += (this.vel.x + this.vel.z) * dt * 0.5;
  }
}

export class InteractionSystem {
  constructor(game) {
    this.game = game;
    this.doors = []; this.switches = []; this.crates = [];
    this.focus = null;
    this.carried = null;
    this.promptText = '';
    this._v = new THREE.Vector3(); this._d = new THREE.Vector3();
    const R = rng(55);
    // grabbable crates near the spawn + scattered on the first rooftops
    const spots = [[-36, 0, -30], [-34, 0, -30], [-35, 0.34, -30], [-30, 0, -36], [-44, 0, -40], [-20, 0, -48], [-52, 0, -48]];
    for (const [x, y, z] of spots) this.crates.push(new Crate(this, x, y, z));
    this.crateSpawned = true;
  }

  addChunk(c) {
    for (const d of c.doors) this.doors.push(new Door(this, c, d));
    for (const b of c.buttons) this.switches.push(new Switch(this, c, b));
  }
  removeChunk(c) {
    this.doors = this.doors.filter((d) => { if (d.chunk === c) { d.dispose(); return false; } return true; });
    this.switches = this.switches.filter((s) => { if (s.chunk === c) { s.dispose(); return false; } return true; });
  }

  items() { return [...this.doors, ...this.switches, ...this.crates]; }

  update(dt) {
    const g = this.game, p = g.player;
    for (const d of this.doors) d.update(dt);
    for (const s of this.switches) s.update(dt);
    for (const c of this.crates) c.update(dt);
    // desktop focus: nearest interactable in front within reach
    this.focus = null; this.promptText = '';
    if (g.vr.active) { if (this.carried && this.carried.held === null) this.carried = null; return; }
    if (this.carried) {
      const cam = g.camera; const w = cam.getWorldDirection(this._d);
      const pos = cam.getWorldPosition(this._v).addScaledVector(w, 1.1); pos.y -= 0.25;
      this.carried.pos.set(pos.x, pos.y - 0.16, pos.z); this.carried.mesh.position.set(pos.x, pos.y, pos.z); this.carried.mesh.rotation.y += dt;
      this.promptText = 'E — THROW';
      return;
    }
    const eye = g.camera.getWorldPosition(this._v), dir = g.camera.getWorldDirection(this._d);
    let best = null, bs = 0.72;
    for (const it of this.items()) {
      if (it.prompt === '' || (it instanceof Switch && it.pressed)) continue;
      const c = it.center || it.pos;
      const dx = c.x - eye.x, dy = (c.y) - eye.y, dz = c.z - eye.z, dist = Math.hypot(dx, dy, dz);
      if (dist > 3.0) continue;
      const dot = (dx * dir.x + dy * dir.y + dz * dir.z) / dist;
      if (dot > bs) { bs = dot; best = it; }
    }
    this.focus = best;
    if (best) this.promptText = 'E — ' + best.prompt;
  }

  interactPressed() {
    const g = this.game;
    if (g.state !== 'playing') return;
    if (this.carried) { this.throwCarried(g.camera.getWorldDirection(this._d), 11); return; }
    const f = this.focus; if (!f) return;
    this.activate(f, -1);
  }

  activate(it, hand) {
    if (it instanceof Door) it.toggle();
    else if (it instanceof Switch) it.press();
    else if (it instanceof Crate) { this.carried = it; it.held = hand >= 0 ? hand : 'desktop'; it.vel.set(0, 0, 0); this.game.audio.play('shell', { gain: 0.5, rate: 0.6 }); }
  }
  throwCarried(dir, speed) {
    const c = this.carried; if (!c) return; c.held = null; c.vel.set(dir.x * speed, dir.y * speed + 2, dir.z * speed); this.carried = null;
    this.game.audio.play('jump', { gain: 0.6, rate: 0.8 });
  }

  /** nearest interactable along a ray (VR laser) */
  rayPick(origin, dir, maxDist = 4) {
    let best = null, bd = 0.12;
    for (const it of this.items()) {
      if (it.prompt === '' || (it instanceof Switch && it.pressed) || it.held !== undefined && it.held !== null) continue;
      const c = it.center || it.pos;
      const to = this._v.subVectors(c, origin); const t = to.dot(dir);
      if (t < 0.1 || t > maxDist) continue;
      const perp = to.addScaledVector(dir, -t).length();
      const tol = it instanceof Door ? 0.8 : 0.22;
      if (perp < tol && perp / Math.max(t, 0.5) < bd + (it instanceof Door ? 0.25 : 0)) { bd = perp / Math.max(t, 0.5); best = it; }
    }
    return best;
  }
  /** physical touch (VR poke / grab) */
  touch(pos, r = 0.14) {
    for (const s of this.switches) if (!s.pressed && s.center.distanceTo(pos) < r + 0.05) return s;
    for (const c of this.crates) if (c.held === null && c.pos.distanceTo(pos) < r + 0.25) return c;
    for (const d of this.doors) { if (Math.abs(pos.z - d.d.z) < 0.5 && Math.abs(pos.x - d.d.x) < d.d.w / 2 && pos.y > d.d.y && pos.y < d.d.y + d.d.h) return d; }
    return null;
  }
  grabCrate(c, hand) { c.held = hand; this.carried = null; }

  onBulletHit(point, dir) {
    for (const s of this.switches) if (!s.pressed && s.center.distanceTo(point) < 0.35) s.press();
    for (const c of this.crates) if (c.held === null && c.pos.distanceTo(point) < 0.5) c.vel.addScaledVector(dir, 5);
  }
}
