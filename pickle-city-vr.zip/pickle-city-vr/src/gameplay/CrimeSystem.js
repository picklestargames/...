// Crime & money: innocents hurt -> wanted -> police car pursuit -> a cop gets out and shoots; the bank + teller; gun-pointing robberies.
import * as THREE from 'three';
import { findBank } from '../world/CityLayout.js';
import { rng, clamp } from '../core/Utils.js';

const AIM_RANGE = 14, AIM_TIME = 0.9, TELLER_TIME = 0.7;

export class CrimeSystem {
  constructor(game) {
    this.game = game;
    this.money = 0;
    this.kills = 0;
    this.wanted = false;
    this.wantedT = 0;
    this.awayT = 0;
    this.car = null; this.cop = null; this.nextDispatch = 0;
    this.teller = null; this.tellerCool = 0;
    this.aim = new Map();            // npc -> seconds aimed at
    this.cool = new Map();           // npc -> time until it can be robbed again
    this.R = rng(77);
    this.bank = findBank();
    this._o = new THREE.Vector3(); this._d = new THREE.Vector3(); this._q = new THREE.Quaternion();
    this.buildBeacon();
  }

  buildBeacon() {
    if (this.bank.none) return;
    const cv = document.createElement('canvas'); cv.width = 256; cv.height = 128;
    const x = cv.getContext('2d');
    x.fillStyle = '#0d5a2c'; x.fillRect(0, 0, 256, 128); x.strokeStyle = '#ffe27a'; x.lineWidth = 8; x.strokeRect(6, 6, 244, 116);
    x.fillStyle = '#ffe27a'; x.font = 'bold 74px system-ui, sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('BANK $', 128, 68);
    const tex = new THREE.CanvasTexture(cv); tex.colorSpace = THREE.SRGBColorSpace;
    const b = this.bank;
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(5.6, 2.8), new THREE.MeshBasicMaterial({ map: tex, toneMapped: false, side: THREE.DoubleSide }));
    sign.position.set(b.mid, b.top + 2.4, b.frontZ + b.s * 0.3); if (b.s < 0) sign.rotation.y = Math.PI;
    const beam = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 90, 8, 1, true), new THREE.MeshBasicMaterial({ color: 0x40ff80, transparent: true, opacity: 0.16, depthWrite: false, side: THREE.DoubleSide, fog: false }));
    beam.position.set(b.mid, b.top + 48, b.frontZ + b.s * 0.3);
    this.game.world.scene.add(sign, beam);
    this.sign = sign; this.beam = beam;
  }

  add(n, msg) { this.money += n; this.game.audio.play('pickup', { gain: 0.7, rate: 1.5, bus: 'ui' }); this.game.ui && this.game.ui.toast(msg || ('+$' + n), 1400); }

  // ------------------------------------------------------------------ wanted
  onInnocentDown(n) {
    if (!n || n.counted || n.cop) return;
    n.counted = true; this.kills++;
    const g = this.game;
    if (this.kills > 3) { if (!this.wanted) this.startWanted(); }
    else g.ui && g.ui.toast('Innocents hurt: ' + this.kills + ' / 4 — police will come', 1600);
  }
  startWanted() {
    this.wanted = true; this.wantedT = 0; this.awayT = 0; this.nextDispatch = 0;
    this.game.ui && this.game.ui.toast('WANTED! Police are on their way', 3000);
    this.game.audio.play('sirenHiLo', { gain: 0.5, bus: 'ui' });
  }
  endWanted(msg) {
    const g = this.game;
    this.wanted = false; this.kills = 0;
    if (this.car) { g.vehicles.retireCop(this.car); this.car = null; }
    if (this.cop) { this.cop.cop = false; if (this.cop.active) g.npcs.release(this.cop); this.cop = null; }
    for (const c of g.vehicles.cars) if (c.cop && c.active) g.vehicles.retireCop(c);
    msg && g.ui && g.ui.toast(msg, 2200);
  }
  onCopCarArrived(car) {
    const g = this.game;
    if (!this.wanted || this.cop && this.cop.active && this.cop.cop) return;
    const cs = Math.cos(car.yaw), sn = Math.sin(car.yaw);
    car.driver = null;
    const x = car.pos.x - cs * 1.9, z = car.pos.z + sn * 1.9;
    const n = g.npcs.spawnAt(x, z, car.pos.y || 0, { skin: 0xe0ac86, shirt: 0x1c2a4a });
    if (!n) return;
    n.cop = true; n.angry = false; n.state = 'cop'; n.hp = 70; n.copCD = 1.2; n.copMove = false; n.stateT = 0; n.counted = true;
    this.cop = n;
    g.ui && g.ui.toast('A cop is getting out!', 2000);
  }
  updateCop(n, dt) {
    const g = this.game, p = g.player, w = g.world.collision;
    if (g.health.dead || !this.wanted) { n.state = 'walk'; n.cop = false; g.npcs.toGraph(n); return; }
    const dx = p.pos.x - n.x, dz = p.pos.z - n.z, d = Math.hypot(dx, dz) || 1;
    n.yaw = Math.atan2(-dx, -dz);
    n.copCD -= dt;
    const ty = (p.driving ? p.pos.y + 1.0 : p.pos.y + p.height * 0.7);
    let los = false;
    if (d < 60) { const hit = w.raycast(n.x, n.y + 1.45, n.z, dx / d, (ty - (n.y + 1.45)) / d, dz / d, d - 0.5, {}); los = !hit; }
    n.copMove = false;
    if (!los || d > 20) {
      const sp = 3.3 * dt;
      let mx = (dx / d) * sp, mz = (dz / d) * sp;
      const hit = w.raycast(n.x, n.y + 0.9, n.z, dx / d, 0, dz / d, 0.8, {});
      if (hit) { mx *= 0.2; mz *= 0.2; }
      n.x += mx; n.z += mz; n.copMove = true; n.phase += dt * 6;
      const gy = w.groundBelow(n.x, n.y + 0.6, n.z, 0.15, 0.3); if (gy > -1e8) n.y = gy;
    }
    if (los && d <= 24 && n.copCD <= 0) {
      n.copCD = 1.0 + Math.random() * 0.4;
      const mp = { x: n.x - Math.sin(n.yaw) * 0.0 + (dx / d) * 0.5, y: n.y + 1.35, z: n.z + (dz / d) * 0.5 };
      g.particles.burst(mp, [1, 0.9, 0.5], 6, 2, 0.1, 0.12);
      g.audio.play('shot_pistol', { pos: mp, gain: 0.8, ref: 4, hrtf: false });
      const hitChance = p.driving ? 0.4 : 0.5;
      if (Math.random() < hitChance) { g.health.damage(7, 'police'); g.camera_ctrl && g.camera_ctrl.punch(0.35); if (g.vr.active) g.vr.pulseBoth(0.5, 60); }
      else g.audio.play('impact', { pos: { x: p.pos.x + (Math.random() - 0.5) * 1.5, y: p.pos.y + 1, z: p.pos.z + (Math.random() - 0.5) * 1.5 }, gain: 0.5, ref: 2, hrtf: false });
    }
  }

  // ------------------------------------------------------------------ per frame
  update(dt) {
    const g = this.game, p = g.player;
    // --- teller
    this.tellerCool -= dt;
    const b = this.bank;
    if (!b.none) {
      const near = Math.hypot(p.pos.x - b.mid, p.pos.z - b.teller.z) < 90;
      const ok = !!(this.teller && this.teller.active && this.teller.teller);
      if (!ok && near && this.tellerCool <= 0 && g.world.chunks.getHiChunkAt(b.mid, b.teller.z)) {
        const n = g.npcs.spawnAt(b.teller.x, b.teller.z, 0, { skin: 0xc58c5e, shirt: 0x1f6a3a });
        this.tellerCool = 3;
        if (n) { n.teller = true; n.angry = false; n.state = 'teller'; n.yaw = Math.atan2(0, b.s > 0 ? 1 : -1); n.counted = true; n.stateT = 0; this.teller = n; }
      }
    }
    for (const [n, t] of this.cool) { if (t - dt <= 0) this.cool.delete(n); else this.cool.set(n, t - dt); }
    if (!g.health.dead && !p.driving) this.updateAim(dt);
    // --- police
    if (this.wanted) {
      this.wantedT += dt;
      if (g.health.dead) { this.endWanted(); return; }
      const copAlive = this.cop && this.cop.active && this.cop.cop && this.cop.state !== 'fall';
      if (this.cop && this.cop.active && this.cop.cop && this.cop.state === 'fall') { this.cop.cop = false; this.cop = null; this.nextDispatch = Math.max(this.nextDispatch, 7); }
      if (this.cop && !this.cop.active) { this.cop.cop = false; this.cop = null; }
      this.nextDispatch -= dt;
      const carLive = this.car && this.car.active && !this.car.dead;
      if (!carLive && !copAlive && this.nextDispatch <= 0) { this.car = g.vehicles.dispatchCop(p.pos); this.nextDispatch = this.car ? 14 : 4; if (this.car) g.ui && g.ui.toast('Police car incoming', 1500); }
      // lose them by getting far away for a while
      let dMin = 1e9;
      if (this.cop && this.cop.active) dMin = Math.hypot(this.cop.x - p.pos.x, this.cop.z - p.pos.z);
      if (this.car && this.car.active && !this.car.dead) dMin = Math.min(dMin, Math.hypot(this.car.x - p.pos.x, this.car.z - p.pos.z));
      if (dMin > 170 || (!copAlive && !carLive && this.wantedT > 40 && dMin > 120)) this.awayT += dt; else this.awayT = Math.max(0, this.awayT - dt);
      if (this.awayT > 14) this.endWanted('You lost the cops');
    }
    if (this.beam) this.beam.material.opacity = 0.12 + Math.sin(g.time * 2) * 0.04;
  }

  // ------------------------------------------------------------------ pointing a gun
  aimRays(out) {
    const g = this.game, W = g.weapons;
    out.length = 0;
    if (W.mode === 'desktop') {
      const h = W.holders[0]; if (!h.model) return out;
      const o = new THREE.Vector3(), d = new THREE.Vector3(); g.camera.getWorldPosition(o); g.camera.getWorldDirection(d); out.push([o, d]);
    } else {
      for (const h of W.holders) { if (!h.model || !h.def) continue; const o = W.muzzlePos(h, new THREE.Vector3()); const d = new THREE.Vector3(0, 0, -1).applyQuaternion(h.model.root.getWorldQuaternion(this._q)); out.push([o, d]); }
    }
    return out;
  }
  updateAim(dt) {
    const g = this.game, w = g.world.collision;
    this._rays = this._rays || [];
    const rays = this.aimRays(this._rays);
    const seen = new Set();
    for (const [o, d] of rays) {
      const wr = w.raycast(o.x, o.y, o.z, d.x, d.y, d.z, AIM_RANGE, {});
      const nr = g.npcs.raycast(o, d, wr ? Math.min(wr.t, AIM_RANGE) : AIM_RANGE);
      if (!nr) continue;
      const n = nr.npc;
      if (n.cop || n.state === 'held' || n.state === 'thrown' || n.state === 'fall' || this.cool.has(n)) continue;
      seen.add(n);
      const t = (this.aim.get(n) || 0) + dt;
      this.aim.set(n, t);
      if (n.state !== 'handsup' && n.state !== 'teller') { n.prevState = n.state; n.state = 'handsup'; n.stateT = 3; n.edge = null; n.goto = null; n.fear = 0; n.yaw = Math.atan2(-(o.x - n.x), -(o.z - n.z)); }
      else if (n.state === 'handsup') { n.stateT = 3; n.yaw = Math.atan2(-(o.x - n.x), -(o.z - n.z)); }
      if (n.teller) n.handsT = 1.2;
      if (t >= (n.teller ? TELLER_TIME : AIM_TIME)) { this.aim.delete(n); this.rob(n); }
    }
    for (const n of Array.from(this.aim.keys())) if (!seen.has(n)) { const t = this.aim.get(n) - dt * 2; if (t <= 0) this.aim.delete(n); else this.aim.set(n, t); }
  }
  rob(n) {
    const g = this.game;
    this.cool.set(n, n.teller ? 50 : 40);
    if (n.teller) {
      const amt = this.R.int(3, 8) * 100;
      this.add(amt, 'The teller hands over $' + amt + '!');
      n.state = 'handsup'; n.stateT = 4; n.handsT = 4;
    } else if (Math.random() < 0.4) {
      this.add(100, 'They hand over $100');
      n.state = 'handsup'; n.stateT = 1.5;
    } else {
      g.ui && g.ui.toast('They ran away', 900);
      n.state = 'walk'; g.npcs.panic(n, g.player.pos.x, g.player.pos.z);
      g.audio.play('scream', { pos: { x: n.x, y: 1.5, z: n.z }, gain: 0.7, ref: 4, hrtf: false });
    }
    if (n.teller) return;
  }
  /** NPC think hooks */
  thinkTeller(n, dt) {
    const g = this.game;
    if (n.state === 'handsup') {
      n.stateT -= dt;
      if (n.stateT <= 0) { if (n.teller) { n.state = 'teller'; } else { n.state = 'walk'; g.npcs.toGraph(n); } }
    }
  }

  // ------------------------------------------------------------------ minimap
  drawMarkers(c, R, p) {
    const b = this.bank;
    if (!b.none) {
      let x = b.mid, z = b.frontZ + b.s * 2;
      const dx = x - p.pos.x, dz = z - p.pos.z, d = Math.hypot(dx, dz);
      if (d > R * 0.85) { x = p.pos.x + (dx / d) * R * 0.85; z = p.pos.z + (dz / d) * R * 0.85; }
      c.fillStyle = '#ffe27a'; c.strokeStyle = '#0d5a2c'; c.lineWidth = R * 0.03;
      c.beginPath(); c.arc(x, z, R * 0.07, 0, 6.2832); c.fill(); c.stroke();
    }
    if (this.cop && this.cop.active) { c.fillStyle = '#4070ff'; c.beginPath(); c.arc(this.cop.x, this.cop.z, 2.2, 0, 6.2832); c.fill(); }
  }
}
