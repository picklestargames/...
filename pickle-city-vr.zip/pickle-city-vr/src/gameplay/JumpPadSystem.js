// Jump pads: instanced neon discs + rings + direction chevrons + light beams, sound, particles, strong feedback.
import * as THREE from 'three';

const CAP = 160;
const KIND_COLOR = {
  street: [0.1, 0.9, 1.0], roof: [1.0, 0.25, 0.9], launch: [1.0, 0.65, 0.1], tower: [1.0, 0.95, 0.5], hidden: [0.25, 1.0, 0.45],
};

export class JumpPadSystem {
  constructor(game) {
    this.game = game;
    this.pads = [];           // active pad records
    this.unlocked = new Set();
    this.group = new THREE.Group();
    game.world.scene.add(this.group);
    const base = new THREE.CylinderGeometry(1.15, 1.3, 0.2, 14);
    base.translate(0, 0.1, 0);
    this.base = new THREE.InstancedMesh(base, new THREE.MeshStandardMaterial({ color: 0x23272d, roughness: 0.4, metalness: 0.8 }), CAP);
    const ring = new THREE.TorusGeometry(0.95, 0.07, 6, 20); ring.rotateX(Math.PI / 2); ring.translate(0, 0.22, 0);
    this.ring = new THREE.InstancedMesh(ring, new THREE.MeshBasicMaterial({ color: 0xffffff }), CAP);
    const chev = new THREE.ConeGeometry(0.42, 0.8, 3); chev.rotateX(Math.PI / 2); // points to -Z
    this.chev = new THREE.InstancedMesh(chev, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.9 }), CAP * 2);
    const beam = new THREE.CylinderGeometry(0.85, 1.0, 8, 12, 1, true); beam.translate(0, 4.2, 0);
    this.beam = new THREE.InstancedMesh(beam, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.17, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }), CAP);
    for (const m of [this.base, this.ring, this.chev, this.beam]) { m.frustumCulled = false; m.count = 0; this.group.add(m); }
    this.base.receiveShadow = true;
    this._m = new THREE.Matrix4(); this._q = new THREE.Quaternion(); this._p = new THREE.Vector3(); this._s = new THREE.Vector3(1, 1, 1); this._c = new THREE.Color();
    this._up = new THREE.Vector3(0, 1, 0);
    this.t = 0;
    this.dirty = true;
  }

  addChunk(c) {
    for (const d of c.L.pads) {
      const rec = { d, chunk: c, locked: d.locked && !this.unlocked.has(d.id), cool: 0, pulse: 0 };
      this.pads.push(rec);
    }
    this.dirty = true;
  }
  removeChunk(c) { this.pads = this.pads.filter((r) => r.chunk !== c); this.dirty = true; }
  unlock(id) { this.unlocked.add(id); for (const r of this.pads) if (r.d.id === id) { r.locked = false; r.pulse = 1; } this.dirty = true; }

  color(rec, out) {
    if (rec.locked) return out.setRGB(0.25, 0.25, 0.28);
    const c = KIND_COLOR[rec.d.kind] || KIND_COLOR.street; return out.setRGB(c[0], c[1], c[2]);
  }

  update(dt) {
    const g = this.game, p = g.player;
    this.t += dt;
    const n = Math.min(CAP, this.pads.length);
    this.base.count = this.ring.count = this.beam.count = n;
    let chevN = 0;
    for (let i = 0; i < n; i++) {
      const r = this.pads[i], d = r.d;
      r.pulse = Math.max(0, r.pulse - dt * 2); r.cool = Math.max(0, r.cool - dt);
      const dx = p.pos.x - d.x, dz = p.pos.z - d.z;
      const near = dx * dx + dz * dz < 1600;
      // matrices
      this._q.identity();
      this._p.set(d.x, d.y, d.z);
      const sc = 1 + r.pulse * 0.25;
      this._s.set(sc, 1 + r.pulse * 0.6, sc);
      this._m.compose(this._p, this._q, this._s); this.base.setMatrixAt(i, this._m);
      const ps = 1 + Math.sin(this.t * 4 + i) * 0.04 + r.pulse * 0.2;
      this._s.set(ps, 1, ps); this._m.compose(this._p, this._q, this._s); this.ring.setMatrixAt(i, this._m);
      const bs = r.locked ? 0.001 : 1;
      this._s.set(bs, bs * (1 + r.pulse * 0.8), bs); this._m.compose(this._p, this._q, this._s); this.beam.setMatrixAt(i, this._m);
      this.color(r, this._c); this.ring.setColorAt(i, this._c); this.beam.setColorAt(i, this._c);
      // chevrons (2 per pad) pointing along the horizontal launch direction, bobbing upwards
      const h = Math.hypot(d.vx, d.vz);
      const yaw = h > 0.1 ? Math.atan2(-d.vx, -d.vz) : 0;
      for (let k = 0; k < 2; k++) {
        const ph = (this.t * 1.3 + k * 0.5 + i * 0.13) % 1;
        this._q.setFromAxisAngle(this._up, yaw);
        this._p.set(d.x + Math.sin(yaw) * -ph * 0.0, d.y + 0.35 + ph * 1.6, d.z);
        const s2 = r.locked ? 0.001 : (1 - ph) * 0.9 + 0.1;
        this._s.set(s2, s2, s2); this._m.compose(this._p, this._q, this._s); this.chev.setMatrixAt(chevN, this._m);
        this._c.copy(this.color(r, this._c)); this.chev.setColorAt(chevN, this._c); chevN++;
      }
      // sparkle fountain when close
      if (near && !r.locked && Math.random() < dt * 16) g.particles.sparkleFountain({ x: d.x, y: d.y, z: d.z }, this.color(r, this._c).toArray(), 1, 3 + Math.min(8, d.vy * 0.2));
      // trigger
      if (!r.locked && r.cool <= 0 && !g.health.dead && Math.abs(p.pos.y - d.y) < 0.7 && dx * dx + dz * dz < 1.35 * 1.35 && g.loco.padCooldown <= 0 && !p.gliding) this.trigger(r);
    }
    this.chev.count = chevN;
    for (const m of [this.base, this.ring, this.beam, this.chev]) { m.instanceMatrix.needsUpdate = true; if (m.instanceColor) m.instanceColor.needsUpdate = true; }
  }

  trigger(r) {
    const g = this.game, d = r.d, p = g.player;
    r.cool = 0.8; r.pulse = 1;
    g.loco.launch(d.vx, d.vy, d.vz);
    p.pos.y = Math.max(p.pos.y, d.y + 0.05);
    g.audio.play('pad', { pos: { x: d.x, y: d.y, z: d.z }, gain: 1.3, ref: 4, hrtf: false });
    const col = this.color(r, this._c).toArray();
    g.particles.burst({ x: d.x, y: d.y + 0.3, z: d.z }, col, 30, 7, 0.14, 0.7);
    g.particles.poof({ x: d.x, y: d.y, z: d.z }, [1, 1, 1], 6, 2, 0.4);
    g.player.padFlag = true;
    g.camera_ctrl && g.camera_ctrl.punch(0.5);
    if (g.vr.active) g.vr.pulseBoth(1.0, 160);
    g.ui && g.ui.toast('LAUNCH!', 700);
  }
}
