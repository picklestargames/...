import { Emitter, clamp } from '../core/Utils.js';

// Player health: HP + temporary shield, brief invulnerability, respawn on "pickle-jar" defeat.
export class HealthSystem extends Emitter {
  constructor(game) {
    super();
    this.game = game;
    this.max = 100;
    this.hp = 100;
    this.shield = 0;
    this.shieldT = 0;
    this.invuln = 0;
    this.dead = false;
    this.respawnT = 0;
    this.regenDelay = 0;
    this.lastDamageT = 0;
    this.buffs = { boost: 0 };
  }

  damage(amount, source = 'unknown') {
    if (this.dead || this.invuln > 0 || amount <= 0) return false;
    let a = amount;
    if (this.shield > 0) { const s = Math.min(this.shield, a); this.shield -= s; a -= s; }
    this.hp = clamp(this.hp - a, 0, this.max);
    this.invuln = 0.35;
    this.regenDelay = 6;
    this.emit('damage', amount, source);
    const g = this.game;
    if (g.audio) g.audio.play('hurt', { gain: 0.9, bus: 'sfx' });
    if (g.vr && g.vr.active) g.vr.pulseBoth(0.8, 120);
    if (this.hp <= 0) this.die(source);
    return true;
  }

  heal(n) { if (this.dead) return false; const was = this.hp; this.hp = clamp(this.hp + n, 0, this.max); this.emit('heal', n); return this.hp > was; }
  addShield(n, secs = 30) { this.shield = clamp(this.shield + n, 0, 100); this.shieldT = secs; this.emit('shield', n); }
  addBoost(secs = 12) { this.buffs.boost = secs; this.emit('boost', secs); }
  get speedMul() { return this.buffs.boost > 0 ? 1.45 : 1; }
  get full() { return this.hp >= this.max; }

  die(source) {
    this.dead = true; this.respawnT = 2.4;
    this.emit('death', source);
  }

  respawn() {
    this.dead = false; this.hp = this.max; this.shield = 0; this.invuln = 2;
    this.emit('respawn');
  }

  update(dt) {
    if (this.invuln > 0) this.invuln -= dt;
    if (this.dead) { this.respawnT -= dt; if (this.respawnT <= 0) this.respawn(); return; }
    if (this.buffs.boost > 0) this.buffs.boost -= dt;
    if (this.shieldT > 0) { this.shieldT -= dt; if (this.shieldT <= 0) this.shield = 0; }
    if (this.regenDelay > 0) this.regenDelay -= dt;
    else if (this.hp < this.max * 0.5) this.hp = Math.min(this.max * 0.5, this.hp + 2 * dt); // slow regen to 50%
  }
}
