// Pickups: health, ammo, weapons, temporary shield, temporary speed boost. Instanced, readable (beam + spin + bob).
import * as THREE from 'three';
import { mergeSimple } from '../core/Geo.js';
import { WEAPONS } from '../weapons/WeaponDefs.js';

const CAP = 64;
const INFO = {
  health: { color: 0x39ff6a, label: 'HEALTH' },
  ammo: { color: 0xffd23a, label: 'AMMO' },
  shield: { color: 0x3ab8ff, label: 'SHIELD' },
  boost: { color: 0xff7a1a, label: 'SPEED BOOST' },
  weapon: { color: 0xff3ad0, label: 'WEAPON' },
};

export class PickupSystem {
  constructor(game) {
    this.game = game;
    this.recs = [];
    this.collected = new Map();   // id -> respawn time
    this.t = 0;
    const scene = game.world.scene;
    const mk = (geo, color) => { const m = new THREE.InstancedMesh(geo, new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.55, roughness: 0.35, metalness: 0.3, flatShading: true }), CAP); m.count = 0; m.frustumCulled = false; m.castShadow = true; scene.add(m); return m; };
    const cross = mergeSimple([new THREE.BoxGeometry(0.46, 0.15, 0.15), new THREE.BoxGeometry(0.15, 0.46, 0.15)]);
    const ammoG = mergeSimple([new THREE.BoxGeometry(0.4, 0.24, 0.26), (() => { const b = new THREE.BoxGeometry(0.43, 0.06, 0.29); return b; })()]);
    const bolt = mergeSimple([(() => { const c = new THREE.ConeGeometry(0.17, 0.34, 4); c.translate(0, 0.17, 0); return c; })(), (() => { const c = new THREE.ConeGeometry(0.17, 0.34, 4); c.rotateX(Math.PI); c.translate(0, -0.17, 0); return c; })()]);
    this.meshes = {
      health: mk(cross, INFO.health.color), ammo: mk(ammoG, INFO.ammo.color), shield: mk(new THREE.OctahedronGeometry(0.28, 0), INFO.shield.color), boost: mk(bolt, INFO.boost.color),
    };
    const beam = new THREE.CylinderGeometry(0.22, 0.34, 6, 8, 1, true); beam.translate(0, 3, 0);
    this.beam = new THREE.InstancedMesh(beam, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.22, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }), CAP);
    this.beam.count = 0; this.beam.frustumCulled = false; scene.add(this.beam);
    this.ring = new THREE.InstancedMesh(new THREE.TorusGeometry(0.55, 0.035, 5, 18).rotateX(Math.PI / 2), new THREE.MeshBasicMaterial({ color: 0xffffff }), CAP);
    this.ring.count = 0; this.ring.frustumCulled = false; scene.add(this.ring);
    this.weaponModels = new Map();
    this._m = new THREE.Matrix4(); this._q = new THREE.Quaternion(); this._p = new THREE.Vector3(); this._s = new THREE.Vector3(1, 1, 1); this._c = new THREE.Color(); this._e = new THREE.Euler();
  }

  addChunk(c) {
    c.L.pickups.forEach((d, k) => {
      const id = `${c.i}_${c.j}_${k}`;
      this.recs.push({ id, d, chunk: c, seed: (k * 1.7 + c.i * 3.1 + c.j) % 6.28 });
    });
  }
  removeChunk(c) {
    this.recs = this.recs.filter((r) => { if (r.chunk === c) { const m = this.weaponModels.get(r.id); if (m) { m.root.removeFromParent(); this.weaponModels.delete(r.id); } return false; } return true; });
  }

  active(r) { const t = this.collected.get(r.id); return !t || this.t >= t; }

  update(dt) {
    const g = this.game, p = g.player;
    this.t += dt;
    const counts = { health: 0, ammo: 0, shield: 0, boost: 0 };
    let bi = 0;
    const px = p.pos.x, pz = p.pos.z, py = p.pos.y + 0.9;
    for (const r of this.recs) {
      const d = r.d;
      const act = this.active(r);
      if (d.type === 'weapon') {
        let wm = this.weaponModels.get(r.id);
        if (act && !wm && (d.x - px) ** 2 + (d.z - pz) ** 2 < 140 * 140) { wm = g.weapons.create(d.id); wm.root.scale.setScalar(1.5); g.world.scene.add(wm.root); wm.root.traverse((o) => { o.frustumCulled = false; }); this.weaponModels.set(r.id, wm); }
        if (wm) { wm.root.visible = act; if (act) { wm.root.position.set(d.x, d.y + 0.15 + Math.sin(this.t * 2 + r.seed) * 0.1, d.z); wm.root.rotation.set(0.2, this.t * 1.2 + r.seed, 0.0); } }
      }
      if (!act) continue;
      const dx = d.x - px, dz = d.z - pz;
      if (dx * dx + dz * dz > 160 * 160) continue;
      const info = INFO[d.type];
      const bob = Math.sin(this.t * 2.4 + r.seed) * 0.1;
      this._p.set(d.x, d.y + 0.35 + bob, d.z);
      if (d.type !== 'weapon') {
        const m = this.meshes[d.type];
        this._e.set(0.3 * (d.type === 'ammo' ? 1 : 0), this.t * 1.8 + r.seed, 0); this._q.setFromEuler(this._e);
        this._s.setScalar(1.15);
        this._m.compose(this._p, this._q, this._s); m.setMatrixAt(counts[d.type]++, this._m);
      }
      if (bi < CAP) {
        this._q.identity(); this._p.set(d.x, d.y - 0.55, d.z); this._s.set(1, 1, 1);
        this._m.compose(this._p, this._q, this._s); this.beam.setMatrixAt(bi, this._m); this.beam.setColorAt(bi, this._c.setHex(info.color));
        const rs = 1 + Math.sin(this.t * 3 + r.seed) * 0.1;
        this._s.set(rs, 1, rs); this._p.set(d.x, d.y - 0.5, d.z); this._m.compose(this._p, this._q, this._s); this.ring.setMatrixAt(bi, this._m); this.ring.setColorAt(bi, this._c.setHex(info.color));
        bi++;
      }
      // collection
      const dy = d.y - py;
      if (!g.health.dead && dx * dx + dz * dz + dy * dy < 1.5 * 1.5) this.collect(r);
    }
    for (const k of Object.keys(this.meshes)) { this.meshes[k].count = counts[k]; this.meshes[k].instanceMatrix.needsUpdate = true; }
    this.beam.count = this.ring.count = bi;
    this.beam.instanceMatrix.needsUpdate = this.ring.instanceMatrix.needsUpdate = true;
    if (this.beam.instanceColor) this.beam.instanceColor.needsUpdate = true; if (this.ring.instanceColor) this.ring.instanceColor.needsUpdate = true;
  }

  /** VR: hand reaches into a weapon pickup */
  nearestWeapon(pos, r = 0.5) {
    for (const rec of this.recs) { if (rec.d.type !== 'weapon' || !this.active(rec)) continue; if (Math.hypot(rec.d.x - pos.x, rec.d.y - pos.y, rec.d.z - pos.z) < r) return rec; }
    return null;
  }

  /** weapon pickup along a pointing ray (VR: point + trigger flies it into the hand) */
  rayWeapon(origin, dir, maxD = 8) {
    let best = null, bs = 0.2;
    for (const r of this.recs) {
      if (r.d.type !== 'weapon' || !this.active(r)) continue;
      const tx = r.d.x - origin.x, ty = r.d.y - origin.y, tz = r.d.z - origin.z, dist = Math.hypot(tx, ty, tz);
      if (dist > maxD || dist < 0.1) continue;
      const ang = Math.acos(Math.min(1, Math.max(-1, (tx * dir.x + ty * dir.y + tz * dir.z) / dist)));
      if (ang < bs) { bs = ang; best = r; }
    }
    return best;
  }

  collect(r, toHand = -1) {
    const g = this.game, d = r.d;
    let ok = true, msg = '';
    switch (d.type) {
      case 'health': ok = g.health.heal(40); msg = '+40 HEALTH'; if (!ok) { return; } break;
      case 'ammo': ok = g.weapons.inv.addAmmo(2); msg = '+AMMO'; if (!ok) return; g.ui && g.ui.refreshAmmo(); break;
      case 'shield': g.health.addShield(50, 40); msg = 'SHIELD UP'; break;
      case 'boost': g.health.addBoost(14); msg = 'SPEED BOOST!'; break;
      case 'weapon': {
        const had = g.weapons.inv.has(d.id);
        g.weapons.inv.give(d.id);
        msg = had ? 'AMMO: ' + WEAPONS[d.id].name : 'NEW: ' + WEAPONS[d.id].name;
        if (toHand >= 0) g.weapons.equip(toHand, d.id);
        else if (g.weapons.mode === 'desktop' && !had) g.weapons.equip(0, d.id);
        break;
      }
    }
    this.collected.set(r.id, this.t + (d.type === 'weapon' ? 80 : 45));
    g.audio.play(d.type === 'weapon' ? 'weaponPickup' : 'pickup', { pos: { x: d.x, y: d.y, z: d.z }, gain: 0.9, ref: 3, hrtf: false });
    g.particles.burst({ x: d.x, y: d.y + 0.3, z: d.z }, [((INFO[d.type].color >> 16) & 255) / 255, ((INFO[d.type].color >> 8) & 255) / 255, (INFO[d.type].color & 255) / 255], 22, 4, 0.12, 0.7);
    g.ui && g.ui.toast(msg, 1100);
    if (g.vr.active) g.vr.pulseBoth(0.4, 60);
    const wm = this.weaponModels.get(r.id); if (wm) wm.root.visible = false;
  }
}
