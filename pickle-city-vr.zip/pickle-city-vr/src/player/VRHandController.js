// One tracked controller: reads the gamepad, shows a pickle hand, holds weapons/objects, draws/holsters, pokes/lasers.
import * as THREE from 'three';
import { HandModel } from './HandModel.js';
import { WEAPONS } from '../weapons/WeaponDefs.js';
import { rad, clamp } from '../core/Utils.js';

const HOLSTER_REACH = 0.3;

export class VRHandController {
  constructor(vr, idx, ctrlObj, inputSource) {
    this.vr = vr; this.game = vr.game; this.idx = idx; this.side = idx === 1 ? 1 : -1;
    this.ray = ctrlObj; this.input = inputSource;
    this.hand = new HandModel(this.game.world.mats);
    this.hand.root.scale.x = this.side;               // left hand is mirrored
    this.hand.root.traverse((o) => { o.frustumCulled = false; });
    this.game.world.scene.add(this.hand.root);
    this.pos = new THREE.Vector3(); this.quat = new THREE.Quaternion();
    this.palm = new THREE.Vector3();
    this.prevPos = new THREE.Vector3(); this.vel = new THREE.Vector3(); this.hist = [];
    this.trigger = 0; this.grip = 0; this.stick = { x: 0, y: 0 };
    this.b = { trigger: false, grip: false, stickClick: false, a: false, b: false };
    this.pb = { trigger: false, grip: false, stickClick: false, a: false, b: false };
    this.held = null;                 // crate or other grabbed object
    this.laser = new THREE.Mesh(new THREE.CylinderGeometry(0.003, 0.003, 1, 5).translate(0, 0.5, 0).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: 0x8cff6a, transparent: true, opacity: 0.7, depthTest: false }));
    this.laser.visible = false; this.laser.frustumCulled = false; this.laser.renderOrder = 20;
    this.game.world.scene.add(this.laser);
    this.target = null; this.holdsGrabbed = false;
    this.twoHandTarget = false; this._pk = new THREE.Vector3();
    this._q = new THREE.Quaternion(); this._v = new THREE.Vector3(); this._v2 = new THREE.Vector3(); this._m = new THREE.Matrix4(); this._qt = new THREE.Quaternion();
    this.gripRelease = 0;
    this.heldNpc = null; this.punchCD = 0;
    this.ammo = null; this.ammoMesh = null;       // magazine / shell in hand during a manual reload
  }

  get gp() { return this.input && this.input.gamepad; }
  get holder() { return this.game.weapons.holders[this.idx]; }
  get other() { return this.vr.hands[1 - this.idx]; }

  pulse(i, ms) { this.game.audio.vibrate(this.gp, i, ms); }

  readInput() {
    const gp = this.gp;
    this.pb = this.b; this.b = { ...this.b };
    if (!gp) return;
    const bt = gp.buttons;
    const val = (i) => (bt[i] ? bt[i].value : 0);
    this.trigger = val(0); this.grip = val(1);
    this.b.trigger = this.trigger > 0.55; this.b.grip = this.grip > 0.6; this.b.stickClick = !!(bt[3] && bt[3].pressed);
    this.b.a = !!(bt[4] && bt[4].pressed); this.b.b = !!(bt[5] && bt[5].pressed);
    const ax = gp.axes; const o = ax.length >= 4 ? 2 : 0;
    const dz = 0.15;
    const f = (v) => (Math.abs(v) < dz ? 0 : (v - Math.sign(v) * dz) / (1 - dz));
    this.stick.x = f(ax[o] || 0); this.stick.y = f(ax[o + 1] || 0);
  }
  pressed(k) { return this.b[k] && !this.pb[k]; }
  released(k) { return !this.b[k] && this.pb[k]; }

  /** weapon-hand placement in world space; returns palm world position used by the hand model */
  update(dt) {
    const g = this.game, W = g.weapons, S = g.settings;
    // (input is sampled once per frame by VRPlayerController.preUpdate via readInput())
    this.ray.updateWorldMatrix(true, false);
    this.ray.matrixWorld.decompose(this.pos, this.quat, this._v);
    // velocity (for throwing)
    this.hist.push({ t: g.time, p: this.pos.clone() }); while (this.hist.length > 8) this.hist.shift();
    if (this.hist.length > 2) { const a = this.hist[0], b = this.hist[this.hist.length - 1]; const dtt = Math.max(0.001, b.t - a.t); this.vel.subVectors(b.p, a.p).divideScalar(dtt); }
    const h = this.holder;
    const tilt = rad(S.get('aimTilt') || 0);
    this._qt.setFromAxisAngle(new THREE.Vector3(1, 0, 0), tilt);
    const handQ = this.quat.clone().multiply(this._qt);

    // ----- glider bars: both grips = steering (weapons can't be holstered while gliding)
    const gliding = g.glider.active && g.glider.target > 0;
    if (g.vehicles.driving) { this.placeEmptyHand(handQ); this.laser.visible = false; this.updateHandPose(h); return; }

    // ----- trigger = fire (weapon) or interact
    if (h.model) {
      W.setTrigger(this.idx, this.b.trigger);
      this.placeWeapon(h, handQ);
    } else {
      this.placeEmptyHand(handQ);
    }

    // ----- manual reload: ammo in hand
    this.updateAmmo(h);

    // ----- grip actions
    if (this.pressed('grip') && !gliding) this.onGripDown(h);
    if (this.released('grip')) this.onGripUp(h);
    if (this.held) this.carryHeld();

    // ----- weapon-hand buttons
    if (h.model && !gliding) {
      if (this.pressed('b') && this.idx === (S.get('leftHanded') ? 0 : 1)) W.reloadPressed(this.idx);
      if (this.pressed('stickClick') && false) W.cycle(1);
    }

    // ----- civilians: carry, punch
    this.updateNpc(dt, h);

    // ----- laser / poke when empty-handed
    this.updateLaser();
    this.updateHandPose(h);
  }

  placeEmptyHand(handQ) {
    const hr = this.hand.root;
    this._v.set(0.045 * this.side, -0.005, 0.02).applyQuaternion(handQ);
    this.palm.copy(this.pos).add(this._v);
    hr.position.copy(this.palm); hr.quaternion.copy(handQ);
    hr.visible = true;
  }

  placeWeapon(h, handQ) {
    const m = h.model, g = this.game;
    const q = handQ.clone();
    let pos = this.pos.clone();
    const off = this.other;
    // two-handed hold
    let two = false;
    const fg = m.foregrip;
    if (off && off.b.grip && !off.holder.model) {
      if (fg) {
        const fW = pos.clone().add(fg.clone().applyQuaternion(q));
        const dd = off.pos.distanceTo(fW);
        if (dd < (h.twoHand ? 0.6 : 0.26)) two = true;
      } else if (off.pos.distanceTo(pos) < 0.2) two = true;
    }
    h.twoHand = two;
    if (two && fg) {
      const target = off.palm.clone().sub(pos);
      const d = target.clone().normalize();
      const fd = fg.clone().normalize();
      const q2 = new THREE.Quaternion().setFromUnitVectors(fd.clone().applyQuaternion(q), d).multiply(q);
      // roll from the main hand
      const upDesired = new THREE.Vector3(0, 1, 0).applyQuaternion(this.quat);
      const upNow = new THREE.Vector3(0, 1, 0).applyQuaternion(q2);
      const proj = (v) => v.clone().addScaledVector(d, -v.dot(d)).normalize();
      const a = proj(upNow), b = proj(upDesired);
      let ang = Math.acos(clamp(a.dot(b), -1, 1)); if (new THREE.Vector3().crossVectors(a, b).dot(d) < 0) ang = -ang;
      q2.premultiply(new THREE.Quaternion().setFromAxisAngle(d, ang * 0.85));
      q.copy(q2);
    }
    // recoil visual kick (hand only)
    const kick = h.kickZ * (h.twoHand ? 0.6 : 1);
    const back = new THREE.Vector3(0, 0, 1).applyQuaternion(q).multiplyScalar(kick);
    pos.add(back);
    const kp = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1, 0, 0), h.kickP * (h.twoHand ? 0.5 : 1.0));
    q.multiply(kp);
    m.root.position.copy(pos); m.root.quaternion.copy(q); m.root.visible = true; m.root.updateMatrixWorld(true);
    // main hand sits on the grip
    const hr = this.hand.root;
    this.palm.copy(m.root.localToWorld(new THREE.Vector3(0.045 * this.side, -0.005, 0.02)));
    hr.position.copy(this.palm); hr.quaternion.copy(q); hr.visible = true;
    // off hand on the foregrip
    if (two && off) {
      const ohr = off.hand.root;
      const fgp = fg ? new THREE.Vector3(-0.045 * off.side * -1, -0.01, 0).add(fg) : new THREE.Vector3(0.045 * off.side, -0.01, 0.0).add(new THREE.Vector3(0, 0.02, 0.0));
      off.palm.copy(m.root.localToWorld(fgp));
      ohr.position.copy(off.palm); ohr.quaternion.copy(q); ohr.visible = true; off.snapped = true;
    } else if (off) off.snapped = false;
  }

  updateHandPose(h) {
    const hasW = !!h.model;
    const trig = this.trigger, grip = this.grip;
    if (this.snapped) this.hand.curl(0.9, 0.95, 0.5);
    else if (this.held) this.hand.curl(0.8, 0.95, 0.6);
    else if (hasW) this.hand.curl(trig * 0.9 + 0.1, 0.95, 0.35 + (this.b.a || this.b.b ? 0.2 : 0));
    else {
      const thumb = this.b.a || this.b.b || this.b.stickClick ? 0.7 : 0.15 + grip * 0.5;
      this.hand.curl(clamp(trig * 0.85 + grip * 0.3 + 0.1, 0, 1), clamp(grip + 0.18, 0, 1), thumb);
    }
  }

  onGripDown(h) {
    const g = this.game, W = g.weapons, I = g.interaction;
    const head = this.vr.headPos, yaw = this.vr.bodyYaw;
    if (h.model) {
      // holster if the hand is near any holster zone (and the other hand isn't using this gun two-handed at the foregrip)
      return;                                   // weapon already in hand: keep holding the grip to keep it
    }
    // manual reload: off-hand reaches the belt pouch for a fresh mag / shell, or pulls the mag out at the mag well
    const oh0 = this.other && this.other.holder;
    if (oh0 && oh0.model && !oh0.reload && !this.ammo) {
      const mw0 = oh0.model.root.localToWorld(oh0.model.magwell.clone());
      if (this.vr.pouchZone.distanceTo(this.palm) < 0.24) {
        const n = W.pouchTake(oh0);
        if (n > 0) { this.ammo = { n, id: oh0.id, h: oh0 }; g.audio.play('mag_out', { gain: 0.4, rate: 1.4 }); this.pulse(0.3, 30); return; }
      } else if (oh0.def.reload === 'mag' && !oh0.magOut && mw0.distanceTo(this.palm) < 0.2) { W.ejectMag(oh0); this.pulse(0.4, 40); return; }
    }
    // draw: nearest owned weapon in a holster zone
    let best = null, bd = HOLSTER_REACH;
    for (const id of Object.keys(W.holsterModels)) {
      const p = W.holsterWorldPos(id); if (!p) continue;
      const d = p.distanceTo(this.palm); if (d < bd) { bd = d; best = id; }
    }
    if (best && W.equip(this.idx, best)) { g.audio.play('slide', { gain: 0.5, rate: 1.2 }); this.pulse(0.35, 30); return; }
    // a weapon you dropped: grip it where it lies (or point + trigger to summon it)
    const dd = g.weapons.findDropped(this.pos, this._v.set(0, 0, -1).applyQuaternion(this.quat), this.palm, 0);
    if (dd && this.palm.distanceTo(dd.root.position) < 0.5) { g.weapons.discardDropped(dd); if (W.equip(this.idx, dd.id)) { g.audio.play('weaponPickup', { gain: 0.4, rate: 1.4 }); this.pulse(0.4, 40); return; } }
    // weapon lying in the world
    const wr = g.pickups.nearestWeapon(this.palm, 0.55);
    if (wr) { g.pickups.collect(wr, this.idx); return; }
    // reload gesture: off hand grips near the magazine well of the weapon in the *other* hand
    // yank a driver out of their car by the seat
    const dcar = g.vehicles.driverAt(this.palm, 0.7);
    if (dcar) { const dn = g.vehicles.pullDriver(dcar); if (dn) { g.npcs.grab(dn, this.idx, this.palm); this.heldNpc = dn; this.pulse(0.8, 90); g.ui && g.ui.toast('CAR JACKED! Click a thumbstick next to it to get in', 2200); return; } }
    // grab a civilian (they dangle, flail and can be thrown)
    const npc = g.npcs.grabNearest(this.palm, 0.16);
    if (npc) { g.npcs.grab(npc, this.idx, this.palm); this.heldNpc = npc; this.pulse(0.5, 60); return; }
    // grab world objects
    const t = I.touch(this.palm, 0.18);
    if (t) {
      if (t.constructor.name === 'Crate') { I.grabCrate(t, this.idx); this.held = t; g.audio.play('shell', { gain: 0.5, rate: 0.6 }); }
      else I.activate(t, this.idx);
    }
  }
  updateAmmo(h) {
    const a = this.ammo; if (!a) { if (this.ammoMesh) this.ammoMesh.visible = false; return; }
    const W = this.game.weapons, gh = a.h;
    if (!this.ammoMesh || this.ammoMesh.userData.id !== a.id) {
      if (this.ammoMesh) this.ammoMesh.removeFromParent();
      this.ammoMesh = W.makeAmmoProp(gh.def); this.ammoMesh.userData.id = a.id; this.game.world.scene.add(this.ammoMesh);
    }
    const m = this.ammoMesh; m.visible = true;
    m.position.copy(this.palm).add(this._v.set(0, 0.03, -0.02).applyQuaternion(this.quat)); m.quaternion.copy(this.quat);
    // the gun changed or was put away: give the ammo back
    if (gh.id !== a.id || !gh.model) { this.dropAmmo(); return; }
    if (!this.b.grip) { this.dropAmmo(); return; }
    const mw = gh.model.root.localToWorld(gh.model.magwell.clone());
    if (mw.distanceTo(this.palm) < 0.15) { W.seatAmmo(gh, a.n); this.ammo = null; m.visible = false; this.pulse(0.5, 45); }
  }
  dropAmmo() {
    const a = this.ammo; if (!a) return; this.ammo = null;
    if (this.ammoMesh) this.ammoMesh.visible = false;
    this.game.weapons.returnAmmo(a.h, a.n, this.palm.clone());
  }
  onGripUp(h) {
    if (this.ammo) { this.dropAmmo(); return; }
    if (h.model && !this.heldNpc) {
      // hold-to-hold: letting go of the grip puts the gun into a holster (if your hand is at one) or drops it
      const near = this.nearestHolster();
      if (near) { this.game.weapons.holster(this.idx); this.game.audio.play('slide', { gain: 0.5, rate: 0.8 }); this.pulse(0.3, 30); }
      else { this.game.weapons.dropWeapon(this.idx, h.model.root.position, h.model.root.quaternion, this.vel); this.pulse(0.2, 25); }
      return;
    }
    if (this.heldNpc) {
      const n = this.heldNpc; this.heldNpc = null;
      if (n.state === 'held') {
        const v = this.vel.clone().multiplyScalar(1.25); const sp = v.length(); if (sp > 24) v.multiplyScalar(24 / sp);
        this.game.npcs.launch(n, v.x, v.y + (sp < 1.5 ? 0 : 1), v.z);
        if (sp > 3) this.game.ui && this.game.ui.toast('WHEEE!', 600);
        this.pulse(0.3, 40);
      }
    }
    if (this.held) {
      const c = this.held; this.held = null; c.held = null;
      c.vel.copy(this.vel).multiplyScalar(1.15);
      this.game.audio.play('jump', { gain: 0.4, rate: 0.9 });
    }
  }
  carryHeld() {
    const c = this.held;
    const q = this.quat;
    const p = this._v2.set(0, -0.02, -0.1).applyQuaternion(q).add(this.palm);
    c.pos.set(p.x, p.y - 0.16, p.z); c.mesh.position.copy(p); c.mesh.quaternion.copy(q);
  }

  nearestHolster(prefId) {
    const g = this.game, W = g.weapons;
    const zones = this.vr.holsterZones; // world positions
    for (const k in zones) if (zones[k].distanceTo(this.palm) < HOLSTER_REACH) return k;
    return null;
  }


  updateNpc(dt, h) {
    const g = this.game, N = g.npcs;
    this.punchCD -= dt;
    if (this.heldNpc) {
      if (this.heldNpc.state !== 'held' || !this.b.grip) { if (this.heldNpc.state === 'held' && !this.b.grip) this.onGripUp(h); else this.heldNpc = null; }
      else { N.holdAt(this.heldNpc, this.palm, this.quat); return; }
    }
    if (this.punchCD > 0 || this.vr.menuOpen) return;
    // hand speed relative to the player's own motion
    const rel = this._v2.copy(this.vel).sub(g.player.vel);
    const sp = rel.length();
    if (sp < 2.4) return;
    const n = N.grabNearest(this.palm, 0.1);
    if (!n || n === this.heldNpc) return;
    rel.y = Math.max(rel.y, 0).valueOf(); rel.normalize();
    N.punch(n, rel, sp, this.idx);
    this.punchCD = 0.35; this.pulse(Math.min(1, sp / 8), 70);
  }

  updateLaser() {
    const g = this.game, h = this.holder;
    const show = !h.model && !this.held && !this.snapped && !this.heldNpc;
    this.target = null; this.laser.visible = false;
    if (!show) return;
    const dir = this._v.set(0, 0, -1).applyQuaternion(this.quat).clone();
    // poke physical things
    const touched = g.interaction.touch(this.palm, 0.1);
    if (touched && touched.constructor.name === 'Switch' && this.pressed('trigger')) { touched.press(); return; }
    const ui = this.vr.ui;
    let hitT = 3;
    let target = g.interaction.rayPick(this.pos, dir, 4);
    const uhit = ui && ui.rayHit(this.pos, dir);
    const dw = !uhit ? g.weapons.findDropped(this.pos, dir, this.palm) : null;
    const pk = !uhit && !dw ? g.pickups.rayWeapon(this.pos, dir, 8) : null;
    if (uhit) { hitT = uhit.t; this.target = { ui: uhit }; if (this.pressed('trigger')) ui.click(uhit); }
    else if (dw) {
      hitT = Math.max(0.1, this.pos.distanceTo(dw.root.position)); this.target = { drop: dw };
      if (this.pressed('trigger')) g.weapons.summon(dw, this.idx);
    } else if (pk) {
      hitT = Math.max(0.1, this.pos.distanceTo(this._pk.set(pk.d.x, pk.d.y, pk.d.z))); this.target = { pickup: pk };
      if (this.pressed('trigger')) g.pickups.collect(pk, this.idx);
    } else if (target) {
      const c = target.center || target.pos; hitT = this.pos.distanceTo(c);
      this.target = { item: target };
      if (this.pressed('trigger') && !this.pb.grip) g.interaction.activate(target, this.idx);
      if (ui) ui.prompt(c, target.prompt);
    }
    if (this.target) {
      this.laser.visible = true; this.laser.position.copy(this.pos); this.laser.quaternion.copy(this.quat); this.laser.scale.set(1, 1, hitT);
      this.laser.material.color.setHex(uhit ? 0x6ad0ff : (dw || pk) ? 0xffb04a : 0x8cff6a);
    }
    if (this.b.trigger && !h.model && ui && ui.dragging && uhit) ui.drag(uhit);
  }
}
