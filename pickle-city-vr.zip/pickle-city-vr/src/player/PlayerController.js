// Shared player body state. Both the desktop and VR controllers drive the same body through LocomotionSystem.
import * as THREE from 'three';
import { SPAWN } from '../world/Constants.js';

export class PlayerController {
  constructor(game) {
    this.game = game;
    this.pos = new THREE.Vector3(SPAWN.x, 0, SPAWN.z);
    this.vel = new THREE.Vector3();
    this.yaw = SPAWN.yaw;           // facing (desktop view yaw / VR body reference yaw)
    this.pitch = 0;
    this.radius = 0.32;
    this.standH = 1.75;
    this.crouchH = 1.05;
    this.height = this.standH;
    this.grounded = true;
    this.groundY = 0;
    this.crouching = false;
    this.sliding = false;
    this.slideT = 0;
    this.sprinting = false;
    this.gliding = false;
    this.onLadder = null;
    this.airTime = 0;
    this.coyote = 0;
    this.jumpBuffer = 0;
    this.launched = 0;              // seconds since a jump-pad launch (blocks sticky ground)
    this.landImpact = 0;
    this.stepTimer = 0;
    this.eyeOffset = 0;             // smoothed visual eye drop (landing / slide), metres
    this.safePos = new THREE.Vector3().copy(this.pos);
    this.intent = { moveX: 0, moveZ: 0, sprint: false, jump: false, jumpHeld: false, crouch: false, crouchPressed: false, dirYaw: 0 };
    this.hurtT = 0;
    this.out = {};
    this.mode = 'desktop';
    this.driving = null;
  }

  get speedH() { return Math.hypot(this.vel.x, this.vel.z); }
  get altitude() { return this.pos.y - this.groundY; }
  get eyeY() { return this.pos.y + this.height - 0.12; }

  teleport(x, y, z) {
    this.pos.set(x, y, z); this.vel.set(0, 0, 0); this.sliding = false; this.onLadder = null;
    this.game.world && this.game.world.chunks.ensure(x, z);
  }
}
