// WebXR session owner + VR body. The headset ALWAYS owns the camera: we only move/rotate the rig (play space) around the head,
// never the camera itself, so there is no forced rotation. Locomotion feeds the same PlayerController/LocomotionSystem as desktop.
import * as THREE from 'three';
import { VRHandController } from './VRHandController.js';
import { VRUIManager } from '../ui/VRUIManager.js';
import { HOLSTERS } from '../weapons/WeaponDefs.js';
import { AVATAR_EYE_HEIGHT } from './PickleAvatar.js';
import { clamp, damp, dampAngle, angleDiff, rad } from '../core/Utils.js';

const UP = new THREE.Vector3(0, 1, 0);

export class VRPlayerController {
  constructor(game) {
    this.game = game;
    this.active = false;
    this.supported = false;
    this.secure = typeof window !== 'undefined' ? !!window.isSecureContext : false;
    this.session = null;
    this.hands = [null, null];            // 0 = left, 1 = right (VRHandController)
    this.handCache = [null, null];
    this.ctrls = [];
    this.holsterZones = {};
    for (const k of Object.keys(HOLSTERS)) this.holsterZones[k] = new THREE.Vector3();
    this.pouchZone = new THREE.Vector3();    // belt pouch: fresh magazines / shells are grabbed here
    this.pouchMesh = null;
    this.headPos = new THREE.Vector3();    // world
    this.headLocal = new THREE.Vector3();  // reference-space (rig-local)
    this.prevHeadLocal = new THREE.Vector3();
    this.headQuatLocal = new THREE.Quaternion();
    this.hasPose = false;
    this.headForward = { x: 0, z: -1 };
    this.headYaw = 0;                      // world yaw of the gaze (horizontal)
    this.bodyYaw = 0;                      // torso yaw (lags the head; used by holsters/avatar)
    this.yaw = 0;                          // rig yaw (snap/smooth turning)
    this.rigY = 0;
    this.yOffset = 0;                      // seated / no-floor height compensation
    this.needCalib = true;
    this.noFloor = false;
    this.snapLatch = false;
    this.crouchToggle = false;
    this.sprintToggle = false;
    this.carOff = 0;
    this.physCrouch = false;
    this.teleporting = false;
    this.tele = { arc: [], valid: false, point: null };
    this.fade = 0; this.fadeTarget = 0; this.pendingTeleport = null;
    this.vig = 0;
    this._v = new THREE.Vector3(); this._v2 = new THREE.Vector3(); this._q = new THREE.Quaternion(); this._e = new THREE.Euler(0, 0, 0, 'YXZ');
    this.menuOpen = false;
    this.prevGlide = false;
    this.ui = null;
  }

  /** build scene objects (needs renderer + rig) */
  init() {
    const g = this.game, r = g.renderer;
    // controllers live in rig space so rig motion carries them
    for (let i = 0; i < 2; i++) {
      const c = r.xr.getController(i);
      g.rig.add(c);
      c.addEventListener('connected', (e) => this.onConnected(i, c, e.data));
      c.addEventListener('disconnected', () => this.onDisconnected(i));
      this.ctrls.push(c);
    }
    // teleport arc + marker
    const pts = new Float32Array(48 * 3);
    const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.BufferAttribute(pts, 3));
    this.arcLine = new THREE.Line(geo, new THREE.LineBasicMaterial({ color: 0x7dff7a, transparent: true, opacity: 0.9, depthTest: false }));
    this.arcLine.frustumCulled = false; this.arcLine.renderOrder = 18; this.arcLine.visible = false;
    this.marker = new THREE.Group();
    const ring = new THREE.Mesh(new THREE.RingGeometry(0.28, 0.36, 24).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: 0x7dff7a, transparent: true, opacity: 0.9, depthTest: false, side: THREE.DoubleSide }));
    const cone = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.25, 6).rotateX(Math.PI), new THREE.MeshBasicMaterial({ color: 0x7dff7a, depthTest: false }));
    cone.position.y = 0.45; this.marker.add(ring, cone); this.marker.visible = false; this.marker.renderOrder = 18;
    this.markerMats = [ring.material, cone.material, this.arcLine.material];
    g.world.scene.add(this.arcLine, this.marker);
    // comfort vignette + fade (child of the camera so it follows the head exactly)
    this.vigMat = new THREE.ShaderMaterial({
      transparent: true, depthTest: false, depthWrite: false, fog: false,
      uniforms: { vig: { value: 0 }, fade: { value: 0 } },
      vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
      fragmentShader: 'varying vec2 vUv; uniform float vig; uniform float fade; void main(){ float d = length(vUv-0.5)*2.0; float inner = mix(1.6, 0.28, vig); float a = smoothstep(inner, inner+0.5, d)*min(1.0,vig*1.4); a = max(a, fade); gl_FragColor = vec4(0.0,0.0,0.0,a); }',
    });
    this.vigMesh = new THREE.Mesh(new THREE.PlaneGeometry(2.6, 2.6), this.vigMat);
    this.vigMesh.position.z = -0.25; this.vigMesh.renderOrder = 999; this.vigMesh.frustumCulled = false; this.vigMesh.visible = false;
    g.camera.add(this.vigMesh);
    // visible holster pouches at the left and right hip (weapons live here when not in your hands)
    this.pads = [];
    for (const k of ['hipL', 'hipR']) {
      const m = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.26, 0.14), new THREE.MeshStandardMaterial({ color: 0x1d1a17, roughness: 0.8, metalness: 0.1, emissive: 0x000000 }));
      m.userData.zone = k; m.visible = false; m.frustumCulled = false; g.world.scene.add(m); this.pads.push(m);
    }
    this.ui = new VRUIManager(g, this);
    r.xr.addEventListener('sessionstart', () => this.onSessionStart());
    r.xr.addEventListener('sessionend', () => this.onSessionEnd());
  }

  // ------------------------------------------------------------------ session
  async detect() {
    this.secure = !!window.isSecureContext;
    this.supported = false;
    if (!navigator.xr || !this.secure) return false;
    try { this.supported = await navigator.xr.isSessionSupported('immersive-vr'); } catch (e) { this.supported = false; }
    return this.supported;
  }

  async enter() {
    const g = this.game;
    if (!this.supported || this.active || this.entering) return false;
    this.entering = true;
    try {
      g.audio.init(); g.audio.resume();
      const opts = { optionalFeatures: ['local-floor', 'bounded-floor'] };
      const session = await navigator.xr.requestSession('immersive-vr', opts);
      this.session = session;
      this.noFloor = false;
      try {
        g.renderer.xr.setReferenceSpaceType('local-floor');
        await g.renderer.xr.setSession(session);
      } catch (e) {
        console.warn('local-floor unavailable, falling back to local', e);
        this.noFloor = true;
        g.renderer.xr.setReferenceSpaceType('local');
        await g.renderer.xr.setSession(session);
      }
      this.entering = false;
      return true;
    } catch (e) {
      console.error('Could not start VR session', e);
      this.entering = false;
      g.ui && g.ui.toast('Could not start VR: ' + (e && e.message ? e.message : e), 4000);
      return false;
    }
  }

  exit() { if (this.session) { try { this.session.end(); } catch (e) { /* */ } } }

  onSessionStart() {
    const g = this.game;
    this.active = true; this.hasPose = false; this.needCalib = true;
    this.yaw = g.player.yaw; this.bodyYaw = this.yaw; this.rigY = g.player.pos.y;
    g.weapons.setMode('vr');
    g.avatar.setMode('vr');
    g.avatar.setScale(this.avatarScale());
    this.vigMesh.visible = true;
    g.perf.apply(g.renderer, g.world);
    g.onVRStart && g.onVRStart();
  }
  onSessionEnd() {
    const g = this.game;
    this.active = false; this.session = null; this.hasPose = false;
    this.vigMesh.visible = false; this.arcLine.visible = false; this.marker.visible = false;
    for (const m of this.pads) m.visible = false;
    for (const h of this.hands) if (h) { h.hand.root.visible = false; h.laser.visible = false; }
    for (const h of this.handCache) if (h) { h.hand.root.visible = false; h.laser.visible = false; }
    g.player.yaw = this.headYaw || this.yaw;
    g.weapons.setMode('desktop');
    for (const d of g.weapons.dropped.slice()) g.weapons.discardDropped(d);
    for (const h of this.hands) if (h && h.heldNpc) { h.heldNpc = null; }
    g.avatar.setMode(g.camera_ctrl.third ? 'third' : 'hidden');
    g.avatar.ikGroup.visible = false;
    this.ui.setVisible(false);
    g.camera.position.set(0, 1.6, 0); g.camera.quaternion.identity();
    g.perf.apply(g.renderer, g.world);
    g.onVREnd && g.onVREnd();
  }

  avatarScale() { return clamp(this.game.settings.get('eyeHeight') / AVATAR_EYE_HEIGHT, 0.7, 1.3); }

  onConnected(i, ctrl, src) {
    if (!src) return;
    const hd = src.handedness;
    let idx = hd === 'left' ? 0 : hd === 'right' ? 1 : i;
    if (this.hands[idx] && this.hands[idx].ray !== ctrl) idx = 1 - idx;
    let h = this.handCache[idx];
    if (!h) { h = new VRHandController(this, idx, ctrl, src); this.handCache[idx] = h; }
    else { h.ray = ctrl; h.input = src; }
    h.hand.root.visible = true;
    this.hands[idx] = h;
    ctrl.userData.handIdx = idx;
    this.ui.attachWrist(this);
  }
  onDisconnected(i) {
    for (let k = 0; k < 2; k++) {
      const h = this.hands[k];
      if (h && h.ray === this.ctrls[i]) { h.hand.root.visible = false; h.laser.visible = false; h.input = null; this.game.weapons.holster(k); this.hands[k] = null; }
    }
  }

  // ------------------------------------------------------------------ helpers
  get moveHand() { return this.hands[this.game.settings.get('leftHanded') ? 1 : 0]; }
  get turnHand() { return this.hands[this.game.settings.get('leftHanded') ? 0 : 1]; }
  get mainIdx() { return this.game.settings.get('leftHanded') ? 0 : 1; }

  pulseHand(i, intensity, ms) { const h = this.hands[i]; if (h && h.gp) this.game.audio.vibrate(h.gp, intensity, ms); }
  pulseBoth(intensity, ms) { this.pulseHand(0, intensity, ms); this.pulseHand(1, intensity, ms); }
  handWorldPositions() {
    const a = this.hands[0], b = this.hands[1];
    const l = a ? a.palm : this._v.copy(this.headPos).add(this._v2.set(-0.3, -0.5, 0));
    const r = b ? b.palm : this._v2.copy(this.headPos).add(new THREE.Vector3(0.3, -0.5, 0));
    return [l, r];
  }

  calibrateHeight() {
    if (!this.hasPose) return;
    const y = this.headLocal.y + (this.noFloor ? this.yOffset : 0);
    if (y > 0.9 && y < 2.3) { this.game.settings.set('eyeHeight', +y.toFixed(2)); this.game.avatar.setScale(this.avatarScale()); }
    this.needCalib = true;
    this.game.ui && this.game.ui.toast('HEIGHT CALIBRATED: ' + y.toFixed(2) + ' m', 1500);
  }
  recenter() { this.needCalib = true; }

  // ------------------------------------------------------------------ per frame (before locomotion)
  preUpdate(dt, xrFrame) {
    const g = this.game, p = g.player, S = g.settings, I = p.intent;
    if (!this.active) return;
    const veh = g.vehicles;
    // ---- head pose (reference space)
    let got = false;
    const rs = g.renderer.xr.getReferenceSpace();
    if (xrFrame && rs) {
      const pose = xrFrame.getViewerPose(rs);
      if (pose) {
        const t = pose.transform;
        this.headLocal.set(t.position.x, t.position.y, t.position.z);
        this.headQuatLocal.set(t.orientation.x, t.orientation.y, t.orientation.z, t.orientation.w);
        got = true;
      }
    }
    if (!got) return;
    if (!this.hasPose) { this.prevHeadLocal.copy(this.headLocal); this.hasPose = true; }
    // ---- height calibration (seated / no-floor): compensate so the eyes sit at the calibrated height
    if (this.needCalib) {
      this.needCalib = false;
      if (S.get('seated') || this.noFloor) this.yOffset = clamp(S.get('eyeHeight') - this.headLocal.y, -0.5, 1.6);
      else this.yOffset = 0;
      this.prevHeadLocal.copy(this.headLocal);
    }
    // ---- physical walking: collide the head delta against the world (ignored while airborne/ladder/glider)
    const dlx = this.headLocal.x - this.prevHeadLocal.x, dlz = this.headLocal.z - this.prevHeadLocal.z;
    this.prevHeadLocal.copy(this.headLocal);
    if (!g.health.dead && !veh.driving && !p.gliding && !p.onLadder && p.grounded && (dlx !== 0 || dlz !== 0)) {
      if (Math.hypot(dlx, dlz) < 0.8) {
        const c = Math.cos(this.yaw), s = Math.sin(this.yaw);
        g.loco.applyPhysical(dlx * c + dlz * s, -dlx * s + dlz * c, dt);
      }
    }
    // ---- gaze yaw (world)
    const f = this._v.set(0, 0, -1).applyQuaternion(this.headQuatLocal);
    if (f.x * f.x + f.z * f.z > 0.04) this.headYaw = Math.atan2(-f.x, -f.z) + this.yaw;
    this.headForward.x = -Math.sin(this.headYaw); this.headForward.z = -Math.cos(this.headYaw);
    // body yaw trails the head while moving / when twisted far
    const moving = p.speedH > 0.5;
    const diff = Math.abs(angleDiff(this.bodyYaw, this.headYaw));
    if (moving || diff > rad(65)) this.bodyYaw = dampAngle(this.bodyYaw, this.headYaw, moving ? 8 : 3, dt);

    const mh = this.moveHand, th = this.turnHand;
    // hands read their own input in update(); here we read the sticks directly for locomotion
    for (const h of this.hands) if (h) h.readInput();
    const mStick = mh ? mh.stick : { x: 0, y: 0 }, tStick = th ? th.stick : { x: 0, y: 0 };

    if (veh.driving) { const vi = veh.input; vi.throttle = th ? th.trigger : 0; vi.brake = mh ? mh.trigger : 0; vi.steer = veh.updateWheel(dt, [mh, th], mStick.x); vi.hand = !!(th && th.b.a); vi.horn = !!(th && th.b.b); I.moveX = I.moveZ = 0; I.jump = false; }
    // ---- turning (rotates the play space around the head)
    if (veh.driving) { this.turnAmt = 0; }
    else if (S.get('turnMode') === 'snap') {
      if (Math.abs(tStick.x) > 0.7 && !this.snapLatch) { this.snapLatch = true; this.yaw -= Math.sign(tStick.x) * rad(S.get('snapAngle')); g.audio.play('ui', { gain: 0.25, rate: 1.4 }); }
      else if (Math.abs(tStick.x) < 0.35) this.snapLatch = false;
    } else if (Math.abs(tStick.x) > 0) {
      this.yaw -= tStick.x * rad(S.get('smoothTurnSpeed')) * dt;
      this.turnAmt = Math.abs(tStick.x);
    }
    if (!(Math.abs(tStick.x) > 0) || S.get('turnMode') === 'snap') this.turnAmt = 0;

    // ---- buttons
    const edge = (h, k) => h && h.pressed(k);
    if (mh && edge(mh, 'b')) this.ui.toggleMenu();                       // Y: wrist menu
    if ((mh && edge(mh, 'stickClick')) || (th && edge(th, 'stickClick'))) {
      if (veh.driving) veh.exit();
      else if (!veh.tryEnter() && mh && edge(mh, 'stickClick')) this.sprintToggle = !this.sprintToggle;
    }
    I.crouchPressed = false;
    if (!veh.driving && mh && edge(mh, 'a')) {
      if (p.grounded && p.speedH > 4.5 && !p.onLadder) { I.crouchPressed = true; }          // moving fast: X = slide
      else this.crouchToggle = !this.crouchToggle;
    }
    if (!veh.driving && th && edge(th, 'a')) {
      if (p.gliding) g.glider.retract();
      else if (!p.grounded && g.glider.canDeploy) g.glider.tryDeploy();
      else I.jump = true;
    }
    // ---- physical crouch (standing mode only)
    const headH = this.headLocal.y + this.yOffset;
    const eye = S.get('eyeHeight');
    const seated = S.get('seated');
    const wasPhys = this.physCrouch;
    this.physCrouch = !veh.driving && !seated && p.grounded && headH < eye * 0.66 && headH > 0.3;
    if (this.physCrouch && !wasPhys && p.speedH > 4.5) I.crouchPressed = true;           // dropping into a crouch while running = slide

    // ---- locomotion intent
    const mode = S.get('locomotion');
    I.moveX = 0; I.moveZ = 0;
    this.teleporting = false;
    if (!this.menuOpen && !g.health.dead && !veh.driving) {
      if (mode === 'smooth' || p.gliding) {
        if (!p.gliding) {
          I.moveX = mStick.x; I.moveZ = -mStick.y;
        }
      } else {
        // teleport mode: hold stick forward to aim, release to blink
        const aiming = mStick.y < -0.6;
        this.teleporting = aiming && !!mh;
        if (this.teleportWas && !aiming && this.tele.valid && this.tele.point) this.startTeleport(this.tele.point);
        this.teleportWas = aiming;
        if (!aiming) { I.moveX = mStick.x * 0.5; I.moveZ = mStick.y > 0 ? -mStick.y * 0.5 : 0; }   // gentle strafe / back-step
      }
    }
    // direction reference
    let refYaw = this.headYaw;
    if (S.get('moveRef') === 'hand' && mh) {
      const d = this._v.set(0, 0, -1).applyQuaternion(mh.quat);
      if (d.x * d.x + d.z * d.z > 0.04) refYaw = Math.atan2(-d.x, -d.z);
    }
    I.dirYaw = refYaw;
    const mag = Math.hypot(I.moveX, I.moveZ);
    I.sprint = this.sprintToggle && mag > 0.3 && I.moveZ > -0.1;
    if (mag < 0.1 && p.grounded) this.sprintToggle = false;     // auto-release when you stop
    I.crouch = !p.gliding && (this.crouchToggle || this.physCrouch) && !p.onLadder;
    if (p.sliding && p.slideT < 1.2) { /* slide runs on its own */ }
    if (p.gliding || p.onLadder) this.crouchToggle = false;
    p.yaw = this.headYaw;
    // ---- glider steering from hands (bar) + sticks
    const gi = g.glider.input;
    gi.yawTarget = null;
    if (p.gliding) {
      let steer = mStick.x + tStick.x, dive = -(mStick.y || 0) - (tStick.y || 0);
      const a = this.hands[0], b = this.hands[1];
      if (a && b && a.b.grip && b.b.grip) {
        const hd = (b.palm.y - a.palm.y);
        steer += clamp(-hd / 0.3, -1, 1);                         // lower right hand = bank/turn right
        const fwd = ((a.palm.x + b.palm.x) / 2 - this.headPos.x) * this.headForward.x + ((a.palm.z + b.palm.z) / 2 - this.headPos.z) * this.headForward.z;
        dive += clamp((fwd - 0.38) / 0.22, -1, 1);                // reach forward = dive, pull in = flare
      }
      gi.steer = clamp(steer, -1, 1); gi.dive = clamp(dive, -1, 1); gi.yawRate = 0;
    }
    // ---- comfort vignette amount
    const speedK = clamp((p.speedH - 3) / 12, 0, 1) * (mode === 'smooth' ? 1 : 0.4);
    const airK = (!p.grounded && (p.launched > 0 || p.gliding)) ? 0.45 : 0;
    const turnK = (this.turnAmt || 0) * 0.8;
    this.vigTarget = clamp(Math.max(speedK, airK, turnK, p.sliding ? 0.6 : 0), 0, 1) * S.get('vignette') * 1.5;
  }

  onEnterCar(c) { this.carOff = -((this.headYaw || 0) - this.yaw); this.sprintToggle = false; this.crouchToggle = false; this.teleporting = false; }
  onExitCar() { this.carOff = 0; }

  startTeleport(pt) { this.pendingTeleport = pt.clone(); this.fadeTarget = 1; }

  // ------------------------------------------------------------------ per frame (after locomotion)
  postUpdate(dt) {
    const g = this.game, p = g.player, S = g.settings;
    if (!this.active || !this.hasPose) return;
    // fade (teleport blink / snap blink)
    if (this.pendingTeleport && this.fade > 0.95) {
      const t = this.pendingTeleport; this.pendingTeleport = null;
      p.teleport(t.x, t.y, t.z); this.rigY = t.y; g.audio.play('slide', { gain: 0.4, rate: 1.6 });
      this.fadeTarget = 0;
    }
    this.fade = damp(this.fade, this.fadeTarget, this.fadeTarget > this.fade ? 38 : 16, dt);
    this.vig = damp(this.vig, this.vigTarget || 0, this.vigTarget > this.vig ? 6 : 2.5, dt);
    this.vigMat.uniforms.vig.value = this.vig; this.vigMat.uniforms.fade.value = this.fade > 0.01 ? this.fade : 0;
    this.vigMesh.visible = this.vig > 0.01 || this.fade > 0.01;

    // ---- place the rig: head world = player body (xz). yaw pivots around the head.
    const rig = g.rig;
    const car = g.vehicles.driving;
    if (car) { this.yaw = car.yaw + Math.PI + this.carOff; this.rigY = p.pos.y + 1.15 - this.headLocal.y - this.yOffset; }
    else this.rigY = Math.abs(p.pos.y - this.rigY) > 1.2 ? p.pos.y : damp(this.rigY, p.pos.y, 22, dt);
    const c = Math.cos(this.yaw), s = Math.sin(this.yaw);
    const hx = this.headLocal.x, hz = this.headLocal.z;
    rig.rotation.set(0, this.yaw, 0);
    rig.position.set(p.pos.x - (hx * c + hz * s), this.rigY + this.yOffset, p.pos.z - (-hx * s + hz * c));
    rig.updateMatrixWorld(true);
    this.headPos.set(hx, this.headLocal.y, hz).applyMatrix4(rig.matrixWorld);

    // ---- hands (weapons, grabbing, laser)
    for (const h of this.hands) if (h) h.update(dt);
    // ---- holsters follow the torso
    const hz2 = this.holsterZones;
    const sy = Math.sin(this.bodyYaw), cy = Math.cos(this.bodyYaw);
    const hh = this.headPos;
    for (const k in HOLSTERS) {
      const z = HOLSTERS[k];
      hz2[k].set(hh.x + z[0] * cy + z[2] * sy, hh.y + z[1], hh.z - z[0] * sy + z[2] * cy);
    }
    this.pouchZone.set(hh.x + 0.0 * cy + -0.2 * sy, hh.y - 0.62, hh.z - 0.0 * sy + -0.2 * cy);
    if (!this.pouchMesh) {
      const pm = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.1, 0.06), new THREE.MeshStandardMaterial({ color: 0x2a2f26, roughness: 0.85 })); pm.frustumCulled = false;
      for (let i = 0; i < 2; i++) { const mg = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.05, 0.045), new THREE.MeshStandardMaterial({ color: 0x1d2024, roughness: 0.5, metalness: 0.5 })); mg.position.set(-0.04 + i * 0.08, 0.07, 0); pm.add(mg); }
      this.pouchMesh = pm; g.world.scene.add(pm);
    }
    this.pouchMesh.visible = !g.vehicles.driving; this.pouchMesh.position.copy(this.pouchZone); this.pouchMesh.rotation.y = this.bodyYaw;
    g.weapons.updateHolsters(hh, this.bodyYaw, this.menuOpen === 'hide');
    for (const m of this.pads) {
      const z = hz2[m.userData.zone];
      m.visible = true; m.position.set(z.x, z.y - 0.08, z.z); m.rotation.y = this.bodyYaw;
      let near = false; for (const hd of this.hands) if (hd && hd.palm.distanceTo(z) < 0.3) near = true;
      m.material.emissive.setHex(near ? 0x1f5a1f : 0x000000);
    }

    // ---- teleport arc
    this.updateTeleportVisual(dt);
    // ---- avatar legs/arms
    this.updateAvatar(dt);
    // ---- UI
    this.ui.update(dt);
    g.audio.setListener(g.camera);
  }

  updateTeleportVisual(dt) {
    const g = this.game;
    if (this.teleporting && this.moveHand) {
      const h = this.moveHand;
      const dir = this._v.set(0, 0, -1).applyQuaternion(h.quat).clone();
      g.loco.teleportArc(h.pos, dir, this.tele);
      const arr = this.arcLine.geometry.attributes.position.array;
      const n = Math.min(47, this.tele.arc.length);
      for (let i = 0; i < n; i++) { const a = this.tele.arc[i]; arr[i * 3] = a.x; arr[i * 3 + 1] = a.y; arr[i * 3 + 2] = a.z; }
      for (let i = n; i < 48; i++) { const a = this.tele.arc[n - 1] || h.pos; arr[i * 3] = a.x; arr[i * 3 + 1] = a.y; arr[i * 3 + 2] = a.z; }
      this.arcLine.geometry.attributes.position.needsUpdate = true;
      this.arcLine.visible = true;
      this.marker.visible = this.tele.valid && !!this.tele.point;
      if (this.marker.visible) { this.marker.position.copy(this.tele.point); this.marker.rotation.y += dt * 1.5; }
      const col = this.tele.valid ? 0x7dff7a : 0xff6a5a;
      for (const m of this.markerMats) m.color.setHex(col);
    } else { this.arcLine.visible = false; this.marker.visible = false; this.tele.valid = false; }
  }

  updateAvatar(dt) {
    const g = this.game, p = g.player, av = g.avatar;
    const show = g.settings.get('showBody') && !g.health.dead;
    av.root.visible = show;
    av.ikGroup.visible = show;
    if (!show) return;
    av.root.position.set(p.pos.x, p.pos.y, p.pos.z);
    av.root.rotation.y = this.bodyYaw;
    // legs/torso hidden in VR mode (body mesh hidden); feed the animation state so the legs walk
    const wh = g.weapons;
    av.animate(dt, {
      speed: p.speedH, grounded: p.grounded, crouch: p.crouching, slide: p.sliding, sprint: p.sprinting, vy: p.vel.y, gliding: p.gliding,
      deploy: g.glider.active && g.glider.deploy > 0 && g.glider.deploy < 0.9, shoot: false, reload: false, landImpact: 0, turn: 0, hurt: p.hurtT > 0, dt,
    });
    // arms: shoulders sit just below the head; elbows point down/out
    const hd = this.headPos, sy = Math.sin(this.bodyYaw), cy = Math.cos(this.bodyYaw);
    const shoulder = (sx) => this._v.set(hd.x + sx * cy, hd.y - 0.24, hd.z - sx * sy).clone();
    const pole = (sx) => new THREE.Vector3(hd.x + sx * 2.2 * cy, hd.y - 0.9, hd.z - sx * 2.2 * sy);
    for (let i = 0; i < 2; i++) {
      const h = this.hands[i], ik = av.ik[i];
      const vis = !!h && h.hand.root.visible;
      ik.up.visible = ik.fo.visible = ik.elbow.visible = vis;
      if (vis) av.solveArm(i, shoulder(i === 0 ? -0.2 : 0.2), h.palm, pole(i === 0 ? -0.2 : 0.2));
    }
  }
}
