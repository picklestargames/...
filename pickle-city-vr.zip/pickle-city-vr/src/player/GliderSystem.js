// The "Gherkin Glider": two pickle-slice wings on a dill-sprig frame with a bottle-cap propeller.
// Never rotates the VR camera: the player is carried along a steered heading (like a vehicle) while the head stays free.
import * as THREE from 'three';
import { clamp, damp, dampAngle, angleDiff, lerp } from '../core/Utils.js';

const MIN_ALT = 5;
const SINK_MIN = 2.3, SINK_MAX = 10;
const SPD_MIN = 11, SPD_BASE = 17, SPD_MAX = 31;

export class GliderSystem {
  constructor(game) {
    this.game = game;
    this.active = false;
    this.deploy = 0;         // 0 = stowed, 1 = fully open
    this.target = 0;
    this.yaw = 0;            // heading (direction of travel)
    this.bank = 0;
    this.dive = 0;           // 0 = neutral, +1 dive, -1 flare
    this.speed = 0;
    this.input = { steer: 0, dive: 0, yawTarget: null, yawRate: 0 };
    this.group = new THREE.Group();
    this.group.visible = false;
    this.build();
    game.world.scene.add(this.group);
    this.canDeploy = false;
    this.wind = 0;
  }

  build() {
    const M = this.game.world.mats;
    const skin = M.pickleWet, dill = M.flat(0x3f7a28, 0.7, 0), seed = M.flat(0xe6dca0, 0.8, 0), metal = M.flat(0xb8bcc4, 0.35, 0.8), rope = M.flat(0x1b1b1b, 0.9, 0);
    const root = this.group;
    this.frame = new THREE.Group(); root.add(this.frame);
    const spine = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.12, 3.4), dill); spine.position.set(0, 0, 0.1); this.frame.add(spine);
    this.wings = [];
    for (const s of [-1, 1]) {
      const pivot = new THREE.Group(); pivot.position.set(s * 0.1, 0.02, 0);
      const g = new THREE.SphereGeometry(1, 16, 7); g.scale(2.7, 0.07, 1.65); g.translate(s * 2.7, 0, 0);
      const wing = new THREE.Mesh(g, skin); wing.castShadow = true; pivot.add(wing);
      // pickle-slice seed rings
      const sg = new THREE.SphereGeometry(0.11, 5, 4); sg.scale(1.4, 0.4, 0.8);
      for (let k = 0; k < 14; k++) {
        const a = (k / 14) * Math.PI * 2;
        const m = new THREE.Mesh(sg, seed); m.position.set(s * (2.0 + Math.cos(a) * 1.3), 0.075, Math.sin(a) * 0.62); m.rotation.y = a; pivot.add(m);
      }
      // wing rib poles
      const rib = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 4.8, 5), dill); rib.rotation.z = Math.PI / 2; rib.position.set(s * 2.5, -0.02, 0); pivot.add(rib);
      this.frame.add(pivot); this.wings.push({ pivot, s });
    }
    // tail flaps (dill sprigs)
    this.flaps = [];
    for (const s of [-1, 1]) {
      const f = new THREE.Group(); f.position.set(s * 0.12, 0, 1.8);
      const m = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.04, 0.5), dill); m.position.set(s * 0.3, 0, 0.2); f.add(m);
      this.frame.add(f); this.flaps.push({ f, s });
    }
    // bottle-cap propeller up front
    this.prop = new THREE.Group(); this.prop.position.set(0, 0, -1.75);
    const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.24, 0.07, 14), metal); cap.rotation.x = Math.PI / 2; this.prop.add(cap);
    for (let k = 0; k < 3; k++) { const b = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.02, 0.1), dill); b.rotation.z = (k / 3) * Math.PI; b.position.z = -0.05; this.prop.add(b); }
    this.frame.add(this.prop);
    // hang rods (cables to the player's hands/shoulders)
    this.rods = [0, 1].map(() => { const r = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 1, 4), rope); r.geometry.translate(0, 0.5, 0); r.frustumCulled = false; this.group.add(r); return r; });
    // control bar
    this.bar = new THREE.Group();
    const barMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.6, 6), metal); barMesh.rotation.z = Math.PI / 2; this.bar.add(barMesh);
    this.group.add(this.bar);
    this.frame.scale.setScalar(0.001);
  }

  tryDeploy() {
    const g = this.game, p = g.player;
    if (this.active || p.grounded || p.onLadder || g.health.dead) return false;
    if (p.altitude < MIN_ALT || p.vel.y > 3.5) return false;
    this.active = true; this.target = 1; p.gliding = true; p.sliding = false;
    this.speed = Math.max(SPD_BASE * 0.8, p.speedH);
    this.yaw = p.speedH > 3 ? Math.atan2(-p.vel.x, -p.vel.z) : p.yaw;
    this.group.visible = true;
    g.audio.play('deploy', { pos: { x: p.pos.x, y: p.pos.y + 2, z: p.pos.z }, gain: 1.1, hrtf: false });
    g.particles.burst({ x: p.pos.x, y: p.pos.y + p.height + 0.8, z: p.pos.z }, [0.7, 1, 0.5], 18, 4, 0.12, 0.5);
    if (g.vr.active) g.vr.pulseBoth(0.7, 120);
    g.ui && g.ui.toast('GHERKIN GLIDER!', 900);
    return true;
  }
  retract() {
    if (!this.active) return;
    this.target = 0; this.game.player.gliding = false;
    this.game.audio.play('retract', { gain: 0.8, hrtf: false });
  }
  toggle() { if (this.active && this.target > 0) this.retract(); else this.tryDeploy(); }
  onLand() {
    const g = this.game, p = g.player;
    this.retract();
    p.vel.x *= 0.45; p.vel.z *= 0.45;
    g.particles.poof({ x: p.pos.x, y: p.pos.y, z: p.pos.z }, [0.85, 0.85, 0.8], 12, 3, 0.4);
  }

  update(dt) {
    const g = this.game, p = g.player, I = this.input;
    // availability hint
    this.canDeploy = !this.active && !p.grounded && p.altitude > MIN_ALT + 2 && p.vel.y < 1 && !p.onLadder;
    // animate open/close with a little spring overshoot
    const k = this.target > this.deploy ? 4.2 : 6;
    this.deploy = damp(this.deploy, this.target, k, dt);
    if (Math.abs(this.deploy - this.target) < 0.004) this.deploy = this.target;
    if (this.active && this.target === 0 && this.deploy <= 0.01) { this.active = false; this.group.visible = false; }
    if (!this.active) { this.wind = damp(this.wind, 0, 3, dt); return; }

    if (this.target > 0 && p.gliding) {
      // ---------- flight model
      if (g.health.dead || p.onLadder) { this.retract(); }
      // heading
      let turn = 0;
      if (I.yawTarget !== null && I.yawTarget !== undefined) {
        const d = angleDiff(this.yaw, I.yawTarget);
        turn = clamp(d * 2.2, -1.9, 1.9);
      } else turn = -I.steer * 1.5;
      turn += I.yawRate || 0;
      this.yaw += turn * dt;
      this.bank = damp(this.bank, clamp(-turn / 1.9, -1, 1), 5, dt);
      // dive / flare
      this.dive = damp(this.dive, clamp(I.dive, -1, 1), 3.5, dt);
      const dv = this.dive;
      const tSpeed = dv >= 0 ? lerp(SPD_BASE, SPD_MAX, dv) : lerp(SPD_BASE, SPD_MIN, -dv);
      const tSink = dv >= 0 ? lerp(SINK_MIN + 1.0, SINK_MAX, dv) : lerp(SINK_MIN + 1.0, 1.4, -dv);
      this.speed = damp(this.speed, tSpeed * g.health.speedMul ** 0.5, 1.4, dt);
      const dirX = -Math.sin(this.yaw), dirZ = -Math.cos(this.yaw);
      p.vel.x = damp(p.vel.x, dirX * this.speed, 2.6, dt);
      p.vel.z = damp(p.vel.z, dirZ * this.speed, 2.6, dt);
      p.vel.y = damp(p.vel.y, -tSink, 2.4, dt);
      // updraft from jump pad beams keeps glides satisfying
      p.airTime += 0;
      // wind particles
      if (Math.random() < dt * 40) g.particles.windStreak({ x: p.pos.x + dirX * 4, y: p.pos.y + 1.2, z: p.pos.z + dirZ * 4 }, p.vel, 1);
      // gentle haptic rumble in VR
      if (g.vr.active && Math.random() < dt * 8) g.vr.pulseBoth(0.08 + this.speed / 300, 40);
    }
    this.wind = this.speed;

    // ---------- visuals
    const op = clamp(this.deploy, 0, 1.15);
    const sc = Math.max(0.001, op);
    this.frame.scale.setScalar(sc);
    const fold = (1 - Math.min(1, op)) * 1.45;
    for (const w of this.wings) { w.pivot.rotation.z = w.s * (fold + Math.max(0, op - 1) * -0.6) * -1 + this.bank * -w.s * 0.12; w.pivot.rotation.y = w.s * fold * 0.6; }
    for (const f of this.flaps) f.f.rotation.x = Math.sin(performance.now() * 0.004 + f.s) * 0.12 + this.dive * -0.35 + (1 - op) * 0.8;
    this.prop.rotation.z += dt * (6 + this.speed * 1.4) * op;
    const anchor = new THREE.Vector3(p.pos.x, p.pos.y + p.height + 1.25, p.pos.z);
    this.group.position.copy(anchor);
    this.group.rotation.set(0, this.yaw + Math.PI, 0); // model's nose is -Z; group yaw: travel = -sin/-cos
    this.group.rotation.y = this.yaw;
    this.frame.rotation.z = this.bank * 0.5; this.frame.rotation.x = -this.dive * 0.28;
    // control bar + rods to the player (hands in VR / chest in desktop)
    this.updateHang(anchor);
  }

  updateHang(anchor) {
    const g = this.game, p = g.player;
    const hands = g.vr.active ? g.vr.handWorldPositions() : null;
    const tmp = new THREE.Vector3();
    const worldAnchor = anchor.clone();
    const set = (rod, from, to) => {
      const v = tmp.subVectors(to, from); const len = v.length() || 0.001;
      rod.position.copy(from); rod.scale.set(1, len, 1); rod.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), v.clone().multiplyScalar(1 / len));
    };
    const vis = this.deploy > 0.5;
    for (const r of this.rods) r.visible = vis;
    this.bar.visible = vis && !hands;
    if (hands) {
      set(this.rods[0], worldAnchor.clone().add(new THREE.Vector3(-0.4, 0, 0).applyAxisAngle(new THREE.Vector3(0, 1, 0), this.yaw)), hands[0]);
      set(this.rods[1], worldAnchor.clone().add(new THREE.Vector3(0.4, 0, 0).applyAxisAngle(new THREE.Vector3(0, 1, 0), this.yaw)), hands[1]);
    } else {
      const chest = new THREE.Vector3(p.pos.x, p.pos.y + p.height * 0.78, p.pos.z);
      const fw = new THREE.Vector3(-Math.sin(this.yaw), 0, -Math.cos(this.yaw)).multiplyScalar(0.35);
      const l = new THREE.Vector3(-0.3, 0, 0).applyAxisAngle(new THREE.Vector3(0, 1, 0), this.yaw).add(chest).add(fw);
      const r2 = new THREE.Vector3(0.3, 0, 0).applyAxisAngle(new THREE.Vector3(0, 1, 0), this.yaw).add(chest).add(fw);
      set(this.rods[0], worldAnchor.clone().add(new THREE.Vector3(-0.35, 0, 0).applyAxisAngle(new THREE.Vector3(0, 1, 0), this.yaw)), l);
      set(this.rods[1], worldAnchor.clone().add(new THREE.Vector3(0.35, 0, 0).applyAxisAngle(new THREE.Vector3(0, 1, 0), this.yaw)), r2);
      this.bar.position.copy(chest).add(fw); this.bar.rotation.y = this.yaw;
    }
  }
}
