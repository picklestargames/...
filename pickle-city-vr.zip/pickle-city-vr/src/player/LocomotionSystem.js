// Movement physics: acceleration, momentum, air control, sprint, slide, jump, ladders, landing, teleport.
import * as THREE from 'three';
import { moveBody } from '../world/CollisionWorld.js';
import { GRAVITY } from '../world/Constants.js';
import { clamp, damp, lerp } from '../core/Utils.js';

const WALK = 6.4, SPRINT = 10.8, CROUCH = 3.2;
const ACCEL = 44, DECEL = 34, AIR_ACCEL = 16, MOMENTUM_FRICTION = 3.2;
const JUMP_V = 8.7;
const MAX_FALL = 58;

export class LocomotionSystem {
  constructor(game) {
    this.game = game;
    this._w = new THREE.Vector3();
    this.footDist = 0;
    this.padCooldown = 0;
    this.events = [];
  }

  update(dt) {
    const g = this.game, p = g.player, w = g.world.collision, I = p.intent, S = g.settings;
    if (g.health.dead) { p.vel.x = p.vel.z = 0; I.jump = false; }
    p.launched = Math.max(0, p.launched - dt);
    this.padCooldown = Math.max(0, this.padCooldown - dt);
    p.hurtT = Math.max(0, p.hurtT - dt);
    const speedMul = S.get('moveSpeed') * g.health.speedMul;

    // ---- crouch / slide state
    const wasCrouch = p.crouching;
    if (I.crouchPressed && p.grounded && p.speedH > 4.5 && !p.sliding && !p.onLadder && !p.gliding) this.startSlide();
    const wantCrouch = I.crouch && !p.gliding;
    if (wantCrouch && !p.crouching) { p.crouching = true; p.height = p.crouchH; }
    else if (!wantCrouch && p.crouching && !p.sliding) {
      if (!w.blockedAt(p.pos.x, p.pos.y + 0.02, p.pos.z, p.radius * 0.9, p.standH)) { p.crouching = false; p.height = p.standH; }
    }
    if (p.sliding) {
      p.slideT += dt;
      if (!p.grounded || p.slideT > 1.25 || p.speedH < 3.3) this.endSlide(wantCrouch);
    }
    p.sprinting = I.sprint && !p.crouching && p.grounded ? (I.moveX * I.moveX + I.moveZ * I.moveZ > 0.25) : (p.sprinting && !p.grounded && I.sprint);
    if (!wantCrouch && p.sliding) { /* slide continues until it dies out */ }

    // ---- ladder
    if (this.updateLadder(dt)) { this.finish(dt, wasCrouch); return; }

    // ---- horizontal
    let wishX = 0, wishZ = 0;
    const m = Math.hypot(I.moveX, I.moveZ);
    if (m > 0.05) {
      const c = Math.cos(I.dirYaw), s = Math.sin(I.dirYaw);
      // forward = -Z rotated by yaw; strafe = +X
      const fx = -s, fz = -c, rx = c, rz = -s;
      wishX = rx * I.moveX + fx * I.moveZ; wishZ = rz * I.moveX + fz * I.moveZ;
      const l = Math.hypot(wishX, wishZ) || 1; wishX /= l; wishZ /= l;
    }
    const mag = Math.min(1, m);
    let target = (p.crouching ? CROUCH : p.sprinting ? SPRINT : WALK) * speedMul * (p.sprinting ? 1 : mag);
    if (p.gliding) { /* glider owns horizontal velocity */ }
    else if (p.sliding) {
      const sp = p.speedH;
      const fr = 5.2 + (p.slideT * 3.2);
      const ns = Math.max(0, sp - fr * dt);
      if (sp > 0.01) { const k = ns / sp; p.vel.x *= k; p.vel.z *= k; }
      // a little steering
      if (m > 0.2) { p.vel.x += wishX * 6 * dt; p.vel.z += wishZ * 6 * dt; }
    } else if (p.grounded) {
      const vx = p.vel.x, vz = p.vel.z;
      const sp = Math.hypot(vx, vz);
      if (m > 0.05) {
        const tx = wishX * target, tz = wishZ * target;
        const dx = tx - vx, dz = tz - vz, dl = Math.hypot(dx, dz);
        const acc = (sp > target + 0.5 ? MOMENTUM_FRICTION : ACCEL) * dt;
        if (dl > 0.0001) { const k = Math.min(1, acc / dl); if (sp > target + 0.5) { // keep momentum, just steer it
          const ns = Math.max(target, sp - MOMENTUM_FRICTION * 1.6 * dt);
          const ang = Math.atan2(tz, tx), cur = Math.atan2(vz, vx);
          let d = ang - cur; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI;
          const na = cur + clamp(d, -6 * dt, 6 * dt);
          p.vel.x = Math.cos(na) * ns; p.vel.z = Math.sin(na) * ns;
        } else { p.vel.x += dx * k; p.vel.z += dz * k; } }
      } else {
        const ns = Math.max(0, sp - (sp > WALK ? MOMENTUM_FRICTION * 2 : DECEL) * dt);
        if (sp > 0.001) { const k = ns / sp; p.vel.x *= k; p.vel.z *= k; }
      }
    } else if (!p.gliding) {
      // air control: add speed along wish dir without exceeding the wish speed (never remove momentum)
      if (m > 0.05) {
        const ws = Math.max(WALK, p.sprinting ? SPRINT : WALK) * speedMul * mag;
        const cur = p.vel.x * wishX + p.vel.z * wishZ;
        const add = ws - cur;
        if (add > 0) { const a = Math.min(add, AIR_ACCEL * dt * ws * 0.35 + AIR_ACCEL * dt); p.vel.x += wishX * a; p.vel.z += wishZ * a; }
      }
    }

    // ---- jump
    p.coyote = p.grounded ? 0.12 : Math.max(0, p.coyote - dt);
    if (I.jump) p.jumpBuffer = 0.14; else p.jumpBuffer = Math.max(0, p.jumpBuffer - dt);
    I.jump = false;
    if (p.jumpBuffer > 0 && p.coyote > 0 && !p.gliding && !g.health.dead) {
      p.vel.y = JUMP_V * (p.sliding ? 1.05 : 1);
      if (p.sliding) { this.endSlide(false); const sp = p.speedH; if (sp > 0) { const k = (sp + 2.0) / sp; p.vel.x *= k; p.vel.z *= k; } }
      p.grounded = false; p.coyote = 0; p.jumpBuffer = 0; p.launched = 0.25;
      g.audio.play('jump', { gain: 0.8 });
      g.particles.poof({ x: p.pos.x, y: p.pos.y, z: p.pos.z }, [0.8, 0.8, 0.78], 4, 1, 0.25);
      this.events.push('jump');
    }

    // ---- gravity
    if (!p.gliding) {
      if (!p.grounded || p.vel.y > 0) p.vel.y -= GRAVITY * (p.vel.y < 0 ? 1.12 : 1) * dt;
      p.vel.y = Math.max(p.vel.y, -MAX_FALL);
    }

    this.step(dt, wasCrouch);
  }

  step(dt, wasCrouch) {
    const g = this.game, p = g.player, w = g.world.collision;
    // sub-step for high speeds so thin parapets/slabs can't be tunnelled
    const speed = Math.hypot(p.vel.x, p.vel.y, p.vel.z);
    const n = clamp(Math.ceil((speed * dt) / 0.22), 1, 8);
    const sdt = dt / n;
    const wasGrounded = p.grounded && p.launched <= 0;
    let landed = false, impact = 0, hitWall = false;
    for (let k = 0; k < n; k++) {
      moveBody(w, p.pos, p.vel, sdt, p.radius, p.height, 0.55, p.out, p.grounded && p.launched <= 0);
      if (p.out.landed) { landed = true; impact = Math.max(impact, p.out.impact); }
      if (p.out.hitX || p.out.hitZ) hitWall = true;
    }
    p.groundY = p.out.groundY;
    const wasAir = !p.grounded;
    p.grounded = p.out.grounded && p.launched <= 0 ? true : (p.out.grounded && p.vel.y <= 0);
    if (p.launched > 0 && p.vel.y > 0) p.grounded = false;
    if (!p.grounded) p.airTime += dt;
    if (landed && p.airTime > 0.12) this.land(impact);
    if (p.grounded) { if (landed || wasAir) p.airTime = 0; }
    // keep the player in the world
    const WH = 280 + 30;
    p.pos.x = clamp(p.pos.x, -WH, WH); p.pos.z = clamp(p.pos.z, -WH, WH);
    if (p.pos.y < -60) { p.teleport(p.safePos.x, p.safePos.y + 1, p.safePos.z); }
    this.finish(dt, wasCrouch);
    if (p.grounded) this.updateSafe(dt);
  }

  updateSafe(dt) {
    const p = this.game.player;
    this._safeT = (this._safeT || 0) + dt;
    if (this._safeT > 1.5 && p.speedH < 9 && p.grounded) { p.safePos.copy(p.pos); this._safeT = 0; }
  }

  finish(dt, wasCrouch) {
    const g = this.game, p = g.player;
    // car collisions
    const hit = g.world.carHit(p.pos.x, p.pos.y, p.pos.z, p.radius);
    if (hit && hit.speed > 2 && !g.health.dead && this.padCooldown <= 0) {
      p.vel.x += hit.kx * 9; p.vel.z += hit.kz * 9; p.vel.y = Math.max(p.vel.y, 4);
      p.grounded = false; p.launched = 0.2;
      g.health.damage(8, 'car');
      g.audio.play('honk', { pos: { x: hit.car.x, y: 1, z: hit.car.z }, gain: 1.2 });
      this.padCooldown = 0.8;
    } else if (hit && !p.driving) { p.pos.x += hit.kx * 0.15; p.pos.z += hit.kz * 0.15; }
    // footsteps
    if (p.grounded && !p.sliding && p.speedH > 0.8 && !p.onLadder) {
      this.footDist += p.speedH * dt;
      const stride = p.sprinting ? 2.6 : p.crouching ? 1.6 : 2.2;
      if (this.footDist > stride) {
        this.footDist = 0;
        const metal = p.pos.y > 0.4;
        g.audio.play(metal ? 'stepMetal' : 'step', { pos: { x: p.pos.x, y: p.pos.y, z: p.pos.z }, gain: (p.crouching ? 0.25 : p.sprinting ? 0.7 : 0.5), ref: 3, vary: 0.2, hrtf: false });
      }
    }
    // visual eye drop (smoothed) – never a violent camera move
    const target = p.sliding ? 0.0 : 0;
    p.eyeOffset = damp(p.eyeOffset, target, 10, dt);
  }

  land(impact) {
    const g = this.game, p = g.player;
    p.landImpact = impact;
    const hard = impact > 7;
    if (hard) {
      g.audio.play('land', { pos: { x: p.pos.x, y: p.pos.y, z: p.pos.z }, gain: clamp(impact / 25, 0.25, 1.1), hrtf: false });
      g.particles.poof({ x: p.pos.x, y: p.pos.y, z: p.pos.z }, [0.85, 0.85, 0.82], Math.min(14, 4 + impact * 0.4), clamp(impact * 0.15, 1, 4), 0.3);
      // comfortable camera feedback: very small dip (desktop larger than VR)
      p.eyeOffset = Math.max(p.eyeOffset, clamp(impact * (g.vr.active ? 0.0035 : 0.012), 0, g.vr.active ? 0.07 : 0.22));
      if (g.vr.active) g.vr.pulseBoth(clamp(impact / 30, 0.2, 0.8), 60);
    }
    if (impact > 40 && !p.gliding) g.health.damage(Math.round((impact - 40) * 1.4), 'fall');
    if (p.gliding) g.glider.onLand();
    this.events.push('land');
    // landing a slide-jump keeps momentum; otherwise light friction
    if (impact > 14) { const k = 0.9; p.vel.x *= k; p.vel.z *= k; }
  }

  startSlide() {
    const p = this.game.player;
    p.sliding = true; p.slideT = 0; p.crouching = true; p.height = p.crouchH;
    const sp = p.speedH;
    const boost = clamp(sp * 1.12, 9.5, 14.5);
    if (sp > 0.1) { p.vel.x *= boost / sp; p.vel.z *= boost / sp; }
    this.game.audio.play('slide', { pos: { x: p.pos.x, y: p.pos.y, z: p.pos.z }, gain: 0.7, hrtf: false });
    this.events.push('slide');
  }
  endSlide(keepCrouch) { const p = this.game.player; p.sliding = false; if (!keepCrouch && !this.game.player.intent.crouch) { /* stand handled by crouch logic */ } }

  updateLadder(dt) {
    const g = this.game, p = g.player, w = g.world.collision, I = p.intent;
    if (p.gliding) { p.onLadder = null; return false; }
    const L = w.ladderAt(p.pos.x, p.pos.y + 0.6, p.pos.z);
    if (p.onLadder && !L) { p.onLadder = null; return false; }
    if (!p.onLadder) {
      if (L && I.moveZ > 0.4 && p.vel.y < 4) { p.onLadder = L; p.sliding = false; }
      else return false;
    } else p.onLadder = L;
    const lad = p.onLadder;
    // jump off backwards
    if (I.jump) {
      I.jump = false; p.onLadder = null; p.vel.set(lad.fx * 4.5, 6.5, lad.fz * 4.5); p.launched = 0.3; p.grounded = false; return false;
    }
    const climb = I.moveZ * 3.3 * (g.settings.get('moveSpeed') * 0.5 + 0.5);
    p.vel.set(0, climb, 0);
    // glue to the ladder plane
    const tx = lad.x + lad.fx * 0.34, tz = lad.z + lad.fz * 0.34;
    p.pos.x = damp(p.pos.x, tx, 18, dt); p.pos.z = damp(p.pos.z, tz, 18, dt);
    p.pos.y += climb * dt;
    p.grounded = false; p.airTime = 0;
    // reached the top or bottom
    if (p.pos.y >= lad.y1 - 0.15 && I.moveZ > 0) {
      // hop onto the surface behind the ladder
      const px = lad.x - lad.fx * 0.9, pz = lad.z - lad.fz * 0.9;
      const gy = w.groundBelow(px, p.pos.y + 0.7, pz, p.radius * 0.8, 0);
      if (gy > p.pos.y - 0.4 && gy < p.pos.y + 0.9) { p.pos.set(px, gy, pz); p.vel.set(0, 0, 0); p.onLadder = null; p.grounded = true; p.groundY = gy; return true; }
    }
    if (p.pos.y <= lad.y0 && I.moveZ < 0) { p.onLadder = null; p.pos.y = Math.max(p.pos.y, lad.y0); }
    // intermediate floors: step off when pushing forward into a floor slab right behind the ladder
    if (I.moveZ > 0) {
      const px = lad.x - lad.fx * 0.9, pz = lad.z - lad.fz * 0.9;
      const gy = w.groundBelow(px, p.pos.y + 0.35, pz, p.radius * 0.8, 0);
      if (gy > -1e8 && Math.abs(gy - p.pos.y) < 0.3 && gy > 0.5 && w.ladderAt(p.pos.x, p.pos.y + 0.6, p.pos.z) && (lad.y1 - gy) > 1.0 && p.pos.y - gy < 0.2 && I.moveX !== 0) { p.pos.set(px, gy, pz); p.vel.set(0, 0, 0); p.onLadder = null; p.grounded = true; return true; }
    }
    return true;
  }

  /** Apply a launch (jump pad). */
  launch(vx, vy, vz) {
    const p = this.game.player;
    p.vel.set(vx, vy, vz); p.grounded = false; p.launched = 0.35; p.sliding = false; p.onLadder = null; p.airTime = 0; p.coyote = 0;
    if (p.crouching) { p.crouching = false; p.height = p.standH; }
    this.padCooldown = 0.25;
  }

  /** VR physical walking: collide the head-driven body delta (no gravity). */
  applyPhysical(dx, dz, dt) {
    const g = this.game, p = g.player, w = g.world.collision;
    if (dt <= 0 || (dx === 0 && dz === 0)) return;
    const tmpV = { x: dx / dt, y: 0, z: dz / dt };
    const ox = p.pos.x, oy = p.pos.y;
    const n = Math.max(1, Math.ceil(Math.hypot(dx, dz) / 0.2));
    const out = {};
    for (let k = 0; k < n; k++) moveBody(w, p.pos, tmpV, dt / n, p.radius, p.height, 0.2, out, p.grounded);
    // moveBody can step-up; revert large vertical changes caused by physical walking (comfort)
    if (p.pos.y - oy > 0.25 || !p.grounded) p.pos.y = oy;
  }

  /** Find a teleport target along a ballistic arc. returns {valid, point, arc[]} */
  teleportArc(origin, dir, out) {
    const w = this.game.world.collision, p = this.game.player;
    const pts = out.arc; pts.length = 0;
    const v = dir.clone().multiplyScalar(11);
    const pos = origin.clone();
    const dt = 0.05;
    out.valid = false;
    for (let i = 0; i < 40; i++) {
      pts.push(pos.clone());
      const nv = v.clone(); nv.y -= 20 * dt;
      const seg = nv.clone().multiplyScalar(dt); const len = seg.length();
      const d = seg.clone().normalize();
      const hit = w.raycast(pos.x, pos.y, pos.z, d.x, d.y, d.z, len, {});
      if (hit) {
        const pt = pos.clone().addScaledVector(d, hit.t);
        pts.push(pt.clone());
        if (hit.ny > 0.7) {
          const gy = w.groundBelow(pt.x, pt.y + 0.1, pt.z, 0.2, 0.2);
          if (!w.blockedAt(pt.x, gy + 0.05, pt.z, p.radius, p.standH * 0.85)) { out.valid = true; out.point = new THREE.Vector3(pt.x, gy, pt.z); }
        }
        break;
      }
      pos.addScaledVector(nv, dt); v.copy(nv);
      if (pos.y < -8) break;
    }
    return out;
  }
}
