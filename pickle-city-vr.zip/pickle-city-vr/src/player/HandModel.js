// Low-poly articulated pickle-green hand. Local frame (right hand): palm normal = -X, fingers point -Z, stacked along Y.
// curl(index, grip, thumb) sets finger pose. Left hand = mirrored by scale.x = -1 on the wrapper.
import * as THREE from 'three';

const _box = (w, h, d, mat, x = 0, y = 0, z = 0) => { const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat); m.position.set(x, y, z); return m; };

export class HandModel {
  constructor(mats) {
    this.root = new THREE.Group();
    const skin = mats.pickleWet;
    this.skin = skin;
    // palm
    const palm = _box(0.03, 0.085, 0.095, skin, 0, 0, 0.0);
    palm.castShadow = false;
    this.root.add(palm);
    this.fingers = [];
    const ys = [0.03, 0.01, -0.01, -0.03];
    const len = [0.036, 0.04, 0.038, 0.03];
    ys.forEach((y, i) => {
      const f1 = new THREE.Group(); f1.position.set(0, y, -0.047);
      f1.add(_box(0.018, 0.017, len[i], skin, 0, 0, -len[i] / 2));
      const f2 = new THREE.Group(); f2.position.set(0, 0, -len[i]);
      f2.add(_box(0.016, 0.015, len[i] * 0.85, skin, 0, 0, -len[i] * 0.425));
      const f3 = new THREE.Group(); f3.position.set(0, 0, -len[i] * 0.85);
      f3.add(_box(0.014, 0.013, len[i] * 0.55, skin, 0, 0, -len[i] * 0.275));
      f2.add(f3); f1.add(f2); this.root.add(f1);
      this.fingers.push([f1, f2, f3]);
    });
    // thumb
    const t1 = new THREE.Group(); t1.position.set(-0.005, 0.045, -0.03);
    t1.add(_box(0.02, 0.018, 0.035, skin, 0, 0, -0.0175));
    const t2 = new THREE.Group(); t2.position.set(0, 0, -0.035);
    t2.add(_box(0.017, 0.016, 0.03, skin, 0, 0, -0.015));
    t1.add(t2); this.root.add(t1);
    this.thumb = [t1, t2];
    // wrist cuff
    this.root.add(_box(0.034, 0.07, 0.025, mats.flat(0x2b2f33, 0.6, 0.2), 0, 0, 0.06));
    this.curlState = [0, 0, 0];
    this.curl(0, 0, 0);
  }

  /** index: 0..1 (trigger), grip: 0..1 (middle/ring/pinky), thumb: 0..1 */
  curl(index, grip, thumb) {
    this.curlState = [index, grip, thumb];
    const set = (f, c, base = 0) => { f[0].rotation.y = base + c * 1.2; f[1].rotation.y = c * 1.35; f[2].rotation.y = c * 0.9; };
    set(this.fingers[0], index, 0.0);
    set(this.fingers[1], grip); set(this.fingers[2], grip); set(this.fingers[3], grip * 0.95);
    for (let i = 1; i < 4; i++) this.fingers[i][0].rotation.x = 0;
    this.thumb[0].rotation.y = 0.15 + thumb * 0.9; this.thumb[0].rotation.z = -thumb * 0.35; this.thumb[1].rotation.y = thumb * 0.8;
  }

  setVisible(v) { this.root.visible = v; }
}
