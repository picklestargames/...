// Desktop camera: smoothing, subtle bob, FOV effects, recoil recovery, optional third-person.
// (In VR the headset owns the camera – VRPlayerController never rotates it.)
import * as THREE from 'three';
import { clamp, damp } from '../core/Utils.js';

export class CameraController {
  constructor(game) {
    this.game = game;
    this.eyeLocal = 1.63;
    this.bobT = 0; this.bobAmt = 0;
    this.fov = 80; this.fovKick = 0;
    this.recoilP = 0; this.recoilY = 0;
    this.shake = 0;
    this.third = false;
    this.ads = 0;
    this._v = new THREE.Vector3();
  }
  punch(a) { this.fovKick = Math.max(this.fovKick, a * 14); this.shake = Math.max(this.shake, a * 0.6); }
  addRecoil(p, y) { this.recoilP += p; this.recoilY += y; }

  update(dt) {
    const g = this.game, p = g.player, cam = g.camera, rig = g.rig;
    if (g.vr.active) return;
    const S = g.settings;
    // eye height follows crouch/slide smoothly
    const slideDip = p.sliding ? 0.18 : 0;
    const targetEye = p.height - 0.12 - slideDip - p.eyeOffset;
    this.eyeLocal = damp(this.eyeLocal, targetEye, 14, dt);
    // recoil settles back (the view recovers, not the aim punch itself)
    const rp = this.recoilP * (1 - Math.exp(-9 * dt)), ry = this.recoilY * (1 - Math.exp(-9 * dt));
    this.recoilP -= rp; this.recoilY -= ry;
    p.pitch = clamp(p.pitch + rp, -1.5, 1.5); p.yaw += ry;
    // bob
    const moving = p.grounded && p.speedH > 1 && !p.sliding;
    this.bobAmt = damp(this.bobAmt, moving ? Math.min(1, p.speedH / 10) : 0, 8, dt);
    this.bobT += dt * (6 + p.speedH * 0.6) * (moving ? 1 : 0);
    const bobY = Math.sin(this.bobT * 2) * 0.018 * this.bobAmt, bobX = Math.cos(this.bobT) * 0.012 * this.bobAmt;
    this.shake = Math.max(0, this.shake - dt * 3);
    const sh = this.shake * 0.02;
    rig.position.copy(p.pos);
    rig.rotation.set(0, p.yaw, 0);
    cam.position.set(bobX + (Math.random() - 0.5) * sh, this.eyeLocal + bobY + (Math.random() - 0.5) * sh, 0);
    cam.rotation.set(p.pitch, 0, -bobX * 0.4 + (p.sliding ? 0.04 : 0), 'YXZ');
    if (this.third) {
      const back = new THREE.Vector3(Math.sin(p.yaw) * Math.cos(p.pitch), -Math.sin(p.pitch) * 0 + 0.0, Math.cos(p.yaw) * Math.cos(p.pitch));
      const pivot = new THREE.Vector3(p.pos.x, p.pos.y + p.height * 0.85, p.pos.z);
      let dist = this.dist || 3.6;
      const dir = new THREE.Vector3(Math.sin(p.yaw) * Math.cos(p.pitch), Math.sin(p.pitch) + 0.15, Math.cos(p.yaw) * Math.cos(p.pitch)).normalize();
      const hit = g.world.collision.raycast(pivot.x, pivot.y, pivot.z, dir.x, dir.y, dir.z, dist, {});
      if (hit) dist = Math.max(0.6, hit.t - 0.25);
      cam.position.copy(rig.worldToLocal(pivot.clone().addScaledVector(dir, dist)));
      // look back at the pivot
      const toP = rig.worldToLocal(pivot.clone());
      cam.lookAt(toP);
      cam.rotation.z = 0;
    }
    // fov
    const base = S.get('fov');
    const tgt = base + (p.sprinting ? 6 : 0) + (p.gliding ? 12 : 0) + clamp(p.speedH - 11, 0, 20) * 0.5 + this.fovKick - this.ads * (g.weapons.adsFovDrop || 0);
    this.fovKick = damp(this.fovKick, 0, 5, dt);
    this.fov = damp(this.fov, tgt, 9, dt);
    if (Math.abs(cam.fov - this.fov) > 0.05) { cam.fov = this.fov; cam.updateProjectionMatrix(); }
  }
}
