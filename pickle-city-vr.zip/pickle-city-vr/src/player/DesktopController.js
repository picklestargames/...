// Keyboard + mouse input (pointer lock). Fills the shared player intent; the same world and systems as VR.
import { clamp } from '../core/Utils.js';

export class DesktopController {
  constructor(game) {
    this.game = game;
    this.down = new Set();
    this.pressed = new Set();
    this.mouse = { left: false, right: false };
    this.locked = false;
    this.enabled = false;
    this.remapping = null;
    this.onRemap = null;
    const el = game.canvas;
    window.addEventListener('keydown', (e) => this.onKey(e, true));
    window.addEventListener('keyup', (e) => this.onKey(e, false));
    window.addEventListener('mousedown', (e) => this.onMouseBtn(e, true));
    window.addEventListener('mouseup', (e) => this.onMouseBtn(e, false));
    window.addEventListener('mousemove', (e) => this.onMove(e));
    window.addEventListener('wheel', (e) => this.onWheel(e), { passive: true });
    window.addEventListener('blur', () => { this.down.clear(); this.mouse.left = this.mouse.right = false; });
    document.addEventListener('pointerlockchange', () => {
      this.locked = document.pointerLockElement === el;
      if (!this.locked && this.enabled && game.state === 'playing' && !game.vr.active) game.pause();
    });
    el.addEventListener('click', () => { if (this.enabled && game.state === 'playing' && !this.locked && !game.vr.active) this.lock(); });
  }
  lock() { try { const p = this.game.canvas.requestPointerLock(); if (p && p.catch) p.catch(() => {}); } catch (e) { /* */ } }
  unlock() { if (document.pointerLockElement) document.exitPointerLock(); }
  enable(on) { this.enabled = on; if (!on) { this.down.clear(); this.mouse.left = this.mouse.right = false; } }

  code(action) { return this.game.settings.get('keys')[action]; }
  held(action) { return this.down.has(this.code(action)); }

  onKey(e, isDown) {
    if (this.remapping && isDown) {
      e.preventDefault();
      if (e.code !== 'Escape') this.game.settings.setKey(this.remapping, e.code);
      const cb = this.onRemap; this.remapping = null; this.onRemap = null; cb && cb();
      return;
    }
    if (!this.enabled) return;
    if (isDown && !e.repeat) this.pressed.add(e.code);
    if (isDown) this.down.add(e.code); else this.down.delete(e.code);
    if (['Space', 'ControlLeft', 'Tab'].includes(e.code) || e.code.startsWith('Arrow')) e.preventDefault();
    if (isDown && e.code === 'ControlLeft') e.preventDefault();
  }
  onMouseBtn(e, isDown) {
    if (!this.enabled || !this.locked) return;
    if (e.button === 0) this.mouse.left = isDown;
    if (e.button === 2) this.mouse.right = isDown;
  }
  onMove(e) {
    if (!this.enabled || !this.locked || this.game.state !== 'playing') return;
    const g = this.game, p = g.player, s = g.settings;
    const k = 0.0022 * s.get('mouseSens') * (1 - g.camera_ctrl.ads * 0.55);
    p.yaw -= e.movementX * k;
    p.pitch = clamp(p.pitch - e.movementY * k * (s.get('invertY') ? -1 : 1), -1.52, 1.52);
  }
  onWheel(e) {
    if (!this.enabled || !this.locked) return;
    this.game.weapons.cycle(e.deltaY > 0 ? 1 : -1);
  }

  was(action) { return this.pressed.has(this.code(action)); }

  update(dt) {
    const g = this.game, p = g.player, I = p.intent;
    if (!this.enabled || g.vr.active) { this.pressed.clear(); return; }
    const f = this.held('forward') ? 1 : 0, b = this.held('back') ? 1 : 0, l = this.held('left') ? 1 : 0, r = this.held('right') ? 1 : 0;
    I.moveX = r - l; I.moveZ = f - b;
    I.dirYaw = p.yaw;
    const T = g.touch && g.touch.enabled ? g.touch : null;
    if (T) { this.mouse.left = T.fire; this.mouse.right = T.ads; T.apply(I, false); }
    const veh = g.vehicles;
    if (this.pressed.has('KeyF')) { if (veh.driving) veh.exit(); else veh.tryEnter(); }
    if (veh.driving) {
      const vi = veh.input; vi.throttle = f; vi.brake = b; vi.steer = r - l; vi.hand = this.down.has('Space'); vi.horn = this.down.has('KeyH');
      if (T) T.apply(I, true, vi);
      I.moveX = I.moveZ = 0; I.jump = false; I.sprint = false; I.crouch = false; I.crouchPressed = false;
      if (this.was('thirdPerson')) g.toggleThirdPerson();
      g.weapons.setTrigger(0, false); g.weapons.setAds(false); this.pressed.clear(); return;
    }
    I.sprint = this.held('sprint') && I.moveZ > 0 ? true : (this.held('sprint') && (I.moveX !== 0 || I.moveZ !== 0));
    const crouchNow = this.held('crouch');
    I.crouchPressed = crouchNow && !I.crouch;
    I.crouch = crouchNow || (p.sliding && p.slideT < 1.2 && false);
    if (this.was('jump') || (this.held('jump') && p.jumpBuffer <= 0 && p.grounded)) I.jump = true;
    if (this.pressed.has('Space') && !p.grounded && g.glider.canDeploy && !g.glider.active) g.glider.tryDeploy();
    if (this.was('glider')) g.glider.toggle();
    if (this.was('reload')) g.weapons.reloadPressed();
    if (this.was('interact')) g.interaction.interactPressed();
    if (this.was('thirdPerson')) g.toggleThirdPerson();
    if (this.was('fps')) g.toggleFps();
    for (let n = 1; n <= 6; n++) if (this.pressed.has('Digit' + n)) g.weapons.selectSlot(n - 1);
    if (this.pressed.has('KeyQ')) g.weapons.cycle(-1);
    if (this.pressed.has('Escape')) { /* pointer lock exit pauses */ }
    // glider steering (mouse yaw = heading target, A/D adds banking, W/S dives / flares)
    const gi = g.glider.input;
    gi.dive = (I.moveZ > 0 ? 1 : 0) - (I.moveZ < 0 ? 1 : 0);
    gi.steer = 0; gi.yawTarget = p.yaw; gi.yawRate = -I.moveX * 1.0;
    // weapons
    g.weapons.setTrigger(0, this.mouse.left && g.state === 'playing');
    g.weapons.setAds(this.mouse.right && !p.sprinting);
    this.pressed.clear();
  }
}
