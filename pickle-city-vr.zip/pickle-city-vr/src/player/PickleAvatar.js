// The player's body: a faceted, wet, warty anthropomorphic pickle with an angry-but-lovable face.
// Fully procedural, animated from simple state (idle/walk/run/sprint/crouch/slide/jump/fall/land/shoot/reload/pad/deploy/glide).
import * as THREE from 'three';
import { HandModel } from './HandModel.js';
import { mergeSimple } from '../core/Geo.js';
import { rng, damp, lerp } from '../core/Utils.js';

const BODY_RX = 0.30, BODY_RY = 0.64, BODY_RZ = 0.27;
export const AVATAR_EYE_HEIGHT = 1.55;   // eye height of the unscaled avatar (face is just below the top)

function limb(w, h, d, mat, y) { const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat); m.position.y = y; m.castShadow = true; return m; }

export class PickleAvatar {
  constructor(mats) {
    this.mats = mats;
    this.root = new THREE.Group();
    this.pose = new THREE.Group();    // animated sub-root (lean/squash)
    this.root.add(this.pose);
    const skin = mats.pickleWet;
    const black = mats.flat(0x0a0a0a, 0.5, 0);

    // ---- torso (faceted ellipsoid) + warts
    const bg = new THREE.SphereGeometry(1, 14, 10);
    bg.scale(BODY_RX, BODY_RY, BODY_RZ);
    this.body = new THREE.Mesh(bg, skin);
    this.body.position.y = 0.38 + BODY_RY;
    this.body.castShadow = true;
    this.pose.add(this.body);
    const R = rng(31);
    const warts = [];
    for (let i = 0; i < 46; i++) {
      const u = R() * Math.PI * 2, v = Math.acos(1 - R() * 2);
      const nx = Math.sin(v) * Math.cos(u), ny = Math.cos(v), nz = Math.sin(v) * Math.sin(u);
      const c = new THREE.ConeGeometry(0.022 + R() * 0.012, 0.045, 4);
      c.translate(0, 0.02, 0);
      const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), new THREE.Vector3(nx / BODY_RX, ny / BODY_RY, nz / BODY_RZ).normalize());
      c.applyQuaternion(q);
      c.translate(nx * BODY_RX, ny * BODY_RY, nz * BODY_RZ);
      warts.push(c);
    }
    const wartMesh = new THREE.Mesh(mergeSimple(warts), mats.flat(0x9bb43a, 0.6, 0));
    wartMesh.position.copy(this.body.position);
    this.pose.add(wartMesh);

    // ---- face (faces -Z in local space)
    this.face = new THREE.Group();
    this.face.position.set(0, this.body.position.y + 0.38, -BODY_RZ * 0.92);
    const brow = (s) => { const b = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.028, 0.03), black); b.position.set(s * 0.1, 0.075, 0); b.rotation.z = -s * 0.42; return b; };
    this.brows = [brow(-1), brow(1)];
    const eye = (s) => { const e = new THREE.Mesh(new THREE.BoxGeometry(0.048, 0.07, 0.03), black); e.position.set(s * 0.1, 0.0, 0); return e; };
    this.eyes = [eye(-1), eye(1)];
    this.mouth = new THREE.Mesh(new THREE.BoxGeometry(0.17, 0.02, 0.03), black); this.mouth.position.set(0, -0.14, 0);
    this.face.add(...this.brows, ...this.eyes, this.mouth);
    this.face.rotation.x = 0.0;
    this.pose.add(this.face);

    // ---- legs
    this.legs = [];
    for (const s of [-1, 1]) {
      const hip = new THREE.Group(); hip.position.set(s * 0.12, 0.46, 0);
      const thigh = limb(0.11, 0.24, 0.11, skin, -0.11);
      const knee = new THREE.Group(); knee.position.y = -0.22;
      const shin = limb(0.1, 0.24, 0.1, skin, -0.12);
      const foot = limb(0.12, 0.07, 0.24, mats.flat(0x2e3a1a, 0.9, 0), -0.265); foot.position.z = -0.06;
      knee.add(shin, foot); hip.add(thigh, knee); this.pose.add(hip);
      this.legs.push({ hip, knee, side: s });
    }
    // ---- animated arms (third person)
    this.arms = [];
    for (const s of [-1, 1]) {
      const sh = new THREE.Group(); sh.position.set(s * 0.33, this.body.position.y + 0.35, 0);
      const up = limb(0.075, 0.34, 0.075, skin, -0.17);
      const el = new THREE.Group(); el.position.y = -0.34;
      const fo = limb(0.065, 0.34, 0.065, skin, -0.17);
      const hand = new HandModel(mats);
      // hang the hand at the end of the forearm, fingers down-forward
      hand.root.position.set(0, -0.36, 0); hand.root.rotation.set(Math.PI / 2, 0, s > 0 ? -Math.PI / 2 : Math.PI / 2);
      hand.root.scale.setScalar(0.9);
      hand.curl(0.3, 0.45, 0.3);
      el.add(fo, hand.root); sh.add(up, el); this.pose.add(sh);
      this.arms.push({ sh, el, hand, side: s });
    }

    // ---- first-person IK arms (world space; fed by VR/desktop viewmodel)
    this.ikGroup = new THREE.Group();
    this.ik = [0, 1].map(() => {
      const cg = new THREE.CylinderGeometry(0.034, 0.028, 1, 7); cg.translate(0, 0.5, 0);
      const up = new THREE.Mesh(cg, skin), fo = new THREE.Mesh(cg, skin);
      up.frustumCulled = fo.frustumCulled = false;
      const elbow = new THREE.Mesh(new THREE.SphereGeometry(0.036, 6, 5), skin);
      this.ikGroup.add(up, fo, elbow);
      return { up, fo, elbow };
    });
    this.ikGroup.visible = false;

    this.phase = 0; this.squash = 0; this.landT = 0; this.padT = 0; this.shootT = 0; this.blink = 3; this.smoothSpeed = 0;
    this.mode = 'third';   // 'third' | 'vr' | 'hidden'
    this.setMode('third');
  }

  /** third: full body; vr: legs + IK arms (torso hides itself from inside); hidden: nothing (desktop first person) */
  setMode(m) {
    this.mode = m;
    const third = m === 'third', vr = m === 'vr';
    this.root.visible = third || vr;
    this.body.visible = third; this.face.visible = third;
    this.pose.children.forEach((c) => { if (c !== this.body && c !== this.face) c.visible = true; });
    for (const a of this.arms) a.sh.visible = third;
    this.ikGroup.visible = vr || m === 'fps';
    // warts: hide with body in vr mode
    this.pose.children.forEach((c) => { if (c.isMesh && c !== this.body && c.material === this.mats.flat && false) c.visible = third; });
    this.wartsVisible(third);
  }
  wartsVisible(v) { for (const c of this.pose.children) if (c.isMesh && c !== this.body && c.geometry && c.geometry.attributes.position.count > 200) c.visible = v; }

  setScale(s) { this.root.scale.setScalar(s); }

  /** Two-bone IK arm in world space. shoulder/hand/pole are THREE.Vector3 (world). */
  solveArm(i, shoulder, hand, pole, L1 = 0.31, L2 = 0.31) {
    const a = this.ik[i];
    const d = new THREE.Vector3().subVectors(hand, shoulder);
    let dist = d.length();
    const max = L1 + L2 - 0.005;
    const dir = d.clone().normalize();
    let l1 = L1, l2 = L2;
    if (dist > max) { const k = dist / max; l1 = L1 * k; l2 = L2 * k; dist = max * k; }
    const cosA = THREE.MathUtils.clamp((l1 * l1 + dist * dist - l2 * l2) / (2 * l1 * dist), -1, 1);
    const ang = Math.acos(cosA);
    // elbow = shoulder + dir rotated toward pole by ang
    const toPole = new THREE.Vector3().subVectors(pole, shoulder);
    toPole.addScaledVector(dir, -toPole.dot(dir));
    if (toPole.lengthSq() < 1e-6) toPole.set(0, -1, 0);
    toPole.normalize();
    const elbow = shoulder.clone().addScaledVector(dir, Math.cos(ang) * l1).addScaledVector(toPole, Math.sin(ang) * l1);
    const place = (mesh, from, to) => {
      const v = new THREE.Vector3().subVectors(to, from); const len = v.length() || 0.001;
      mesh.position.copy(from); mesh.scale.set(1, len, 1);
      mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), v.multiplyScalar(1 / len));
    };
    place(a.up, shoulder, elbow); place(a.fo, elbow, hand); a.elbow.position.copy(elbow);
  }

  /** s: {speed,maxSpeed,grounded,crouch,slide,sprint,vy,gliding,deploy,shoot,reload,pad,landImpact,turn,dt} */
  animate(dt, s) {
    const sp = this.smoothSpeed = damp(this.smoothSpeed, s.speed, 12, dt);
    const moving = sp > 0.4;
    const run = Math.min(1, sp / 6.5), sprint = s.sprint ? 1 : 0;
    this.phase += dt * (3.2 + sp * 1.35) * (moving && s.grounded && !s.slide ? 1 : 0);
    const ph = this.phase;
    if (s.landImpact) { this.landT = 0.28; this.squash = Math.min(1, s.landImpact / 22); }
    if (s.pad) this.padT = 0.7;
    if (s.shoot) this.shootT = 0.18;
    this.landT = Math.max(0, this.landT - dt); this.padT = Math.max(0, this.padT - dt); this.shootT = Math.max(0, this.shootT - dt);
    const airborne = !s.grounded && !s.gliding;
    const P = this.pose;

    // body posture
    let lean = (moving ? 0.05 + run * 0.12 + sprint * 0.2 : 0);
    let bodyY = 0, scaleY = 1, scaleXZ = 1, pitch = lean, roll = 0;
    if (s.crouch && !s.slide) { bodyY = -0.28; pitch += 0.15; }
    if (s.slide) { pitch = -0.75; bodyY = -0.34; }
    if (this.landT > 0) { const k = this.landT / 0.28; scaleY = 1 - 0.14 * this.squash * Math.sin(k * Math.PI); scaleXZ = 1 + 0.07 * this.squash * Math.sin(k * Math.PI); }
    if (this.padT > 0) { const k = this.padT / 0.7; scaleY = 1 + 0.16 * k; scaleXZ = 1 - 0.07 * k; }
    if (!moving && s.grounded) { const b = Math.sin(performance.now() * 0.0025) * 0.012; scaleY += b; }
    if (s.gliding) { pitch = 1.15; bodyY = 0.05; }
    P.position.y = bodyY; P.rotation.set(0, 0, 0);
    P.rotation.x = pitch; P.rotation.z = roll + (s.turn || 0) * 0.5;
    P.scale.set(scaleXZ, scaleY, scaleXZ);
    // pitch around the hips rather than the feet: shift the pose origin
    P.position.z = -Math.sin(pitch) * 0.25;

    // legs
    for (const L of this.legs) {
      let h = 0, k = 0;
      if (s.slide) { h = -1.25; k = 0.15; if (L.side > 0) { h = -0.9; k = 0.9; } }
      else if (s.gliding) { h = 0.5 + (L.side > 0 ? 0.15 : 0); k = 0.4; }
      else if (airborne) { if (s.vy > 0) { h = L.side > 0 ? -0.7 : -0.2; k = L.side > 0 ? 1.1 : 0.5; } else { h = L.side > 0 ? -0.3 : 0.15; k = 0.3; } }
      else if (s.crouch) { h = -0.9 * (L.side > 0 ? 1 : 1); k = 1.7; if (moving) { h += Math.sin(ph * 2 + L.side * 1.57) * 0.3; } }
      else if (moving) { const amp = 0.45 + run * 0.35 + sprint * 0.35; h = Math.sin(ph + (L.side > 0 ? 0 : Math.PI)) * amp; k = Math.max(0, Math.sin(ph + (L.side > 0 ? 0 : Math.PI) - 1.2)) * (0.6 + run * 0.9); }
      L.hip.rotation.x = lerp(L.hip.rotation.x, h, 1 - Math.exp(-30 * dt));
      L.knee.rotation.x = lerp(L.knee.rotation.x, k, 1 - Math.exp(-30 * dt));
    }
    // arms
    for (const A of this.arms) {
      let sx = 0, sz = A.side * 0.12, ex = 0;
      if (s.gliding) { sx = -2.75; sz = A.side * 0.35; ex = -0.1; }
      else if (s.slide) { sx = -0.4; sz = A.side * 0.5; }
      else if (airborne) { sx = s.vy > 0 ? -2.3 : -0.4; sz = A.side * (s.vy > 0 ? 0.3 : 0.9); ex = -0.2; }
      else if (moving) { const amp = 0.4 + run * 0.7 + sprint * 0.3; sx = Math.sin(ph + (A.side > 0 ? Math.PI : 0)) * amp; ex = -0.4 - run * 0.5 - sprint * 0.4; }
      if (A.side > 0 && (this.shootT > 0 || s.aiming)) { sx = -1.45; sz = 0.05; ex = -0.1; if (this.shootT > 0) sx -= 0.12; }
      if (s.reload) { sx = A.side > 0 ? -1.0 : -1.2; sz = A.side * -0.25; ex = -1.0; }
      if (s.deploy) { sx = -2.6; sz = A.side * 0.5; ex = -0.3; }
      A.sh.rotation.x = lerp(A.sh.rotation.x, sx, 1 - Math.exp(-24 * dt));
      A.sh.rotation.z = lerp(A.sh.rotation.z, sz, 1 - Math.exp(-24 * dt));
      A.el.rotation.x = lerp(A.el.rotation.x, ex, 1 - Math.exp(-24 * dt));
    }
    // face: blink + angry brows, determination when sprinting
    this.blink -= dt;
    const closed = this.blink < 0.1;
    if (this.blink < 0) this.blink = 2 + Math.random() * 4;
    for (const e of this.eyes) e.scale.y = closed ? 0.12 : 1;
    const k = s.sprint || s.slide ? 0.65 : s.hurt ? 0.1 : 0.42;
    this.brows[0].rotation.z = -k; this.brows[1].rotation.z = k;
    this.mouth.scale.x = s.hurt ? 0.6 : 1; this.mouth.position.y = s.hurt ? -0.16 : -0.14;
    this.mouth.rotation.z = (s.sprint ? 0.12 : 0);
  }
}
