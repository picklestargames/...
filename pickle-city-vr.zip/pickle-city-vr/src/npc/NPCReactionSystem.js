// Non-graphic, arcade-style civilian reactions. Civilians NEVER attack, chase, carry weapons or damage the player.
import { clamp } from '../core/Utils.js';

export class NPCReactionSystem {
  constructor(game, npcs) { this.game = game; this.npcs = npcs; }

  /** A shot was fired at pos: nearby civilians get scared and run away. */
  alertShot(pos, radius) {
    const r2 = radius * radius;
    for (const n of this.npcs.pool) {
      if (!n.active || n.inside || n.state === 'fall') continue;
      const dx = n.x - pos.x, dz = n.z - pos.z, d2 = dx * dx + dz * dz;
      if (d2 > r2) continue;
      this.scare(n, pos.x, pos.z, d2 < 20 * 20 && Math.random() < 0.6);
    }
  }

  scare(n, fx, fz, scream = false) {
    if (n.state === 'fall' || n.state === 'stagger' || n.inside) return;
    this.npcs.panic(n, fx, fz);
    if (scream && !n.screamed) {
      n.screamed = true;
      this.game.audio.play(Math.random() < 0.4 ? 'help' : 'scream', { pos: { x: n.x, y: 1.5, z: n.z }, gain: 0.7, ref: 4, hrtf: false });
      setTimeout(() => { n.screamed = false; }, 4000);
    }
  }

  /** Player shot hit this civilian. dmg is reduced to an arcade "bonk": stagger, maybe fall, then run. */
  hit(n, dmg, dir, point) {
    if (n.state === 'fall') return;
    const g = this.game;
    n.hp -= dmg;
    if (n.cop && n.hp > 0) { g.particles.burst({ x: n.x, y: n.y + n.h * 0.7, z: n.z }, [1, 0.95, 0.4], 6, 2.2, 0.09, 0.6); this.alertShot({ x: n.x, z: n.z }, 22); return; }
    n.teller = false;
    n.angry = !n.cop;
    g.particles.burst({ x: n.x, y: n.h + 0.25, z: n.z }, [1, 0.95, 0.4], 7, 2.2, 0.09, 0.8);   // comedic stars, no blood
    g.audio.play('help', { pos: { x: n.x, y: 1.5, z: n.z }, gain: 0.6, ref: 4, hrtf: false, minGap: 0.2 });
    // knock back a little
    n.kx = dir.x * 1.8; n.kz = dir.z * 1.8;
    if (n.hp <= 0) {
      n.state = 'fall'; n.stateT = 0; n.fallDir = Math.atan2(dir.x, dir.z); n.edge = null; n.goto = null;
      n.respawnDelay = 6 + Math.random() * 6;
      g.ui && g.ui.toast('OOF! (civilian is fine, just embarrassed)', 1200);
      g.crime && g.crime.onInnocentDown(n);
    } else {
      n.state = 'stagger'; n.stateT = 0; n.edge = null; n.goto = null;
      n.fearX = n.x - dir.x * 5; n.fearZ = n.z - dir.z * 5;
    }
    this.alertShot({ x: n.x, z: n.z }, 22);
  }
}
