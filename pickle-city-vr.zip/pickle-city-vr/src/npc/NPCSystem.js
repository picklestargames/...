// Civilian crowd: pooled, instanced, LOD'd, distance-ticked. Civilians are strictly non-combatants.
import * as THREE from 'three';
import { NPCNavigation } from './NPCNavigation.js';
import { NPCReactionSystem } from './NPCReactionSystem.js';
import { rng, clamp, dampAngle, lerp } from '../core/Utils.js';
import { cx, GRID } from '../world/Constants.js';

const POOL = 72;
const SKIN = [0xf1c8a4, 0xe0ac86, 0xc58c5e, 0x9b6a45, 0x6e4529, 0x4a2e1d, 0xf6d9bd];
const SHIRT = [0xc0392b, 0x2e86c1, 0x27ae60, 0xf1c40f, 0x8e44ad, 0xe67e22, 0xecf0f1, 0x2c3e50, 0x16a085, 0xd35400, 0xe84393, 0x7f8c8d, 0x1abc9c, 0xb8d04a, 0x3d3d3f, 0x5b6b7a, 0x8a9a6b, 0xd9cdb8, 0x7a2f2f, 0x2f4a6b, 0xe8e8e8, 0x1f1f22];
const PANTS = [0x2c3e50, 0x1b2631, 0x5d4a3a, 0x34495e, 0x7b7d7d, 0x3b4a2e, 0x1f2d4a, 0x8a6d3b, 0x222222, 0x3f5f8f, 0x4a6a9a, 0x6b5b45, 0xa89878, 0x2a2a2e, 0x55606b];
const HAIR = [0x1c1410, 0x3a2416, 0x6b4423, 0xb98a4b, 0xd8c070, 0x8a2e1a, 0x777777, 0x151515];
const ACCC = [0x2c3e50, 0xc0392b, 0x27ae60, 0x8e44ad, 0xe67e22, 0x111111];

const D = {
  walk: 1, goto: 1, flee: 1, sit: 1, talk: 1, phone: 1, inside: 1, stagger: 1, fall: 1, wait: 1,
};

/** rounds a unit box's horizontal cross-section into an ellipse (smooth normals) – turns box limbs/torsos into believable body parts */
function rounded(g, k) {
  const p = g.attributes.position, n = g.attributes.normal;
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), z = p.getZ(i), len = Math.hypot(x, z) || 1, ny = n.getY(i), m = Math.min(len, 0.5);
    const rx = x + ((x / len) * m - x) * k, rz = z + ((z / len) * m - z) * k;
    p.setXYZ(i, rx, p.getY(i), rz);
    if (Math.abs(ny) < 0.5) { const nl = Math.hypot(rx, rz) || 1; n.setXYZ(i, rx / nl, 0, rz / nl); }
  }
  return g;
}
function rbox(oy = 0, k = 0.9, sy = 3) { const g = new THREE.BoxGeometry(1, 1, 1, 4, sy, 4); g.translate(0, oy, 0); return rounded(g, k); }
function box(w, h, d, oy = 0) { const g = new THREE.BoxGeometry(w, h, d); g.translate(0, oy, 0); return g; }

export class NPCSystem {
  constructor(game) {
    this.game = game;
    this.nav = new NPCNavigation(game.world);
    this.react = new NPCReactionSystem(game, this);
    this.pool = [];
    this.time = 0;
    this.spawnT = 0;
    this.listT = 0;
    this.entrances = []; this.benches = [];
    this.active = 0;
    this.positions = [];
    this.R = rng(2024);
    this._neigh = [];
    this.buildMeshes();
    for (let i = 0; i < POOL; i++) this.pool.push(this.makeNPC(i));
  }

  // ------------------------------------------------------------ rendering setup
  buildMeshes() {
    const mat = new THREE.MeshStandardMaterial({ roughness: 0.85, metalness: 0.0 });
    const mk = (geo, cap = POOL) => { const m = new THREE.InstancedMesh(geo, mat, cap); m.frustumCulled = false; m.castShadow = true; m.count = cap; this.game.world.scene.add(m); return m; };
    const hair = new THREE.SphereGeometry(0.5, 8, 5, 0, Math.PI * 2, 0, Math.PI * 0.55);
    const hat = (() => { const a = new THREE.CylinderGeometry(0.4, 0.45, 0.45, 8); a.translate(0, 0.35, 0); const b = new THREE.CylinderGeometry(0.85, 0.85, 0.06, 10); b.translate(0, 0.1, 0); const g = new THREE.BufferGeometry(); return mergeG(a, b); })();
    this.M = {
      torso: mk(rbox(0, 0.8)), head: mk(new THREE.SphereGeometry(0.5, 8, 6)), hairCap: mk(hair), hairLong: mk(box(1, 1, 1)), hat: mk(hat),
      bag: mk(box(1, 1, 1)), glasses: mk(box(1, 1, 1)), armU: mk(rbox(-0.5, 0.95), POOL * 2), armL: mk(rbox(-0.5, 0.95), POOL * 2),
      leg: mk(rbox(-0.5, 0.9), POOL * 2), foot: mk(rbox(0, 0.55), POOL * 2), phone: mk(box(1, 1, 1)), low: mk(rbox(0, 0.8)),
    };
    this.zero = new THREE.Matrix4().makeScale(0, 0, 0);
    for (const m of Object.values(this.M)) for (let i = 0; i < m.count; i++) m.setMatrixAt(i, this.zero);
    this._base = new THREE.Matrix4(); this._loc = new THREE.Matrix4(); this._mm = new THREE.Matrix4(); this._q = new THREE.Quaternion(); this._qy = new THREE.Quaternion();
    this._p = new THREE.Vector3(); this._s = new THREE.Vector3(); this._e = new THREE.Euler(); this._one = new THREE.Vector3(1, 1, 1);
  }

  makeNPC(i) {
    const R = this.R;
    const n = {
      i, active: false, inside: false, state: 'walk', stateT: 0, x: 0, z: 0, y: 0, yaw: 0, h: 1.75, w: 1,
      hp: 40, fear: 0, speed: 1.3, lane: 0.6, phase: 0, edge: null, t: 0, prev: null, goto: null,
      lod: 2, tick: 0, enterCool: 0, kx: 0, kz: 0, fade: 1, fleeDir: null, style: {}, colors: {}, lastLod: -1, afraidAnim: 0,
      angry: false, atkT: 0, atkCD: 0, talkWith: null, bench: null, entrance: null, respawnAt: 0, screamed: false, wait: 0, fallDir: 0, helped: false,
    };
    return n;
  }

  randomizeLook(n) {
    const R = this.R;
    n.h = R.range(1.58, 1.94); n.w = R.range(0.86, 1.28); n.counted = false; n.cop = false; n.teller = false;
    n.style = { hair: R.int(0, 3), acc: R.int(0, 3), gait: R.range(0.8, 1.2), swing: R.range(0.6, 1.1), phone: R() < 0.18, longSleeve: R() < 0.4 };
    const skin = R.pick(SKIN), shirt = R.pick(SHIRT), pants = R.pick(PANTS), hair = R.pick(HAIR), acc = R.pick(ACCC);
    n.colors = { skin, shirt, pants, hair, acc };
    const c = new THREE.Color();
    const set = (m, idx, col) => m.setColorAt(idx, c.setHex(col));
    const i = n.i;
    set(this.M.torso, i, shirt); set(this.M.head, i, skin); set(this.M.hairCap, i, hair); set(this.M.hairLong, i, hair); set(this.M.hat, i, acc);
    set(this.M.bag, i, acc); set(this.M.glasses, i, 0x111111); set(this.M.phone, i, 0x111418); set(this.M.low, i, shirt);
    for (let k = 0; k < 2; k++) {
      set(this.M.armU, i * 2 + k, shirt); set(this.M.armL, i * 2 + k, n.style.longSleeve ? shirt : skin);
      set(this.M.leg, i * 2 + k, pants); set(this.M.foot, i * 2 + k, 0x1a1a1c);
    }
    for (const m of Object.values(this.M)) if (m.instanceColor) m.instanceColor.needsUpdate = true;
  }

  // ------------------------------------------------------------ lists from loaded chunks
  refreshLists() {
    const hi = this.game.world.chunks.hi;
    this.entrances.length = 0; this.benches.length = 0;
    for (const c of hi.values()) { for (const e of c.entrances) this.entrances.push(e); for (const b of c.benches) this.benches.push(b); }
  }

  // ------------------------------------------------------------ spawning
  spawnOne() {
    const g = this.game, p = g.player, R = this.R;
    const slot = this.pool.find((n) => !n.active && n.respawnAt <= this.time);
    if (!slot) return false;
    const ang = R() * Math.PI * 2, rad = R.range(28, 105);
    const x = p.pos.x + Math.cos(ang) * rad, z = p.pos.z + Math.sin(ang) * rad;
    if (!g.world.chunks.getHiChunkAt(x, z)) return false;
    // avoid popping in right in front of the player
    const cam = g.vr.active ? g.vr.headForward : { x: -Math.sin(p.yaw), z: -Math.cos(p.yaw) };
    const dx = x - p.pos.x, dz = z - p.pos.z, d = Math.hypot(dx, dz);
    if (d < 60 && (dx * cam.x + dz * cam.z) / d > 0.45) return false;
    const nn = NPCNavigation.nearest(x, z);
    const nb = NPCNavigation.neighbors(nn.a, nn.b, this._neigh);
    const to = nb[(R() * nb.length) | 0];
    this.randomizeLook(slot);
    slot.angry = false; slot.atkT = 0; slot.atkCD = 0;
    slot.active = true; slot.inside = false; slot.fade = 1; slot.fear = 0; slot.hp = 40; slot.state = 'walk'; slot.stateT = 0; slot.helped = false; slot.enterCool = R.range(0, 20);
    slot.speed = R.range(1.05, 1.65) * slot.style.gait; slot.lane = R.range(0.2, 1.5); slot.talkWith = null; slot.bench = null; slot.kx = slot.kz = 0; slot.y = 0; slot.lastLod = -1; slot.screamed = false;
    slot.prev = null;
    this.setEdge(slot, nn.a, nn.b, to[0], to[1], R());
    const roll = R();
    if (roll < 0.16 && this.benches.length) { // sitter
      const bs = this.benches.filter((b) => Math.hypot(b.x - p.pos.x, b.z - p.pos.z) > 25 && Math.hypot(b.x - p.pos.x, b.z - p.pos.z) < 100 && !b.taken);
      if (bs.length) { const b = bs[(R() * bs.length) | 0]; b.taken = slot; slot.bench = b; slot.x = b.x; slot.z = b.z; slot.y = b.y - slot.h * 0.26; slot.yaw = b.face; slot.state = 'sit'; slot.stateT = R.range(10, 40); slot.edge = null; }
    } else if (roll < 0.34) { // chatting pair
      const mate = this.pool.find((q) => !q.active && q !== slot && q.respawnAt <= this.time);
      if (mate) {
        slot.state = 'talk'; slot.edge = null; slot.yaw = R() * 6.28; slot.stateT = R.range(15, 45);
        this.randomizeLook(mate);
        mate.active = true; mate.inside = false; mate.fade = 1; mate.fear = 0; mate.hp = 40; mate.state = 'talk'; mate.stateT = slot.stateT; mate.edge = null; mate.y = 0; mate.lastLod = -1; mate.talkWith = slot; slot.talkWith = mate;
        mate.speed = R.range(1.1, 1.5); mate.style.phone = false; mate.kx = mate.kz = 0;
        slot.x = slot.x; mate.x = slot.x + Math.cos(slot.yaw) * 1.1; mate.z = slot.z + Math.sin(slot.yaw) * 1.1; mate.yaw = slot.yaw + Math.PI;
        slot.yaw = Math.atan2(-(mate.x - slot.x), -(mate.z - slot.z)); mate.yaw = Math.atan2(-(slot.x - mate.x), -(slot.z - mate.z));
      }
    } else if (roll < 0.46 || slot.style.phone && roll < 0.55) { slot.state = 'phone'; slot.edge = null; slot.stateT = R.range(10, 30); slot.yaw = R() * 6.28; }
    return true;
  }

  setEdge(n, a0, b0, a1, b1, t = 0) {
    const p0 = NPCNavigation.node(a0, b0), p1 = NPCNavigation.node(a1, b1);
    n.edge = { a0, b0, a1, b1, x0: p0.x, z0: p0.z, x1: p1.x, z1: p1.z, len: Math.hypot(p1.x - p0.x, p1.z - p0.z), cross: NPCNavigation.isCrossing(a0, b0, a1, b1), waited: false };
    n.t = t;
    // outward lateral direction (away from the block, toward the street kerb)
    const e = n.edge; const dx = (e.x1 - e.x0) / e.len, dz = (e.z1 - e.z0) / e.len;
    if (e.cross) { e.lx = -dz; e.lz = dx; e.lo = n.lane * 0.5; }
    else {
      const bx = cx(e.a0 >> 1), bz = cx(e.b0 >> 1);
      if (e.a0 === e.a1) { e.lx = Math.sign(e.x0 - bx); e.lz = 0; } else { e.lx = 0; e.lz = Math.sign(e.z0 - bz); }
      e.lo = n.lane;
    }
    this.evalEdge(n);
  }
  evalEdge(n) {
    const e = n.edge;
    const x = e.x0 + (e.x1 - e.x0) * n.t + e.lx * e.lo, z = e.z0 + (e.z1 - e.z0) * n.t + e.lz * e.lo;
    n.x = x; n.z = z;
  }

  chooseNext(n) {
    const e = n.edge, R = this.R;
    const here = [e.a1, e.b1];
    const list = NPCNavigation.neighbors(here[0], here[1], this._neigh);
    let best = null, bs = -1e9;
    const dirx = (e.x1 - e.x0) / (e.len || 1), dirz = (e.z1 - e.z0) / (e.len || 1);
    for (const [a, b] of list) {
      if (a === e.a0 && b === e.b0 && list.length > 1) continue; // no immediate U-turn
      const q = NPCNavigation.node(a, b);
      let s = R() * 1.2;
      const ddx = q.x - e.x1, ddz = q.z - e.z1, dl = Math.hypot(ddx, ddz) || 1;
      s += ((ddx * dirx + ddz * dirz) / dl) * 0.9;        // prefer going straight
      if (n.fear > 0) s += (Math.hypot(q.x - n.fearX, q.z - n.fearZ) - Math.hypot(e.x1 - n.fearX, e.z1 - n.fearZ)) * 0.1 + R() * 0.2;
      // stay roughly around the player
      const pp = this.game.player.pos;
      s -= Math.max(0, Math.hypot(q.x - pp.x, q.z - pp.z) - 110) * 0.03;
      if (s > bs) { bs = s; best = [a, b]; }
    }
    this.setEdge(n, e.a1, e.b1, best[0], best[1], 0);
  }

  panic(n, fx, fz) {
    if (n.state === 'held' || n.state === 'thrown' || n.angry || n.teller || n.cop || n.state === 'handsup') return;
    n.fear = 8 + this.R() * 6; n.fearX = fx; n.fearZ = fz; n.afraidAnim = 1;
    if (n.bench) { n.bench.taken = null; n.bench = null; n.y = 0; }
    if (n.talkWith) { n.talkWith.talkWith = null; n.talkWith = null; }
    if (n.state === 'inside') return;
    if (n.state !== 'walk' && n.state !== 'goto' && n.state !== 'stagger') {
      const nn = NPCNavigation.nearest(n.x, n.z), q = NPCNavigation.node(nn.a, nn.b);
      n.state = 'goto'; n.goto = { x: q.x + (q.x > n.x ? 0 : 0), z: q.z, next: 'walk', a: nn.a, b: nn.b }; n.edge = null;
    }
    if (n.state === 'walk') n.state = 'flee';
  }

  enterNear(n) {
    for (const e of this.entrances) {
      if (Math.abs(e.x - n.x) > 3 || Math.abs(e.z - n.z) > 3) continue;
      n.entrance = e; n.state = 'goto'; n.goto = { x: e.x, z: e.z, next: 'enter' }; n.edge = null; n.enterCool = 40;
      return true;
    }
    return false;
  }

  // ------------------------------------------------------------ simulation
  update(dt) {
    const g = this.game, p = g.player;
    this.time += dt;
    this.listT -= dt; if (this.listT <= 0) { this.refreshLists(); this.listT = 2; }
    this.spawnT -= dt;
    const budget = g.perf ? g.perf.npcBudget : 40;
    this.active = 0;
    for (const n of this.pool) if (n.active) this.active++;
    if (this.spawnT <= 0 && this.active < budget) { for (let k = 0; k < 3; k++) this.spawnOne(); this.spawnT = 0.2; }
    this.positions.length = 0;
    for (const n of this.pool) {
      if (!n.active) continue;
      const dx = n.x - p.pos.x, dz = n.z - p.pos.z, d2 = dx * dx + dz * dz;
      const rough = n.state === 'held' || n.state === 'thrown';
      if (d2 > 150 * 150 && !rough && !n.cop) { this.release(n); continue; }
      const lod = rough || d2 < 45 * 45 ? 0 : d2 < 95 * 95 ? 1 : 2;
      n.lod = lod;
      n.tick += dt;
      const period = lod === 0 ? 0 : lod === 1 ? 0.1 : 0.4;
      if (n.tick >= period) { this.think(n, n.tick); n.tick = 0; }
      if (!n.inside) this.positions.push(n);
    }
    // bench/entrance flags
    this.render(dt);
  }

  release(n) {
    n.active = false; n.inside = false; n.cop = false; n.teller = false; if (n.bench) { n.bench.taken = null; n.bench = null; } if (n.talkWith) { n.talkWith.talkWith = null; n.talkWith = null; }
    n.lastLod = -1; this.clearSlot(n);
  }
  clearSlot(n) {
    const i = n.i;
    for (const k of ['torso', 'head', 'hairCap', 'hairLong', 'hat', 'bag', 'glasses', 'phone', 'low']) this.M[k].setMatrixAt(i, this.zero);
    for (const k of ['armU', 'armL', 'leg', 'foot']) { this.M[k].setMatrixAt(i * 2, this.zero); this.M[k].setMatrixAt(i * 2 + 1, this.zero); }
  }

  think(n, dt) {
    const g = this.game, R = this.R;
    n.stateT -= dt; n.enterCool -= dt;
    if (n.fear > 0) { n.fear -= dt; if (n.fear <= 0 && (n.state === 'flee')) n.state = 'walk'; }
    // knock-back decay
    if (n.kx || n.kz) { n.x += n.kx * dt * 3; n.z += n.kz * dt * 3; n.kx *= Math.max(0, 1 - dt * 6); n.kz *= Math.max(0, 1 - dt * 6); if (Math.abs(n.kx) + Math.abs(n.kz) < 0.05) n.kx = n.kz = 0; }
    switch (n.state) {
      case 'walk': case 'flee': this.walk(n, dt); break;
      case 'goto': this.goto(n, dt); break;
      case 'wait': n.wait -= dt; if (n.wait <= 0 || n.fear > 0) { n.state = n.fear > 0 ? 'flee' : 'walk'; } break;
      case 'sit': if (n.stateT <= 0) { if (n.bench) { n.bench.taken = null; n.bench = null; } n.y = 0; this.toGraph(n); } break;
      case 'talk':
        if (n.stateT <= 0 || !n.talkWith || !n.talkWith.active) { n.talkWith = null; this.toGraph(n); }
        else if (Math.random() < dt * 0.1 && n.lod < 2) g.audio.play('murmur', { pos: { x: n.x, y: 1.6, z: n.z }, gain: 0.4, ref: 3, bus: 'amb' });
        break;
      case 'phone': if (n.stateT <= 0) this.toGraph(n); break;
      case 'inside': if (n.stateT <= 0) this.exitBuilding(n); break;
      case 'stagger': if (n.cop) { n.stagT = (n.stagT || 0) + dt; if (n.stagT > 0.6) { n.stagT = 0; n.state = 'cop'; } break; }
        n.stateT -= 0; n.stagT = (n.stagT || 0) + dt; if (n.stagT > 0.6 && n.angry) { n.stagT = 0; n.state = 'chase'; } else if (n.stagT > 0.6) { n.stagT = 0; this.panic(n, n.fearX, n.fearZ); this.toGraph(n, true); if (!n.helped && g.audio) { n.helped = true; g.audio.play('help', { pos: { x: n.x, y: 1.6, z: n.z }, gain: 0.7, ref: 4, hrtf: false }); } } break;
      case 'chase': this.chase(n, dt); break;
      case 'cop': g.crime.updateCop(n, dt); break;
      case 'teller': case 'handsup': g.crime.thinkTeller(n, dt); break;
      case 'held': n.kx = n.kz = 0; break;
      case 'thrown': this.fly(n, dt); break;
      case 'fall':
        n.fallT = (n.fallT || 0) + dt;
        if (n.angry && n.fallT > 2.2 && !g.health.dead) { n.hp = 30; n.fallT = 0; n.fallK = 0; n.state = 'chase'; n.fade = 1; break; }   // gets back up, furious
        if (n.fallT > 3.2) { n.fade -= dt * 1.2; if (n.fade <= 0) { n.fallT = 0; this.release(n); n.respawnAt = this.time + n.respawnDelay; } }
        break;
      default: break;
    }
  }

  toGraph(n, flee = false) {
    const nn = NPCNavigation.nearest(n.x, n.z), q = NPCNavigation.node(nn.a, nn.b);
    n.state = 'goto'; n.goto = { x: q.x, z: q.z, next: 'walk', a: nn.a, b: nn.b }; n.edge = null;
  }

  stepSpeed(n) { return n.fear > 0 ? 5.2 + n.speed * 0.8 : n.speed; }

  walk(n, dt) {
    const e = n.edge; if (!e) { this.toGraph(n); return; }
    const g = this.game;
    // wait for traffic before crossing
    if (e.cross && n.t === 0 && n.fear <= 0 && !e.waited) {
      if (!this.nav.crossingClear(e.a0, e.b0, e.a1, e.b1)) { n.state = 'wait'; n.wait = 1.0; n.afterWait = 'walk'; return; }
      e.waited = true;
    }
    n.t += (this.stepSpeed(n) * dt) / e.len;
    // shop visits
    if (n.fear <= 0 && n.enterCool <= 0 && !e.cross && n.lod < 2 && Math.random() < dt * 0.35) { if (this.enterNear(n)) return; }
    if (n.t >= 1) {
      n.t = 0; if (n.state === 'flee' && n.fear <= 0) n.state = 'walk';
      this.chooseNext(n);
      // sometimes stop for a phone call / chat
      if (n.fear <= 0 && Math.random() < 0.05) { n.state = 'phone'; n.stateT = 6 + Math.random() * 14; n.edge = null; n.yaw = Math.random() * 6.28; return; }
    }
    const ox = n.x, oz = n.z;
    this.evalEdge(n);
    const mx = n.x - ox, mz = n.z - oz;
    if (mx * mx + mz * mz > 1e-8) n.yaw = dampAngle(n.yaw, Math.atan2(-mx, -mz), 10, Math.min(dt, 0.1));
    n.phase += (this.stepSpeed(n) * dt) * 2.4;
    this.footstep(n);
  }

  /** soft footsteps from nearby walkers */
  footstep(n) {
    const s = Math.floor(n.phase / Math.PI);
    if (s === n.stepIdx) return;
    n.stepIdx = s;
    if (n.lod !== 0) return;
    const p = this.game.player, dx = n.x - p.pos.x, dz = n.z - p.pos.z;
    if (dx * dx + dz * dz > 100 || Math.abs(n.y - p.pos.y) > 4) return;
    this.game.audio.play('step', { pos: { x: n.x, y: n.y, z: n.z }, gain: 0.16, ref: 2, vary: 0.25, hrtf: false, minGap: 0.05 });
  }

  goto(n, dt) {
    const t = n.goto; if (!t) { n.state = 'walk'; return; }
    const dx = t.x - n.x, dz = t.z - n.z, d = Math.hypot(dx, dz);
    const sp = this.stepSpeed(n) * dt;
    if (d <= Math.max(0.2, sp)) {
      n.x = t.x; n.z = t.z; n.goto = null;
      if (t.next === 'walk') {
        const nb = NPCNavigation.neighbors(t.a, t.b, this._neigh);
        let to = nb[(this.R() * nb.length) | 0];
        if (n.fear > 0) { let bd = -1; for (const q of nb) { const p = NPCNavigation.node(q[0], q[1]); const dd = Math.hypot(p.x - n.fearX, p.z - n.fearZ); if (dd > bd) { bd = dd; to = q; } } }
        this.setEdge(n, t.a, t.b, to[0], to[1], 0); n.state = n.fear > 0 ? 'flee' : 'walk';
      } else if (t.next === 'enter') {
        n.state = 'inside'; n.inside = true; n.stateT = this.R.range(8, 28); this.clearSlot(n); n.lastLod = -1;
        this.game.audio.play('door_click', { pos: { x: n.x, y: 1.2, z: n.z }, gain: 0.5, ref: 3, hrtf: false });
      }
      return;
    }
    n.x += (dx / d) * sp; n.z += (dz / d) * sp;
    n.yaw = dampAngle(n.yaw, Math.atan2(-dx, -dz), 10, Math.min(dt, 0.1));
    n.phase += this.stepSpeed(n) * dt * 2.4;
    this.footstep(n);
  }

  exitBuilding(n) {
    const e = n.entrance; n.inside = false; n.lastLod = -1;
    if (e) { n.x = e.x; n.z = e.z; }
    this.toGraph(n);
  }

  // ------------------------------------------------------------ API used by weapons

  // ------------------------------------------------------------ VR grabbing, punching, throwing (all cartoonish, non-graphic)
  /** nearest civilian whose BODY (capsule: head to feet, or a ball when lying down) is within r of a hand position */
  grabNearest(pos, r = 0.16) {
    let best = null, bd = 1e9;
    for (const n of this.pool) {
      if (!n.active || n.inside || n.state === 'held' || n.fade < 0.6) continue;
      let d;
      if (n.state === 'fall') d = Math.hypot(pos.x - n.x, pos.y - (n.y + 0.3), pos.z - n.z) - 0.75;
      else {
        const y0 = n.y + 0.12, y1 = n.y + n.h - 0.1;
        const cy = Math.min(y1, Math.max(y0, pos.y));
        d = Math.hypot(pos.x - n.x, pos.y - cy, pos.z - n.z) - 0.2 * n.w;
      }
      if (d < r && d < bd) { bd = d; best = n; }
    }
    return best;
  }
  /** pick the civilian up by whatever part of the body the hand is on */
  grab(n, hand, palm) {
    if (n.bench) { n.bench.taken = null; n.bench = null; }
    if (n.talkWith) { n.talkWith.talkWith = null; n.talkWith = null; }
    n.state = 'held'; n.heldBy = hand; n.edge = null; n.goto = null; n.kx = n.kz = 0; n.fear = 0; n.fallK = 0; n.fade = 1; n.fallT = 0; n.stateT = 0;
    n.gx = palm ? Math.max(-0.5, Math.min(0.5, palm.x - n.x)) : 0;
    n.gy = palm ? Math.max(0.1, Math.min(n.h, palm.y - n.y)) : n.h * 0.82;
    n.gz = palm ? Math.max(-0.5, Math.min(0.5, palm.z - n.z)) : 0;
    this.anger(n);
    this.game.audio.play('help', { pos: { x: n.x, y: 1.5, z: n.z }, gain: 0.8, ref: 4, hrtf: false, minGap: 0.2 });
    for (const o of this.pool) if (o !== n && o.active && !o.inside && !o.angry && Math.hypot(o.x - n.x, o.z - n.z) < 16) this.react.scare(o, n.x, n.z, false);
  }
  /** held civilians dangle from the exact spot you grabbed (called every frame by the hand) */
  holdAt(n, palm, quat) {
    n.x = palm.x - (n.gx || 0); n.z = palm.z - (n.gz || 0); n.y = palm.y - (n.gy || n.h * 0.82);
    n.yaw = Math.atan2(-(palm.x - this.game.vr.headPos.x), -(palm.z - this.game.vr.headPos.z)) + Math.PI;
  }
  /** this civilian is now furious: slow, fists only, never armed */
  anger(n) {
    if (n.state === 'inside') return;
    if (!n.angry) { n.angry = true; if (this.game.ui && Math.random() < 0.5) this.game.ui.toast('SOMEONE IS MAD AT YOU!', 1100); }
    if (n.bench) { n.bench.taken = null; n.bench = null; }
    if (n.talkWith) { n.talkWith.talkWith = null; n.talkWith = null; }
    n.fear = 0;
    if (n.state === 'walk' || n.state === 'flee' || n.state === 'goto' || n.state === 'sit' || n.state === 'talk' || n.state === 'phone' || n.state === 'wait') { n.state = 'chase'; n.edge = null; n.goto = null; }
  }
  chase(n, dt) {
    const g = this.game, p = g.player, w = g.world.collision;
    n.atkT = Math.max(0, n.atkT - dt); n.atkCD = Math.max(0, n.atkCD - dt);
    if (g.health.dead) { n.angry = false; n.state = 'walk'; this.toGraph(n); return; }
    const dx = p.pos.x - n.x, dz = p.pos.z - n.z, d = Math.hypot(dx, dz) || 1;
    n.yaw = Math.atan2(-dx, -dz);
    n.phase += dt * 5.5;
    const vert = Math.abs((p.pos.y + 0.9) - (n.y + n.h * 0.5));
    if (d > 0.85 || vert > 1.4) {
      const sp = 1.75;                                    // really slow
      let mx = (dx / d) * sp * dt, mz = (dz / d) * sp * dt;
      const hit = w.raycast(n.x, n.y + 0.9, n.z, dx / d, 0, dz / d, 0.7, {});
      if (hit) { mx *= 0.15; mz *= 0.15; }                // blocked by a wall: shuffle against it
      n.x += mx; n.z += mz;
      const gy = w.groundBelow(n.x, n.y + 0.6, n.z, 0.15, 0.3);
      if (gy > -1e8) n.y = gy;
    } else if (n.atkCD <= 0 && vert <= 1.4) {
      // fist swing
      n.atkT = 0.35; n.atkCD = 1.3;
      if (g.health.damage(5, 'fist')) { g.audio.play('impact', { pos: { x: n.x, y: 1.2, z: n.z }, gain: 0.7, ref: 3, hrtf: false }); p.vel.x += (dx / d) * 1.5; p.vel.z += (dz / d) * 1.5; g.camera_ctrl && g.camera_ctrl.punch(0.4); }
    }
  }
  /** a civilian appears at an exact spot (e.g. a driver pulled out of a car) */
  spawnAt(x, z, y, look) {
    const slot = this.pool.find((n) => !n.active) || this.pool.find((n) => n.active && n.state === 'walk' && !n.inside);
    if (!slot) return null;
    if (slot.active) this.release(slot);
    this.randomizeLook(slot);
    if (look) {
      const c = new THREE.Color(), i = slot.i;
      this.M.head.setColorAt(i, c.setHex(look.skin)); this.M.torso.setColorAt(i, c.setHex(look.shirt)); this.M.low.setColorAt(i, c.setHex(look.shirt));
      for (let k = 0; k < 2; k++) { this.M.armU.setColorAt(i * 2 + k, c.setHex(look.shirt)); if (!slot.style.longSleeve) this.M.armL.setColorAt(i * 2 + k, c.setHex(look.skin)); }
      for (const m of [this.M.head, this.M.torso, this.M.low, this.M.armU, this.M.armL]) m.instanceColor.needsUpdate = true;
    }
    slot.angry = true; slot.atkT = 0; slot.atkCD = 0; slot.active = true; slot.inside = false; slot.fade = 1; slot.fear = 0; slot.hp = 40; slot.helped = false;
    slot.talkWith = null; slot.bench = null; slot.kx = slot.kz = 0; slot.lastLod = -1; slot.screamed = false; slot.prev = null; slot.edge = null; slot.goto = null;
    slot.x = x; slot.z = z; slot.y = y; slot.state = 'stagger'; slot.stagT = 0; slot.fearX = x; slot.fearZ = z; slot.tick = 0;
    return slot;
  }
  launch(n, vx, vy, vz) {
    n.state = 'thrown'; n.heldBy = null; n.edge = null; n.goto = null; n.vx = vx; n.vy = vy; n.vz = vz; n.tumble = 0;
    n.spin = (Math.random() < 0.5 ? -1 : 1) * (3 + Math.random() * 5); n.maxImpact = 0; n.airT = 0; n.fade = 1; n.fallT = 0;
    n.respawnDelay = 6 + Math.random() * 6;
  }
  fly(n, dt) {
    const g = this.game, w = g.world.collision;
    n.airT += dt;
    n.vy -= 22 * dt;
    let nx = n.x + n.vx * dt, ny = n.y + n.vy * dt, nz = n.z + n.vz * dt;
    const dx = nx - n.x, dz = nz - n.z, L = Math.hypot(dx, dz);
    if (L > 1e-4) {
      const hit = w.raycast(n.x, n.y + n.h * 0.5, n.z, dx / L, 0, dz / L, L + 0.3, {});
      if (hit) { n.maxImpact = Math.max(n.maxImpact, Math.hypot(n.vx, n.vz)); n.vx *= -0.25; n.vz *= -0.25; nx = n.x; nz = n.z; g.audio.play('impact', { pos: { x: n.x, y: n.y + 1, z: n.z }, gain: 0.5, ref: 3, hrtf: false, minGap: 0.1 }); }
    }
    const gy = w.groundBelow(nx, ny + 0.6, nz, 0.15, 0.3);
    n.x = nx; n.z = nz; n.y = ny;
    if (gy > -1e8 && ny <= gy && n.vy < 0) {
      n.y = gy;
      const imp = -n.vy; n.maxImpact = Math.max(n.maxImpact, imp);
      if (imp > 5) { n.vy = imp * 0.3; n.vx *= 0.65; n.vz *= 0.65; n.spin *= 0.6; g.particles.poof({ x: n.x, y: n.y, z: n.z }, [0.85, 0.85, 0.8], 5, 1.2, 0.25); g.audio.play('land', { pos: { x: n.x, y: n.y, z: n.z }, gain: 0.5, hrtf: false, minGap: 0.15 }); }
      else {
        n.vy = 0; n.vx *= Math.max(0, 1 - dt * 5); n.vz *= Math.max(0, 1 - dt * 5);
        if (Math.hypot(n.vx, n.vz) < 0.8) {
          // settle: big impacts leave them dazed on the ground (then they despawn), small ones just run away
          n.yaw = Math.atan2(-n.vx, -n.vz) || n.yaw; n.tumble = 0; n.vx = n.vz = 0;
          if (n.maxImpact > 8) { n.state = 'fall'; n.fallT = 0; n.fallK = 0; n.hp = 0; g.crime && g.crime.onInnocentDown(n); }
          else { n.state = 'stagger'; n.stagT = 0; n.fearX = n.x - 2; n.fearZ = n.z; n.helped = false; }
        }
      }
    }
    n.tumble += (n.state === 'thrown' ? n.spin : 0) * dt * (n.y - gy > 0.15 ? 1 : 0.2);
    if (n.y < -40 || n.airT > 12) { n.state = 'fall'; n.fallT = 0; n.fallK = 0; }
  }
  /** a fast hand hit a civilian: weak = comic stagger, hard = they go flying */
  punch(n, dir, speed, hand) {
    const g = this.game;
    g.audio.play('impact', { pos: { x: n.x, y: n.y + 1.2, z: n.z }, gain: 0.7, ref: 3, hrtf: false, minGap: 0.1 });
    g.particles.burst({ x: n.x, y: n.y + n.h * 0.7, z: n.z }, [1, 0.95, 0.4], 8, 2.4, 0.09, 0.7);
    n.angry = true;
    if (speed > 5.5) {
      const k = Math.min(1.2, speed / 6);
      this.launch(n, dir.x * speed * 0.9, 3 + speed * 0.35, dir.z * speed * 0.9);
      g.ui && g.ui.toast('BONK!', 700);
    } else this.react.hit(n, speed * 4, { x: dir.x, z: dir.z }, null);
    this.react.alertShot({ x: n.x, z: n.z }, 18);
  }

  alertShot(pos, r) { this.react.alertShot(pos, r); }
  hit(n, dmg, dir, point) { this.react.hit(n, dmg, dir, point); }
  raycast(o, d, maxT) {
    let best = null, bt = maxT;
    for (const n of this.pool) {
      if (!n.active || n.inside || n.fade < 0.5) continue;
      const fallen = n.state === 'fall';
      const hh = fallen ? 0.45 : n.h, hw = fallen ? 0.9 : 0.27 * n.w + 0.04;
      const x0 = n.x - hw, x1 = n.x + hw, z0 = n.z - hw, z1 = n.z + hw, y0 = n.y, y1 = n.y + hh;
      let tmin = 0, tmax = bt;
      for (const [oo, dd, lo, hi] of [[o.x, d.x, x0, x1], [o.y, d.y, y0, y1], [o.z, d.z, z0, z1]]) {
        if (Math.abs(dd) < 1e-8) { if (oo < lo || oo > hi) { tmax = -1; break; } continue; }
        let a = (lo - oo) / dd, b = (hi - oo) / dd; if (a > b) { const t = a; a = b; b = t; }
        tmin = Math.max(tmin, a); tmax = Math.min(tmax, b); if (tmin > tmax) { tmax = -1; break; }
      }
      if (tmax >= 0 && tmin < bt) { bt = tmin; best = n; }
    }
    return best ? { npc: best, t: bt } : null;
  }

  // ------------------------------------------------------------ rendering
  render(dt) {
    const M = this.M, t = this.time;
    for (const n of this.pool) {
      if (!n.active || n.inside) { if (n.active && n.lastLod !== -2) { this.clearSlot(n); n.lastLod = -2; } continue; }
      if (n.lod === 0 || n.lod === 1) { if (n.lod === 0) this.drawFull(n, dt); else this.drawMid(n, dt); }
      else this.drawLow(n);
    }
    for (const m of Object.values(M)) m.instanceMatrix.needsUpdate = true;
  }

  put(mesh, idx, base, px, py, pz, rx, sx, sy, sz, rz = 0) {
    this._e.set(rx, 0, rz); this._q.setFromEuler(this._e);
    this._p.set(px, py, pz); this._s.set(sx, sy, sz);
    this._loc.compose(this._p, this._q, this._s);
    this._mm.multiplyMatrices(base, this._loc);
    mesh.setMatrixAt(idx, this._mm);
  }

  baseMatrix(n, extraRotX = 0) {
    this._e.set(extraRotX, n.yaw, 0, 'YXZ'); this._q.setFromEuler(this._e);
    const s = n.fade;
    this._p.set(n.x, n.y, n.z); this._s.set(s, s, s);
    return this._base.compose(this._p, this._q, this._s);
  }

  pose(n, dt) {
    // returns animation parameters
    const P = { legL: 0, legR: 0, armL: 0, armR: 0, elbowL: 0, elbowR: 0, lean: 0, bob: 0, armLz: 0, armRz: 0, tiltX: 0 };
    const st = n.state, ph = n.phase, sw = n.style.swing;
    const moving = st === 'walk' || st === 'flee' || st === 'goto' || st === 'chase';
    if (st === 'chase') {
      // angry shuffle: fists up, stomping
      const A = 0.5;
      P.legL = Math.sin(ph) * A; P.legR = -Math.sin(ph) * A; P.bob = Math.abs(Math.sin(ph)) * 0.03; P.lean = 0.18;
      P.armL = -1.5 + Math.sin(ph * 2) * 0.25; P.armR = -1.5 - Math.sin(ph * 2) * 0.25; P.elbowL = P.elbowR = -1.5; P.armLz = 0.15; P.armRz = -0.15;
      if (n.atkT > 0) { const k = Math.sin((1 - n.atkT / 0.35) * Math.PI); P.armR = -1.5 - 0.9 * k; P.elbowR = -1.5 + 1.4 * k; P.lean = 0.18 + 0.3 * k; }
    } else if (moving) {
      const fast = n.fear > 0;
      const A = (fast ? 0.95 : 0.55) * sw;
      P.legL = Math.sin(ph) * A; P.legR = -Math.sin(ph) * A;
      P.armL = -Math.sin(ph) * A * 0.9; P.armR = Math.sin(ph) * A * 0.9;
      P.elbowL = fast ? -1.1 : -0.25; P.elbowR = fast ? -1.1 : -0.25;
      P.bob = Math.abs(Math.sin(ph)) * (fast ? 0.045 : 0.025); P.lean = fast ? 0.22 : 0.05;
      if (fast) { P.armL = -2.3 + Math.sin(ph * 1.7) * 0.5; P.armR = -2.3 + Math.cos(ph * 1.7) * 0.5; P.armLz = 0.4; P.armRz = -0.4; }
    } else if (st === 'sit') { P.legL = P.legR = -1.45; P.armL = -0.5; P.armR = -0.5; P.elbowL = P.elbowR = -0.6; }
    else if (st === 'talk') { const t = this.time * 2 + n.i; P.armR = -0.6 + Math.sin(t * 1.3) * 0.5; P.elbowR = -1.1 + Math.sin(t * 2.1) * 0.4; P.armL = -0.2 + Math.sin(t * 0.9 + 1) * 0.3; P.elbowL = -0.7; P.bob = Math.sin(t * 1.1) * 0.01; }
    else if (st === 'phone') { P.armR = -1.9; P.elbowR = -1.55; P.armL = 0.05; P.bob = Math.sin(this.time + n.i) * 0.008; }
    else if (st === 'handsup') { P.armL = -2.9; P.armR = -2.9; P.armLz = 0.3; P.armRz = -0.3; P.elbowL = P.elbowR = -0.15; P.bob = Math.sin(this.time * 9 + n.i) * 0.006; }
    else if (st === 'cop') { const A = n.copMove ? 0.55 : 0; P.legL = Math.sin(ph) * A; P.legR = -Math.sin(ph) * A; P.armR = -1.5; P.elbowR = -0.1; P.armL = -0.35; P.lean = n.copMove ? 0.1 : -0.05; P.bob = n.copMove ? Math.abs(Math.sin(ph)) * 0.025 : 0; }
    else if (st === 'stagger') { const k = Math.sin(this.time * 18) * 0.4; P.armL = -1.8 + k; P.armR = -1.8 - k; P.lean = -0.35; P.armLz = 0.6; P.armRz = -0.6; }
    else if (st === 'wait') { P.armL = 0.0; P.bob = Math.sin(this.time * 2 + n.i) * 0.006; }
    else if (st === 'held') { const t = this.time * 14 + n.i; P.armL = -2.7 + Math.sin(t) * 0.5; P.armR = -2.7 + Math.cos(t * 1.1) * 0.5; P.armLz = 0.5; P.armRz = -0.5; P.legL = Math.sin(t * 0.9) * 0.6; P.legR = -Math.sin(t * 0.9) * 0.6; P.lean = -0.1; }
    else if (st === 'thrown') { P.armL = -2.8; P.armR = -2.8; P.armLz = 0.7; P.armRz = -0.7; P.legL = 0.6; P.legR = -0.4; }
    else if (st === 'fall') { P.armL = -2.4; P.armR = -2.4; P.legL = 0.3; P.legR = -0.2; }
    else P.bob = Math.sin(this.time * 1.3 + n.i) * 0.006;
    return P;
  }

  drawFull(n, dt) {
    const M = this.M, h = n.h, w = n.w, i = n.i;
    const P = this.pose(n, dt);
    let tilt = 0; let yOff = 0;
    if (n.state === 'fall') { n.fallK = Math.min(1, (n.fallK || 0) + dt * 3.5); tilt = -Math.PI / 2 * n.fallK; yOff = 0.0; }
    else if (n.state === 'thrown') { tilt = n.tumble || 0; n.fallK = 0; }
    else n.fallK = 0;
    const base = this.baseMatrix(n, tilt);
    n.lastLod = 0;
    M.low.setMatrixAt(i, this.zero);
    const legLen = 0.47 * h, torsoH = 0.36 * h, hipY = legLen + P.bob;
    const tw = 0.27 * h * w * 0.78, td = 0.15 * h * w;
    // torso (leans around the hips)
    this.put(M.torso, i, base, 0, hipY + torsoH / 2, 0, P.lean, tw, torsoH, td);
    const shoulderY = hipY + torsoH * 0.93, sx = tw / 2 + 0.045;
    const headY = hipY + torsoH + 0.1 * h * 0.8;
    const hd = 0.135 * h;
    this.put(M.head, i, base, 0, headY, -0.01 + Math.sin(P.lean) * 0.05, 0, hd * 0.95, hd * 1.1, hd);
    const hs = n.style.hair, a = n.style.acc;
    if (hs === 1) { this.put(M.hairCap, i, base, 0, headY + hd * 0.02, 0, 0, hd * 1.08, hd * 1.15, hd * 1.08); M.hairLong.setMatrixAt(i, this.zero); M.hat.setMatrixAt(i, this.zero); }
    else if (hs === 2) { this.put(M.hairCap, i, base, 0, headY + hd * 0.02, 0, 0, hd * 1.08, hd * 1.15, hd * 1.08); this.put(M.hairLong, i, base, 0, headY - hd * 0.35, hd * 0.42, 0, hd * 1.0, hd * 1.5, hd * 0.3); M.hat.setMatrixAt(i, this.zero); }
    else if (hs === 3) { M.hairCap.setMatrixAt(i, this.zero); M.hairLong.setMatrixAt(i, this.zero); this.put(M.hat, i, base, 0, headY + hd * 0.38, 0, 0, hd * 1.15, hd * 1.15, hd * 1.15); }
    else { M.hairCap.setMatrixAt(i, this.zero); M.hairLong.setMatrixAt(i, this.zero); M.hat.setMatrixAt(i, this.zero); }
    if (a === 1) this.put(M.bag, i, base, 0, hipY + torsoH * 0.5, td * 0.5 + 0.08, P.lean, tw * 0.85, torsoH * 0.8, 0.14);
    else if (a === 2) this.put(M.bag, i, base, tw / 2 + 0.07, hipY + 0.02, -0.02, 0, 0.1, 0.26, 0.24);
    else M.bag.setMatrixAt(i, this.zero);
    if (a === 3) this.put(M.glasses, i, base, 0, headY + hd * 0.08, -hd * 0.5, 0, hd * 0.95, hd * 0.2, 0.02); else M.glasses.setMatrixAt(i, this.zero);
    // arms (upper + lower), legs, feet
    const aU = 0.19 * h, aL = 0.17 * h, aw = 0.045 * h * (0.9 + w * 0.1);
    for (let k = 0; k < 2; k++) {
      const s = k ? 1 : -1;
      const sw = k ? P.armR : P.armL, el = k ? P.elbowR : P.elbowL, az = (k ? P.armRz : P.armLz);
      // upper arm pivot at the shoulder
      this._e.set(sw, 0, s * 0.06 + az); this._q.setFromEuler(this._e);
      this._p.set(s * sx, shoulderY, 0); this._s.set(aw * 1.1, aU, aw * 1.1);
      this._loc.compose(this._p, this._q, this._s); const up = this._mm.multiplyMatrices(base, this._loc).clone();
      M.armU.setMatrixAt(i * 2 + k, up);
      // forearm: child of upper arm
      this._e.set(el, 0, 0); this._q.setFromEuler(this._e); this._p.set(0, -1, 0); this._s.set(0.9, aL / aU, 0.9);
      this._loc.compose(this._p, this._q, this._s);
      M.armL.setMatrixAt(i * 2 + k, this._mm.multiplyMatrices(up, this._loc));
      // leg
      const lg = k ? P.legR : P.legL;
      this.put(M.leg, i * 2 + k, base, s * tw * 0.22, hipY, 0, lg, 0.075 * h * 0.95, legLen - 0.04, 0.085 * h);
      this.put(M.foot, i * 2 + k, base, s * tw * 0.22, 0.03 * h, -0.04 * h + Math.sin(lg) * 0.0, 0, 0.075 * h, 0.04 * h, 0.14 * h);
    }
    // phone
    if (n.state === 'phone' || (n.style.phone && n.state === 'walk')) this.put(M.phone, i, base, tw / 2 + 0.04, shoulderY - 0.02, -0.18 * h * 0.5, 0, 0.03, 0.1, 0.055); else M.phone.setMatrixAt(i, this.zero);
  }

  drawMid(n, dt) {
    // reduced: torso + head + legs as one pair (no arm/foot detail, simple swing)
    const M = this.M, h = n.h, w = n.w, i = n.i;
    const P = this.pose(n, dt);
    let tilt = 0;
    if (n.state === 'fall') tilt = -Math.PI / 2;
    const base = this.baseMatrix(n, tilt);
    if (n.lastLod === 2 || n.lastLod === 0 || n.lastLod === -1 || n.lastLod === -2) { for (const k of ['hairLong', 'hat', 'bag', 'glasses', 'phone']) M[k].setMatrixAt(i, this.zero); for (const k of ['armU', 'armL', 'foot']) { M[k].setMatrixAt(i * 2, this.zero); M[k].setMatrixAt(i * 2 + 1, this.zero); } M.low.setMatrixAt(i, this.zero); }
    n.lastLod = 1;
    const legLen = 0.47 * h, torsoH = 0.36 * h, tw = 0.27 * h * w * 0.78, hipY = legLen + P.bob * 0.5;
    this.put(M.torso, i, base, 0, hipY + torsoH / 2, 0, P.lean, tw, torsoH, 0.15 * h * w);
    this.put(M.head, i, base, 0, hipY + torsoH + 0.08 * h, 0, 0, 0.13 * h, 0.15 * h, 0.13 * h);
    if (n.style.hair) this.put(M.hairCap, i, base, 0, hipY + torsoH + 0.085 * h, 0, 0, 0.14 * h, 0.16 * h, 0.14 * h); else M.hairCap.setMatrixAt(i, this.zero);
    for (let k = 0; k < 2; k++) { const s = k ? 1 : -1; this.put(M.leg, i * 2 + k, base, s * tw * 0.22, hipY, 0, k ? P.legR : P.legL, 0.07 * h, legLen, 0.085 * h); }
  }

  drawLow(n) {
    const M = this.M, i = n.i;
    if (n.lastLod !== 2) { this.clearSlot(n); n.lastLod = 2; }
    const h = n.h * (n.state === 'fall' ? 0.3 : 1);
    this._e.set(0, n.yaw, 0); this._q.setFromEuler(this._e); this._p.set(n.x, n.y + h * 0.5, n.z); this._s.set(0.3 * n.w, h * 0.96, 0.2 * n.w);
    this._mm.compose(this._p, this._q, this._s); M.low.setMatrixAt(i, this._mm);
  }
}

function mergeG(a, b) {
  const geos = [a, b];
  const pos = [], nor = [], idx = []; let off = 0;
  for (const g of geos) { const p = g.attributes.position, n = g.attributes.normal; for (let i = 0; i < p.count; i++) { pos.push(p.getX(i), p.getY(i), p.getZ(i)); nor.push(n.getX(i), n.getY(i), n.getZ(i)); } if (g.index) for (let i = 0; i < g.index.count; i++) idx.push(g.index.getX(i) + off); off += p.count; }
  const m = new THREE.BufferGeometry(); m.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); m.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3)); m.setIndex(idx); return m;
}
