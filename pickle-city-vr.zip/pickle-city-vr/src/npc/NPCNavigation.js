// Efficient sidewalk navigation: an analytic grid graph (no per-frame pathfinding, no navmesh).
// Nodes sit on the sidewalk corners of every block; edges run along blocks or across streets.
import { GRID, P, cx } from '../world/Constants.js';

const W = 26.8;                 // sidewalk line offset from block centre
const N = GRID * 2;             // nodes per axis

const axisPos = (a) => cx(a >> 1) + (a & 1 ? W : -W);

export class NPCNavigation {
  constructor(world) { this.world = world; }

  static node(a, b) { return { x: axisPos(a), z: axisPos(b) }; }
  static valid(a, b) { return a >= 0 && b >= 0 && a < N && b < N; }
  static isCrossing(a0, b0, a1, b1) {
    if (a0 !== a1) return (Math.min(a0, a1) & 1) === 1;
    return (Math.min(b0, b1) & 1) === 1;
  }
  static nearest(x, z) {
    const f = (v) => { let best = 0, bd = 1e9; const i = Math.round(v / P + (GRID - 1) / 2); for (let k = Math.max(0, i - 1); k <= Math.min(GRID - 1, i + 1); k++) for (const s of [0, 1]) { const a = k * 2 + s, d = Math.abs(axisPos(a) - v); if (d < bd) { bd = d; best = a; } } return best; };
    return { a: f(x), b: f(z) };
  }
  static neighbors(a, b, out) {
    out.length = 0;
    if (NPCNavigation.valid(a + 1, b)) out.push([a + 1, b]);
    if (NPCNavigation.valid(a - 1, b)) out.push([a - 1, b]);
    if (NPCNavigation.valid(a, b + 1)) out.push([a, b + 1]);
    if (NPCNavigation.valid(a, b - 1)) out.push([a, b - 1]);
    return out;
  }
  static edgeLen(a0, b0, a1, b1) { const p = NPCNavigation.node(a0, b0), q = NPCNavigation.node(a1, b1); return Math.hypot(p.x - q.x, p.z - q.z); }

  /** true if no moving car is near the street-crossing segment */
  crossingClear(a0, b0, a1, b1) {
    const p = NPCNavigation.node(a0, b0), q = NPCNavigation.node(a1, b1);
    const cars = this.world.cars; if (!cars) return true;
    const mx = (p.x + q.x) / 2, mz = (p.z + q.z) / 2;
    const alongX = a0 !== a1;           // crossing a street that runs along z: cars move along z
    for (const c of cars.list) {
      if (!c.active || !c.ai) continue;
      // car lanes lie on a street line; relevant if the car's street line is the street being crossed
      if (alongX ? (c.axis !== 'z' || Math.abs(c.x - mx) > 12) : (c.axis !== 'x' || Math.abs(c.z - mz) > 12)) continue;
      const d = alongX ? Math.abs(c.z - mz) : Math.abs(c.x - mx);
      const headingToward = alongX ? (c.dir > 0 ? c.z < mz : c.z > mz) : (c.dir > 0 ? c.x < mx : c.x > mx);
      if (d < 7 || (d < 28 && headingToward)) return false;
    }
    return true;
  }
}
