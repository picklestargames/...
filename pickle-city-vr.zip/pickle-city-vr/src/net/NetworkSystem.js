// Multiplayer over the artifact "room" capability (everyone who has this page open right now shares one lobby).
// Presence carries each player's pose (about 12 Hz); events carry shots, hits and frags.
// Everything is optional: with no room (public link, old viewer) the game simply stays single-player.
import * as THREE from 'three';
import { WEAPONS } from '../weapons/WeaponDefs.js';
import { WebSocketRoom, serverUrl } from './WebSocketRoom.js';

const r2 = (v) => Math.round(v * 100) / 100;
const HUES = [0xe0453a, 0x3a86e0, 0xe0b030, 0xb04ae0, 0x30c0b0, 0xe07a30, 0xe04a9a, 0xf0f0f0];
const hash = (s) => { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return Math.abs(h); };

class Remote {
  constructor(net, peer) {
    this.net = net; this.id = peer; const g = net.game, mats = g.world.mats;
    this.color = HUES[hash(peer) % HUES.length]; this.name = 'PICKLE-' + peer.slice(0, 4).toUpperCase();
    this.root = new THREE.Group(); this.root.visible = false;
    this.pos = new THREE.Vector3(); this.tp = new THREE.Vector3(); this.head = new THREE.Vector3(); this.th = new THREE.Vector3();
    this.hands = [new THREE.Vector3(), new THREE.Vector3()]; this.th_ = [new THREE.Vector3(), new THREE.Vector3()];
    this.hq = [new THREE.Quaternion(), new THREE.Quaternion()]; this.tq = [new THREE.Quaternion(), new THREE.Quaternion()];
    this.yaw = 0; this.ty = 0; this.hp = 100; this.inCity = false; this.vr = false; this.driving = false; this.seen = 0; this.fresh = false;
    this.ad = new THREE.Vector3(0, 0, -1);
    // body: a pickle capsule, eyes, a coloured cap
    this.body = new THREE.Mesh(new THREE.CapsuleGeometry(0.21, 1.0, 6, 14), mats.pickle); this.root.add(this.body);
    const eyeM = new THREE.MeshStandardMaterial({ color: 0xf6f6f0, roughness: 0.3 }), pupM = new THREE.MeshStandardMaterial({ color: 0x101010, roughness: 0.2 });
    this.eyes = new THREE.Group();
    for (const sx of [-1, 1]) { const e = new THREE.Mesh(new THREE.SphereGeometry(0.06, 10, 8), eyeM); e.position.set(sx * 0.09, 0, -0.17); const p = new THREE.Mesh(new THREE.SphereGeometry(0.03, 8, 6), pupM); p.position.set(0, 0, -0.045); e.add(p); this.eyes.add(e); }
    this.root.add(this.eyes);
    this.cap = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.22, 0.09, 14), new THREE.MeshStandardMaterial({ color: this.color, roughness: 0.6 })); this.root.add(this.cap);
    // arms + hands
    const skin = mats.pickle;
    this.arms = [0, 1].map(() => { const m = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 1, 7), skin); m.frustumCulled = false; this.root.add(m); return m; });
    this.fists = [0, 1].map(() => { const m = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 6), skin); this.root.add(m); return m; });
    this.guns = [null, null]; this.gunIds = [null, null];
    // car shown while driving
    this.car = new THREE.Group();
    const cm = new THREE.MeshStandardMaterial({ color: this.color, metalness: 0.5, roughness: 0.3 });
    const b = new THREE.Mesh(new THREE.BoxGeometry(1.85, 0.6, 4.3), cm); b.position.y = 0.6; const cab = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.55, 2.0), new THREE.MeshStandardMaterial({ color: 0x1a2530, metalness: 0.8, roughness: 0.1 })); cab.position.set(0, 1.12, -0.1);
    this.car.add(b, cab);
    for (const [x, z] of [[-0.9, -1.4], [0.9, -1.4], [-0.9, 1.4], [0.9, 1.4]]) { const w = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.34, 0.24, 12).rotateZ(Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0x111111 })); w.position.set(x, 0.34, z); this.car.add(w); }
    this.car.visible = false; this.root.add(this.car);
    // name plate
    this.cv = document.createElement('canvas'); this.cv.width = 256; this.cv.height = 64; this.tex = new THREE.CanvasTexture(this.cv); this.tex.colorSpace = THREE.SRGBColorSpace;
    this.plate = new THREE.Sprite(new THREE.SpriteMaterial({ map: this.tex, transparent: true, depthWrite: false })); this.plate.scale.set(0.9, 0.225, 1); this.plate.renderOrder = 9; this.root.add(this.plate);
    this._plateKey = ''; this.drawPlate();
    net.group.add(this.root);
  }
  drawPlate() {
    const key = this.name + '|' + Math.round(this.hp / 5); if (key === this._plateKey) return; this._plateKey = key;
    const g = this.cv.getContext('2d'); g.clearRect(0, 0, 256, 64);
    g.fillStyle = 'rgba(0,0,0,0.55)'; g.fillRect(8, 6, 240, 52);
    g.fillStyle = '#fff'; g.font = 'bold 26px system-ui, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(this.name, 128, 24);
    g.fillStyle = '#222'; g.fillRect(24, 42, 208, 10); g.fillStyle = this.hp > 50 ? '#4cd964' : this.hp > 25 ? '#f0b030' : '#e0453a'; g.fillRect(24, 42, 208 * Math.max(0, Math.min(1, this.hp / 100)), 10);
    this.tex.needsUpdate = true;
  }
  apply(pr) {
    if (!pr || !pr.p) return;
    const first = !this.fresh; this.fresh = true;
    this.tp.fromArray(pr.p); this.th.fromArray(pr.hd || [pr.p[0], pr.p[1] + 1.6, pr.p[2]]); this.ty = pr.yw || 0;
    this.hp = pr.hp ?? 100; this.inCity = !!pr.in; this.vr = !!pr.vr; this.driving = !!pr.dv;
    if (pr.n) this.name = String(pr.n).slice(0, 20);
    if (pr.ad) this.ad.fromArray(pr.ad);
    for (let i = 0; i < 2; i++) { const h = pr.H && pr.H[i]; if (!h) continue; this.th_[i].set(h[0], h[1], h[2]); this.tq[i].set(h[3], h[4], h[5], h[6]); this.setGun(i, h[7] || null); }
    if (first) { this.pos.copy(this.tp); this.head.copy(this.th); this.yaw = this.ty; for (let i = 0; i < 2; i++) { this.hands[i].copy(this.th_[i]); this.hq[i].copy(this.tq[i]); } }
  }
  setGun(i, id) {
    if (this.gunIds[i] === id) return; this.gunIds[i] = id;
    if (this.guns[i]) { this.root.remove(this.guns[i]); this.guns[i] = null; }
    if (id && WEAPONS[id]) { try { const m = this.net.game.weapons.create(id); m.flash.visible = false; m.root.traverse((o) => { o.frustumCulled = false; }); this.guns[i] = m.root; this.root.add(m.root); } catch (e) { /* ignore */ } }
  }
  update(dt) {
    const k = 1 - Math.exp(-14 * dt);
    this.pos.lerp(this.tp, k); this.head.lerp(this.th, k);
    let d = this.ty - this.yaw; while (d > Math.PI) d -= 6.2832; while (d < -Math.PI) d += 6.2832; this.yaw += d * k;
    for (let i = 0; i < 2; i++) { this.hands[i].lerp(this.th_[i], k); this.hq[i].slerp(this.tq[i], k); }
    const R = this.root; R.visible = this.inCity && this.fresh;
    if (!R.visible) return;
    R.position.set(this.pos.x, this.pos.y, this.pos.z);
    // world-space helpers below use root-local coordinates
    const lx = (v) => v.x - R.position.x, ly = (v) => v.y - R.position.y, lz = (v) => v.z - R.position.z;
    const hy = Math.max(0.9, this.head.y - this.pos.y);
    if (this.driving) { this.car.visible = true; this.car.rotation.y = this.yaw + Math.PI; this.body.visible = false; this.eyes.visible = false; this.cap.visible = false; for (const a of this.arms) a.visible = false; for (const f of this.fists) f.visible = false; for (const gn of this.guns) if (gn) gn.visible = false; this.plate.position.set(0, 2.3, 0); this.drawPlate(); return; }
    this.car.visible = false; this.body.visible = true; this.eyes.visible = true; this.cap.visible = true;
    this.body.position.set(lx(this.head) * 0.5, hy / 2 - 0.05, lz(this.head) * 0.5); this.body.scale.set(1, (hy + 0.15) / 1.42, 1);
    const hp = new THREE.Vector3(lx(this.head), hy, lz(this.head));
    this.eyes.position.set(hp.x, hy - 0.12, hp.z); this.eyes.rotation.y = this.vr ? Math.atan2(-this.ad.x, -this.ad.z) : this.yaw;
    this.cap.position.set(hp.x, hy + 0.08, hp.z);
    this.plate.position.set(hp.x, hy + 0.55, hp.z);
    const sh = [new THREE.Vector3(hp.x - 0.22, hy - 0.35, hp.z), new THREE.Vector3(hp.x + 0.22, hy - 0.35, hp.z)];
    const yq = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), this.yaw);
    for (let i = 0; i < 2; i++) {
      let hpw;
      if (this.vr) hpw = new THREE.Vector3(lx(this.hands[i]), ly(this.hands[i]), lz(this.hands[i]));
      else { // desktop: hands in front, gun along the aim direction
        const right = new THREE.Vector3(i === 1 ? 0.22 : -0.22, 0, 0).applyQuaternion(yq);
        hpw = new THREE.Vector3(hp.x, hy - 0.45, hp.z).add(right).addScaledVector(this.ad, 0.35);
      }
      const a = sh[i], b = hpw, dir = new THREE.Vector3().subVectors(b, a), len = Math.max(0.01, dir.length());
      this.arms[i].visible = true; this.arms[i].position.copy(a).addScaledVector(dir, 0.5); this.arms[i].scale.set(1, len, 1); this.arms[i].quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize());
      this.fists[i].visible = true; this.fists[i].position.copy(b);
      const gn = this.guns[i];
      if (gn) {
        gn.visible = true; gn.position.copy(b);
        if (this.vr) gn.quaternion.copy(this.hq[i]);
        else { const aq = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 0, -1), this.ad); gn.quaternion.copy(aq); }
      }
    }
    this.drawPlate();
  }
  dispose() { this.net.group.remove(this.root); this.root.traverse((o) => { if (o.geometry && o.geometry !== undefined && o.geometry.dispose && !(o.material === this.net.game.world.mats.pickle)) { /* shared mats stay */ } }); }
}

export class NetworkSystem {
  constructor(game) {
    this.game = game; this.room = null; this.connected = false; this.status = 'offline';
    this.remote = new Map(); this.group = new THREE.Group(); game.world.scene.add(this.group);
    this.myPeer = null; this.name = ''; this.sendT = 0; this.shotT = 0; this.pending = new Map(); this.count = 1; this.names = [];
    this._v = new THREE.Vector3(); this._q = new THREE.Quaternion(); this._v2 = new THREE.Vector3();
    this.init();
  }

  async init() {
    try {
      let room = null; this.mode = 'room';
      const c = typeof window !== 'undefined' && window.claude;
      if (c && c.use) { try { room = await c.use('room'); } catch (e) { room = null; } }
      if (!room) {                                   // not inside the artifact viewer: use the game's own WebSocket relay
        const url = serverUrl();
        if (url) { const w = new WebSocketRoom(url); if (await w.ready) room = w; else w.close(); this.mode = 'server'; }
      }
      if (!room) return;
      this.room = room; this.status = 'online';
      room.onConnection((ok) => { this.connected = ok; }, () => { this.status = 'offline'; });
      room.onPeers((ch) => this.onPeers(ch), () => { this.status = 'offline'; });
      room.on('shot', (m) => this.onShot(m), () => {});
      room.on('hit', (m) => this.onHit(m), () => {});
      room.on('frag', (m) => this.onFrag(m), () => {});
    } catch (e) { console.warn('multiplayer unavailable', e); }
  }

  get online() { return !!this.room && this.status === 'online'; }

  onPeers(ch) {
    const list = ch.peers; let me = null;
    this.names = [];
    for (const p of list) {
      if (p.sameTab) { me = p; continue; }
      if (p.isMe) continue;
      let r = this.remote.get(p.peer);
      if (!r) { r = new Remote(this, p.peer); this.remote.set(p.peer, r); }
      r.apply(p.presence); r.seen = p.updatedAt; this.names.push(r.name);
    }
    for (const p of ch.left) { const r = this.remote.get(p.peer); if (r) { this.group.remove(r.root); this.remote.delete(p.peer); } }
    if (me) { this.myPeer = me.peer; this.name = 'PICKLE-' + me.peer.slice(0, 4).toUpperCase(); }
    this.count = list.filter((p) => !p.isMe || p.sameTab).length;
  }

  presenceNow() {
    const g = this.game, p = g.player, vr = g.vr, W = g.weapons;
    const head = this._v;
    if (vr.active) head.copy(vr.headPos); else g.camera.getWorldPosition(head);
    const o = { n: this.name, in: g.apartment && g.apartment.inside ? 0 : 1, p: [r2(p.pos.x), r2(p.pos.y), r2(p.pos.z)], hd: [r2(head.x), r2(head.y), r2(head.z)], yw: r2(p.yaw), hp: Math.round(g.health.hp), vr: vr.active ? 1 : 0, dv: g.vehicles && g.vehicles.driving ? 1 : 0 };
    if (o.dv) { const c = g.vehicles.driving; o.p = [r2(c.pos.x), r2(c.pos.y), r2(c.pos.z)]; o.yw = r2(c.yaw); o.hd = [o.p[0], o.p[1] + 1.4, o.p[2]]; }
    if (vr.active) {
      o.H = [0, 1].map((i) => { const h = vr.hands[i], hd = W.holders[i]; if (!h) return null; const mdl = hd.model; const q = mdl ? mdl.root.quaternion : h.quat; const pos = mdl ? mdl.root.position : h.palm; return [r2(pos.x), r2(pos.y), r2(pos.z), r2(q.x * 1000) / 1000, r2(q.y * 1000) / 1000, r2(q.z * 1000) / 1000, r2(q.w * 1000) / 1000, hd.id || 0]; });
      if (o.H.includes(null)) o.H = null;
    } else {
      const d = g.camera.getWorldDirection(this._v2); o.ad = [r2(d.x), r2(d.y), r2(d.z)]; o.H = [[0, 0, 0, 0, 0, 0, 1, 0], [0, 0, 0, 0, 0, 0, 1, W.holders[0].id || 0]];
    }
    if (vr.active && vr.headForward) { const d = vr.headForward; o.ad = [r2(d.x), r2(d.y), r2(d.z)]; }
    return o;
  }

  update(dt) {
    if (!this.online) return;
    try {
      this.sendT -= dt;
      if (this.sendT <= 0 && this.connected && this.game.state === 'playing') { this.sendT = 1 / 12; this.room.presence(this.presenceNow()).catch(() => {}); }
      for (const r of this.remote.values()) r.update(dt);
    } catch (e) { if (!this._warned) { this._warned = true; console.warn('net update', e); } }
  }

  // ------------------------------------------------------------------ shooting
  /** ray vs the other players (vertical capsules). returns {t, peer, head} for the nearest one */
  raycast(o, d, maxT) {
    let best = null;
    for (const r of this.remote.values()) {
      if (!r.root.visible || r.hp <= 0) continue;
      const top = Math.max(r.head.y + 0.2, r.pos.y + 1.2), bot = r.pos.y, cx = r.driving ? r.pos.x : r.head.x, cz = r.driving ? r.pos.z : r.head.z, R = r.driving ? 1.1 : 0.34;
      const t0 = r.driving ? bot : bot, t1 = r.driving ? bot + 1.6 : top;
      const dx = o.x - cx, dz = o.z - cz, a = d.x * d.x + d.z * d.z;
      let t = -1;
      if (a < 1e-8) { if (dx * dx + dz * dz < R * R) t = 0; }
      else { const b = dx * d.x + dz * d.z, c = dx * dx + dz * dz - R * R, disc = b * b - a * c; if (disc >= 0) { const s = Math.sqrt(disc); t = (-b - s) / a; if (t < 0) t = (-b + s) / a >= 0 ? 0 : -1; } }
      if (t < 0 || t > maxT) continue;
      const y = o.y + d.y * t; if (y < t0 || y > t1) continue;
      if (!best || t < best.t) best = { t, peer: r.id, head: !r.driving && y > r.head.y - 0.22, r };
    }
    return best;
  }
  hitPlayer(pr, dmg, fall, withHead) {
    const d = dmg * fall * (pr.head ? 2.2 : 1); const e = this.pending.get(pr.peer) || 0; this.pending.set(pr.peer, e + d);
    const g = this.game; g.ui && g.ui.hitMarker(); g.audio.play('hit', { gain: 0.55, bus: 'ui' }); g.weapons.hitT = 0.12;
  }
  /** called once per trigger pull after the pellets were traced */
  afterFire(origin, dir, d) {
    if (!this.online) return;
    try {
      const now = performance.now();
      if (now - this.shotT > 70) { this.shotT = now; this.room.emit('shot', { w: d.id, o: [r2(origin.x), r2(origin.y), r2(origin.z)], d: [r2(dir.x), r2(dir.y), r2(dir.z)] }).catch(() => {}); }
      for (const [peer, dmg] of this.pending) this.room.emit('hit', { to: peer, dmg: Math.round(dmg) }).catch(() => {});
    } catch (e) { /* ignore */ }
    this.pending.clear();
  }
  onShot(m) {
    if (m.isMe || !m.data || !WEAPONS[m.data.w]) return;
    const g = this.game, d = WEAPONS[m.data.w], o = this._v.fromArray(m.data.o), dir = this._v2.fromArray(m.data.d).normalize();
    if (o.distanceTo(g.player.pos) > 220) return;
    const end = o.clone().addScaledVector(dir, Math.min(d.range, 140));
    g.weapons.addTracer(o.clone(), end, d);
    g.audio.play(d.sound, { pos: o.clone(), gain: 0.8, ref: 8 });
    g.particles.muzzleFlash(o.clone(), dir.clone(), d.pellets > 1 ? 1.3 : 1);
  }
  onHit(m) {
    if (m.isMe || !m.data || m.data.to !== this.myPeer) return;
    const g = this.game; if (g.health.dead || (g.apartment && g.apartment.inside)) return;
    const dmg = Math.min(120, Math.max(0, +m.data.dmg || 0)); if (!dmg) return;
    const was = g.health.dead; g.health.damage(dmg, 'player');
    if (!was && g.health.dead) this.room.emit('frag', { to: m.peer, victim: this.name }).catch(() => {});
  }
  onFrag(m) {
    if (m.isMe || !m.data || m.data.to !== this.myPeer) return;
    const g = this.game; g.crime && g.crime.add(500, 'FRAG! ' + String(m.data.victim || '').slice(0, 20) + '  +$500');
  }
}
