// A drop-in stand-in for the artifact "room" capability, backed by the game's own WebSocket relay (server/server.cjs).
// Same surface NetworkSystem uses: presence(), emit(), on(), onPeers(), onConnection(), connected().
export class WebSocketRoom {
  constructor(url) {
    this.url = url; this.ws = null; this.myId = null; this.pres = {}; this.map = new Map();   // peer -> { presence, updatedAt }
    this.topics = new Map(); this.peerCbs = []; this.connCbs = []; this._ok = false; this.retry = 0; this.closed = false;
    this._flush = false; this._joined = []; this._left = []; this._updated = new Set();
    this.ready = new Promise((res) => { this._res = res; setTimeout(() => res(this._ok), 6000); });
    this.connect();
  }
  connected() { return this._ok; }
  connect() {
    if (this.closed) return;
    let ws; try { ws = new WebSocket(this.url); } catch (e) { this._res(false); return; }
    this.ws = ws;
    ws.onopen = () => { this.retry = 0; };
    ws.onmessage = (ev) => { let m; try { m = JSON.parse(ev.data); } catch (e) { return; } this.onMsg(m); };
    ws.onclose = () => {
      const was = this._ok; this._ok = false; this._res(false);
      for (const p of [...this.map.keys()]) this.removePeer(p);
      this.myId = null; if (was) this.notifyConn(); this.schedule();
      if (!this.closed) setTimeout(() => this.connect(), Math.min(10000, 800 * 2 ** Math.min(this.retry++, 4)));
    };
    ws.onerror = () => {};
  }
  schedule() { if (this._flush) return; this._flush = true; setTimeout(() => { this._flush = false; this.deliver(); }, 0); }
  notifyConn() { for (const f of this.connCbs) { try { f(this._ok); } catch (e) { /* */ } } }
  peers() {
    const out = [];
    if (this.myId) out.push(this.snap(this.myId, { presence: this.pres, updatedAt: Date.now() }, true));
    for (const [id, v] of this.map) out.push(this.snap(id, v, false));
    return out;
  }
  snap(id, v, me) { return { peer: id, by: null, isMe: me, sameTab: me, kind: 'viewer', guest: false, presence: v.presence, updatedAt: v.updatedAt }; }
  deliver() {
    if (!this.peerCbs.length) { this._joined = []; this._left = []; this._updated.clear(); return; }
    const ch = { peers: this.peers(), joined: this._joined.map((id) => this.snapOf(id)).filter(Boolean), left: this._left, updated: [...this._updated].map((id) => this.snapOf(id)).filter(Boolean) };
    this._joined = []; this._left = []; this._updated.clear();
    for (const f of this.peerCbs) { try { f(ch); } catch (e) { console.warn(e); } }
  }
  snapOf(id) { const v = this.map.get(id); return v ? this.snap(id, v, false) : null; }
  removePeer(id) { if (!this.map.has(id)) return; this.map.delete(id); this._left.push(this.snap(id, { presence: {}, updatedAt: Date.now() }, false)); this.schedule(); }
  onMsg(m) {
    if (m.t === 'hi') {
      this.myId = String(m.id); this._ok = true; this._res(true);
      for (const p of m.peers || []) { this.map.set(p.peer, { presence: p.presence || {}, updatedAt: Date.now() }); this._joined.push(p.peer); }
      this.notifyConn(); this.schedule();
      if (Object.keys(this.pres).length) this.raw({ t: 'p', d: this.pres });
    } else if (m.t === 'join') { if (!this.map.has(m.peer)) { this.map.set(m.peer, { presence: {}, updatedAt: Date.now() }); this._joined.push(m.peer); this.schedule(); } }
    else if (m.t === 'x') this.removePeer(m.peer);
    else if (m.t === 'p') {
      const v = this.map.get(m.peer) || { presence: {}, updatedAt: 0 }; const next = { ...v.presence };
      for (const k of Object.keys(m.d || {})) { if (m.d[k] === null) delete next[k]; else next[k] = m.d[k]; }
      const isNew = !this.map.has(m.peer); this.map.set(m.peer, { presence: Object.freeze(next), updatedAt: Date.now() });
      if (isNew) this._joined.push(m.peer); else this._updated.add(m.peer); this.schedule();
    } else if (m.t === 'e') {
      const hs = this.topics.get(m.topic); if (!hs) return;
      const msg = { topic: m.topic, data: m.data, peer: m.peer, by: null, isMe: false, sameTab: false, kind: 'viewer', guest: false };
      for (const f of hs) { try { f(msg); } catch (e) { console.warn(e); } }
    }
  }
  raw(o) { if (this.ws && this.ws.readyState === 1) { try { this.ws.send(JSON.stringify(o)); } catch (e) { /* */ } } }
  presence(patch) { for (const k of Object.keys(patch)) { if (patch[k] === null) delete this.pres[k]; else this.pres[k] = patch[k]; } if (this._ok) this.raw({ t: 'p', d: patch }); return Promise.resolve(); }
  emit(topic, data) { if (this._ok) this.raw({ t: 'e', topic, data }); return Promise.resolve(); }
  on(topic, fn) { let s = this.topics.get(topic); if (!s) this.topics.set(topic, (s = new Set())); s.add(fn); return () => s.delete(fn); }
  onPeers(fn) { this.peerCbs.push(fn); this.schedule(); return () => { this.peerCbs = this.peerCbs.filter((f) => f !== fn); }; }
  onConnection(fn) { this.connCbs.push(fn); setTimeout(() => { try { fn(this._ok); } catch (e) { /* */ } }, 0); return () => { this.connCbs = this.connCbs.filter((f) => f !== fn); }; }
  close() { this.closed = true; try { this.ws && this.ws.close(); } catch (e) { /* */ } }
}

/** where the relay lives: ?server=wss://host/ws, window.PICKLE_SERVER, or the page's own host (when served by server.cjs) */
export function serverUrl() {
  try {
    if (typeof location === 'undefined' || !/^https?:$/.test(location.protocol)) return null;
    const q = new URLSearchParams(location.search).get('server'); if (q) return q;
    if (window.PICKLE_SERVER) return window.PICKLE_SERVER;
    if (/claude|anthropic/i.test(location.hostname)) return null;       // inside the artifact viewer: use the artifact room instead
    return (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/ws';
  } catch (e) { return null; }
}
