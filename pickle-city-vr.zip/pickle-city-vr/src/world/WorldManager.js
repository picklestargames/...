// Owns the scene: sky, sun, fog, environment reflections, traffic, birds, wind and ambient world state.
import * as THREE from 'three';
import { createMaterials } from './Materials.js';
import { CollisionWorld } from './CollisionWorld.js';
import { CityStreamingSystem } from './CityStreamingSystem.js';
import { GRID, P, WORLD_HALF } from './Constants.js';
import { rng } from '../core/Utils.js';
import { mergeSimple } from '../core/Geo.js';

const SUN_DIR = new THREE.Vector3(-0.55, 0.62, -0.42).normalize();

export class WorldManager {
  constructor(game) {
    this.game = game;
    this.scene = new THREE.Scene();
    this.collision = new CollisionWorld();
    this.time = 0;
    this.cars = null;
    this._m = new THREE.Matrix4(); this._q = new THREE.Quaternion(); this._s = new THREE.Vector3(1, 1, 1); this._p = new THREE.Vector3(); this._up = new THREE.Vector3(0, 1, 0);
    this.birds = null;
    this.windStrength = 0.3;
    this.mats = null;
  }

  init(renderer, onProgress) {
    const { scene } = this;
    const horizon = new THREE.Color(0xc9d9e6);
    scene.background = horizon;
    scene.fog = new THREE.Fog(horizon, 90, 520);
    this.horizon = horizon;

    // sky dome
    const skyGeo = new THREE.SphereGeometry(900, 24, 12);
    const skyMat = new THREE.ShaderMaterial({
      side: THREE.BackSide, depthWrite: false, fog: false,
      uniforms: { top: { value: new THREE.Color(0x3f78c4) }, mid: { value: new THREE.Color(0x9cc4e8) }, hor: { value: horizon }, sun: { value: SUN_DIR.clone() } },
      vertexShader: 'varying vec3 vD; void main(){ vD = normalize(position); gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.0); }',
      fragmentShader: `varying vec3 vD; uniform vec3 top; uniform vec3 mid; uniform vec3 hor; uniform vec3 sun;
        void main(){ float h = clamp(vD.y,0.0,1.0); vec3 c = mix(hor, mid, smoothstep(0.0,0.25,h)); c = mix(c, top, smoothstep(0.2,0.9,h));
          float s = max(dot(normalize(vD), normalize(sun)),0.0); c += vec3(1.0,0.85,0.55)*(pow(s,600.0)*3.0 + pow(s,12.0)*0.25);
          // soft clouds
          vec2 q = vD.xz/(vD.y+0.35)*1.6; float n = sin(q.x*1.7+sin(q.y*2.3))*sin(q.y*1.3+q.x*0.7); c = mix(c, vec3(1.0), smoothstep(0.35,0.9,n)*0.35*smoothstep(0.05,0.4,h));
          gl_FragColor = vec4(c,1.0); }`,
    });
    this.sky = new THREE.Mesh(skyGeo, skyMat);
    this.sky.frustumCulled = false;
    this.sky.renderOrder = -10;
    scene.add(this.sky);

    // lights
    this.hemi = new THREE.HemisphereLight(0xcfe2ff, 0x6b6558, 0.75);
    scene.add(this.hemi);
    this.sun = new THREE.DirectionalLight(0xfff0d8, 2.6);
    this.sun.position.copy(SUN_DIR).multiplyScalar(160);
    this.sun.castShadow = true;
    const sc = this.sun.shadow.camera; sc.left = -70; sc.right = 70; sc.top = 70; sc.bottom = -70; sc.near = 10; sc.far = 400;
    this.sun.shadow.mapSize.set(2048, 2048);
    this.sun.shadow.bias = -0.0004; this.sun.shadow.normalBias = 0.06;
    scene.add(this.sun, this.sun.target);
    this.interiorLight = new THREE.PointLight(0xfff2dc, 0, 16, 1.6);
    scene.add(this.interiorLight);

    // reflections: bake the sky into a PMREM environment once
    try {
      const pm = new THREE.PMREMGenerator(renderer);
      const envScene = new THREE.Scene();
      envScene.add(new THREE.Mesh(skyGeo, skyMat));
      const rt = pm.fromScene(envScene, 0, 1, 2000);
      scene.environment = rt.texture;
      scene.environmentIntensity = 0.7;
      pm.dispose();
    } catch (e) { console.warn('PMREM failed', e); }

    onProgress && onProgress('Materials', 0.2);
    this.mats = createMaterials(Math.min(8, renderer.capabilities.getMaxAnisotropy()));
    this.mats.pickle.flatShading = true; this.mats.pickleWet.flatShading = true;

    this.chunks = new CityStreamingSystem(this.game, this);
    this.buildBirds();
    this.buildAmbientProps();
    onProgress && onProgress('World', 0.6);
  }

  // ---------------------------------------------------------------- traffic
  buildTraffic() {
    const R = rng(404);
    const bodyGeo = new THREE.BoxGeometry(1.9, 0.75, 4.4); bodyGeo.translate(0, 0.62, 0);
    const cabGeo = new THREE.BoxGeometry(1.7, 0.6, 2.2); cabGeo.translate(0, 1.28, -0.1);
    // merge manually: copy attributes
    const geo = mergeSimple([bodyGeo, cabGeo]);
    const mat = new THREE.MeshStandardMaterial({ roughness: 0.3, metalness: 0.7, flatShading: true });
    const N = 56;
    this.cars = { mesh: new THREE.InstancedMesh(geo, mat, N), list: [], N };
    const colors = [0xb03a2e, 0x2e6fb0, 0xd8d8d8, 0x222222, 0xc8902a, 0x2e8b57, 0x8e44ad, 0xe8e0c0];
    for (let n = 0; n < N; n++) {
      const axis = n % 2 === 0 ? 'x' : 'z';
      const s = 1 + R.int(0, GRID - 1);
      const dir = R() < 0.5 ? 1 : -1;
      const line = (s - GRID / 2) * P;
      this.cars.list.push({ axis, line, dir, off: dir * 3.2, speed: R.range(7, 15), t: R.range(-WORLD_HALF - 30, WORLD_HALF + 30), len: 4.4, w: 1.9, x: 0, z: 0, honk: 0 });
      this.cars.mesh.setColorAt(n, new THREE.Color(R.pick(colors)));
    }
    this.cars.mesh.instanceColor.needsUpdate = true;
    this.cars.mesh.frustumCulled = false;
    this.cars.mesh.castShadow = true;
    this.scene.add(this.cars.mesh);
    this._m = new THREE.Matrix4(); this._q = new THREE.Quaternion(); this._s = new THREE.Vector3(1, 1, 1); this._p = new THREE.Vector3();
    this._up = new THREE.Vector3(0, 1, 0);
  }

  updateTraffic(dt) {
    const c = this.cars; if (!c) return;
    const lim = WORLD_HALF + 30;
    for (let n = 0; n < c.N; n++) {
      const car = c.list[n];
      car.t += car.speed * car.dir * dt;
      if (car.t > lim) car.t = -lim; else if (car.t < -lim) car.t = lim;
      if (car.axis === 'x') { car.x = car.t; car.z = car.line + car.off; } else { car.z = car.t; car.x = car.line + car.off; }
      const yaw = car.axis === 'x' ? (car.dir > 0 ? Math.PI / 2 : -Math.PI / 2) : (car.dir > 0 ? 0 : Math.PI);
      this._q.setFromAxisAngle(this._up, yaw);
      this._p.set(car.x, 0, car.z);
      this._m.compose(this._p, this._q, this._s);
      c.mesh.setMatrixAt(n, this._m);
    }
    c.mesh.instanceMatrix.needsUpdate = true;
  }

  /** Called by the player controller; returns a knock-back vector if a car hits the body. */
  carHit(px, py, pz, r) { const v = this.game.vehicles; return v ? v.carHit(px, py, pz, r) : null; }
  _oldCarHit(px, py, pz, r) {
    if (py > 2.0 || !this.cars) return null;
    for (const car of this.cars.list) {
      const along = car.axis === 'x' ? px - car.x : pz - car.z;
      const side = car.axis === 'x' ? pz - car.z : px - car.x;
      if (Math.abs(along) < car.len / 2 + r && Math.abs(side) < car.w / 2 + r) {
        const kx = car.axis === 'x' ? 0 : Math.sign(side) || 1, kz = car.axis === 'x' ? Math.sign(side) || 1 : 0;
        return { kx, kz, speed: car.speed, car };
      }
    }
    return null;
  }
  nearestCarDistance(px, pz) { const v = this.game.vehicles; return v ? v.nearestCarDistance(px, pz) : 1e9; }
  _oldNearest(px, pz) {
    let best = 1e9;
    if (!this.cars) return best;
    for (const car of this.cars.list) { const d = Math.hypot(car.x - px, car.z - pz); if (d < best) best = d; }
    return best;
  }

  // ---------------------------------------------------------------- birds
  buildBirds() {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute([0, 0, -0.12, -0.5, 0, 0.1, 0, 0, 0.1, 0, 0, -0.12, 0, 0, 0.1, 0.5, 0, 0.1], 3));
    g.computeVertexNormals();
    const m = new THREE.MeshBasicMaterial({ color: 0x222428, side: THREE.DoubleSide });
    const N = 28;
    this.birds = { mesh: new THREE.InstancedMesh(g, m, N), N, data: [] };
    const R = rng(8);
    for (let n = 0; n < N; n++) this.birds.data.push({ a: R() * 6.28, r: 20 + R() * 60, h: 30 + R() * 50, sp: 0.15 + R() * 0.2, ph: R() * 6.28, cx: 0, cz: 0 });
    this.birds.mesh.frustumCulled = false;
    this.scene.add(this.birds.mesh);
  }
  updateBirds(t, center) {
    const b = this.birds; if (!b) return;
    for (let n = 0; n < b.N; n++) {
      const d = b.data[n];
      const a = d.a + t * d.sp;
      const x = center.x + Math.cos(a) * d.r, z = center.z + Math.sin(a) * d.r, y = d.h + Math.sin(t * 0.7 + d.ph) * 3;
      const flap = Math.sin(t * 9 + d.ph) * 0.5;
      this._q.setFromEuler(new THREE.Euler(0, -a - Math.PI / 2 * 0 + Math.PI, flap * 0.3));
      this._p.set(x, y, z);
      this._s.set(1 + flap * 0.15, 1, 1);
      this._m.compose(this._p, this._q, this._s);
      b.mesh.setMatrixAt(n, this._m);
    }
    this._s.set(1, 1, 1);
    b.mesh.instanceMatrix.needsUpdate = true;
  }

  buildAmbientProps() { /* reserved for future ambient props (steam vents, flags) */ }

  update(dt, playerPos) {
    this.time += dt;
    { const v = this.game.vehicles; if (v && !v.driving) v.update(dt); }
    this.updateBirds(this.time, playerPos);
    this.sky.position.copy(playerPos);
    // keep the shadow frustum centred on the player in texel-snapped steps
    const snap = 140 / this.sun.shadow.mapSize.x * 2;
    const sx = Math.round(playerPos.x / snap) * snap, sz = Math.round(playerPos.z / snap) * snap, sy = Math.round(playerPos.y / 4) * 4;
    this.sun.target.position.set(sx, sy, sz);
    this.sun.position.set(sx, sy, sz).addScaledVector(SUN_DIR, 160);
    this.chunks.update(dt, playerPos);
    // animated chunk props
    for (const c of this.chunks.hi.values()) for (const a of c.animated) a.fn(this.time);
    // interior light follows the player into shops/garages
    this.updateInteriorLight(playerPos);
  }

  updateInteriorLight(p) {
    let best = null, bd = 14 * 14;
    for (const c of this.chunks.hi.values()) {
      if (Math.abs(c.L.cx - p.x) > 45 || Math.abs(c.L.cz - p.z) > 45) continue;
      for (const l of c.lights) {
        if (!l.interior) continue;
        const d = (l.x - p.x) ** 2 + (l.z - p.z) ** 2 + (l.y - p.y - 1.5) ** 2 * 1.5;
        if (d < bd) { bd = d; best = l; }
      }
    }
    if (best) { this.interiorLight.position.set(best.x, best.y, best.z); this.interiorLight.intensity = 14; }
    else this.interiorLight.intensity = 0;
  }
}
