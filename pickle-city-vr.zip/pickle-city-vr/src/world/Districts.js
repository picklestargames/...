// District-specific geometry: industrial, construction, gas station, parking garage, park, metro station.
import * as THREE from 'three';
import { tint } from './Batcher.js';
import { tree } from './ChunkBuilder.js';
import { FLOOR } from './Constants.js';
import { rng } from '../core/Utils.js';

const C = (h, k = 1) => tint(h, k);

function inwardQuad(B, key, a, b, c, d, n, col) {
  B.quad(key, a, b, c, d, n[0], n[1], n[2], [[0, 0], [1, 0], [1, 1], [0, 1]], col);
}

export function buildDistrictExtras(B, L, r, out, mats, lowOnly = false) {
  const R = rng(L.i * 911 + L.j * 53 + 17);
  switch (L.district) {
    case 'ind': industrial(B, L, R, out, lowOnly); break;
    case 'con': construction(B, L, R, out, lowOnly, mats); break;
    case 'gas': gas(B, L, R, out, lowOnly); break;
    case 'pkg': garage(B, L, R, out, lowOnly); break;
    case 'park': park(B, L, R, out, lowOnly); break;
    case 'metro': metro(B, L, R, out, lowOnly, mats); break;
    case 'plaza': plaza(B, L, R, out, lowOnly); break;
    default: break;
  }
}

function industrial(B, L, R, out, low) {
  const ch = L.extra.chimney;
  B.cyl('conc', ch.x, 0, ch.z, 1.6, ch.h, { n: 10, color: C(0x9a5a48), solid: true });
  B.cyl('plain', ch.x, ch.h - 2, ch.z, 1.75, 0.6, { n: 10, color: C(0x3a3a3a) });
  if (low) return;
  // shipping containers: stacks of 1-3
  const cols = [0xb03a2e, 0x2e6fb0, 0x2e8b57, 0xc8902a, 0x7a7a7a, 0x8e44ad];
  for (let a = 0; a < 3; a++) for (let b = 0; b < 2; b++) {
    const x = L.cx + 6 + a * 6.6, z = L.cz + 4 + b * 10;
    if (R() < 0.15) continue;
    const n = 1 + R.int(0, 2);
    for (let k = 0; k < n; k++) {
      const col = C(R.pick(cols));
      B.solidBox(x, k * 2.7, z, x + 6.0, (k + 1) * 2.7, z + 2.5, { side: 'metal', top: 'metal', color: col, tile: 0.9, floor: 2.7 });
    }
  }
  // fuel tanks with ladders
  for (let n = 0; n < 2; n++) {
    const x = L.cx + 8 + n * 9, z = L.cz - 12;
    B.cyl('metal', x, 0, z, 3.0, 7, { n: 12, color: C(0xc9ccd0), solid: true });
    B.ladder(x, z + 3.02, 0, 1, 0, 7.0);
  }
  // pipe bridge between the two sheds & vertical pipes
  B.box(L.cx - 26, 8.0, L.cz - 3.6, L.cx - 2, 8.4, L.cz + 6.4, { side: 'metal', color: C(0x555a60), skip: 't', tile: 1 });
  for (let k = 0; k < 4; k++) B.cyl('metal', L.cx - 26, 8.6 + k * 0.0, L.cz - 3 + k * 2.4, 0.22, 24, { n: 6, axis: 'x', color: C([0xb03a2e, 0x7a8a96, 0xc8902a, 0x4a6a8a][k]) });
  // crates and barrels
  for (let n = 0; n < 10; n++) {
    const x = L.cx + R.range(-24, -4), z = L.cz + R.range(-2, 5);
    if (R() < 0.5) B.solidBox(x, 0, z, x + 1.1, 1.1, z + 1.1, { side: 'plain', top: 'plain', color: C(0x9a7a50), tile: 1.1, floor: 1.1 });
    else B.cyl('plain', x, 0, z, 0.4, 1.0, { n: 8, color: C(R.pick([0x2e6fb0, 0xb03a2e, 0x4a4a4a])), solid: true });
  }
}

function construction(B, L, R, out, low, mats) {
  const x0 = L.cx - 18, z0 = L.cz - 18, x1 = L.cx + 18, z1 = L.cz + 18;
  const floors = 9;
  if (low) {
    B.box(x0, 0, z0, x1, floors * FLOOR, z1, { side: 'conc', top: 'conc', color: C(0xaaaaaa) });
  } else {
    // columns 5x5
    for (let a = 0; a < 5; a++) for (let b = 0; b < 5; b++) {
      const x = x0 + 1 + a * 8.5, z = z0 + 1 + b * 8.5;
      B.solidBox(x - 0.35, 0, z - 0.35, x + 0.35, floors * FLOOR, z + 0.35, { side: 'conc', top: 'conc', color: C(0xb4b2ac), tile: 2, floor: FLOOR });
    }
    // floor slabs with a ladder shaft (x 10..13.5, z -14..-10 relative)
    const hx0 = L.cx + 10, hx1 = L.cx + 13.5, hz0 = L.cz - 14, hz1 = L.cz - 10;
    for (let k = 1; k <= floors; k++) {
      const y = k * FLOOR;
      const slab = (a, b, c, d) => B.solidBox(a, y - 0.3, b, c, y, d, { side: 'conc', top: 'conc', color: C(0xc2bfb7), tile: 3, floor: 0.3 });
      if (k === floors) { // roof: unfinished, partial
        slab(x0, z0, x1, hz0); slab(x0, hz0, hx0, hz1); slab(hx1, hz0, x1, hz1); slab(x0, hz1, x1, z1);
      } else { slab(x0, z0, x1, hz0); slab(x0, hz0, hx0, hz1); slab(hx1, hz0, x1, hz1); slab(x0, hz1, x1, z1); }
      // scaffold railing on some edges
      if (k < floors && k % 2 === 0) B.box(x0, y, z1 - 0.05, x1, y + 1.0, z1, { side: 'metal', color: C(0xd8a020), skip: 't', tile: 0.5, floor: 0.5 });
      // stacked material pallets
      if (k % 3 === 1) B.solidBox(x0 + 3, y, z0 + 3, x0 + 5, y + 1.0, z0 + 5, { side: 'plain', top: 'plain', color: C(0xa8896a) });
    }
    B.ladder(L.cx + 11.75, L.cz - 9.95, 0, -1, 0, floors * FLOOR);
    // ground: barriers, cones, mixer
    for (let n = 0; n < 14; n++) {
      const a = (n / 14) * Math.PI * 2;
      const x = L.cx + Math.cos(a) * 24 * 1.0, z = L.cz + Math.sin(a) * 24;
      B.solidBox(x - 0.9, 0, z - 0.15, x + 0.9, 1.0, z + 0.15, { side: 'plain', top: 'plain', color: n % 2 ? C(0xe8e8e8) : C(0xff8a1a) });
    }
    for (let n = 0; n < 8; n++) B.cone('plain', L.cx + R.range(-24, 24), 0, L.cz + (R() < 0.5 ? 24.5 : -24.5), 0.22, 0.04, 0.7, { n: 6, color: C(0xff6a10) });
    B.cyl('metal', L.cx - 26, 0.9, L.cz + 22, 1.1, 2.0, { n: 10, color: C(0xd8a020), solid: true });
    // scaffolding tower on the east side
    for (let k = 0; k < 6; k++) {
      const y = k * 2.0;
      for (const [dx, dz] of [[0, 0], [2.4, 0], [0, 2.4], [2.4, 2.4]]) B.box(L.cx + 20 + dx - 0.04, y, L.cz + 4 + dz - 0.04, L.cx + 20 + dx + 0.04, y + 2.0, L.cz + 4 + dz + 0.04, { side: 'metal', color: C(0x8a9096) });
      B.solidBox(L.cx + 19.8, y + 1.9, L.cz + 3.8, L.cx + 22.6, y + 2.0, L.cz + 6.6, { side: 'plain', top: 'plain', color: C(0xa8896a) });
    }
    B.ladder(L.cx + 21.2, L.cz + 3.75, 0, -1, 0, 12.0);
  }
  // tower crane
  const cr = L.crane;
  const H = cr.h;
  for (const [dx, dz] of [[-1.3, -1.3], [1.3, -1.3], [-1.3, 1.3], [1.3, 1.3]]) B.solidBox(cr.x + dx - 0.12, 0, cr.z + dz - 0.12, cr.x + dx + 0.12, H, cr.z + dz + 0.12, { side: 'metal', top: 'metal', color: C(0xe8b020) });
  if (!low) {
    for (let y = 2; y < H; y += 4) {
      for (const [x0b, z0b, x1b, z1b] of [[-1.3, -1.3, 1.3, -1.3], [-1.3, 1.3, 1.3, 1.3], [-1.3, -1.3, -1.3, 1.3], [1.3, -1.3, 1.3, 1.3]]) {
        B.box(cr.x + Math.min(x0b, x1b) - 0.04, y, cr.z + Math.min(z0b, z1b) - 0.04, cr.x + Math.max(x0b, x1b) + 0.04, y + 0.08, cr.z + Math.max(z0b, z1b) + 0.04, { side: 'metal', color: C(0xe8b020), skip: 't' });
      }
    }
    B.ladder(cr.x, cr.z + 1.45, 0, 1, 0, H);
  }
  // top platform with hatch gap in front of the ladder, + jib & counterweight
  const py = H, pt = 0.3;
  const plat = (a, b, c, d) => B.solidBox(cr.x + a, py - pt, cr.z + b, cr.x + c, py, cr.z + d, { side: 'metal', top: 'metal', color: C(0xe8b020), tile: 1.5, floor: 0.3 });
  plat(-3.5, -3.5, 3.5, 1.0); plat(-3.5, 1.0, -0.7, 3.5); plat(0.7, 1.0, 3.5, 3.5);
  plat(-26, -0.7, -3.5, 0.7);              // jib
  plat(3.5, -0.9, 9, 0.9);                 // counter jib
  B.solidBox(cr.x + 5.5, py, cr.z - 0.7, cr.x + 8, py + 1.6, cr.z + 0.7, { side: 'plain', top: 'plain', color: C(0x7a7a7a) });
  B.box(cr.x - 1.0, py, cr.z - 1.0, cr.x + 1.0, py + 5, cr.z + 1.0, { side: 'metal', color: C(0xe8b020), skip: 't' });
  B.box(cr.x - 0.1, py + 5, cr.z - 0.1, cr.x + 0.1, py + 6, cr.z + 0.1, { side: 'emissive', color: [1, 0.1, 0.05] });
  out.lights.push({ x: cr.x, y: py + 5.5, z: cr.z });
  // animated hook on the jib
  if (!low && mats) {
    const g = new THREE.Group();
    const cable = new THREE.Mesh(new THREE.BoxGeometry(0.05, 12, 0.05), mats.metal);
    cable.position.y = -6;
    const hook = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.9, 0.9), mats.flat(0xe8b020, 0.5, 0.3));
    hook.position.y = -12.4;
    const load = new THREE.Mesh(new THREE.BoxGeometry(2.4, 1.2, 1.6), mats.flat(0x7a5a3a, 0.9, 0));
    load.position.y = -13.5;
    g.add(cable, hook, load);
    g.position.set(cr.x - 15, py - 0.3, cr.z);
    out.extraMeshes = out.extraMeshes || [];
    out.extraMeshes.push(g);
    out.animated.push({ obj: g, fn: (t) => { g.position.x = cr.x - 15 + Math.sin(t * 0.15) * 9; g.children[0].scale.y = 1 + Math.sin(t * 0.2) * 0.1; } });
  }
}

function gas(B, L, R, out, low) {
  const py = L.extra.pylon;
  B.cyl('metal', py.x, 0, py.z, 0.3, py.h, { n: 6, color: C(0x3a3d42), solid: true });
  B.box(py.x - 1.6, py.h - 0.2, py.z - 0.3, py.x + 1.6, py.h + 3.4, py.z + 0.3, { side: 'emissive', color: [0.95, 0.85, 0.2] });
  B.box(py.x - 1.7, py.h - 0.3, py.z - 0.35, py.x + 1.7, py.h - 0.2, py.z + 0.35, { side: 'plain', color: C(0x222222) });
  const cx = L.cx - 2, cz = L.cz - 6;
  B.solidBox(cx - 12, 5.0, cz - 6, cx + 12, 5.5, cz + 6, { side: 'plain', top: 'roof', color: C(0xe8e8e8), tile: 2, floor: 0.5 });
  B.box(cx - 12.05, 5.1, cz - 6.05, cx + 12.05, 5.4, cz + 6.05, { side: 'plain', color: C(0xd03030), skip: 't', tile: 4, floor: 0.4 });
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) B.cyl('conc', cx + sx * 9, 0, cz + sz * 4, 0.35, 5, { n: 8, color: C(0xd8d8d8), solid: true });
  B.box(cx - 11, 4.95, cz - 0.3, cx + 11, 5.0, cz + 0.3, { side: 'emissive', color: [1, 1, 0.95], skip: 'xz' });
  out.lights.push({ x: cx, y: 4.8, z: cz, wide: true });
  if (low) return;
  for (const px of [-5, 5]) for (const pz of [-3, 3]) {
    B.solidBox(cx + px - 0.5, 0, cz + pz - 0.35, cx + px + 0.5, 1.5, cz + pz + 0.35, { side: 'plain', top: 'plain', color: C(0xd03030) });
    B.box(cx + px - 0.35, 1.0, cz + pz - 0.37, cx + px + 0.35, 1.35, cz + pz + 0.37, { side: 'emissive', color: [0.2, 0.9, 0.4], skip: 't' });
  }
  // parked car (static) + air pump + oil drums
  B.solidBox(cx + 16, 0.25, cz + 3, cx + 20.5, 0.95, cz + 5.2, { side: 'metal', top: 'metal', color: C(0x2e6fb0) });
  B.solidBox(cx + 17, 0.95, cz + 3.1, cx + 19.4, 1.5, cz + 5.1, { side: 'windowGlass', top: 'metal', color: C(0x2e6fb0) });
}

function garage(B, L, R, out, low) {
  const x0 = L.cx - 20, z0 = L.cz - 20, x1 = L.cx + 20, z1 = L.cz + 20;
  const H = 3.4, floors = 5;
  if (low) { B.box(x0, 0, z0, x1, floors * H, z1, { side: 'conc', top: 'conc', color: C(0xaaaaaa), tile: 6, floor: H }); return; }
  const slabHole = (y, hole) => {
    const s = (a, b, c, d) => { if (c - a > 0.01 && d - b > 0.01) B.solidBox(a, y - 0.4, b, c, y, d, { side: 'conc', top: 'conc', color: C(0xb0aea8), tile: 4, floor: 0.4 }); };
    if (!hole) return s(x0, z0, x1, z1);
    s(x0, z0, x1, hole.z0); s(x0, hole.z1, x1, z1); s(x0, hole.z0, hole.x0, hole.z1); s(hole.x1, hole.z0, x1, hole.z1);
  };
  for (let k = 0; k <= floors; k++) {
    const y = k * H;
    if (k === 0) { B.box(x0, 0, z0, x1, 0.02, z1, { side: 'plain', color: C(0x55565a), skip: 'xz' }); }
    else {
      // ramp k-1 -> k occupies lane A (k-1 even: z=-12, climbing +x) or lane B (z=+12, climbing -x)
      const laneZ = (k - 1) % 2 === 0 ? -12 : 12;
      const hole = { x0: (k - 1) % 2 === 0 ? x0 + 3 : x0 + 3, x1: x1 - 3 - 3, z0: laneZ - 3, z1: laneZ + 3 };
      if (k % 2 === 1) { hole.x0 = x0 + 3; hole.x1 = x1 - 5; } else { hole.x0 = x0 + 5; hole.x1 = x1 - 3; }
      slabHole(y, hole);
    }
    if (k < floors) {
      // pillars + low parapet walls + ceiling light strips
      for (let a = 0; a < 5; a++) for (let b = 0; b < 5; b++) {
        if (b % 4 === 0 || a % 4 === 0) B.solidBox(x0 + 1 + a * 9.5 - 0.4, y, z0 + 1 + b * 9.5 - 0.4, x0 + 1 + a * 9.5 + 0.4, y + H, z0 + 1 + b * 9.5 + 0.4, { side: 'conc', top: 'conc', color: C(0xa8a6a0), tile: 2, floor: H });
      }
      B.solidBox(x0, y, z0, x1, y + 1.0, z0 + 0.3, { side: 'conc', top: 'conc', color: C(0x9a9890), tile: 4, floor: 1 });
      B.solidBox(x0, y, z1 - 0.3, x1, y + 1.0, z1, { side: 'conc', top: 'conc', color: C(0x9a9890), tile: 4, floor: 1 });
      B.solidBox(x0, y, z0 + 0.3, x0 + 0.3, y + 1.0, z1 - 0.3, { side: 'conc', top: 'conc', color: C(0x9a9890), tile: 4, floor: 1 });
      B.solidBox(x1 - 0.3, y, z0 + 0.3, x1, y + 1.0, z1 - 0.3, { side: 'conc', top: 'conc', color: C(0x9a9890), tile: 4, floor: 1 });
      for (let a = 0; a < 4; a++) {
        B.box(x0 + 4 + a * 10, y + H - 0.55, L.cz - 0.2, x0 + 7 + a * 10, y + H - 0.5, L.cz + 0.2, { side: 'emissive', color: [1, 1, 0.92], skip: 'xz' });
        out.lights.push({ x: x0 + 5.5 + a * 10, y: y + H - 0.8, z: L.cz, interior: true });
      }
      // parked cars
      for (let n = 0; n < 4; n++) {
        const cxn = x0 + 6 + R() * 24, czn = R() < 0.5 ? z0 + 3 : z1 - 5.5;
        const col = C(R.pick([0xb03a2e, 0x2e6fb0, 0xd8d8d8, 0x222222, 0xc8902a, 0x2e8b57]));
        B.solidBox(cxn, y + 0.2, czn, cxn + 2.0, y + 0.85, czn + 4.4, { side: 'metal', top: 'metal', color: col });
        B.solidBox(cxn + 0.1, y + 0.85, czn + 0.9, cxn + 1.9, y + 1.45, czn + 3.2, { side: 'windowGlass', top: 'metal', color: col });
      }
      // ramp for this floor (steps)
      const laneZ = k % 2 === 0 ? -12 : 12;
      const rx0 = k % 2 === 0 ? x0 + 3 : x1 - 5, dir = k % 2 === 0 ? 1 : -1;
      const sx0 = k % 2 === 0 ? x0 + 3 : x1 - 3;
      const steps = 16, len = (x1 - x0) - 8;
      const run = len / steps;
      for (let n = 0; n < steps; n++) {
        const top = y + (n + 1) * (H / steps);
        const a = k % 2 === 0 ? x0 + 3 + n * run : x1 - 3 - (n + 1) * run;
        B.solidBox(a, top - 0.25, laneZ - 2.8, a + run, top, laneZ + 2.8, { side: 'conc', top: 'plain', color: C(0x6a6a70), tile: 2, floor: 0.25 });
      }
      B.box(x0 + 3, y + 0.001, laneZ - 0.05, x1 - 3, y + 0.003, laneZ + 0.05, { side: 'emissive', color: [0.9, 0.8, 0.2], skip: 'xz' });
    }
  }
  // lobby entrance sign + roof edge
  B.box(L.cx - 5, floors * H + 0.0, z0 - 0.5, L.cx + 5, floors * H + 2.0, z0 + 0.1, { side: 'emissive', color: [0.15, 0.4, 0.9] });
  B.solidBox(x0, floors * H, z0, x1, floors * H + 0.45, z0 + 0.3, { side: 'conc', top: 'conc', color: C(0xa8a6a0) });
  B.solidBox(x0, floors * H, z1 - 0.3, x1, floors * H + 0.45, z1, { side: 'conc', top: 'conc', color: C(0xa8a6a0) });
  // ground-floor open entrance drive-in is the lane gap at z edge; stair tower with a ladder to the roof
  B.ladder(x1 - 0.1, L.cz + 4, -1, 0, 0, floors * H);
}

function park(B, L, R, out, low) {
  if (low) return;
  // pond with a footbridge
  B.quad('water', [L.cx - 9, 0.03, L.cz + 6], [L.cx + 9, 0.03, L.cz + 6], [L.cx + 9, 0.03, L.cz - 6], [L.cx - 9, 0.03, L.cz - 6], 0, 1, 0, [[0, 0], [1, 0], [1, 1], [0, 1]], [1, 1, 1]);
  const bcol = C(0x7a5a3a);
  for (let n = 0; n < 4; n++) B.solidBox(L.cx - 3 + n * 0.0 - 1.0, 0, L.cz - 7.5 + n * 0.0, L.cx + 1.0, 0.0, L.cz - 7.0, { side: 'plain', color: bcol });
  const steps = [0.4, 0.8, 1.2];
  steps.forEach((h, n) => {
    B.solidBox(L.cx - 1.2, 0, L.cz - 6.2 - n * 0.0 + 0, L.cx + 1.2, h, L.cz - 6.0 + 0, { side: 'plain', top: 'plain', color: bcol });
  });
  B.solidBox(L.cx - 1.2, 0, L.cz - 6, L.cx + 1.2, 1.2, L.cz + 6, { side: 'plain', top: 'plain', color: bcol, tile: 1, floor: 1 }); // deck
  // fountain
  B.cyl('conc', L.cx + 18, 0, L.cz - 14, 3.2, 0.5, { n: 12, color: C(0xb8b4aa), solid: true });
  B.cyl('water', L.cx + 18, 0.5, L.cz - 14, 2.9, 0.02, { n: 12, color: [1, 1, 1], cap: true });
  B.cyl('conc', L.cx + 18, 0.5, L.cz - 14, 0.4, 2.2, { n: 8, color: C(0xc8c4ba) });
  // gazebo
  const gx = L.cx - 18, gz = L.cz + 14;
  B.solidBox(gx - 3, 0, gz - 3, gx + 3, 0.35, gz + 3, { side: 'conc', top: 'conc', color: C(0xc8c4ba) });
  for (const [dx, dz] of [[-2.6, -2.6], [2.6, -2.6], [-2.6, 2.6], [2.6, 2.6]]) B.cyl('plain', gx + dx, 0.35, gz + dz, 0.14, 3.0, { n: 6, color: C(0xe8e0d0), solid: true });
  B.cone('plain', gx, 3.35, gz, 4.2, 0.2, 1.8, { n: 8, color: C(0x3f6a50) });
  out.benches.push({ x: gx, z: gz, y: 0.35, face: 0 });
  // hill of terraces (good launch point)
  for (let n = 0; n < 4; n++) B.solidBox(L.cx + 14 - n * 1.5 + 4, n * 0.5, L.cz + 14 + n * 1.5 - 6, L.cx + 24 + n * 1.5 - 4, (n + 1) * 0.5, L.cz + 24 - n * 1.5 + 0, { side: 'plain', top: 'plain', color: C(0x4c7a36, 1 - n * 0.05) });
  // trees + benches
  for (let n = 0; n < 34; n++) {
    const a = R() * Math.PI * 2, d = 8 + R() * 22;
    const x = L.cx + Math.cos(a) * d, z = L.cz + Math.sin(a) * d;
    if (Math.abs(x - L.cx) < 11 && Math.abs(z - L.cz) < 8.5) continue;
    if (Math.hypot(x - (L.cx + 18), z - (L.cz - 14)) < 5 || Math.hypot(x - gx, z - gz) < 5.2) continue;
    if (x > L.cx + 8 && x < L.cx + 28 && z > L.cz + 6 && z < L.cz + 26) continue;
    tree(B, x, z, R, 1 + R() * 0.4);
  }
  for (const [x, z, f] of [[L.cx - 12, L.cz - 3, 0], [L.cx + 12, L.cz + 3, Math.PI], [L.cx - 3, L.cz + 12, -Math.PI / 2], [L.cx + 4, L.cz - 14, Math.PI / 2]]) {
    B.solidBox(x - 0.8, 0, z - 0.25, x + 0.8, 0.5, z + 0.25, { side: 'plain', top: 'plain', color: C(0x7a5a3a) });
    out.benches.push({ x, z, y: 0.5, face: f });
  }
}

function plaza(B, L, R, out, low) {
  if (low) return;
  // street-level planters around the tower
  for (let n = 0; n < 8; n++) {
    const a = (n / 8) * Math.PI * 2, x = L.cx + Math.cos(a) * 25.5, z = L.cz + Math.sin(a) * 25.5;
    B.solidBox(x - 1.2, 0, z - 1.2, x + 1.2, 0.7, z + 1.2, { side: 'conc', top: 'plain', color: C(0xb8b4aa) });
    tree(B, x, z, R, 0.8);
  }
}

function metro(B, L, R, out, low, mats) {
  const h = L.hole;
  const D = -h.y; // 7
  const wc = C(0x8c8a84);
  // pit walls (inward facing) + floor
  inwardQuad(B, 'conc', [h.x0, -D, h.z0], [h.x1, -D, h.z0], [h.x1, 0, h.z0], [h.x0, 0, h.z0], [0, 0, 1], wc);
  inwardQuad(B, 'conc', [h.x1, -D, h.z1], [h.x0, -D, h.z1], [h.x0, 0, h.z1], [h.x1, 0, h.z1], [0, 0, -1], wc);
  inwardQuad(B, 'conc', [h.x0, -D, h.z1], [h.x0, -D, h.z0], [h.x0, 0, h.z0], [h.x0, 0, h.z1], [1, 0, 0], wc);
  inwardQuad(B, 'conc', [h.x1, -D, h.z0], [h.x1, -D, h.z1], [h.x1, 0, h.z1], [h.x1, 0, h.z0], [-1, 0, 0], wc);
  B.quad('plain', [h.x0, -D, h.z1], [h.x1, -D, h.z1], [h.x1, -D, h.z0], [h.x0, -D, h.z0], 0, 1, 0, [[0, 0], [1, 0], [1, 1], [0, 1]], C(0x55575c));
  if (low) return;
  // stairs at both ends
  const sw = 6;
  for (let n = 0; n < 12; n++) {
    const top = -0.5 * (n + 1);
    B.solidBox(h.x0 + n, -D, L.cz + 2.2, h.x0 + n + 1, top, L.cz + 5.8, { side: 'conc', top: 'plain', color: C(0x9a9890), tile: 1, floor: 0.5 });
    B.solidBox(h.x1 - n - 1, -D, L.cz + 2.2, h.x1 - n, top, L.cz + 5.8, { side: 'conc', top: 'plain', color: C(0x9a9890), tile: 1, floor: 0.5 });
  }
  // platforms + rails + pillars + ceiling lights
  for (const s of [-1, 1]) {
    B.solidBox(h.x0 + 13, -D, L.cz + (s > 0 ? 2.2 : -6), h.x1 - 13, -D + 0.5, L.cz + (s > 0 ? 6 : -2.2), { side: 'conc', top: 'plain', color: C(0xb0aea8), tile: 2, floor: 0.9 });
    B.box(h.x0 + 13, -D + 0.5, L.cz + (s > 0 ? 2.2 : -2.3), h.x1 - 13, -D + 0.53, L.cz + (s > 0 ? 2.3 : -2.2), { side: 'emissive', color: [1, 0.85, 0.1], skip: 'xz' });
  }
  for (const rz of [-0.75, 0.75]) B.box(h.x0 + 12, -D, L.cz + rz - 0.05, h.x1 - 12, -D + 0.12, L.cz + rz + 0.05, { side: 'metal', color: C(0x777a80), skip: 't' });
  for (let n = 0; n < 6; n++) {
    const x = h.x0 + 16 + n * 4.0;
    B.solidBox(x - 0.3, -D + 0.5, L.cz - 0.3 + (n % 2 ? 4 : -4), x + 0.3, 0, L.cz + 0.3 + (n % 2 ? 4 : -4), { side: 'conc', top: 'conc', color: C(0xb4b2ac), tile: 2, floor: 3 });
    B.box(x - 0.8, -1.2, L.cz - 0.2, x + 0.8, -1.1, L.cz + 0.2, { side: 'emissive', color: [0.9, 0.95, 1.0], skip: 'xz' });
    out.lights.push({ x, y: -1.5, z: L.cz, interior: true });
  }
  // cross beams (jumpable)
  for (let n = 0; n < 3; n++) B.solidBox(h.x0 + 18 + n * 10, -0.4, h.z0, h.x0 + 19.2 + n * 10, 0, h.z1, { side: 'conc', top: 'conc', color: C(0x9a9890) });
  // entrance canopies + signage at both ends, benches on the platforms
  for (const s of [h.x0 - 0.5, h.x1 - 5.5]) {
    B.solidBox(s, 3.2, L.cz - 3.6, s + 6, 3.5, L.cz + 3.6, { side: 'metal', top: 'metal', color: C(0x2f6a4a) });
    for (const [dx, dz] of [[0.3, -3.3], [5.7, -3.3], [0.3, 3.3], [5.7, 3.3]]) B.cyl('metal', s + dx, 0, L.cz + dz, 0.12, 3.2, { n: 6, color: C(0x3a3d42), solid: true });
    B.box(s + 0.5, 3.5, L.cz - 0.9, s + 5.5, 4.4, L.cz + 0.9, { side: 'emissive', color: [0.1, 0.65, 0.4] });
  }
  for (const bx of [h.x0 + 20, h.x1 - 20]) { B.solidBox(bx - 0.8, -D + 0.5, L.cz + 5, bx + 0.8, -D + 1.0, L.cz + 5.5, { side: 'plain', top: 'plain', color: C(0x7a5a3a) }); out.benches.push({ x: bx, z: L.cz + 5.3, y: -D + 1.0, face: 0 }); }
  // animated train
  if (mats) {
    const g = new THREE.Group();
    const body = mats.flat(0xd8dce0, 0.35, 0.6), stripe = mats.flat(0x2f8a4a, 0.5, 0.2), glass = mats.flat(0x223344, 0.1, 0.8);
    for (let k = 0; k < 3; k++) {
      const car = new THREE.Mesh(new THREE.BoxGeometry(9.6, 3.0, 2.8), body); car.position.set(k * 10, 1.9, 0);
      const st = new THREE.Mesh(new THREE.BoxGeometry(9.62, 0.35, 2.82), stripe); st.position.set(k * 10, 1.0, 0);
      const wn = new THREE.Mesh(new THREE.BoxGeometry(8.6, 0.9, 2.84), glass); wn.position.set(k * 10, 2.3, 0);
      g.add(car, st, wn);
    }
    g.position.set(h.x0, -D, L.cz);
    out.extraMeshes = out.extraMeshes || [];
    out.extraMeshes.push(g);
    const x0t = h.x0 - 34, x1t = h.x1 + 4;
    out.animated.push({ obj: g, fn: (t) => {
      // glide in from the tunnel, dwell at the platform, glide out the other way
      const T = 36, p = (t % T) / T;
      const stopX = (h.x0 + h.x1) / 2 - 15;
      let x;
      if (p < 0.3) { const e = p / 0.3; x = x0t + (stopX - x0t) * (1 - (1 - e) * (1 - e)); }
      else if (p < 0.65) x = stopX;
      else { const e = (p - 0.65) / 0.35; x = stopX + (x1t - stopX) * e * e; }
      g.position.x = x;
    } });
  }
  // above ground: low flower beds & kiosk
  B.solidBox(L.cx - 10, 0, L.cz - 12, L.cx - 4, 2.6, L.cz - 9, { side: 'plain', top: 'plain', color: C(0x2f6a4a) });
  B.box(L.cx - 9.5, 1.6, L.cz - 9.02, L.cx - 4.5, 2.4, L.cz - 9.0, { side: 'emissive', color: [0.9, 0.95, 0.7] });
}
