// AABB collision world with per-chunk lists, dynamic boxes (doors/props), holes (underground) and ladders.
// Pure JS (no three.js) so it can run in Node tests.
import { P, GRID, cx as blockCx, toI, chunkKey } from './Constants.js';

const EPS = 1e-4;
const DYN_CAP = 512;

export class CollisionWorld {
  constructor() {
    this.chunks = new Map();     // key -> {col:Float32Array, n, ladders:[], hole}
    this.dyn = new Float32Array(DYN_CAP * 6);
    this.dynFree = [];
    this.dynN = 0;
    for (let k = 0; k < DYN_CAP * 6; k += 6) { this.dyn[k] = 1e9; this.dyn[k + 3] = -1e9; this.dyn[k + 1] = 1e9; this.dyn[k + 4] = -1e9; this.dyn[k + 2] = 1e9; this.dyn[k + 5] = -1e9; }
    this.holes = [];
    this._lists = [];
    this._cnt = [];
    this._l2 = [];
    this._c2 = [];
    this.nLists = 0;
  }

  addChunk(i, j, col, ladders, hole) {
    const f = Float32Array.from(col);
    this.chunks.set(chunkKey(i, j), { col: f, n: f.length / 6, ladders: ladders || [], hole: hole || null, i, j });
    if (hole) this.holes.push(hole);
  }
  removeChunk(i, j) {
    const k = chunkKey(i, j);
    const c = this.chunks.get(k);
    if (c && c.hole) this.holes = this.holes.filter((h) => h !== c.hole);
    this.chunks.delete(k);
  }
  hasChunk(i, j) { return this.chunks.has(chunkKey(i, j)); }
  hasChunkAt(x, z) { return this.chunks.has(chunkKey(toI(x), toI(z))); }

  /** dynamic box handle */
  addDyn(x0, y0, z0, x1, y1, z1) {
    const id = this.dynFree.length ? this.dynFree.pop() : this.dynN++;
    if (id >= DYN_CAP) { this.dynN = DYN_CAP; return -1; }
    this.setDyn(id, x0, y0, z0, x1, y1, z1);
    return id;
  }
  setDyn(id, x0, y0, z0, x1, y1, z1) {
    if (id < 0) return;
    const d = this.dyn, k = id * 6;
    d[k] = x0; d[k + 1] = y0; d[k + 2] = z0; d[k + 3] = x1; d[k + 4] = y1; d[k + 5] = z1;
  }
  disableDyn(id) { this.setDyn(id, 1e9, 1e9, 1e9, -1e9, -1e9, -1e9); }
  freeDyn(id) { if (id < 0) return; this.disableDyn(id); this.dynFree.push(id); }

  groundAt(x, z) {
    for (const h of this.holes) if (x > h.x0 && x < h.x1 && z > h.z0 && z < h.z1) return h.y;
    return 0;
  }

  /** Collect box lists near (x,z). Returns array of {a:Float32Array,n}. */
  gather(x, z, pad, lists = this._lists, cnts = this._cnt) {
    let n = 0;
    const i0 = toI(x - pad), i1 = toI(x + pad), j0 = toI(z - pad), j1 = toI(z + pad);
    for (let i = i0; i <= i1; i++) for (let j = j0; j <= j1; j++) {
      const c = this.chunks.get(chunkKey(i, j));
      if (c) { lists[n] = c.col; cnts[n] = c.n; n++; }
    }
    lists[n] = this.dyn; cnts[n] = this.dynN; n++;
    this.nLists = n;
    return lists;
  }

  /** highest walkable surface y at/below `y` (+tolerance) under the footprint, including base ground */
  groundBelow(x, y, z, r, tol = 0.06) {
    let best = this.groundAt(x, z);
    if (best > y + tol) best = -1e9; // inside a hole while above? (shouldn't happen)
    const lists = this.gather(x, z, r + 1);
    const n = this.nLists;
    const x0 = x - r, x1 = x + r, z0 = z - r, z1 = z + r;
    for (let l = 0; l < n; l++) {
      const a = lists[l], cnt = this._cnt[l] * 6;
      for (let k = 0; k < cnt; k += 6) {
        if (a[k + 3] <= x0 || a[k] >= x1 || a[k + 5] <= z0 || a[k + 2] >= z1) continue;
        const top = a[k + 4];
        if (top <= y + tol && top > best) best = top;
      }
    }
    return best;
  }

  blockedAt(x, y, z, r, h) {
    const lists = this._l2, cnts = this._c2;
    this.gather(x, z, r + 1, lists, cnts);
    const n = this.nLists;
    for (let l = 0; l < n; l++) {
      const a = lists[l], cnt = cnts[l] * 6;
      for (let k = 0; k < cnt; k += 6) {
        if (x + r > a[k] && x - r < a[k + 3] && z + r > a[k + 2] && z - r < a[k + 5] && y + h > a[k + 1] + EPS && y < a[k + 4] - EPS) return true;
      }
    }
    return false;
  }

  /** Ladder volume containing (x,y,z), or null. */
  ladderAt(x, y, z) {
    for (let i = toI(x - 3); i <= toI(x + 3); i++) for (let j = toI(z - 3); j <= toI(z + 3); j++) {
      const c = this.chunks.get(chunkKey(i, j));
      if (!c) continue;
      for (const L of c.ladders) {
        if (y < L.y0 - 0.3 || y > L.y1 + 0.2) continue;
        const dx = x - L.x, dz = z - L.z;
        const along = dx * L.fx + dz * L.fz;       // distance in front of the ladder plane
        const lat = Math.abs(dx * -L.fz + dz * L.fx);
        if (along > -0.15 && along < 0.9 && lat < 0.6) return L;
      }
    }
    return null;
  }

  /** Ray vs all nearby boxes + ground plane. Returns {t,nx,ny,nz} or null. */
  raycast(ox, oy, oz, dx, dy, dz, maxT, out) {
    let bestT = maxT, nx = 0, ny = 0, nz = 0, hit = false;
    // gather lists along the ray
    const seen = new Set();
    const steps = Math.max(1, Math.ceil(maxT / 40));
    const lists = [], cnts = [];
    for (let s = 0; s <= steps; s++) {
      const t = (s / steps) * maxT;
      const px = ox + dx * t, pz = oz + dz * t;
      for (let i = toI(px - 45); i <= toI(px + 45); i++) for (let j = toI(pz - 45); j <= toI(pz + 45); j++) {
        const k = chunkKey(i, j);
        if (seen.has(k)) continue;
        seen.add(k);
        const c = this.chunks.get(k);
        if (c) { lists.push(c.col); cnts.push(c.n); }
      }
    }
    lists.push(this.dyn); cnts.push(this.dynN);
    const idx = 1 / (dx || 1e-9), idy = 1 / (dy || 1e-9), idz = 1 / (dz || 1e-9);
    for (let l = 0; l < lists.length; l++) {
      const a = lists[l], cnt = cnts[l] * 6;
      for (let k = 0; k < cnt; k += 6) {
        let t1 = (a[k] - ox) * idx, t2 = (a[k + 3] - ox) * idx;
        let tmin = Math.min(t1, t2), tmax = Math.max(t1, t2);
        let axis = 0, sgn = t1 < t2 ? -1 : 1;
        t1 = (a[k + 1] - oy) * idy; t2 = (a[k + 4] - oy) * idy;
        let lo = Math.min(t1, t2), hi = Math.max(t1, t2);
        if (lo > tmin) { tmin = lo; axis = 1; sgn = t1 < t2 ? -1 : 1; }
        if (hi < tmax) tmax = hi;
        t1 = (a[k + 2] - oz) * idz; t2 = (a[k + 5] - oz) * idz;
        lo = Math.min(t1, t2); hi = Math.max(t1, t2);
        if (lo > tmin) { tmin = lo; axis = 2; sgn = t1 < t2 ? -1 : 1; }
        if (hi < tmax) tmax = hi;
        if (tmax < 0 || tmin > tmax || tmin < 0 || tmin >= bestT) continue;
        bestT = tmin; hit = true;
        nx = axis === 0 ? sgn : 0; ny = axis === 1 ? sgn : 0; nz = axis === 2 ? sgn : 0;
      }
    }
    // ground plane
    if (dy < -1e-6) {
      const gy = 0;
      const t = (gy - oy) / dy;
      if (t > 0 && t < bestT) {
        const gx = ox + dx * t, gz = oz + dz * t;
        if (this.groundAt(gx, gz) === 0) { bestT = t; hit = true; nx = 0; ny = 1; nz = 0; }
      }
    }
    if (!hit) return null;
    out = out || {};
    out.t = bestT; out.nx = nx; out.ny = ny; out.nz = nz;
    return out;
  }
}

/**
 * Move a vertical cylinder body through the world. Axis-separated with step-up, landing and ceilings.
 * pos: {x,y,z} (feet), vel: {x,y,z}. Returns flags in `out`.
 */
export function moveBody(w, pos, vel, dt, r, h, stepH, out, wasGrounded) {
  out.hitX = out.hitZ = false; out.landed = false; out.ceiling = false; out.stepped = 0; out.impact = 0;
  const reach = r + Math.abs(vel.x * dt) + Math.abs(vel.z * dt) + 1.5;
  let lists = w.gather(pos.x, pos.z, reach + 1);
  let n = w.nLists;
  const cnt = w._cnt;

  const resolve = (axis) => {
    for (let l = 0; l < n; l++) {
      const a = lists[l], c = cnt[l] * 6;
      for (let k = 0; k < c; k += 6) {
        if (pos.x + r <= a[k] || pos.x - r >= a[k + 3] || pos.z + r <= a[k + 2] || pos.z - r >= a[k + 5]) continue;
        if (pos.y + h <= a[k + 1] + EPS || pos.y >= a[k + 4] - EPS) continue;
        const top = a[k + 4];
        const rise = top - pos.y;
        if (rise <= stepH && (wasGrounded || vel.y > -2) && !w.blockedAt(pos.x, top + 0.001, pos.z, r, h)) {
          out.stepped += rise; pos.y = top + 0.001;
          continue;
        }
        if (axis === 0) {
          if (vel.x > 0) pos.x = a[k] - r - EPS; else if (vel.x < 0) pos.x = a[k + 3] + r + EPS;
          else pos.x += (pos.x < (a[k] + a[k + 3]) / 2) ? -(pos.x + r - a[k]) : (a[k + 3] - (pos.x - r));
          vel.x = 0; out.hitX = true;
        } else {
          if (vel.z > 0) pos.z = a[k + 2] - r - EPS; else if (vel.z < 0) pos.z = a[k + 5] + r + EPS;
          else pos.z += (pos.z < (a[k + 2] + a[k + 5]) / 2) ? -(pos.z + r - a[k + 2]) : (a[k + 5] - (pos.z - r));
          vel.z = 0; out.hitZ = true;
        }
      }
    }
  };

  if (vel.x !== 0) { pos.x += vel.x * dt; resolve(0); }
  if (vel.z !== 0) { pos.z += vel.z * dt; resolve(1); }

  // vertical
  const prevY = pos.y;
  pos.y += vel.y * dt;
  lists = w.gather(pos.x, pos.z, r + 2); n = w.nLists;
  const ir = r * 0.92;
  if (vel.y <= 0) {
    let best = -1e9;
    for (let l = 0; l < n; l++) {
      const a = lists[l], c = cnt[l] * 6;
      for (let k = 0; k < c; k += 6) {
        if (pos.x + ir <= a[k] || pos.x - ir >= a[k + 3] || pos.z + ir <= a[k + 2] || pos.z - ir >= a[k + 5]) continue;
        const top = a[k + 4];
        if (prevY >= top - 0.08 && pos.y < top && top > best) best = top;
      }
    }
    const g = w.groundAt(pos.x, pos.z);
    if (prevY >= g - 0.08 && pos.y < g && g > best) best = g;
    if (best > -1e8) { out.impact = -vel.y; pos.y = best; vel.y = 0; out.landed = true; }
  } else {
    for (let l = 0; l < n; l++) {
      const a = lists[l], c = cnt[l] * 6;
      for (let k = 0; k < c; k += 6) {
        if (pos.x + ir <= a[k] || pos.x - ir >= a[k + 3] || pos.z + ir <= a[k + 2] || pos.z - ir >= a[k + 5]) continue;
        if (prevY + h <= a[k + 1] + 0.02 && pos.y + h > a[k + 1]) { pos.y = a[k + 1] - h; vel.y = 0; out.ceiling = true; }
      }
    }
  }
  // sticky ground (walking down stairs) and grounded state
  let gy = w.groundBelow(pos.x, pos.y, pos.z, ir, 0.06);
  if (!out.landed && wasGrounded && vel.y <= 0.01 && pos.y - gy > 0.06) {
    const g4 = w.groundBelow(pos.x, pos.y, pos.z, ir, 0.0);
    if (g4 > -1e8 && pos.y - g4 <= 0.5) { pos.y = g4; vel.y = 0; gy = g4; }
  }
  out.grounded = vel.y <= 0.01 && pos.y - gy <= 0.06 && gy > -1e8;
  out.groundY = gy;
  return out;
}
