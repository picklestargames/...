// Data-first city layout: districts, building footprints, roofs, jump pads and pickups.
// Pure data (no three.js) – deterministic from the block coordinates.
import { GRID, P, FLOOR, LOT, SW, DMAP, GRAVITY, SPAWN, cx, inGrid } from './Constants.js';
import { rng } from '../core/Utils.js';

const cache = new Map();
const TINTS = {
  apt: [0xffffff, 0xeadccd, 0xd9c7b5, 0xcfd6da, 0xe8cdbb],
  shop: [0xffffff, 0xf0e2d0, 0xd8e0d0, 0xe0d0d8, 0xd0dce8],
  glass: [0xffffff, 0xd6ecff, 0xcfe6f0, 0xe0f0ff],
  ind: [0xffffff, 0xd8d8d0, 0xc9cfd6, 0xe0d6c0],
  conc: [0xffffff, 0xe8e8e8, 0xd8d4cc],
};
export const SHOP_GROUND = 4.2;

function addBuilding(L, x0, z0, x1, z1, o) {
  const b = {
    id: L.buildings.length, x0, z0, x1, z1, type: o.type, front: o.front || null,
    tint: o.tint ?? 0xffffff, tiers: [], mat: o.mat || null, frame: !!o.frame,
  };
  if (o.stack) {
    let y = 0;
    for (const [ins, floors, mat] of o.stack) {
      const [a, b2, c, d] = Array.isArray(ins) ? ins : [ins, ins, ins, ins];
      const t = { x0: x0 + a, z0: z0 + b2, x1: x1 - c, z1: z1 - d, y0: y, y1: y + floors * FLOOR, mat: mat || null };
      b.tiers.push(t);
      y = t.y1;
    }
  } else {
    b.tiers.push({ x0, z0, x1, z1, y0: 0, y1: o.h, mat: null });
  }
  b.top = b.tiers[b.tiers.length - 1].y1;
  L.buildings.push(b);
  return b;
}

function genApt(L, r) {
  const cxx = L.cx, czz = L.cz;
  const sx = r.range(-4, 4);
  const cols = [[-LOT, sx - 2], [sx + 2, LOT]];
  const annex = r.chance(1) ? { x0: czz * 0 + cxx + 16, x1: cxx + LOT, z0: czz - LOT, z1: czz - 14 } : null;
  cols.forEach(([a, b], ci) => {
    const sz = r.range(-5, 5);
    [[-LOT, sz - 2], [sz + 2, LOT]].forEach(([c, d], ri) => {
      let x1 = cxx + b;
      if (ci === 1 && ri === 0) x1 = Math.min(x1, cxx + 14);
      const inset = r.range(0, 1.5);
      addBuilding(L, cxx + a + inset, czz + c + inset, x1 - inset, czz + d - inset, {
        type: 'apt', tint: r.pick(TINTS.apt), h: (6 + r.int(0, 4)) * FLOOR,
      });
    });
  });
  addBuilding(L, annex.x0, annex.z0, annex.x1, annex.z1, { type: 'annex', tint: r.pick(TINTS.shop), h: 2 * FLOOR, front: '+z' });
}

function genShop(L, r, zMin = -LOT, zMax = LOT, rowsOnly = null) {
  const rows = rowsOnly || [[-LOT, -3, '-z'], [3, LOT, '+z']];
  for (const [a, b, front] of rows) {
    let x = -LOT;
    while (x < LOT - 8) {
      let w = r.range(11, 18);
      if (LOT - (x + w) < 11) w = LOT - x;
      const n = 2 + r.int(0, 2);
      addBuilding(L, L.cx + x, L.cz + a, L.cx + x + w, L.cz + b, {
        type: r.chance(0.25) ? 'rest' : 'shop', tint: r.pick(TINTS.shop), front,
        h: SHOP_GROUND + n * FLOOR,
      });
      x += w + (r.chance(0.3) ? 4 : 0.0);
    }
  }
}

function genDown(L, r) {
  const hs = [[-LOT, -2], [2, LOT]];
  for (const [a, b] of hs) for (const [c, d] of hs) {
    const stack = [
      [0, 3, 'conc'],
      [[4, 2, 0, 2], 4, 'glass'],
      [[8, 2, 0, 2], 4, 'glass'],
      [[12, 4, 2, 4], 10 + r.int(0, 12), 'glass'],
    ];
    addBuilding(L, L.cx + a, L.cz + c, L.cx + b, L.cz + d, { type: 'glass', tint: r.pick(TINTS.glass), stack });
  }
}

function genPlaza(L, r) {
  addBuilding(L, L.cx - 22, L.cz - 22, L.cx + 22, L.cz + 22, {
    type: 'glass', tint: 0xe8f4ff,
    stack: [[0, 4, 'conc'], [6, 4, 'glass'], [12, 4, 'glass'], [18, 4, 'glass'], [19, 12, 'glass']],
  });
}

function genInd(L, r) {
  addBuilding(L, L.cx - LOT, L.cz - LOT, L.cx + 2, L.cz - 4, { type: 'ind', tint: r.pick(TINTS.ind), h: 3 * FLOOR + 0.4 });
  addBuilding(L, L.cx - LOT, L.cz + 6, L.cx - 2, L.cz + LOT, { type: 'ind', tint: r.pick(TINTS.ind), h: 3 * FLOOR + 0.4 });
  L.extra.chimney = { x: L.cx + 14, z: L.cz - 20, h: 38 };
}

function genCon(L, r) {
  addBuilding(L, L.cx - 18, L.cz - 18, L.cx + 18, L.cz + 18, { type: 'frame', frame: true, h: 9 * FLOOR });
  L.crane = { x: L.cx + 22, z: L.cz - 22, h: 48 };
}

function genGas(L, r) {
  genShop(L, r, 0, 0, [[14, LOT, '-z']]);
  L.extra.pylon = { x: L.cx + 24, z: L.cz - 3, h: 14 };
}

function genPkg(L, r) {
  addBuilding(L, L.cx - 20, L.cz - 20, L.cx + 20, L.cz + 20, { type: 'garage', h: 5 * FLOOR });
}

const GEN = { apt: genApt, shop: genShop, down: genDown, plaza: genPlaza, ind: genInd, con: genCon, gas: genGas, pkg: genPkg, park: () => {}, metro: () => {} };

export function ballistic(from, to, rise) {
  const apex = Math.max(from.y, to.y) + rise;
  const vy = Math.sqrt(2 * GRAVITY * (apex - from.y));
  const t1 = vy / GRAVITY;
  const t2 = Math.sqrt((2 * (apex - to.y)) / GRAVITY);
  const T = t1 + t2;
  return { vx: (to.x - from.x) / T, vy, vz: (to.z - from.z) / T, T };
}

function roofSpots(L) {
  const out = [];
  for (const b of L.buildings) {
    if (b.type === 'frame') continue;
    b.tiers.forEach((t, k) => {
      const next = b.tiers[k + 1];
      let x, z, w;
      if (!next) { x = (t.x0 + t.x1) / 2; z = (t.z0 + t.z1) / 2; w = Math.min(t.x1 - t.x0, t.z1 - t.z0); }
      else {
        const band = next.x0 - t.x0;
        if (band < 4) return;
        x = t.x0 + band / 2; z = (t.z0 + t.z1) / 2; w = band;
      }
      const half = (t.z1 - t.z0) / 2 - 2;
      out.push({ x, z, y: t.y1, w, b, k, rect: t, pad: { x, z: z - Math.min(5, half) }, land: { x, z: z + Math.min(4, half) } });
    });
  }
  return out;
}

function clampInto(rect, x, z, m = 3) {
  return { x: Math.min(Math.max(x, rect.x0 + m), rect.x1 - m), z: Math.min(Math.max(z, rect.z0 + m), rect.z1 - m) };
}

const WEAPON_SPOTS = { smg: [1, 2], rifle: [2, 1], shotgun: [3, 5] };

function computePads(L, r) {
  const roofs = roofSpots(L);
  L.roofs = roofs;
  const toCenter = (x, z) => { const d = Math.hypot(x, z) || 1; return { x: -x / d, z: -z / d }; };
  let pid = 0;
  const addPad = (p) => { p.id = `${L.i}_${L.j}_${pid++}`; L.pads.push(p); return p; };
  const nearestRoof = (from, minRise, maxRise, maxDist, exclude) => {
    let best = null, bd = 1e9;
    for (const s of roofs) {
      if (exclude && s.rect === exclude.rect) continue;
      const rise = s.y - from.y;
      if (rise < minRise || rise > maxRise) continue;
      const d = Math.hypot(s.land.x - from.x, s.land.z - from.z);
      if (d < bd && d < maxDist && d > 3) { bd = d; best = s; }
    }
    return best;
  };
  const launch = (from, kind, hv, vy) => {
    const dir = toCenter(from.x, from.z);
    return addPad({ x: from.x, y: from.y, z: from.z, kind, vx: dir.x * hv, vy, vz: dir.z * hv, locked: false });
  };
  const targeted = (from, kind, rise, s) => {
    const to = { x: s.land.x, y: s.y, z: s.land.z };
    let v = ballistic(from, to, rise);
    for (let k = 0; k < 6 && (Math.hypot(v.vx, v.vz) > 18 || v.vy > 32); k++) {
      if (v.vy > 32) return null;
      rise += 3; v = ballistic(from, to, rise);
    }
    if (Math.hypot(v.vx, v.vz) > 18 || v.vy > 32) return null;
    const pad = addPad({ x: from.x, y: from.y, z: from.z, kind, vx: v.vx, vy: v.vy, vz: v.vz, locked: false, target: to });
    L.landings.push(to);
    return pad;
  };

  if (L.district === 'park' || L.district === 'metro') {
    launch({ x: L.cx + 8, y: 0, z: L.cz + 14 }, 'launch', 12, 20);
    return;
  }
  // street pad at one corner of the block
  const sx = r.chance(0.5) ? 1 : -1, sz = r.chance(0.5) ? 1 : -1;
  let spot = { x: L.cx + sx * SW, y: 0, z: L.cz + sz * SW };
  if (L.i === 3 && L.j === 3) spot = { x: L.cx - SW, y: 0, z: L.cz - SW + 3.5 }; // near spawn
  const first = nearestRoof(spot, 2.5, 16, 70, null);
  if (!(first && targeted(spot, 'street', 4.5, first))) launch(spot, 'street', 11, 20);

  // chain of rooftop pads
  const cand = roofs.filter((s) => s.y >= 6 && s.w >= 4).sort((a, b) => a.y - b.y);
  let count = 0;
  for (const s of cand) {
    if (count >= 5) break;
    const from = { x: s.pad.x, y: s.y, z: s.pad.z };
    const t = nearestRoof(from, 2.5, 16, 45, s);
    if (t) { targeted(from, 'roof', 4.5, t); count++; }
  }
  // highest reachable roof: glide launch
  const glideRoofs = cand.filter((s) => s.y <= 75);
  const top = glideRoofs[glideRoofs.length - 1];
  if (top) { launch({ x: top.pad.x, y: top.y, z: top.pad.z }, 'launch', 15, 21); }
  // tower launch pads (glide spots) on very tall last tiers
  for (const s of roofs) {
    if (s.y > 75 && s.k === s.b.tiers.length - 1) {
      const a = r.range(0, Math.PI * 2);
      addPad({ x: s.pad.x, y: s.y, z: s.pad.z, kind: 'tower', vx: Math.cos(a) * 16, vy: 14, vz: Math.sin(a) * 16, locked: false });
    }
  }
  // hidden (locked) boost pad unlocked by a switch – shop roofs only
  if (L.district === 'shop') {
    const s = roofs.filter((q) => q.y >= 8 && q.y <= 24 && q.w >= 8)[0];
    if (s) {
      const pad = launch({ x: s.x - 5, y: s.y, z: s.z - 1 }, 'hidden', 17, 29);
      pad.locked = true;
      L.buttons.push({ id: pad.id, x: s.x + 5, y: s.y, z: s.z - 1, label: 'BOOST PAD' });
    }
  }
}

function computePickups(L, r) {
  const types = ['health', 'health', 'ammo', 'ammo', 'shield', 'boost'];
  const n = L.district === 'park' ? 2 : 3;
  for (let k = 0; k < n; k++) {
    const side = k % 4;
    const u = r.range(-18, 18);
    const x = side === 0 ? L.cx + SW : side === 1 ? L.cx - SW : L.cx + u;
    const z = side === 2 ? L.cz + SW : side === 3 ? L.cz - SW : L.cz + u;
    L.pickups.push({ type: r.pick(types), x, y: 0.9, z });
  }
  for (const [id, [i, j]] of Object.entries(WEAPON_SPOTS)) {
    if (L.i === i && L.j === j) {
      const t = L.landings[0];
      if (t) L.pickups.push({ type: 'weapon', id, x: t.x, y: t.y + 0.9, z: t.z });
      else L.pickups.push({ type: 'weapon', id, x: L.cx + 2, y: 0.9, z: L.cz + 2 });
    }
  }
  if (L.landings[0] && L.district !== 'down') L.pickups.push({ type: r.pick(['ammo', 'health']), x: L.landings[0].x + 2.2, y: L.landings[0].y + 0.9, z: L.landings[0].z + 1.5 });
  if (L.i === 1 && L.j === 1) L.pickups.push({ type: 'weapon', id: 'marksman', x: L.crane.x, y: L.crane.h + 0.9, z: L.crane.z });
  if (L.i === 3 && L.j === 3) L.pickups.push({ type: 'weapon', id: 'revolver', x: -36, y: 0.9, z: -33 });
}

export function getLayout(i, j) {
  const key = i * 16 + j;
  if (cache.has(key)) return cache.get(key);
  if (!inGrid(i, j)) return null;
  const district = DMAP[j][i];
  const r = rng(i * 977 + j * 131 + 7);
  const L = {
    i, j, cx: cx(i), cz: cx(j), district, buildings: [], pads: [], pickups: [], buttons: [], landings: [],
    extra: {}, crane: null, hole: null, roofs: [],
  };
  GEN[district](L, r);
  if (district === 'metro') L.hole = { x0: L.cx - 26, x1: L.cx + 26, z0: L.cz - 6, z1: L.cz + 6, y: -7 };
  computePads(L, r);
  computePickups(L, r);
  cache.set(key, L);
  return L;
}

export function allLayouts() {
  const out = [];
  for (let j = 0; j < GRID; j++) for (let i = 0; i < GRID; i++) out.push(getLayout(i, j));
  return out;
}

export { P };

// ---- the one bank: the widest street-front shop nearest the spawn point
let _bank = null;
export function findBank() {
  if (_bank) return _bank;
  const ls = allLayouts().filter(Boolean).sort((a, b) => Math.hypot(a.cx - SPAWN.x, a.cz - SPAWN.z) - Math.hypot(b.cx - SPAWN.x, b.cz - SPAWN.z));
  for (const L of ls) {
    let best = null;
    for (const b of L.buildings) if (b.type === 'shop' && b.front && (!best || (b.tiers[0].x1 - b.tiers[0].x0) > (best.tiers[0].x1 - best.tiers[0].x0))) best = b;
    if (best && best.tiers[0].x1 - best.tiers[0].x0 >= 11) {
      const t = best.tiers[0], s = best.front === '+z' ? 1 : -1, frontZ = s > 0 ? t.z1 : t.z0, mid = (t.x0 + t.x1) / 2;
      const zAt = (u) => frontZ - s * (0.1 + u);
      _bank = { i: L.i, j: L.j, b: best, s, mid, frontZ, zAt, teller: { x: mid, z: zAt(5.2) }, door: { x: mid, z: frontZ + s * 2.5 }, top: best.top };
      return _bank;
    }
  }
  _bank = { none: true };
  return _bank;
}
