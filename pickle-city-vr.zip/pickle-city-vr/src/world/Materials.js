// Shared PBR materials with procedurally generated (canvas) textures. Everything is created once and shared.
import * as THREE from 'three';
import { rng } from '../core/Utils.js';

function canvas(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return [c, c.getContext('2d')]; }
function tex(c, rx = 1, ry = 1, srgb = true, aniso = 8) {
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(rx, ry);
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = aniso;
  return t;
}
function noise(ctx, w, h, amt, seed = 1) {
  const r = rng(seed);
  const id = ctx.getImageData(0, 0, w, h), d = id.data;
  for (let i = 0; i < d.length; i += 4) { const n = (r() - 0.5) * amt; d[i] += n; d[i + 1] += n; d[i + 2] += n; }
  ctx.putImageData(id, 0, 0);
}

function facadeTexture(kind) {
  const S = 512, k = 2;
  const [c, g] = canvas(S, S);
  const r = rng(kind.length * 31 + 5);
  const bases = { apt: [181, 154, 134], shop: [165, 139, 120], ind: [141, 141, 134], glass: [39, 65, 79], conc: [154, 154, 150] };
  const bc = bases[kind];
  g.fillStyle = `rgb(${bc[0]},${bc[1]},${bc[2]})`; g.fillRect(0, 0, S, S);
  if (kind === 'apt' || kind === 'shop') {
    // individual bricks with colour variance, mortar joints and the odd dark/burnt brick
    const bh = 8 * k * 0.5 * 2, bw = 16 * k;
    g.fillStyle = 'rgba(205,195,180,0.9)'; g.fillRect(0, 0, S, S);
    for (let y = 0, row = 0; y < S; y += bh, row++) for (let x = row % 2 ? -bw / 2 : 0; x < S; x += bw) {
      const v = (r() - 0.5) * 34, burnt = r() < 0.05 ? -30 : 0;
      g.fillStyle = `rgb(${bc[0] + v + burnt - 6},${bc[1] + v * 0.8 + burnt - 8},${bc[2] + v * 0.7 + burnt - 8})`;
      g.fillRect(x + 1, y + 1, bw - 2, bh - 2);
    }
  } else if (kind === 'ind') {
    for (let x = 0; x < S; x += 24) { g.fillStyle = (x / 24) % 2 ? 'rgba(0,0,0,.10)' : 'rgba(255,255,255,.05)'; g.fillRect(x, 0, 24, S); g.fillStyle = 'rgba(0,0,0,.35)'; g.fillRect(x, 0, 2, S); }
    for (let n = 0; n < 40; n++) { g.fillStyle = 'rgba(90,60,30,0.10)'; g.fillRect(r() * S, r() * S, 2 + r() * 4, 20 + r() * 80); }  // rust runs
  }
  noise(g, S, S, kind === 'glass' ? 6 : 30, 3);
  if (kind === 'glass') {
    const gr = g.createLinearGradient(0, 0, 0, S); gr.addColorStop(0, '#7aa6c0'); gr.addColorStop(0.45, '#3c5f73'); gr.addColorStop(1, '#1f3340');
    g.fillStyle = gr; g.fillRect(0, 0, S, S);
    for (let q = 0; q < 4; q++) { g.fillStyle = 'rgba(255,255,255,.07)'; g.save(); g.translate(r() * S, 0); g.rotate(0.35); g.fillRect(0, -S * 0.2, 14 + r() * 40, S * 1.4); g.restore(); }
    g.fillStyle = '#141f26'; g.fillRect(0, 0, S, 26); g.fillRect(0, 0, 14, S); g.fillRect(S / 2 - 3, 0, 6, S);
    g.fillStyle = 'rgba(255,255,255,.18)'; g.fillRect(0, 26, S, 3);
    if (r() < 0.4) { g.fillStyle = 'rgba(255,226,150,.38)'; g.fillRect(18, 34, S / 2 - 24, S - 48); g.fillStyle = 'rgba(30,40,50,.5)'; g.fillRect(40, S - 120, 120, 90); }
    return c;
  }
  if (kind === 'conc') {
    g.strokeStyle = 'rgba(0,0,0,.2)'; g.lineWidth = 2; g.strokeRect(1, 1, S - 2, S - 2);
    g.fillStyle = 'rgba(0,0,0,.22)'; g.fillRect(0, 236, S, 10);
    for (let n = 0; n < 24; n++) { g.fillStyle = 'rgba(0,0,0,.07)'; g.fillRect(r() * S, 0, 3 + r() * 6, S); }
    return c;
  }
  // storey slab line, cornice shadow and a plinth-style band
  g.fillStyle = 'rgba(235,228,215,.75)'; g.fillRect(0, S - 22, S, 12); g.fillStyle = 'rgba(0,0,0,.28)'; g.fillRect(0, S - 10, S, 10);
  g.fillStyle = 'rgba(0,0,0,.14)'; g.fillRect(0, 0, S, 8);
  // window: stone surround, sill, lintel, glazing bars, depth shadow, interior glow / curtains / blinds
  const wx = 104, wy = 92, ww = 304, wh = 290;
  g.fillStyle = '#d8d0bf'; g.fillRect(wx - 14, wy - 22, ww + 28, 16);              // lintel
  g.fillStyle = '#cfc7b6'; g.fillRect(wx - 10, wy - 6, ww + 20, wh + 12);           // surround
  g.fillStyle = '#e4ddcd'; g.fillRect(wx - 22, wy + wh + 6, ww + 44, 14);           // sill
  g.fillStyle = 'rgba(0,0,0,.35)'; g.fillRect(wx - 22, wy + wh + 20, ww + 44, 8);
  const lit = r() < 0.32, blind = !lit && r() < 0.35;
  if (lit) {
    const gr = g.createLinearGradient(0, wy, 0, wy + wh); gr.addColorStop(0, '#ffe3a0'); gr.addColorStop(1, '#ffc260'); g.fillStyle = gr; g.fillRect(wx, wy, ww, wh);
    g.fillStyle = 'rgba(120,70,40,.55)'; g.fillRect(wx, wy, 34, wh); g.fillRect(wx + ww - 34, wy, 34, wh);   // curtains
    g.fillStyle = 'rgba(70,45,30,.6)'; g.fillRect(wx + 90, wy + wh - 90, 90, 90); g.fillRect(wx + 190, wy + wh - 60, 50, 60);  // furniture silhouettes
  } else {
    const gr = g.createLinearGradient(wx, wy, wx + ww, wy + wh); gr.addColorStop(0, '#7b9db3'); gr.addColorStop(0.5, '#34506a'); gr.addColorStop(1, '#1a2836');
    g.fillStyle = gr; g.fillRect(wx, wy, ww, wh);
    g.fillStyle = 'rgba(255,255,255,.1)'; g.beginPath(); g.moveTo(wx, wy); g.lineTo(wx + 120, wy); g.lineTo(wx, wy + 160); g.fill();      // sky reflection
    if (blind) { g.fillStyle = 'rgba(200,190,170,.85)'; g.fillRect(wx, wy, ww, wh * (0.3 + r() * 0.4)); for (let y = wy; y < wy + wh * 0.6; y += 9) { g.fillStyle = 'rgba(0,0,0,.12)'; g.fillRect(wx, y, ww, 1); } }
  }
  g.fillStyle = '#e8e2d4'; g.fillRect(wx + ww / 2 - 5, wy, 10, wh); g.fillRect(wx, wy + wh * 0.42, ww, 10);        // glazing bars
  g.fillStyle = 'rgba(0,0,0,.35)'; g.fillRect(wx, wy, ww, 9); g.fillRect(wx, wy, 8, wh);                            // reveal shadow
  if (r() < 0.12) { g.fillStyle = '#9aa0a4'; g.fillRect(wx + 30, wy + wh - 80, ww - 60, 80); g.fillStyle = '#6a7074'; g.fillRect(wx + 30, wy + wh - 80, ww - 60, 8); for (let x = wx + 44; x < wx + ww - 44; x += 12) { g.fillStyle = '#50565a'; g.fillRect(x, wy + wh - 62, 6, 50); } }  // window AC unit
  // weathering streaks under the sill
  for (let n = 0; n < 5; n++) { g.fillStyle = 'rgba(40,30,20,.08)'; g.fillRect(wx + r() * ww, wy + wh + 24, 3 + r() * 5, 60 + r() * 90); }
  return c;
}

function grayOf(c) {
  try { const [o, g] = canvas(c.width, c.height); g.filter = 'grayscale(1) contrast(1.6)'; g.drawImage(c, 0, 0); return o; } catch (e) { return c; }
}

// interior floor / wall surface textures
function tileTexture() {
  const S = 256; const [c, g] = canvas(S, S);
  g.fillStyle = '#e8e4da'; g.fillRect(0, 0, S, S);
  g.fillStyle = '#b4aea2'; g.fillRect(0, 0, S / 2, S / 2); g.fillRect(S / 2, S / 2, S / 2, S / 2);
  noise(g, S, S, 16, 21);
  g.strokeStyle = 'rgba(60,55,50,.55)'; g.lineWidth = 3; for (let i = 0; i <= 2; i++) { g.beginPath(); g.moveTo(i * S / 2, 0); g.lineTo(i * S / 2, S); g.moveTo(0, i * S / 2); g.lineTo(S, i * S / 2); g.stroke(); }
  return c;
}
function marbleTexture() {
  const S = 256; const [c, g] = canvas(S, S); const r = rng(44);
  g.fillStyle = '#ebe7e0'; g.fillRect(0, 0, S, S);
  noise(g, S, S, 12, 22);
  for (let n = 0; n < 14; n++) { g.strokeStyle = `rgba(110,105,100,${0.12 + r() * 0.15})`; g.lineWidth = 1 + r() * 2; g.beginPath(); let x = r() * S, y = 0; g.moveTo(x, y); while (y < S) { x += (r() - 0.5) * 40; y += 20 + r() * 20; g.lineTo(x, y); } g.stroke(); }
  g.strokeStyle = 'rgba(70,65,60,.5)'; g.lineWidth = 2; g.strokeRect(0, 0, S, S); g.beginPath(); g.moveTo(S / 2, 0); g.lineTo(S / 2, S); g.moveTo(0, S / 2); g.lineTo(S, S / 2); g.stroke();
  return c;
}
function plankTexture() {
  const S = 256; const [c, g] = canvas(S, S); const r = rng(46);
  for (let i = 0; i < 8; i++) { g.fillStyle = `hsl(${26 + r() * 8},${36 + r() * 10}%,${38 + r() * 12}%)`; g.fillRect(0, i * 32, S, 31); for (let n = 0; n < 14; n++) { g.fillStyle = 'rgba(50,25,8,.10)'; g.fillRect(r() * S, i * 32 + r() * 30, 30 + r() * 80, 1); } g.fillStyle = 'rgba(20,10,0,.55)'; g.fillRect(0, i * 32 + 31, S, 1); g.fillRect(r() * S, i * 32, 1, 31); }
  return c;
}
function carpetTexture() {
  const S = 128; const [c, g] = canvas(S, S); g.fillStyle = '#8a8d94'; g.fillRect(0, 0, S, S); noise(g, S, S, 40, 23); return c;
}

function roadTexture() {
  const S = 1024, k = S / 80;
  const [c, g] = canvas(S, S);
  g.fillStyle = '#34363a'; g.fillRect(0, 0, S, S);
  noise(g, S, S, 22, 8);
  // pavement block in the middle (|x|,|z| < 30)
  g.fillStyle = '#8f8d88'; g.fillRect(10 * k, 10 * k, 60 * k, 60 * k);
  g.strokeStyle = 'rgba(0,0,0,.12)'; g.lineWidth = 1;
  for (let i = 10; i <= 70; i += 3) { g.beginPath(); g.moveTo(i * k, 10 * k); g.lineTo(i * k, 70 * k); g.stroke(); g.beginPath(); g.moveTo(10 * k, i * k); g.lineTo(70 * k, i * k); g.stroke(); }
  noise(g, S, S, 10, 9);
  // curb line
  g.strokeStyle = '#b8b5ad'; g.lineWidth = 3; g.strokeRect(10 * k, 10 * k, 60 * k, 60 * k);
  // worn wheel paths, asphalt patches and cracks
  { const rr = rng(31);
    g.fillStyle = 'rgba(0,0,0,0.16)';
    for (const s of [0, 80]) for (const sg of [-1, 1]) for (const off of [-0.95, 0.95]) {
      const c = (s + sg * 3.2 + off) * k;
      g.fillRect(c - 0.28 * k, 0, 0.56 * k, 10 * k); g.fillRect(c - 0.28 * k, 70 * k, 0.56 * k, 10 * k); g.fillRect(0, c - 0.28 * k, 10 * k, 0.56 * k); g.fillRect(70 * k, c - 0.28 * k, 10 * k, 0.56 * k);
    }
    for (let n = 0; n < 26; n++) { const x = (rr() < 0.5 ? rr() * 10 : 70 + rr() * 10) * k, y = rr() * 80 * k; g.fillStyle = rr() < 0.5 ? 'rgba(20,20,22,0.35)' : 'rgba(110,112,116,0.22)'; g.fillRect(x, y, (0.8 + rr() * 2.2) * k, (0.8 + rr() * 2.6) * k); }
    for (let n = 0; n < 26; n++) { const y = (rr() < 0.5 ? rr() * 10 : 70 + rr() * 10) * k, x = rr() * 80 * k; g.fillStyle = rr() < 0.5 ? 'rgba(20,20,22,0.35)' : 'rgba(110,112,116,0.22)'; g.fillRect(x, y, (0.8 + rr() * 2.6) * k, (0.8 + rr() * 2.2) * k); }
    g.strokeStyle = 'rgba(0,0,0,0.4)'; g.lineWidth = 1.2;
    for (let n = 0; n < 60; n++) { let x = (rr() < 0.5 ? rr() * 10 : 70 + rr() * 10) * k, y = rr() * 80 * k; g.beginPath(); g.moveTo(x, y); for (let q = 0; q < 5; q++) { x += (rr() - 0.5) * 22; y += (rr() - 0.5) * 22; g.lineTo(x, y); } g.stroke(); }
    // pavement cracks and gum
    g.strokeStyle = 'rgba(0,0,0,0.25)'; g.lineWidth = 1;
    for (let n = 0; n < 50; n++) { let x = (12 + rr() * 56) * k, y = (12 + rr() * 56) * k; g.beginPath(); g.moveTo(x, y); for (let q = 0; q < 4; q++) { x += (rr() - 0.5) * 18; y += (rr() - 0.5) * 18; g.lineTo(x, y); } g.stroke(); }
    g.fillStyle = 'rgba(60,50,45,0.5)'; for (let n = 0; n < 160; n++) g.fillRect((12 + rr() * 56) * k, (12 + rr() * 56) * k, 2.2, 2.2);
  }
  // lane markings: street centres are on the texture edges
  g.strokeStyle = '#e8c840'; g.lineWidth = 0.35 * k * 2;
  for (const s of [0, 80]) { g.beginPath(); g.moveTo(s * k, 0); g.lineTo(s * k, 10 * k); g.moveTo(s * k, 70 * k); g.lineTo(s * k, 80 * k); g.stroke(); g.beginPath(); g.moveTo(0, s * k); g.lineTo(10 * k, s * k); g.moveTo(70 * k, s * k); g.lineTo(80 * k, s * k); g.stroke(); }
  g.strokeStyle = '#d8d8d8'; g.lineWidth = 0.15 * k;
  g.setLineDash([3 * k, 4 * k]);
  for (const s of [5, 75]) { g.beginPath(); g.moveTo(s * k, 0); g.lineTo(s * k, 10 * k); g.moveTo(s * k, 70 * k); g.lineTo(s * k, 80 * k); g.moveTo(0, s * k); g.lineTo(10 * k, s * k); g.moveTo(70 * k, s * k); g.lineTo(80 * k, s * k); g.stroke(); }
  g.setLineDash([]);
  // zebra crossings next to the intersections
  g.fillStyle = 'rgba(235,235,235,.85)';
  for (let t = 0; t < 8; t++) {
    const o = (1 + t * 1.2) * k;
    for (const edge of [6, 72.5]) {
      g.fillRect(o + 0 * k, edge * k, 0.7 * k, 2.5 * k); // arm along x (top/bottom)
      g.fillRect(o + 0 * k, (edge === 6 ? 71.5 : 6) * k, 0.01, 0.01);
    }
  }
  for (let t = 0; t < 8; t++) {
    const o = (1 + t * 1.2) * k;
    g.fillRect(6 * k, o, 2.5 * k, 0.7 * k); g.fillRect(72 * k, o, 2.5 * k, 0.7 * k);
    g.fillRect(o, 6 * k, 0.7 * k, 2.5 * k); g.fillRect(o, 72 * k, 0.7 * k, 2.5 * k);
  }
  // manholes & stains
  const r = rng(12);
  g.fillStyle = 'rgba(0,0,0,.18)';
  for (let n = 0; n < 40; n++) { g.beginPath(); g.ellipse(r() * S, r() * S, 6 + r() * 30, 3 + r() * 10, r() * 3, 0, 7); g.fill(); }
  return c;
}

function grassTexture() {
  const S = 512; const [c, g] = canvas(S, S);
  g.fillStyle = '#4c7a36'; g.fillRect(0, 0, S, S);
  const r = rng(77);
  for (let n = 0; n < 9000; n++) { g.fillStyle = `hsl(${85 + r() * 25},${40 + r() * 20}%,${22 + r() * 18}%)`; g.fillRect(r() * S, r() * S, 2, 3 + r() * 4); }
  // paths in the 80m tile
  const k = S / 80; g.strokeStyle = '#b6a98a'; g.lineWidth = 3.2 * k; g.lineCap = 'round';
  g.beginPath(); g.moveTo(10 * k, 40 * k); g.quadraticCurveTo(40 * k, 22 * k, 70 * k, 40 * k); g.moveTo(40 * k, 10 * k); g.quadraticCurveTo(52 * k, 40 * k, 40 * k, 70 * k); g.stroke();
  g.strokeStyle = '#34363a'; g.lineWidth = 20 * k; g.strokeRect(-5 * k, -5 * k, 90 * k, 90 * k);
  g.strokeStyle = '#8f8d88'; g.lineWidth = 5 * k; g.strokeRect(7 * k, 7 * k, 66 * k, 66 * k);
  return c;
}

function signAtlas() {
  const [c, g] = canvas(1024, 512);
  const names = [['PIZZA','#c0392b'],['CAFE','#6b4423'],['MARKET','#1e8449'],['BURGERS','#d35400'],['PHARMACY','#16a085'],['BOOKS','#7d3c98'],['NOODLES','#b9770e'],['BAKERY','#cb4335'],
    ['ELECTRONICS','#2471a3'],['DELI','#1f618d'],['GYM','#2c3e50'],['TACOS','#ba4a00'],['FLOWERS','#c2185b'],['ARCADE','#6c3483'],['SUSHI','#117a65'],['PICKLES!','#5e9a14']];
  names.forEach(([n, col], i) => {
    const x = (i % 4) * 256, y = Math.floor(i / 4) * 128;
    g.fillStyle = col; g.fillRect(x, y, 256, 128);
    g.strokeStyle = '#fff'; g.lineWidth = 5; g.strokeRect(x + 6, y + 6, 244, 116);
    g.fillStyle = '#fff'; g.font = 'bold 42px "Trebuchet MS",sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
    let s = 42; while (g.measureText(n).width > 215 && s > 14) { s -= 2; g.font = `bold ${s}px "Trebuchet MS",sans-serif`; }
    g.fillText(n, x + 128, y + 66);
  });
  return c;
}

function pickleSkin() {
  const [c, g] = canvas(512, 512);
  const gr = g.createLinearGradient(0, 0, 512, 0);
  gr.addColorStop(0, '#5b7d1f'); gr.addColorStop(0.5, '#7a9a2c'); gr.addColorStop(1, '#5b7d1f');
  g.fillStyle = gr; g.fillRect(0, 0, 512, 512);
  const r = rng(99);
  for (let n = 0; n < 700; n++) { g.fillStyle = `rgba(${30 + r() * 40},${60 + r() * 50},10,${0.15 + r() * 0.25})`; g.beginPath(); g.ellipse(r() * 512, r() * 512, 2 + r() * 7, 1.5 + r() * 4, r() * 3, 0, 7); g.fill(); }
  // lighter vertical streaks like a real gherkin
  for (let n = 0; n < 60; n++) { g.fillStyle = `rgba(190,210,90,${0.05 + r() * 0.08})`; g.fillRect(r() * 512, 0, 2 + r() * 10, 512); }
  // warty bumps
  for (let n = 0; n < 380; n++) { const x = r() * 512, y = r() * 512, rr = 2 + r() * 3; g.fillStyle = 'rgba(210,225,120,.55)'; g.beginPath(); g.arc(x, y, rr, 0, 7); g.fill(); g.fillStyle = 'rgba(25,45,5,.5)'; g.beginPath(); g.arc(x + 1, y + 1.5, rr * 0.7, 0, 7); g.fill(); }
  return c;
}
function pickleBump() {
  const [c, g] = canvas(256, 256);
  g.fillStyle = '#808080'; g.fillRect(0, 0, 256, 256);
  const r = rng(5);
  for (let n = 0; n < 260; n++) { const x = r() * 256, y = r() * 256, rr = 2 + r() * 4; const gr = g.createRadialGradient(x, y, 0, x, y, rr); gr.addColorStop(0, '#fff'); gr.addColorStop(1, '#808080'); g.fillStyle = gr; g.beginPath(); g.arc(x, y, rr, 0, 7); g.fill(); }
  noise(g, 256, 256, 30, 4);
  return c;
}

export function createMaterials(maxAniso = 8) {
  const std = (o) => new THREE.MeshStandardMaterial(o);
  const M = {};
  const mk = (kind, rough, metal, rep = 1) => { const fc = facadeTexture(kind); return std({ map: tex(fc, 1, 1, true, maxAniso), bumpMap: tex(grayOf(fc), 1, 1, false, maxAniso), bumpScale: kind === 'glass' ? 0.3 : 1.4, roughness: rough, metalness: metal, vertexColors: true }); };
  M.apt = mk('apt', 0.85, 0.0);
  M.shop = mk('shop', 0.8, 0.0);
  M.ind = mk('ind', 0.7, 0.35);
  M.conc = mk('conc', 0.95, 0.0);
  M.glass = mk('glass', 0.12, 0.85);
  M.glass.envMapIntensity = 1.4;
  const rt = tex(roadTexture(), 1, 1, true, maxAniso);
  rt.wrapS = rt.wrapT = THREE.ClampToEdgeWrapping;
  M.road = std({ map: rt, roughness: 0.92, metalness: 0 });
  const gt = tex(grassTexture(), 1, 1, true, maxAniso); gt.wrapS = gt.wrapT = THREE.ClampToEdgeWrapping;
  M.grass = std({ map: gt, roughness: 1, metalness: 0 });
  M.tile = std({ map: tex(tileTexture(), 1, 1, true, maxAniso), roughness: 0.28, metalness: 0.05, vertexColors: true });
  M.marble = std({ map: tex(marbleTexture(), 1, 1, true, maxAniso), roughness: 0.18, metalness: 0.05, vertexColors: true });
  M.wood = std({ map: tex(plankTexture(), 1, 1, true, maxAniso), roughness: 0.5, metalness: 0.0, vertexColors: true });
  M.carpet = std({ map: tex(carpetTexture(), 1, 1, true, maxAniso), roughness: 1, metalness: 0.0, vertexColors: true });
  const plain = (rough, metal) => std({ roughness: rough, metalness: metal, vertexColors: true });
  M.plain = plain(0.85, 0.0);
  M.metal = plain(0.45, 0.8);
  M.roof = std({ map: tex(roofTex(), 1, 1, true, maxAniso), roughness: 0.95, vertexColors: true });
  M.emissive = new THREE.MeshBasicMaterial({ vertexColors: true });
  M.foliage = std({ roughness: 0.9, flatShading: true, vertexColors: true });
  M.signs = new THREE.MeshBasicMaterial({ map: tex(signAtlas(), 1, 1, true, maxAniso) });
  M.windowGlass = std({ color: 0x9fc4d8, roughness: 0.05, metalness: 0.9, transparent: true, opacity: 0.35, envMapIntensity: 1.5 });
  M.water = std({ color: 0x2f6f8f, roughness: 0.05, metalness: 0.6, transparent: true, opacity: 0.85 });
  M.pickle = std({ map: tex(pickleSkin(), 1, 1, true, maxAniso), bumpMap: tex(pickleBump(), 2, 3, false, maxAniso), bumpScale: 1.6, roughness: 0.38, metalness: 0.0, clearcoat: 0 });
  M.pickleWet = new THREE.MeshPhysicalMaterial({ map: M.pickle.map, bumpMap: M.pickle.bumpMap, bumpScale: 1.8, roughness: 0.42, metalness: 0, clearcoat: 0.7, clearcoatRoughness: 0.25 });
  M.flat = (color, rough = 0.6, metal = 0.1) => std({ color, roughness: rough, metalness: metal, flatShading: true });
  return M;
}

function roofTex() {
  const [c, g] = canvas(128, 128);
  g.fillStyle = '#4a4a4c'; g.fillRect(0, 0, 128, 128); noise(g, 128, 128, 30, 2);
  g.strokeStyle = 'rgba(255,255,255,.07)'; g.strokeRect(0, 0, 128, 128);
  return c;
}
