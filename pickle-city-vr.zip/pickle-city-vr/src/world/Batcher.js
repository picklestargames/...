// Geometry batcher: accumulates boxes/cylinders/cones into one BufferGeometry per material key.
// UVs are world-scaled (box projected) so shared tiling textures line up across boxes. Vertex colours tint.
import * as THREE from 'three';

class Group {
  constructor() { this.pos = []; this.nor = []; this.uv = []; this.col = []; this.idx = []; this.n = 0; }
}

export class Batcher {
  constructor() { this.groups = new Map(); this.col = []; this.ladders = []; this.minY = 0; }
  g(key) { let g = this.groups.get(key); if (!g) this.groups.set(key, (g = new Group())); return g; }

  quad(key, a, b, c, d, nx, ny, nz, uvs, color, flip = false) {
    const g = this.g(key), i = g.n;
    for (const p of [a, b, c, d]) { g.pos.push(p[0], p[1], p[2]); g.nor.push(nx, ny, nz); g.col.push(color[0], color[1], color[2]); }
    for (const u of uvs) g.uv.push(u[0], u[1]);
    // default winding is CCW seen from above (floors/tops). flip=true reverses it for vertical faces whose vertex order is bottom-left,bottom-right,top-right,top-left seen from inside.
    if (flip) g.idx.push(i, i + 2, i + 1, i, i + 3, i + 2); else g.idx.push(i, i + 1, i + 2, i, i + 2, i + 3);
    g.n += 4;
  }

  /**
   * Axis aligned box.  o: {side,top,bottom,color,tile,floor,solid,noSide:[..]}
   * tile = metres per texture repeat horizontally; floor = metres per repeat vertically.
   */
  box(x0, y0, z0, x1, y1, z1, o = {}) {
    if (x1 <= x0 || y1 <= y0 || z1 <= z0) return;
    const side = o.side || 'plain', top = o.top || side, col = o.color || [1, 1, 1];
    const tw = o.tile || 3.6, th = o.floor || 3.6, tt = o.ttile || 4;
    const uo = o.uoff || 0;
    const sk = o.skip || '';
    if (!sk.includes('z')) { // +z, -z faces
      this.quad(side, [x1, y0, z1], [x0, y0, z1], [x0, y1, z1], [x1, y1, z1], 0, 0, 1, [[x1 / tw + uo, y0 / th], [x0 / tw + uo, y0 / th], [x0 / tw + uo, y1 / th], [x1 / tw + uo, y1 / th]], col, true);
      this.quad(side, [x0, y0, z0], [x1, y0, z0], [x1, y1, z0], [x0, y1, z0], 0, 0, -1, [[x0 / tw + uo, y0 / th], [x1 / tw + uo, y0 / th], [x1 / tw + uo, y1 / th], [x0 / tw + uo, y1 / th]], col, true);
    }
    if (!sk.includes('x')) {
      this.quad(side, [x1, y0, z0], [x1, y0, z1], [x1, y1, z1], [x1, y1, z0], 1, 0, 0, [[z0 / tw + uo, y0 / th], [z1 / tw + uo, y0 / th], [z1 / tw + uo, y1 / th], [z0 / tw + uo, y1 / th]], col, true);
      this.quad(side, [x0, y0, z1], [x0, y0, z0], [x0, y1, z0], [x0, y1, z1], -1, 0, 0, [[z1 / tw + uo, y0 / th], [z0 / tw + uo, y0 / th], [z0 / tw + uo, y1 / th], [z1 / tw + uo, y1 / th]], col, true);
    }
    if (!sk.includes('t')) this.quad(top, [x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [x0, y1, z0], 0, 1, 0, [[x0 / tt, z1 / tt], [x1 / tt, z1 / tt], [x1 / tt, z0 / tt], [x0 / tt, z0 / tt]], col);
    if (o.bottom) this.quad(o.bottom, [x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1], 0, -1, 0, [[0, 0], [1, 0], [1, 1], [0, 1]], col);
    if (o.solid) this.col.push(x0, y0, z0, x1, y1, z1);
  }

  /** a box with explicit collision toggled */
  solidBox(x0, y0, z0, x1, y1, z1, o = {}) { this.box(x0, y0, z0, x1, y1, z1, { ...o, solid: true }); }
  /** collision only */
  collider(x0, y0, z0, x1, y1, z1) { this.col.push(x0, y0, z0, x1, y1, z1); }

  /** vertical or horizontal-x/z prism with n sides (approximate cylinder). axis: 'y'|'x'|'z' */
  cyl(key, cx, cy, cz, r, len, o = {}) {
    const n = o.n || 8, col = o.color || [1, 1, 1], axis = o.axis || 'y';
    const g = this.g(key);
    const P = (a, t) => {
      const u = Math.cos(a) * r, v = Math.sin(a) * r;
      if (axis === 'y') return [cx + u, cy + t, cz + v];
      if (axis === 'x') return [cx + t, cy + u, cz + v];
      return [cx + u, cy + v, cz + t];
    };
    for (let k = 0; k < n; k++) {
      const a0 = (k / n) * Math.PI * 2, a1 = ((k + 1) / n) * Math.PI * 2, am = (a0 + a1) / 2;
      const ux = Math.cos(am), uz = Math.sin(am);
      const nrm = axis === 'y' ? [ux, 0, uz] : axis === 'x' ? [0, ux, uz] : [ux, uz, 0];
      const A = P(a0, 0), B = P(a1, 0), C = P(a1, len), D = P(a0, len);
      this.quad(key, A, B, C, D, nrm[0], nrm[1], nrm[2], [[k / n * 4, 0], [(k + 1) / n * 4, 0], [(k + 1) / n * 4, len / 3.6], [k / n * 4, len / 3.6]], col, true);
    }
    if (o.cap !== false) {
      const base = g.n;
      const capN = axis === 'y' ? [0, 1, 0] : axis === 'x' ? [1, 0, 0] : [0, 0, 1];
      const c0 = axis === 'y' ? [cx, cy + len, cz] : axis === 'x' ? [cx + len, cy, cz] : [cx, cy, cz + len];
      g.pos.push(...c0); g.nor.push(...capN); g.uv.push(0.5, 0.5); g.col.push(...col);
      for (let k = 0; k <= n; k++) { const a = (k / n) * Math.PI * 2; const p = P(a, len); g.pos.push(...p); g.nor.push(...capN); g.uv.push(0.5 + Math.cos(a) * 0.5, 0.5 + Math.sin(a) * 0.5); g.col.push(...col); }
      for (let k = 0; k < n; k++) { if (axis === 'y') g.idx.push(base, base + 2 + k, base + 1 + k); else g.idx.push(base, base + 1 + k, base + 2 + k); }
      g.n += n + 2;
    }
    if (o.solid) {
      if (axis === 'y') this.col.push(cx - r, cy, cz - r, cx + r, cy + len, cz + r);
      else if (axis === 'x') this.col.push(cx, cy - r, cz - r, cx + len, cy + r, cz + r);
      else this.col.push(cx - r, cy - r, cz, cx + r, cy + r, cz + len);
    }
  }

  /** cone / pyramid frustum, vertical */
  cone(key, cx, cy, cz, r0, r1, h, o = {}) {
    const n = o.n || 7, col = o.color || [1, 1, 1];
    for (let k = 0; k < n; k++) {
      const a0 = (k / n) * Math.PI * 2, a1 = ((k + 1) / n) * Math.PI * 2, am = (a0 + a1) / 2;
      const A = [cx + Math.cos(a0) * r0, cy, cz + Math.sin(a0) * r0], B = [cx + Math.cos(a1) * r0, cy, cz + Math.sin(a1) * r0];
      const C = [cx + Math.cos(a1) * r1, cy + h, cz + Math.sin(a1) * r1], D = [cx + Math.cos(a0) * r1, cy + h, cz + Math.sin(a0) * r1];
      const sl = (r0 - r1) / h, l = Math.hypot(1, sl);
      this.quad(key, A, B, C, D, Math.cos(am) / l, sl / l, Math.sin(am) / l, [[0, 0], [1, 0], [1, 1], [0, 1]], col, true);
    }
  }

  /** icosphere-ish blob for foliage (low-poly octahedron subdivided once) */
  blob(key, cx, cy, cz, r, o = {}) {
    const col = o.color || [1, 1, 1];
    const g = this.g(key);
    const v = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];
    const f = [[0, 2, 4], [4, 2, 1], [1, 2, 5], [5, 2, 0], [4, 3, 0], [1, 3, 4], [5, 3, 1], [0, 3, 5]];
    const sy = o.sy || 1;
    for (const t of f) {
      const pts = t.map((i) => [cx + v[i][0] * r, cy + v[i][1] * r * sy, cz + v[i][2] * r]);
      const ux = pts[1][0] - pts[0][0], uy = pts[1][1] - pts[0][1], uz = pts[1][2] - pts[0][2];
      const wx = pts[2][0] - pts[0][0], wy = pts[2][1] - pts[0][1], wz = pts[2][2] - pts[0][2];
      let nx = uy * wz - uz * wy, ny = uz * wx - ux * wz, nz = ux * wy - uy * wx; const l = Math.hypot(nx, ny, nz) || 1; nx /= l; ny /= l; nz /= l;
      const i0 = g.n;
      for (const p of pts) { g.pos.push(...p); g.nor.push(nx, ny, nz); g.uv.push(0, 0); g.col.push(...col); }
      g.idx.push(i0, i0 + 1, i0 + 2); g.n += 3;
    }
  }

  ladder(x, z, fx, fz, y0, y1, o = {}) {
    // visual: two rails + rungs hugging the wall; climb volume stored for the collision world
    const w = 0.55, rail = 0.04;
    const lx = -fz, lz = fx; // lateral axis
    const col = o.color || [0.5, 0.5, 0.52];
    const px = (a, b) => [x + lx * a + fx * b, z + lz * a + fz * b];
    for (const s of [-1, 1]) {
      const [rx, rz] = px(s * w / 2, 0.06);
      this.box(rx - rail, y0, rz - rail, rx + rail, y1 + 1.0, rz + rail, { side: 'metal', color: col });
    }
    for (let y = y0 + 0.3; y < y1 + 0.9; y += 0.32) {
      const [ax, az] = px(-w / 2, 0.06), [bx, bz] = px(w / 2, 0.06);
      this.box(Math.min(ax, bx) - 0.02, y, Math.min(az, bz) - 0.02, Math.max(ax, bx) + 0.02, y + 0.035, Math.max(az, bz) + 0.02, { side: 'metal', color: col });
    }
    this.ladders.push({ x, z, fx, fz, y0, y1 });
  }

  build(materials, opts = {}) {
    const root = new THREE.Group();
    const meshes = [];
    for (const [key, g] of this.groups) {
      if (!g.n) continue;
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.Float32BufferAttribute(g.pos, 3));
      geo.setAttribute('normal', new THREE.Float32BufferAttribute(g.nor, 3));
      geo.setAttribute('uv', new THREE.Float32BufferAttribute(g.uv, 2));
      geo.setAttribute('color', new THREE.Float32BufferAttribute(g.col, 3));
      geo.setIndex(g.n > 65000 ? new THREE.Uint32BufferAttribute(g.idx, 1) : new THREE.Uint16BufferAttribute(g.idx, 1));
      geo.computeBoundingSphere(); geo.computeBoundingBox();
      const m = materials[key];
      if (!m) { console.warn('missing material', key); continue; }
      const mesh = new THREE.Mesh(geo, m);
      mesh.castShadow = !!opts.shadows && key !== 'emissive' && key !== 'signs' && key !== 'windowGlass';
      mesh.receiveShadow = true;
      mesh.matrixAutoUpdate = false;
      if (key === 'windowGlass') mesh.renderOrder = 2;
      root.add(mesh); meshes.push(mesh);
    }
    return root;
  }
}

export const tint = (hex, k = 1) => [((hex >> 16) & 255) / 255 * k, ((hex >> 8) & 255) / 255 * k, (hex & 255) / 255 * k];
