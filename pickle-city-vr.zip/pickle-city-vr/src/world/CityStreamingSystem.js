// Streams city chunks around the player: full detail (LOD0, with collision/props) nearby,
// shell-only (LOD1) farther out, and unloads chunks beyond the far radius. Builds are spread over frames.
import { GRID, P, toI, inGrid, chunkKey, cx as blockCx } from './Constants.js';
import { buildChunk } from './ChunkBuilder.js';

const HI_R = 1;     // chunk radius at full detail (3x3 = 240m wide)
const LO_R = 4;     // chunk radius of low-detail shells
const KEEP_R = 5;   // unload beyond this

export class CityStreamingSystem {
  constructor(game, world) {
    this.game = game; this.world = world;
    this.hi = new Map(); this.lo = new Map();
    this.queue = [];
    this.group = world.scene;
    this.stats = { hi: 0, lo: 0, tris: 0 };
    this._pending = new Set();
  }

  disposeRoot(root) {
    this.group.remove(root);
    root.traverse((o) => { if (o.geometry) o.geometry.dispose(); });
  }

  buildHi(i, j) {
    const k = chunkKey(i, j);
    if (this.hi.has(k) || !inGrid(i, j)) return;
    const shadows = this.game.perf ? this.game.perf.shadowsOn : true;
    const c = buildChunk(i, j, this.world.mats, 0, shadows);
    this.group.add(c.root);
    this.world.collision.addChunk(i, j, c.col, c.ladders, c.hole);
    this.hi.set(k, c);
    const lo = this.lo.get(k); if (lo) lo.root.visible = false;
    const g = this.game;
    g.interactables && g.interactables.addChunk(c);
    g.jumpPads && g.jumpPads.addChunk(c);
    g.pickups && g.pickups.addChunk(c);
    g.npcs && g.npcs.onChunkLoaded && g.npcs.onChunkLoaded(c);
  }
  buildLo(i, j) {
    const k = chunkKey(i, j);
    if (this.lo.has(k) || !inGrid(i, j)) return;
    const c = buildChunk(i, j, this.world.mats, 1, false);
    this.group.add(c.root);
    c.root.visible = !this.hi.has(k);
    this.lo.set(k, c);
  }
  unloadHi(k) {
    const c = this.hi.get(k); if (!c) return;
    this.disposeRoot(c.root);
    this.world.collision.removeChunk(c.i, c.j);
    const g = this.game;
    g.interactables && g.interactables.removeChunk(c);
    g.jumpPads && g.jumpPads.removeChunk(c);
    g.pickups && g.pickups.removeChunk(c);
    this.hi.delete(k);
    const lo = this.lo.get(k); if (lo) lo.root.visible = true;
  }
  unloadLo(k) { const c = this.lo.get(k); if (!c) return; this.disposeRoot(c.root); this.lo.delete(k); }

  /** Synchronously make sure the chunk under (x,z) has collision (safety net for fast travel). */
  ensure(x, z) {
    const i = toI(x), j = toI(z);
    if (inGrid(i, j) && !this.hi.has(chunkKey(i, j))) this.buildHi(i, j);
  }

  plan(playerPos, vel) {
    const ci = toI(playerPos.x), cj = toI(playerPos.z);
    const ahead = vel ? [toI(playerPos.x + vel.x * 2.0), toI(playerPos.z + vel.z * 2.0)] : [ci, cj];
    const wantHi = new Set();
    const list = [];
    for (let dj = -HI_R; dj <= HI_R; dj++) for (let di = -HI_R; di <= HI_R; di++) {
      const i = ci + di, j = cj + dj; if (!inGrid(i, j)) continue;
      wantHi.add(chunkKey(i, j)); list.push({ i, j, hi: true, d: Math.hypot(di, dj) });
    }
    if (inGrid(ahead[0], ahead[1]) && !wantHi.has(chunkKey(ahead[0], ahead[1]))) { wantHi.add(chunkKey(ahead[0], ahead[1])); list.push({ i: ahead[0], j: ahead[1], hi: true, d: 0.5 }); }
    for (let dj = -LO_R; dj <= LO_R; dj++) for (let di = -LO_R; di <= LO_R; di++) {
      const i = ci + di, j = cj + dj; if (!inGrid(i, j)) continue;
      list.push({ i, j, hi: false, d: 10 + Math.hypot(di, dj) });
    }
    return { ci, cj, wantHi, list };
  }

  update(dt, playerPos, vel) {
    vel = vel || (this.game.player && this.game.player.vel);
    const { ci, cj, wantHi, list } = this.plan(playerPos, vel);
    this.ensure(playerPos.x, playerPos.z);
    // unload
    for (const [k, c] of this.hi) if (!wantHi.has(k) && Math.max(Math.abs(c.i - ci), Math.abs(c.j - cj)) > HI_R + 1) this.unloadHi(k);
    for (const [k, c] of this.lo) if (Math.max(Math.abs(c.i - ci), Math.abs(c.j - cj)) > KEEP_R) this.unloadLo(k);
    // one build per frame, nearest first
    list.sort((a, b) => a.d - b.d);
    for (const w of list) {
      const k = chunkKey(w.i, w.j);
      if (w.hi ? !this.hi.has(k) : !this.lo.has(k)) {
        if (w.hi) this.buildHi(w.i, w.j); else this.buildLo(w.i, w.j);
        break;
      }
    }
  }

  /** Build everything near a point synchronously, reporting progress (used by the loading screen). */
  async preload(x, z, onStep, yieldFn) {
    const { list } = this.plan({ x, z }, null);
    list.sort((a, b) => a.d - b.d);
    const need = list.filter((w) => w.hi || w.d < 13);
    let n = 0;
    for (const w of need) {
      if (w.hi) this.buildHi(w.i, w.j); else this.buildLo(w.i, w.j);
      n++; onStep && onStep(n / need.length);
      if (yieldFn) await yieldFn();
    }
  }

  getHiChunkAt(x, z) { return this.hi.get(chunkKey(toI(x), toI(z))); }
}
