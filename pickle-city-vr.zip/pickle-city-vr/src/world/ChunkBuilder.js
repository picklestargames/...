// Builds the render geometry + collision for one city block ("chunk"). LOD 0 = full detail, LOD 1 = shell only.
import * as THREE from 'three';
import { Batcher, tint } from './Batcher.js';
import { getLayout, SHOP_GROUND, findBank } from './CityLayout.js';
import { P, LOT, SW, FLOOR, GRID, DMAP, BLOCK, inGrid } from './Constants.js';
import { rng } from '../core/Utils.js';
import { buildDistrictExtras } from './Districts.js';
import { furnish, floorQuad, wallColor } from './Interiors.js';

const C = (h, k = 1) => tint(h, k);
const PARAPET = 0.45;

export function buildChunk(i, j, mats, lod, shadows) {
  const L = getLayout(i, j);
  const B = new Batcher();
  const r = rng(i * 7919 + j * 104729 + 3);
  const out = { i, j, lod, L, doors: [], buttons: L.buttons, benches: [], entrances: [], animated: [], lights: [], hole: L.hole, root: null, signs: 0 };

  buildGround(B, L, out);
  for (const b of L.buildings) buildBuilding(B, b, L, r, out, lod);
  if (lod === 0) {
    buildStreetProps(B, L, r, out);
    buildDistrictExtras(B, L, r, out, mats);
    for (const t of L.landings) landingMarker(B, t);
    skybridges(B, L);
  } else {
    buildDistrictExtras(B, L, r, out, mats, true);
  }

  out.root = B.build(mats, { shadows: shadows && lod === 0 });
  if (out.extraMeshes) for (const m of out.extraMeshes) out.root.add(m);
  out.col = lod === 0 ? B.col : [];
  out.ladders = lod === 0 ? B.ladders : [];
  // ground collision for holes is handled by CollisionWorld.groundAt
  return out;
}

function buildGround(B, L, out) {
  const x0 = L.cx - P / 2, x1 = L.cx + P / 2, z0 = L.cz - P / 2, z1 = L.cz + P / 2;
  const key = L.district === 'park' ? 'grass' : 'road';
  const rects = [];
  if (L.hole) {
    const h = L.hole;
    rects.push([x0, z0, x1, h.z0], [x0, h.z1, x1, z1], [x0, h.z0, h.x0, h.z1], [h.x1, h.z0, x1, h.z1]);
  } else rects.push([x0, z0, x1, z1]);
  for (const [a, b, c, d] of rects) {
    if (c - a < 0.01 || d - b < 0.01) continue;
    const u0 = (a - x0) / P, u1 = (c - x0) / P, v0 = (b - z0) / P, v1 = (d - z0) / P;
    B.quad(key, [a, 0, d], [c, 0, d], [c, 0, b], [a, 0, b], 0, 1, 0, [[u0, v1], [u1, v1], [u1, v0], [u0, v0]], [1, 1, 1]);
  }
}

function dark(B, x0, y0, z0, x1, y1, z1, k = 0.1) { B.box(x0, y0, z0, x1, y1, z1, { side: 'plain', color: [k, k, k * 1.1] }); }

function buildBuilding(B, b, L, r, out, lod) {
  if (b.type === 'frame' || b.type === 'garage') return; // built by district extras
  const hollow = (b.type === 'shop' || b.type === 'rest' || b.type === 'annex') && b.front;
  const base = b.type === 'ind' ? 'ind' : b.type === 'glass' ? 'glass' : b.type === 'shop' || b.type === 'rest' || b.type === 'annex' ? 'shop' : 'apt';
  const col = C(b.tint, 1);
  // apartment buildings facing a street along z get a walk-in lobby on the ground floor
  const lobby = lod === 0 && b.type === 'apt' && (() => { const f = frontOf(b, L), t0 = b.tiers[0]; return (f === '+z' || f === '-z') && t0.x1 - t0.x0 >= 12 && t0.z1 - t0.z0 >= 14; })();

  b.tiers.forEach((t, k) => {
    const mat = t.mat === 'conc' ? 'conc' : t.mat === 'glass' ? 'glass' : base;
    const y0 = (hollow || lobby) && k === 0 && lod === 0 ? (b.type === 'annex' ? t.y1 - 0.2 : SHOP_GROUND) : t.y0;
    const tcol = mat === 'glass' ? (k === 0 ? C(0xffffff) : col) : col;
    B.box(t.x0, y0, t.z0, t.x1, t.y1, t.z1, { side: mat, top: 'roof', color: tcol, tile: 3.6, floor: FLOOR, solid: lod === 0 || false, skip: '' });
    if (lod === 0) {
      rooftop(B, b, t, k, r, L, out);
      if (mat !== 'glass') {                               // projecting cornice + dentils, plinth and a string course
        const cc = C(0xd2cabb);
        B.box(t.x0 - 0.22, t.y1 - 0.6, t.z0 - 0.22, t.x1 + 0.22, t.y1 - 0.3, t.z1 + 0.22, { side: 'conc', top: 'conc', color: cc, tile: 3.6, floor: 3.6 });
        B.box(t.x0 - 0.1, t.y1 - 0.3, t.z0 - 0.1, t.x1 + 0.1, t.y1 - 0.12, t.z1 + 0.1, { side: 'conc', top: 'conc', color: C(0xbdb5a7), tile: 3.6, floor: 3.6 });
        if (k === 0 && !hollow && !lobby) B.box(t.x0 - 0.06, 0, t.z0 - 0.06, t.x1 + 0.06, 0.55, t.z1 + 0.06, { side: 'conc', top: 'conc', color: C(0x8c877e), tile: 3.6, floor: 3.6 });
        if (k === 0 && b.type === 'apt' && b.top > FLOOR * 3) B.box(t.x0 - 0.1, FLOOR - 0.12, t.z0 - 0.1, t.x1 + 0.1, FLOOR + 0.12, t.z1 + 0.1, { side: 'conc', top: 'conc', color: cc, tile: 3.6, floor: 0.4 });
      }
    }
  });
  if (lod === 0) {
    if (hollow) shopGround(B, b, L, r, out);
    else if (b.type === 'ind') warehouse(B, b, L, r, out);
    else if (lobby) buildLobby(B, b, L, r, out);
    else groundEntrance(B, b, L, r, out);
    if (b.type === 'apt') { balconies(B, b, L, r); if (b.fe !== false) fireEscape(B, b, L, r); }
  }
}

function frontOf(b, L) {
  // face of the building looking toward the nearest block edge
  const mx = (b.x0 + b.x1) / 2 - L.cx, mz = (b.z0 + b.z1) / 2 - L.cz;
  if (Math.abs(mx) > Math.abs(mz)) return mx > 0 ? '+x' : '-x';
  return mz > 0 ? '+z' : '-z';
}

function groundEntrance(B, b, L, r, out) {
  const f = b.front || frontOf(b, L);
  const t = b.tiers[0];
  const dw = 2.2;
  let door;
  if (f === '+z' || f === '-z') {
    const x = (t.x0 + t.x1) / 2, z = f === '+z' ? t.z1 : t.z0, s = f === '+z' ? 1 : -1;
    dark(B, x - dw / 2, 0, z + (s > 0 ? 0.0 : -0.06), x + dw / 2, 2.6, z + (s > 0 ? 0.06 : 0));
    B.solidBox(x - 1.6, 2.7, Math.min(z, z + s * 1.2), x + 1.6, 2.82, Math.max(z, z + s * 1.2), { side: 'plain', color: C(0x7a3030) });
    door = { x, z: z + s * 1.2 };
  } else {
    const z = (t.z0 + t.z1) / 2, x = f === '+x' ? t.x1 : t.x0, s = f === '+x' ? 1 : -1;
    dark(B, x + (s > 0 ? 0 : -0.06), 0, z - dw / 2, x + (s > 0 ? 0.06 : 0), 2.6, z + dw / 2);
    B.solidBox(Math.min(x, x + s * 1.2), 2.7, z - 1.6, Math.max(x, x + s * 1.2), 2.82, z + 1.6, { side: 'plain', color: C(0x305a7a) });
    door = { x: x + s * 1.2, z };
  }
  out.entrances.push({ x: door.x, z: door.z, f });
}

function rooftop(B, b, t, k, r, L, out) {
  const topTier = k === b.tiers.length - 1;
  const y = t.y1;
  const pc = C(0xb8b2a6);
  // parapet around the perimeter (low enough to step over)
  const th = 0.35;
  B.solidBox(t.x0, y, t.z0, t.x1, y + PARAPET, t.z0 + th, { side: 'conc', top: 'conc', color: pc });
  B.solidBox(t.x0, y, t.z1 - th, t.x1, y + PARAPET, t.z1, { side: 'conc', top: 'conc', color: pc });
  B.solidBox(t.x0, y, t.z0 + th, t.x0 + th, y + PARAPET, t.z1 - th, { side: 'conc', top: 'conc', color: pc });
  B.solidBox(t.x1 - th, y, t.z0 + th, t.x1, y + PARAPET, t.z1 - th, { side: 'conc', top: 'conc', color: pc });
  const w = t.x1 - t.x0, d = t.z1 - t.z0;
  if (w < 5 || d < 5) return;
  const next = b.tiers[k + 1];
  const free = (x, z, m) => !next || x < next.x0 - m || x > next.x1 + m || z < next.z0 - m || z > next.z1 + m;
  const R = rng((b.id + 1) * 1237 + k * 17 + L.i * 31 + L.j);
  // rooftop path (light strip)
  if (topTier && w > 8) B.box(t.x0 + 2, y + 0.01, (t.z0 + t.z1) / 2 - 0.6, t.x1 - 2, y + 0.03, (t.z0 + t.z1) / 2 + 0.6, { side: 'plain', color: C(0xcfcabd), skip: 'xz' });
  // AC units
  const nAC = 1 + R.int(0, 3);
  for (let n = 0; n < nAC; n++) {
    const x = R.range(t.x0 + 2, t.x1 - 3), z = R.range(t.z0 + 2, t.z1 - 3.5);
    if (!free(x, z, 2)) continue;
    const w1 = R.range(1.4, 2.4), h1 = R.range(0.9, 1.5);
    B.solidBox(x, y, z, x + w1, y + h1, z + 1.2, { side: 'metal', top: 'metal', color: C(0xb9bfc4) });
    B.cyl('metal', x + w1 / 2, y + h1, z + 0.6, 0.45, 0.08, { n: 8, color: C(0x303030) });
  }
  // vents / chimneys
  for (let n = 0; n < 2; n++) {
    const x = R.range(t.x0 + 1.5, t.x1 - 1.5), z = R.range(t.z0 + 1.5, t.z1 - 1.5);
    if (!free(x, z, 1.5)) continue;
    B.cyl('metal', x, y, z, 0.25, R.range(1.1, 2), { n: 8, color: C(0x9a9a9a), solid: true });
    B.cyl('metal', x, y + 1.2, z, 0.36, 0.14, { n: 8, color: C(0x707070) });
  }
  if (topTier) {
    // stair bulkhead with a door
    const bx = t.x1 - 5.2, bz = t.z0 + 1.2;
    if (w > 9 && free(bx, bz, 1)) {
      B.solidBox(bx, y, bz, bx + 3.6, y + 2.9, bz + 3.2, { side: 'conc', top: 'roof', color: C(0xd8d2c4), tile: 3 });
      dark(B, bx + 1.0, y, bz + 3.2, bx + 2.4, y + 2.1, bz + 3.26, 0.12);
      B.box(bx + 0.9, y + 2.12, bz + 3.2, bx + 2.5, y + 2.18, bz + 3.5, { side: 'plain', color: C(0x555555) });
    }
    // water tank or antenna
    const kind = R.int(0, 2);
    const ax = t.x0 + 3.2, az = t.z1 - 3.4;
    if (kind === 0 && w > 9) {
      for (const [dx, dz] of [[-.9, -.9], [.9, -.9], [-.9, .9], [.9, .9]]) B.box(ax + dx - .08, y, az + dz - .08, ax + dx + .08, y + 2.4, az + dz + .08, { side: 'metal', color: C(0x55565a) });
      B.cyl('plain', ax, y + 2.4, az, 1.25, 2.1, { n: 10, color: C(0x8a5a3a), solid: true });
      B.cone('plain', ax, y + 4.5, az, 1.3, 0, 0.8, { n: 10, color: C(0x3a2a20) });
    } else if (kind === 1) {
      B.cyl('metal', ax, y, az, 0.08, 7 + R.range(0, 6), { n: 5, color: C(0x909090) });
      B.box(ax - 0.04, y + 6, az - 0.9, ax + 0.04, y + 6.08, az + 0.9, { side: 'metal', color: C(0x909090) });
    }
    if (b.top > 55) { // aircraft warning light on tall towers
      B.cyl('metal', (t.x0 + t.x1) / 2, y, (t.z0 + t.z1) / 2, 0.15, 9, { n: 5, color: C(0x909090) });
      B.box((t.x0 + t.x1) / 2 - 0.25, y + 9, (t.z0 + t.z1) / 2 - 0.25, (t.x0 + t.x1) / 2 + 0.25, y + 9.5, (t.z0 + t.z1) / 2 + 0.25, { side: 'emissive', color: [1, 0.1, 0.05] });
      out.lights.push({ x: (t.x0 + t.x1) / 2, y: y + 9.2, z: (t.z0 + t.z1) / 2 });
    }
  }
}

function landingMarker(B, t) {
  const s = 3.2, h = 0.05, c = [0.3, 1, 0.45];
  B.box(t.x - s, t.y + 0.04, t.z - s, t.x + s, t.y + 0.07, t.z - s + 0.3, { side: 'emissive', color: c, skip: 'xz' });
  B.box(t.x - s, t.y + 0.04, t.z + s - 0.3, t.x + s, t.y + 0.07, t.z + s, { side: 'emissive', color: c, skip: 'xz' });
  B.box(t.x - s, t.y + 0.04, t.z - s, t.x - s + 0.3, t.y + 0.07, t.z + s, { side: 'emissive', color: c, skip: 'xz' });
  B.box(t.x + s - 0.3, t.y + 0.04, t.z - s, t.x + s, t.y + 0.07, t.z + s, { side: 'emissive', color: c, skip: 'xz' });
  B.box(t.x - 0.3, t.y + 0.04, t.z - 1.3, t.x + 0.3, t.y + 0.07, t.z + 1.3, { side: 'emissive', color: c, skip: 'xz' });
  B.box(t.x - 1.3, t.y + 0.04, t.z - 0.3, t.x + 1.3, t.y + 0.07, t.z + 0.3, { side: 'emissive', color: c, skip: 'xz' });
}

function balconies(B, b, L, r) {
  const t = b.tiers[0];
  const f = frontOf(b, L);
  const n = Math.floor(b.top / FLOOR);
  const alongX = f === '+z' || f === '-z';
  const s = f === '+z' || f === '+x' ? 1 : -1;
  const len = alongX ? t.x1 - t.x0 : t.z1 - t.z0;
  const mid = alongX ? (t.x0 + t.x1) / 2 : (t.z0 + t.z1) / 2;
  const R = rng(b.id * 313 + 11);
  for (let k = 2; k < n; k += 2) {
    for (const off of [-len / 4, len / 4]) {
      if (R() < 0.25) continue;
      const y = k * FLOOR, a = mid + off - 1.6, c = mid + off + 1.6;
      const dep = 1.3;
      const x0 = alongX ? a : (s > 0 ? t.x1 : t.x0 - dep), x1 = alongX ? c : (s > 0 ? t.x1 + dep : t.x0);
      const z0 = alongX ? (s > 0 ? t.z1 : t.z0 - dep) : a, z1 = alongX ? (s > 0 ? t.z1 + dep : t.z0) : c;
      B.solidBox(x0, y - 0.05, z0, x1, y + 0.1, z1, { side: 'conc', top: 'conc', color: C(0xaaa6a0), skip: '' });
      // railing posts + rail (non solid)
      const rx0 = alongX ? x0 : (s > 0 ? x1 - 0.04 : x0), rx1 = alongX ? x1 : (s > 0 ? x1 : x0 + 0.04);
      const rz0 = alongX ? (s > 0 ? z1 - 0.04 : z0) : z0, rz1 = alongX ? (s > 0 ? z1 : z0 + 0.04) : z1;
      B.box(rx0, y + 0.1, rz0, rx1, y + 1.05, rz1, { side: 'metal', color: C(0x2a2a2e), skip: 't', tile: 0.5 });
    }
  }
}

function fireEscape(B, b, L, r) {
  const t = b.tiers[0];
  const f = frontOf(b, L);
  const alongX = f === '+z' || f === '-z';
  const s = f === '+z' || f === '+x' ? 1 : -1;
  const len = alongX ? t.x1 - t.x0 : t.z1 - t.z0;
  if (len < 14) return;
  const c0 = (alongX ? t.x0 : t.z0) + 2.0;     // along-axis start (landing A)
  const c1 = c0 + 6.6;                          // landing B end
  const wall = alongX ? (s > 0 ? t.z1 : t.z0) : (s > 0 ? t.x1 : t.x0);
  const floors = Math.floor(b.top / FLOOR);
  const col = C(0x2f3236);
  const put = (a0, a1, d0, d1, y0, y1, solid = true, o = {}) => {
    // a: along-axis range, d: depth from wall outward (positive)
    const dd0 = s > 0 ? wall + d0 : wall - d1, dd1 = s > 0 ? wall + d1 : wall - d0;
    const [x0, x1, z0, z1] = alongX ? [a0, a1, dd0, dd1] : [dd0, dd1, a0, a1];
    B.box(x0, y0, z0, x1, y1, z1, { side: 'metal', top: 'metal', color: col, solid, tile: 1.0, floor: 1.0, ...o });
  };
  for (let k = 1; k <= floors; k++) {
    const y = k * FLOOR;
    const atA = k % 2 === 1;
    const la0 = atA ? c0 : c1 - 1.6, la1 = atA ? c0 + 1.6 : c1;
    put(la0, la1, 0.05, 1.45, y - 0.12, y);
    if (k < floors) {
      // flight up to the next floor from this landing toward the other end
      const steps = 8, run = (c1 - c0 - 3.2) / steps;
      for (let n = 0; n < steps; n++) {
        const top = y + (n + 1) * (FLOOR / (steps + 1));
        const a0 = atA ? c0 + 1.6 + n * run : c1 - 1.6 - (n + 1) * run;
        put(a0, a0 + run, 0.35, 1.25, top - 0.14, top);
      }
    }
    // railing along landing outer edge (visual)
    const rd = 1.4;
    put(la0, la1, rd, rd + 0.04, y, y + 1.0, false, { tile: 0.4, floor: 0.4 });
  }
  // drop ladder from ground to first landing + ladder from top landing to roof
  const lad = (a, y0, y1) => {
    const ox = alongX ? a : wall + s * 0.1, oz = alongX ? wall + s * 0.1 : a;
    B.ladder(ox, oz, alongX ? 0 : s, alongX ? s : 0, y0, y1);
  };
  lad(c0 + 0.8, 0, FLOOR);
}

function buildLobby(B, b, L, r, out) {
  const t = b.tiers[0], f = frontOf(b, L), D = 10;
  const fz0 = f === '+z' ? t.z1 - D : t.z0, fz1 = f === '+z' ? t.z1 : t.z0 + D;
  // solid ground-floor block behind the lobby
  B.solidBox(t.x0, 0, f === '+z' ? t.z0 : t.z0 + D, t.x1, SHOP_GROUND, f === '+z' ? t.z1 - D : t.z1, { side: 'apt', top: 'conc', color: C(b.tint), tile: 3.6, floor: FLOOR });
  shopGround(B, { ...b, type: 'lobby', front: f, tiers: [{ ...t, z0: fz0, z1: fz1 }, ...b.tiers.slice(1)] }, L, r, out);
}

// ----------------------------------------------------------------- shops with hollow interiors
function shopGround(B, b, L, r, out) {
  const t = b.tiers[0];
  const isBank = findBank().b === b;
  const f = b.front;
  const G = b.type === 'annex' ? 2 * FLOOR : SHOP_GROUND; // ground storey height
  const th = 0.5;
  const col = C(b.tint);
  const side = b.type === 'lobby' ? 'apt' : 'shop';
  const alongX = true;
  const s = f === '+z' ? 1 : -1;
  const frontZ = s > 0 ? t.z1 : t.z0;
  const backZ = s > 0 ? t.z0 : t.z1;
  const W = t.x1 - t.x0;
  const mid = (t.x0 + t.x1) / 2;
  const wall = (x0, y0, z0, x1, y1, z1) => B.solidBox(x0, y0, z0, x1, y1, z1, { side, top: 'conc', color: col, tile: 3.6, floor: FLOOR });
  // back + side walls
  const bz0 = s > 0 ? backZ : backZ - th, bz1 = s > 0 ? backZ + th : backZ;
  wall(t.x0, 0, bz0, t.x1, G, bz1);
  wall(t.x0, 0, t.z0, t.x0 + th, G, t.z1);
  wall(t.x1 - th, 0, t.z0, t.x1, G, t.z1);
  // front wall pieces
  const fz0 = s > 0 ? frontZ - th : frontZ, fz1 = s > 0 ? frontZ : frontZ + th;
  const dW = 2.6;
  const sill = 0.9, head = 3.0;
  wall(t.x0 + th, 0, fz0, t.x0 + 1.2, head, fz1);
  wall(t.x1 - 1.2, 0, fz0, t.x1 - th, head, fz1);
  wall(mid - dW / 2 - 0.6, 0, fz0, mid - dW / 2, head, fz1);
  wall(mid + dW / 2, 0, fz0, mid + dW / 2 + 0.6, head, fz1);
  wall(t.x0 + th, head, fz0, t.x1 - th, G, fz1);          // lintel (door too: transom)
  // window sills + glass
  for (const [a, c] of [[t.x0 + 1.2, mid - dW / 2 - 0.6], [mid + dW / 2 + 0.6, t.x1 - 1.2]]) {
    if (c - a < 0.5) continue;
    wall(a, 0, fz0, c, sill, fz1);
    B.solidBox(a, sill, fz0 + (fz1 - fz0) * 0.4, c, head, fz1 - (fz1 - fz0) * 0.4, { side: 'windowGlass', top: 'windowGlass', color: [1, 1, 1] });
  }
  // sign above the door
  const si = (b.id * 5 + L.i * 3 + L.j) % 16;
  const u0 = (si % 4) / 4, v0 = 1 - (Math.floor(si / 4) + 1) / 4;
  const sz = frontZ + s * 0.06;
  const sw = Math.min(5.2, W - 3);
  const sy0 = head + 0.15, sy1 = G - 0.1;
  const gg = b.type === 'lobby' ? { n: 0, pos: [], nor: [], col: [], uv: [], idx: [] } : B.g('signs'), i0 = gg.n;
  const sx0 = mid - sw / 2, sx1 = mid + sw / 2;
  const P4 = s > 0 ? [[sx0, sy0, sz], [sx1, sy0, sz], [sx1, sy1, sz], [sx0, sy1, sz]] : [[sx1, sy0, sz], [sx0, sy0, sz], [sx0, sy1, sz], [sx1, sy1, sz]];
  for (const p of P4) { gg.pos.push(...p); gg.nor.push(0, 0, s); gg.col.push(1, 1, 1); }
  gg.uv.push(u0, v0, u0 + 0.25, v0, u0 + 0.25, v0 + 0.25, u0, v0 + 0.25);
  gg.idx.push(i0, i0 + 1, i0 + 2, i0, i0 + 2, i0 + 3); gg.n += 4;
  // awning
  const acol = b.type === 'lobby' ? C(0x2a4a3a) : isBank ? C(0x1f8a4a) : [C(0xb03030), C(0x2f6fa0), C(0x2f8a4a), C(0xc8902a)][(b.id + L.i) % 4];
  B.solidBox(t.x0 + 0.3, head + 0.0, Math.min(frontZ, frontZ + s * 1.7), t.x1 - 0.3, head + 0.14, Math.max(frontZ, frontZ + s * 1.7), { side: 'plain', top: 'plain', color: acol });
  // ceiling slab
  B.box(t.x0 + th, G - 0.2, Math.min(bz1, fz0), t.x1 - th, G, Math.max(bz0, fz1), { side: 'plain', top: 'plain', color: C(0xdddddd), skip: 'xzt' });
  // floor: tile (shops), planks (restaurants), marble (bank and lobbies)
  const zA = Math.min(bz1, fz0), zB = Math.max(bz0, fz1);
  const kind = b.type === 'lobby' ? 'lobby' : isBank ? 'bank' : b.type === 'rest' ? 'rest' : 'store';
  floorQuad(B, kind === 'rest' ? 'wood' : kind === 'store' ? 'tile' : 'marble', t.x0 + th, t.x1 - th, zA, zB, 0.02, kind === 'store' ? C(0xffffff) : C(0xffffff), kind === 'rest' ? 1.6 : kind === 'store' ? 1.2 : 2.0);
  // wall lining: painted plaster with dark wainscot, rail and skirting, so the inside no longer shows the brick facade
  {
    const xa = t.x0 + th, xb = t.x1 - th, zi0 = s > 0 ? bz1 : fz1, zi1 = s > 0 ? fz0 : bz0, lw = 0.04;
    const wc = kind === 'lobby' ? C(0xe9dfcc) : kind === 'bank' ? C(0xece8de) : C(wallColor(b.id)), wd = kind === 'bank' || kind === 'lobby' ? C(0x6b4a2f) : C(0x7a7468), lh = G - 0.2;
    const lin = (x0, z0, x1, z1) => {
      B.box(x0, 0.02, z0, x1, lh, z1, { side: 'plain', color: wc, skip: 't' });
      B.box(x0 - (x1 - x0 < 0.2 ? 0.01 : 0), 0.02, z0 - (z1 - z0 < 0.2 ? 0.01 : 0), x1 + (x1 - x0 < 0.2 ? 0.01 : 0), 1.0, z1 + (z1 - z0 < 0.2 ? 0.01 : 0), { side: 'plain', color: wd, skip: 't' });
      B.box(x0 - (x1 - x0 < 0.2 ? 0.02 : 0), 1.0, z0 - (z1 - z0 < 0.2 ? 0.02 : 0), x1 + (x1 - x0 < 0.2 ? 0.02 : 0), 1.06, z1 + (z1 - z0 < 0.2 ? 0.02 : 0), { side: 'plain', color: C(0xf2ede2) });
      B.box(x0 - (x1 - x0 < 0.2 ? 0.02 : 0), 0.02, z0 - (z1 - z0 < 0.2 ? 0.02 : 0), x1 + (x1 - x0 < 0.2 ? 0.02 : 0), 0.14, z1 + (z1 - z0 < 0.2 ? 0.02 : 0), { side: 'plain', color: C(0x2a2622) });
    };
    lin(xa, s > 0 ? zi0 : zi1 - lw, xb, s > 0 ? zi0 + lw : zi1);                 // back
    lin(xa, zi0, xa + lw, zi1); lin(xb - lw, zi0, xb, zi1);                      // sides
    const fa = s > 0 ? fz0 - lw : fz1, fb = s > 0 ? fz0 : fz1 + lw;               // front (piers, under sills, lintel)
    const door0 = mid - dW / 2, door1 = mid + dW / 2;
    for (const [a1, c1] of [[xa, t.x0 + 1.2], [t.x1 - 1.2, xb], [door0 - 0.6, door0], [door1, door1 + 0.6]]) B.box(a1, 0.02, fa, c1, head, fb, { side: 'plain', color: wc, skip: 't' });
    for (const [a1, c1] of [[t.x0 + 1.2, door0 - 0.6], [door1 + 0.6, t.x1 - 1.2]]) if (c1 - a1 > 0.5) { B.box(a1, 0.02, fa, c1, sill, fb, { side: 'plain', color: wd, skip: 't' }); B.box(a1 - 0.03, sill, fa - (s > 0 ? 0.04 : -0.0), c1 + 0.03, sill + 0.04, fb + (s > 0 ? 0 : 0.04), { side: 'plain', color: C(0xf2ede2) }); }
    B.box(xa, head, fa, xb, lh, fb, { side: 'plain', color: wc, skip: 't' });
    // ceiling coffers + crown moulding
    B.box(xa, G - 0.3, s > 0 ? zi0 : zi1 - 0.1, xb, G - 0.2, s > 0 ? zi0 + 0.1 : zi1, { side: 'plain', color: C(0xf2ede2) });
    B.box(xa, G - 0.3, s > 0 ? zi1 - 0.1 : zi0, xb, G - 0.2, s > 0 ? zi1 : zi0 + 0.1, { side: 'plain', color: C(0xf2ede2) });
  }
  // ceiling lights
  for (let n = 0; n < Math.max(2, Math.floor(W / 5)); n++) {
    const lx = t.x0 + 2.5 + n * 5;
    if (lx > t.x1 - 2) break;
    const lz = (zA + zB) / 2;
    B.box(lx - 0.7, G - 0.26, lz - 0.2, lx + 0.7, G - 0.2, lz + 0.2, { side: 'emissive', color: [1, 0.96, 0.85], skip: 'xz' });
    out.lights.push({ x: lx, y: G - 0.5, z: lz, interior: true });
  }
  // interior furniture
  const R = rng(b.id * 91 + 5);
  const inner0 = Math.min(bz1, fz0) + 0.1, inner1 = Math.max(bz0, fz1) - 0.1;
  const depth = inner1 - inner0 - 0.04;
  const zAt = (u) => (s > 0 ? inner1 - 0.04 - u : inner0 + 0.04 + u); // u = distance from front wall inward
  furnish(B, { kind, xa: t.x0 + th + 0.04, xb: t.x1 - th - 0.04, s, G, mid, R, depth, zAt, out, id: b.id });
  // the door (dynamic, interactable)
  out.doors.push({ x: mid, y: 0, z: frontZ - s * th / 2, w: dW, h: 2.9, axis: 'z', thick: 0.12 });
  out.entrances.push({ x: mid, z: frontZ + s * 1.2, f, shop: true });
}

function warehouse(B, b, L, r, out) {
  const t = b.tiers[0];
  const R = rng(b.id * 771 + 9);
  const G = b.top;
  // Warehouses are solid masses (accessible roofs); only the loading-bay door is drawn on the facade.
  const f = frontOf(b, L);
  const alongX = f === '+z' || f === '-z';
  const s = f === '+z' || f === '+x' ? 1 : -1;
  const c = alongX ? (t.x0 + t.x1) / 2 : (t.z0 + t.z1) / 2;
  const wall = alongX ? (s > 0 ? t.z1 : t.z0) : (s > 0 ? t.x1 : t.x0);
  const dW = 6, dH = 4.6;
  const o = 0.04;
  const [x0, x1, z0, z1] = alongX ? [c - dW / 2, c + dW / 2, s > 0 ? wall : wall - o, s > 0 ? wall + o : wall] : [s > 0 ? wall : wall - o, s > 0 ? wall + o : wall, c - dW / 2, c + dW / 2];
  B.box(x0, 0, z0, x1, dH, z1, { side: 'plain', color: [0.28, 0.3, 0.32], tile: 0.6, floor: 0.6, skip: 't' });
  for (let k = 1; k < 8; k++) { const y = k * 0.58; B.box(x0 - 0.02, y, z0 - 0.02, x1 + 0.02, y + 0.05, z1 + 0.02, { side: 'plain', color: [0.18, 0.2, 0.22], skip: 't' }); }
  out.entrances.push({ x: alongX ? c : wall + s * 1.2, z: alongX ? wall + s * 1.2 : c, f, shop: false });
  // exterior pipes + vents
  for (let n = 0; n < 3; n++) {
    const a = (alongX ? t.x0 : t.z0) + 2 + n * 3.1 + R.range(0, 1);
    const [px, pz] = alongX ? [a, wall + s * 0.25] : [wall + s * 0.25, a];
    B.cyl('metal', px, 0, pz, 0.14, G - 0.5, { n: 6, color: C(R.pick([0x7a8a96, 0x8a6a4a])) });
  }
  B.box(t.x0 + 4, G - 1.0, t.z0 + 2, t.x0 + 5.2, G - 0.2, t.z0 + 3.2, { side: 'metal', color: C(0x778088), skip: 't' });
}
function skybridges(B, L) {
  if (L.district !== 'down') return;
  const y = 3 * FLOOR;
  const nb = (di, dj) => (inGrid(L.i + di, L.j + dj) ? DMAP[L.j + dj][L.i + di] : null);
  const g = (x0, z0, x1, z1) => {
    B.solidBox(x0, y - 0.25, z0, x1, y, z1, { side: 'conc', top: 'conc', color: C(0xb0b0b0), skip: '' });
    const along = x1 - x0 > z1 - z0;
    if (along) { B.box(x0, y, z0, x1, y + 2.8, z0 + 0.12, { side: 'windowGlass', color: [1, 1, 1], skip: 'xt' }); B.box(x0, y, z1 - 0.12, x1, y + 2.8, z1, { side: 'windowGlass', color: [1, 1, 1], skip: 'xt' }); B.box(x0, y + 2.8, z0, x1, y + 3.0, z1, { side: 'metal', color: C(0x3a3d42) }); }
    else { B.box(x0, y, z0, x0 + 0.12, y + 2.8, z1, { side: 'windowGlass', color: [1, 1, 1], skip: 'zt' }); B.box(x1 - 0.12, y, z0, x1, y + 2.8, z1, { side: 'windowGlass', color: [1, 1, 1], skip: 'zt' }); B.box(x0, y + 2.8, z0, x1, y + 3.0, z1, { side: 'metal', color: C(0x3a3d42) }); }
    // ground support pylon
    const mx = (x0 + x1) / 2, mz = (z0 + z1) / 2;
    B.cyl('conc', mx, 0, mz, 0.5, y - 0.25, { n: 8, color: C(0x9a9a9a), solid: true });
  };
  if (nb(1, 0) === 'down') g(L.cx + LOT - 2, L.cz - 14, L.cx + P - LOT + 2, L.cz - 10);
  if (nb(0, 1) === 'down') g(L.cx + 10, L.cz + LOT - 2, L.cx + 14, L.cz + P - LOT + 2);
}

function buildStreetProps(B, L, r, out) {
  const R = rng(L.i * 313 + L.j * 59 + 1);
  const lampH = 6.2;
  const corners = [[-1, -1], [1, -1], [1, 1], [-1, 1]];
  for (const [sx, sz] of corners) {
    const x = L.cx + sx * 29.2, z = L.cz + sz * 29.2;
    B.cyl('metal', x, 0, z, 0.1, lampH, { n: 6, color: C(0x3a3d42), solid: true });
    B.box(x - 0.08 - (sx < 0 ? 0 : 1.2), lampH, z - 0.08, x + 0.08 + (sx < 0 ? 1.2 : 0), lampH + 0.12, z + 0.08, { side: 'metal', color: C(0x3a3d42) });
    B.box(x + (sx < 0 ? 0.8 : -0.8) - 0.3, lampH - 0.06, z - 0.15, x + (sx < 0 ? 0.8 : -0.8) + 0.3, lampH, z + 0.15, { side: 'emissive', color: [1, 0.9, 0.65] });
    out.lights.push({ x: x + (sx < 0 ? 0.8 : -0.8), y: lampH - 0.2, z });
    // street-name sign on a short pole (traffic lights themselves are dynamic, see VehicleSystem)
    const tx = L.cx + sx * 31.2, tz = L.cz + sz * 31.2;
    B.cyl('metal', tx, 0, tz, 0.045, 3.2, { n: 5, color: C(0x6a6e73) });
    B.box(tx - 0.5, 2.85, tz - 0.03, tx + 0.5, 3.1, tz + 0.03, { side: 'plain', color: C(0x1f6a3a) });
    B.box(tx - 0.03, 3.12, tz - 0.5, tx + 0.03, 3.37, tz + 0.5, { side: 'plain', color: C(0x1f6a3a) });
    B.box(tx - 0.46, 2.88, tz - 0.035, tx + 0.46, 2.9, tz + 0.035, { side: 'plain', color: C(0xf0f0f0) });
    B.box(tx - 0.035, 3.15, tz - 0.46, tx + 0.035, 3.17, tz + 0.46, { side: 'plain', color: C(0xf0f0f0) });
  }
  // raised-look curb stones around the pavement block
  const cb = C(0xbab7af), cw = 0.3, cy = 0.13;
  B.box(L.cx - 30.3, 0, L.cz - 30.3, L.cx + 30.3, cy, L.cz - 30, { side: 'plain', color: cb });
  B.box(L.cx - 30.3, 0, L.cz + 30, L.cx + 30.3, cy, L.cz + 30.3, { side: 'plain', color: cb });
  B.box(L.cx - 30.3, 0, L.cz - 30, L.cx - 30, cy, L.cz + 30, { side: 'plain', color: cb });
  B.box(L.cx + 30, 0, L.cz - 30, L.cx + 30.3, cy, L.cz + 30, { side: 'plain', color: cb });
  // painted stop lines on the approaches to the junctions (this chunk's far corner streets only, so nothing doubles up)
  const wl = C(0xe6e6e0), sl = 0.012;
  for (const ln of [L.cz + 40, L.cz - 40]) {
    B.box(L.cx + 28.2, 0, ln + 0.3, L.cx + 28.7, sl, ln + 6.2, { side: 'plain', color: wl });
    B.box(L.cx - 28.7, 0, ln - 6.2, L.cx - 28.2, sl, ln - 0.3, { side: 'plain', color: wl });
  }
  for (const ln of [L.cx + 40, L.cx - 40]) {
    B.box(ln + 0.3, 0, L.cz + 28.2, ln + 6.2, sl, L.cz + 28.7, { side: 'plain', color: wl });
    B.box(ln - 6.2, 0, L.cz - 28.7, ln - 0.3, sl, L.cz - 28.2, { side: 'plain', color: wl });
  }
  if (L.district === 'park') return;
  // bus stop shelter, mailboxes, newspaper boxes
  if (R() < 0.4) {
    const bx = L.cx + R.range(-14, 14), bz = L.cz + (R() < 0.5 ? -1 : 1) * 28.6, sg = bz < L.cz ? 1 : -1;      // sg: points from the road toward the buildings
    B.box(bx - 1.7, 2.45, bz - 0.9, bx + 1.7, 2.55, bz + 0.9, { side: 'metal', color: C(0x2d3a45) });
    for (const dx of [-1.6, 1.6]) for (const dz of [-0.8, 0.8]) B.box(bx + dx - 0.03, 0, bz + dz - 0.03, bx + dx + 0.03, 2.45, bz + dz + 0.03, { side: 'metal', color: C(0x2d3a45) });
    B.solidBox(bx - 1.6, 0.35, bz + sg * 0.78 - 0.02, bx + 1.6, 2.4, bz + sg * 0.78 + 0.02, { side: 'windowGlass', color: [1, 1, 1] });
    B.box(bx - 0.55, 1.0, bz + sg * 0.74 - 0.03, bx + 0.55, 2.2, bz + sg * 0.74 + 0.01, { side: 'emissive', color: [0.95, 0.85, 0.5] });
    B.solidBox(bx - 1.1, 0, bz - sg * 0.1 - 0.25, bx + 1.1, 0.48, bz - sg * 0.1 + 0.25, { side: 'plain', top: 'plain', color: C(0x8a5a35) });
  }
  for (let n = 0; n < 3; n++) {
    if (R() < 0.5) continue;
    const x = L.cx + R.range(-24, 24), sgn = R() < 0.5 ? -1 : 1, z = L.cz + sgn * 29.3;
    if (R() < 0.5) B.solidBox(x - 0.28, 0, z - 0.25, x + 0.28, 1.1, z + 0.25, { side: 'plain', top: 'plain', color: C(0x1f4f9a) });
    else { B.solidBox(x - 0.25, 0, z - 0.22, x + 0.25, 0.95, z + 0.22, { side: 'plain', top: 'plain', color: C(R() < 0.5 ? 0xc8902a : 0xb03a2e) }); B.box(x - 0.2, 0.7, z - 0.23, x + 0.2, 0.95, z - 0.22, { side: 'emissive', color: [0.75, 0.8, 0.85] }); }
  }
  // sidewalk trees, hydrants, bins, benches
  for (let n = 0; n < 6; n++) {
    const along = -20 + n * 8 + R.range(-1, 1);
    for (const [ax, sgn] of [['x', -1], ['x', 1], ['z', -1], ['z', 1]]) {
      if (R() < 0.45) continue;
      const x = ax === 'x' ? L.cx + along : L.cx + sgn * 29.0, z = ax === 'x' ? L.cz + sgn * 29.0 : L.cz + along;
      if (R() < 0.5) tree(B, x, z, R);
      else if (R() < 0.5) { B.cyl('plain', x, 0, z, 0.22, 0.9, { n: 6, color: C(0xc02828) }); B.cyl('plain', x, 0.9, z, 0.15, 0.12, { n: 6, color: C(0xc02828) }); }
      else if (R() < 0.6) { B.solidBox(x - 0.3, 0, z - 0.3, x + 0.3, 0.95, z + 0.3, { side: 'plain', top: 'plain', color: C(0x2e5a3a) }); }
      else { B.solidBox(x - 0.8, 0.0, z - 0.25, x + 0.8, 0.5, z + 0.25, { side: 'plain', top: 'plain', color: C(0x7a5a3a) }); out.benches.push({ x, z: z + (ax === 'x' ? -sgn * 0.0 : 0), y: 0.5, face: Math.PI / 2 }); }
    }
  }
}

export function tree(B, x, z, R, big = 1) {
  const h = (2.4 + R() * 1.2) * big;
  B.cyl('plain', x, 0, z, 0.16 * big, h, { n: 6, color: C(0x5a4030), solid: true });
  const gcol = [C(0x4a8a30), C(0x3f7a28), C(0x5a9a3a), C(0x6a9a30)][(R() * 4) | 0];
  B.blob('foliage', x, h + 1.2 * big, z, 1.9 * big, { color: gcol, sy: 1.0 });
  B.blob('foliage', x + 0.9 * big, h + 0.5 * big, z + 0.4 * big, 1.3 * big, { color: gcol });
  B.blob('foliage', x - 0.7 * big, h + 0.7 * big, z - 0.6 * big, 1.2 * big, { color: gcol });
}
