// Furnished interiors for the walk-in ground floors: shops, restaurants, the bank and apartment lobbies.
// All geometry goes through the chunk Batcher (merged per material); nothing here allocates per-frame.
import { tint } from './Batcher.js';

const C = (h, k = 1) => tint(h, k);
const PASTELS = [0xe8dcc8, 0xd8e4d4, 0xdbe3ee, 0xeedcd6, 0xe9e4c8, 0xd9d4e8];

/** floor quad with world-scaled uvs (size = metres per texture repeat) */
export function floorQuad(B, key, xa, xb, za, zb, y, col, size = 1.2) {
  B.quad(key, [xa, y, zb], [xb, y, zb], [xb, y, za], [xa, y, za], 0, 1, 0, [[xa / size, zb / size], [xb / size, zb / size], [xb / size, za / size], [xa / size, za / size]], col);
}

/** poster/sign quad from the sign atlas on a wall. axis 'x': wall plane x=c facing nx; 'z': plane z=c facing nz */
export function poster(B, axis, c, nrm, a0, a1, y0, y1, cell) {
  const gg = B.g('signs'), i0 = gg.n, u0 = (cell % 4) / 4, v0 = 1 - (Math.floor(cell / 4) + 1) / 4;
  let P;
  if (axis === 'x') P = nrm > 0 ? [[c, y0, a1], [c, y0, a0], [c, y1, a0], [c, y1, a1]] : [[c, y0, a0], [c, y0, a1], [c, y1, a1], [c, y1, a0]];
  else P = nrm > 0 ? [[a0, y0, c], [a1, y0, c], [a1, y1, c], [a0, y1, c]] : [[a1, y0, c], [a0, y0, c], [a0, y1, c], [a1, y1, c]];
  const nx = axis === 'x' ? nrm : 0, nz = axis === 'z' ? nrm : 0;
  for (const p of P) { gg.pos.push(...p); gg.nor.push(nx, 0, nz); gg.col.push(1, 1, 1); }
  gg.uv.push(u0, v0, u0 + 0.25, v0, u0 + 0.25, v0 + 0.25, u0, v0 + 0.25);
  gg.idx.push(i0, i0 + 1, i0 + 2, i0, i0 + 2, i0 + 3); gg.n += 4;
}

/** o: { kind:'store'|'rest'|'bank'|'lobby', xa,xb, zi0,zi1, s, G, mid, R, W, depth, zAt(u), out, id } */
export function furnish(B, o) {
  const { kind, xa, xb, s, G, mid, R, depth, zAt } = o;
  const zr = (u0, u1) => [Math.min(zAt(u0), zAt(u1)), Math.max(zAt(u0), zAt(u1))];
  const box = (x0, y0, z0, x1, y1, z1, col, opt = {}) => B.box(x0, y0, z0, x1, y1, z1, { side: opt.key || 'plain', top: opt.top || opt.key || 'plain', color: col, solid: !!opt.solid, skip: opt.skip || '', tile: 1, floor: 1 });
  const ubox = (x0, y0, u0, x1, y1, u1, col, opt) => { const [za, zb] = zr(u0, u1); box(x0, y0, za, x1, y1, zb, col, opt); };
  const em = (x0, y0, z0, x1, y1, z1, col) => B.box(x0, y0, z0, x1, y1, z1, { side: 'emissive', color: col, skip: '' });
  const plant = (x, u, big = 1) => { const z = zAt(u); B.cyl('plain', x, 0, z, 0.2 * big, 0.38, { n: 8, color: C(0xa8603f) }); B.cyl('plain', x, 0.38, z, 0.03, 0.5 * big, { n: 5, color: C(0x4a3a24) }); B.blob('foliage', x, 0.95 * big + 0.1, z, 0.42 * big, { color: C(0x3f8a34), sy: 1.2 }); B.blob('foliage', x + 0.18, 0.7 * big, z + 0.1, 0.28 * big, { color: C(0x57a040) }); };
  const clock = (x, y, z, face) => { B.cyl('plain', x, y, z, 0.28, 0.05, { n: 14, axis: 'z', color: C(0xf2f2ee) }); B.box(x - 0.01, y, z - 0.03, x + 0.01, y + 0.2, z + 0.03, { side: 'plain', color: C(0x111111) }); B.box(x, y - 0.01, z - 0.03, x + 0.14, y + 0.01, z + 0.03, { side: 'plain', color: C(0x111111) }); };
  const pal = [0xd04a3a, 0xe0b030, 0x3a8ad0, 0x4aa04a, 0xe8e8e8, 0xc07030, 0x8a4ac0];
  const pick = (a) => a[(R() * a.length) | 0];
  const W = xb - xa;

  // ---- posters on the side walls (all kinds except the bank)
  if (kind !== 'bank') for (let n = 0; n < 2; n++) {
    const [za, zb] = zr(3 + n * 5.5, 4.6 + n * 5.5);
    if (depth > 8 + n * 5) { poster(B, 'x', xa + 0.045, 1, Math.min(za, zb), Math.max(za, zb), 1.5, 2.5, (R() * 16) | 0); poster(B, 'x', xb - 0.045, -1, Math.min(za, zb), Math.max(za, zb), 1.5, 2.5, (R() * 16) | 0); }
  }

  if (kind === 'store') {
    // chilled cabinets along the back wall: glass doors glow, bands of bottles/cartons
    const cx0 = xa + 1.2, cx1 = xb - 1.2;
    ubox(cx0, 0, depth - 0.85, cx1, 2.05, depth - 0.05, C(0xdfe3e6), { key: 'metal', solid: true });
    const uf = depth - 0.9;
    for (let lv = 0; lv < 4; lv++) for (let x = cx0 + 0.1; x < cx1 - 0.3; x += 0.55) ubox(x, 0.25 + lv * 0.45, uf - 0.02, x + 0.45, 0.55 + lv * 0.45, uf + 0.02, C(pick(pal)), { skip: 'xt' });
    ubox(cx0 + 0.05, 0.1, uf - 0.04, cx1 - 0.05, 2.0, uf - 0.02, [0.7, 0.85, 0.95], { key: 'windowGlass' });
    em(cx0, 2.05, zAt(depth - 0.85) - 0.0, cx1, 2.12, zAt(depth - 0.05), [0.8, 0.95, 1]);
    // gondola shelves with stocked goods on both faces
    const rows = depth > 15 ? 3 : 2, bays = Math.max(1, Math.floor((W - 3) / 3.4));
    for (let n = 0; n < rows; n++) for (let m = 0; m < bays; m++) {
      const sx = xa + 1.8 + m * ((W - 3.2) / bays), u0 = 4.8 + n * 3.4;
      if (u0 + 0.9 > depth - 1.9) continue;
      const w = Math.min(2.8, (W - 3.2) / bays - 0.5);
      ubox(sx, 0, u0, sx + w, 0.2, u0 + 0.8, C(0x4a4f56), { key: 'metal', solid: true });
      ubox(sx, 0.2, u0 + 0.36, sx + w, 1.7, u0 + 0.44, C(0x6d7a85), { key: 'metal', solid: true });
      ubox(sx, 1.7, u0 - 0.02, sx + w, 1.8, u0 + 0.82, C(pick(pal), 0.9), { skip: '' });
      for (let lv = 0; lv < 4; lv++) for (const f of [-1, 1]) {
        const ub = u0 + (f < 0 ? 0.12 : 0.44), y = 0.28 + lv * 0.37;
        let x = sx + 0.05; while (x < sx + w - 0.2) { const ww = 0.25 + R() * 0.3; ubox(x, y, ub, Math.min(x + ww, sx + w - 0.03), y + 0.18 + R() * 0.12, ub + 0.26, C(pick(pal), 0.8 + R() * 0.3), { skip: 't' }); x += ww + 0.04; }
      }
      em(sx + 0.1, 2.15, zAt(u0 + 0.35) - 0.12, sx + w - 0.1, 2.35, zAt(u0 + 0.35) + 0.12, C(pick([0xe0b030, 0xd04a3a, 0x3a8ad0])));   // hanging aisle sign
      B.box(sx + w / 2 - 0.02, 2.35, zAt(u0 + 0.4) - 0.02, sx + w / 2 + 0.02, G - 0.2, zAt(u0 + 0.4) + 0.02, { side: 'metal', color: C(0x555555) });
    }
    // checkout: counter, till, belt, basket stack, candy rack
    const cxn = xb - 5.4, cxm = xb - 1.4;
    ubox(cxn, 0, 2.0, cxm, 1.0, 3.1, C(0xb7b0a2), { solid: true });
    ubox(cxn, 1.0, 2.0, cxm, 1.04, 3.1, C(0x24282c), { key: 'metal' });
    ubox(cxn + 0.4, 1.04, 2.4, cxn + 1.4, 1.5, 2.9, C(0x1b1d20));
    em(cxn + 0.5, 1.28, zAt(2.4) + (s > 0 ? 0.02 : -0.02) - (s > 0 ? 0.0 : 0), cxn + 1.3, 1.46, zAt(2.4) + (s > 0 ? 0.0 : 0), [0.25, 0.95, 0.55]);
    ubox(cxn + 1.8, 1.04, 2.2, cxm - 0.2, 1.1, 2.8, C(0x303338), { key: 'metal' });
    for (let k = 0; k < 4; k++) ubox(xb - 1.1, 0.05 + k * 0.14, 3.6, xb - 0.5, 0.18 + k * 0.14, 4.1, C(pick([0xd04a3a, 0x3a8ad0])), { solid: k === 0 });
    ubox(cxn - 0.5, 0, 3.4, cxn - 0.1, 1.3, 3.8, C(0xc0392b), { solid: true });
    plant(xa + 0.7, 1.3);
    box(mid - 1.2, 0.025, zAt(0.2) - 0.45, mid + 1.2, 0.035, zAt(0.2) + 0.45, C(0x23252a), { skip: 'xz' });     // door mat
  } else if (kind === 'rest') {
    // tables with cloths, plates, candles, chairs and pendant lamps
    const nx = Math.max(1, Math.floor((W - 4) / 3.2)), rowsN = depth > 16 ? 3 : 2;
    for (let n = 0; n < rowsN; n++) for (let m = 0; m < nx; m++) {
      const x = xa + 1.6 + m * ((W - 3.4) / nx) + 0.4, u = 3.6 + n * 3.6, [za, zb] = zr(u, u + 1.0), zc = (za + zb) / 2;
      const cloth = pick([0xf2ece0, 0xc0392b, 0x2e6fb0, 0x2e8b57]);
      box(x + 0.45 - 0.05, 0, zc - 0.05, x + 0.45 + 0.05, 0.74, zc + 0.05, C(0x2a2a2e), { key: 'metal' });
      box(x, 0.74, za, x + 0.9, 0.78, zb, C(cloth), { solid: true });
      box(x + 0.15, 0.78, zc - 0.12, x + 0.35, 0.8, zc + 0.12, C(0xf4f4f4)); box(x + 0.55, 0.78, zc - 0.12, x + 0.75, 0.8, zc + 0.12, C(0xf4f4f4));
      B.cyl('plain', x + 0.45, 0.78, zc, 0.03, 0.12, { n: 6, color: C(0xe8d9a0) }); em(x + 0.435, 0.9, zc - 0.015, x + 0.465, 0.94, zc + 0.015, [1, 0.8, 0.3]);
      for (const f of [-1, 1]) { const zz = zc + f * 0.72; box(x + 0.2, 0.0, zz - 0.2, x + 0.7, 0.46, zz + 0.2, C(0x6b4a2f), { solid: true }); box(x + 0.2, 0.46, zz + (f > 0 ? 0.14 : -0.2), x + 0.7, 0.95, zz + (f > 0 ? 0.2 : -0.14), C(0x6b4a2f)); }
      B.box(x + 0.44, 2.1, zc - 0.01, x + 0.46, G - 0.2, zc + 0.01, { side: 'plain', color: C(0x222222) });
      B.cone('plain', x + 0.45, 1.85, zc, 0.36, 0.08, 0.28, { n: 10, color: C(0xd8b060) }); em(x + 0.35, 1.84, zc - 0.1, x + 0.55, 1.88, zc + 0.1, [1, 0.86, 0.5]);
    }
    // kitchen line at the back: pass counter with hood, shelves of bottles behind a bar
    ubox(xa + 1.2, 0, depth - 2.6, xb - 1.2, 1.05, depth - 1.7, C(0xc9c1b4), { key: 'plain', solid: true });
    ubox(xa + 1.2, 1.05, depth - 2.6, xb - 1.2, 1.1, depth - 1.7, C(0x3a3d42), { key: 'metal' });
    for (let x = xa + 1.8; x < xb - 2.4; x += 1.8) { ubox(x, 0.0, depth - 2.55, x + 0.5, 0.85, depth - 2.45, C(0x2a2a2e), { skip: 'xz' }); box(x - 0.0, 1.0, zAt(depth - 2.2) - 0.0, x + 0.0, 1.0, zAt(depth - 2.2), C(0x000000), { skip: 'xzt' }); }
    for (let k = 0; k < Math.floor((W - 3) / 0.5); k++) ubox(xa + 1.4 + k * 0.5, 1.3 + (k % 2) * 0.55, depth - 0.45, xa + 1.4 + k * 0.5 + 0.18, 1.78 + (k % 2) * 0.55, depth - 0.2, C(pick([0x2e8b57, 0x8a5a2a, 0xd8d0b0, 0x2e6fb0, 0xb03a2e])), { skip: 't' });
    ubox(xa + 1.2, 1.2, depth - 0.5, xb - 1.2, 1.26, depth - 0.1, C(0x6b4a2f), { solid: false });
    ubox(xa + 1.2, 2.0, depth - 0.5, xb - 1.2, 2.06, depth - 0.1, C(0x6b4a2f));
    ubox(xa + 1.2, 2.2, depth - 2.6, xb - 1.2, 2.7, depth - 1.8, C(0x9aa0a6), { key: 'metal' });
    // bar stools at the pass, menu board, plants
    for (let x = xa + 2; x < xb - 2; x += 1.1) { B.cyl('plain', x, 0, zAt(depth - 3.1), 0.03, 0.62, { n: 5, color: C(0x2a2a2e) }); B.cyl('plain', x, 0.62, zAt(depth - 3.1), 0.18, 0.07, { n: 8, color: C(0xb03a2e) }); }
    poster(B, 'x', xb - 0.05, -1, Math.min(zAt(2), zAt(4)), Math.max(zAt(2), zAt(4)), 1.3, 2.4, 11);
    plant(xa + 0.6, 1.4); plant(xb - 0.6, 1.4, 1.2);
  } else if (kind === 'bank') {
    // marble hall: queue ropes, benches, advisers' desks, ATM, plants, clock and the big round vault door
    const [ca, cb] = zr(3.4, 4.3);
    for (let x = xa + 1.5; x < xb - 1.5; x += 3) { box(x, 1.1, (ca + cb) / 2 - 0.35, x + 0.8, 1.14, (ca + cb) / 2 + 0.35, C(0x1b1d20)); em(x + 0.15, 1.14, (ca + cb) / 2 - 0.1, x + 0.65, 1.2, (ca + cb) / 2 + 0.1, [0.4, 1, 0.6]); }
    const q0 = zAt(5.2), q1 = zAt(7.2);
    for (const x of [mid - 1.8, mid + 1.8]) for (const z of [q0, q1]) { B.cyl('metal', x, 0, z, 0.04, 0.95, { n: 6, color: C(0xc9a24a) }); B.cyl('metal', x, 0, z, 0.15, 0.04, { n: 8, color: C(0xc9a24a) }); }
    for (const x of [mid - 1.8, mid + 1.8]) B.box(x - 0.015, 0.8, Math.min(q0, q1), x + 0.015, 0.86, Math.max(q0, q1), { side: 'plain', color: C(0x8a1f1f) });
    B.box(mid - 1.8, 0.8, q0 - 0.015, mid + 1.8, 0.86, q0 + 0.015, { side: 'plain', color: C(0x8a1f1f) });
    for (const x of [xa + 1.2, xb - 2.8]) { ubox(x, 0, 6.0, x + 1.6, 0.46, 6.6, C(0x2a3a50), { solid: true }); ubox(x, 0.46, 6.5, x + 1.6, 0.95, 6.6, C(0x2a3a50)); }
    for (const x of [xa + 1.6, xb - 4.6]) {
      ubox(x, 0, depth - 6.6, x + 1.8, 0.76, depth - 5.6, C(0x6b4a2f), { solid: true });
      ubox(x + 0.4, 0.76, depth - 6.3, x + 1.0, 1.16, depth - 6.25, C(0x15181c)); em(x + 0.43, 0.8, zAt(depth - 6.28) + (s > 0 ? 0.02 : -0.02), x + 0.97, 1.12, zAt(depth - 6.28) + (s > 0 ? 0.03 : -0.03), [0.35, 0.6, 0.9]);
      ubox(x + 0.55, 0, depth - 4.9, x + 1.2, 0.46, depth - 4.4, C(0x2a3a50), { solid: true }); ubox(x + 0.55, 0.46, depth - 4.45, x + 1.2, 0.9, depth - 4.4, C(0x2a3a50));
    }
    ubox(xa + 0.3, 0, depth - 8.4, xa + 1.1, 2.1, depth - 7.6, C(0x20252b), { key: 'metal', solid: true }); em(xa + 0.45, 1.4, zAt(depth - 7.6) + (s > 0 ? 0.0 : -0.0), xa + 0.95, 1.85, zAt(depth - 7.6) + (s > 0 ? 0.015 : -0.015), [0.3, 0.9, 0.55]);
    const vz = zAt(depth - 1.25) - s * 0.05;
    B.cyl('metal', mid, 1.4, vz, 0.95, 0.12, { n: 20, axis: 'z', color: C(0xaeb4ba) }); B.cyl('metal', mid, 1.4, vz - s * 0.08, 0.28, 0.1, { n: 12, axis: 'z', color: C(0x6a6f76) });
    for (let k = 0; k < 6; k++) { const a = k / 6 * Math.PI * 2; B.box(mid + Math.cos(a) * 0.55 - 0.03, 1.4 + Math.sin(a) * 0.55 - 0.03, vz - s * 0.1 - 0.03, mid + Math.cos(a) * 0.55 + 0.03, 1.4 + Math.sin(a) * 0.55 + 0.03, vz - s * 0.1 + 0.03, { side: 'metal', color: C(0x2a2d31) }); }
    clock(mid, 3.0, zAt(depth - 0.12), s);
    plant(xa + 0.7, 2.0, 1.3); plant(xb - 0.7, 2.0, 1.3);
    poster(B, 'x', xb - 0.05, -1, Math.min(zAt(7), zAt(9)), Math.max(zAt(7), zAt(9)), 1.4, 2.4, 2);
  } else if (kind === 'lobby') {
    // apartment lobby: marble floor, reception desk, mailboxes, lift, sofas, rug, plants and a chandelier
    const rz = depth - 3.5;
    ubox(mid - 1.8, 0, rz - 0.4, mid + 1.8, 1.1, rz + 0.4, C(0x5a3d28), { solid: true });
    ubox(mid - 1.9, 1.1, rz - 0.5, mid + 1.9, 1.16, rz + 0.5, C(0xd7cdbb), { key: 'metal' });
    ubox(mid - 0.3, 1.16, rz + 0.1, mid + 0.4, 1.5, rz + 0.2, C(0x15181c)); em(mid - 0.25, 1.2, zAt(rz + 0.1) + (s > 0 ? -0.012 : 0.012), mid + 0.35, 1.45, zAt(rz + 0.1) + (s > 0 ? -0.0 : 0.0), [0.4, 0.8, 1]);
    // mailboxes (brass grid) on the east wall
    for (let r_ = 0; r_ < 4; r_++) for (let c_ = 0; c_ < 8; c_++) { const [za] = zr(2.5 + c_ * 0.32, 2.5 + c_ * 0.32 + 0.28); const zz = Math.min(zAt(2.5 + c_ * 0.32), zAt(2.5 + c_ * 0.32 + 0.28)); B.box(xb - 0.12, 0.9 + r_ * 0.3, zz, xb - 0.04, 1.15 + r_ * 0.3, zz + 0.28, { side: 'metal', color: C(0xb08a3a, 0.8 + R() * 0.3) }); }
    // lift doors on the west wall with call button and floor display
    const lz0 = Math.min(zAt(depth - 5.6), zAt(depth - 3.4)), lz1 = Math.max(zAt(depth - 5.6), zAt(depth - 3.4));
    B.box(xa + 0.0, 0, lz0 - 0.1, xa + 0.12, 2.5, lz1 + 0.1, { side: 'metal', color: C(0x3a3d42) });
    B.box(xa + 0.1, 0, lz0, xa + 0.14, 2.3, (lz0 + lz1) / 2 - 0.01, { side: 'metal', color: C(0xaeb4ba) }); B.box(xa + 0.1, 0, (lz0 + lz1) / 2 + 0.01, xa + 0.14, 2.3, lz1, { side: 'metal', color: C(0xa4aab0) });
    em(xa + 0.1, 2.4, (lz0 + lz1) / 2 - 0.12, xa + 0.15, 2.5, (lz0 + lz1) / 2 + 0.12, [1, 0.3, 0.2]); B.cyl('plain', xa + 0.14, 1.1, lz1 + 0.35, 0.05, 0.03, { n: 8, axis: 'x', color: C(0xdddddd) });
    // waiting sofas + coffee table + rug
    const sofaX = xa + 2.4;
    ubox(sofaX, 0, 3.2, sofaX + 2.0, 0.42, 4.0, C(0x6b4a3a), { solid: true }); ubox(sofaX, 0.42, 3.9, sofaX + 2.0, 0.9, 4.0, C(0x6b4a3a));
    ubox(sofaX + 2.4, 0, 3.4, sofaX + 3.4, 0.4, 3.9, C(0x2a2a2e), { solid: true });
    ubox(xa + 1.2, 0.012, 2.6, xa + 5.4, 0.02, 4.8, C(0x8a3a3a), { skip: 'xz' });
    plant(xa + 0.7, 1.4, 1.3); plant(xb - 0.7, depth - 1.0, 1.3);
    // chandelier + brass wall lights
    const lz = zAt(depth * 0.5); B.cyl('metal', mid, G - 1.0, lz, 0.02, 0.8, { n: 4, color: C(0xc9a24a) }); B.cyl('metal', mid, G - 1.15, lz, 0.5, 0.05, { n: 14, color: C(0xc9a24a) }); for (let k = 0; k < 6; k++) { const a = k / 6 * Math.PI * 2; em(mid + Math.cos(a) * 0.45 - 0.04, G - 1.12, lz + Math.sin(a) * 0.45 - 0.04, mid + Math.cos(a) * 0.45 + 0.04, G - 0.98, lz + Math.sin(a) * 0.45 + 0.04, [1, 0.88, 0.55]); }
    for (const x of [xb - 0.12]) for (const u of [5, 9]) { const zz = zAt(u); em(x - 0.02, 1.9, zz - 0.08, x + 0.0, 2.2, zz + 0.08, [1, 0.88, 0.55]); }
    poster(B, 'x', xb - 0.05, -1, Math.min(zAt(depth - 6), zAt(depth - 4.2)), Math.max(zAt(depth - 6), zAt(depth - 4.2)), 1.4, 2.4, 5);
  }
}

export const wallColor = (id) => PASTELS[id % PASTELS.length];
