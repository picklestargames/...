// World constants. Pure data – no three.js import.
export const GRID = 7;          // blocks per side
export const P = 80;            // block period (block + street)
export const BLOCK = 30;        // half-extent of a block incl. sidewalk
export const LOT = 26;          // half-extent of the buildable lot
export const SW = 28;           // sidewalk centreline offset from block centre
export const FLOOR = 3.6;       // storey height
export const GRAVITY = 22;

export const cx = (i) => (i - (GRID - 1) / 2) * P;
export const toI = (x) => Math.round(x / P + (GRID - 1) / 2);
export const inGrid = (i, j) => i >= 0 && j >= 0 && i < GRID && j < GRID;
export const chunkKey = (i, j) => i * 16 + j;
export const WORLD_HALF = (GRID * P) / 2;

// [j][i]
export const DMAP = [
  ['ind', 'ind', 'ind', 'gas', 'apt', 'apt', 'shop'],
  ['ind', 'con', 'shop', 'apt', 'apt', 'shop', 'shop'],
  ['pkg', 'shop', 'down', 'down', 'down', 'apt', 'park'],
  ['shop', 'apt', 'down', 'plaza', 'down', 'apt', 'apt'],
  ['apt', 'shop', 'down', 'down', 'down', 'shop', 'gas'],
  ['apt', 'apt', 'shop', 'apt', 'park', 'metro', 'shop'],
  ['shop', 'apt', 'apt', 'shop', 'apt', 'apt', 'ind'],
];

export const DISTRICT_COLORS = {
  ind: '#6b6258', con: '#c79a2a', shop: '#8a6a55', apt: '#7a5f52', down: '#4a6f8c',
  plaza: '#3d8a8c', park: '#3f7a32', metro: '#2f6a4a', gas: '#9a4a3a', pkg: '#58606a',
};

export const SPAWN = { x: -40, y: 0, z: -40, yaw: Math.atan2(-1, -1) };

export const WEAPON_IDS = ['pistol', 'revolver', 'smg', 'rifle', 'shotgun', 'marksman'];
