// PICKLE CITY VR: one-file game server. Serves the game (static files) and relays multiplayer over WebSocket at /ws.
// No dependencies: `node server/server.js` (Node 18+). Env: PORT (default 8080), MAX_PLAYERS (32), ALLOW_ORIGIN (optional, e.g. https://mygame.example).
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = +process.env.PORT || 8080;
const MAX_PLAYERS = +process.env.MAX_PLAYERS || 32;
const ALLOW_ORIGIN = process.env.ALLOW_ORIGIN || '';
const ROOT = path.resolve(__dirname, '..');
const TOPICS = new Set(['shot', 'hit', 'frag', 'chat']);
const TOPIC_RE = /^[a-z][a-z0-9_.-]{0,47}$/;
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.wasm': 'application/wasm', '.map': 'application/json', '.txt': 'text/plain; charset=utf-8', '.md': 'text/plain; charset=utf-8' };

// ------------------------------------------------------------------ static files
const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://x');
  if (url.pathname === '/health') { res.writeHead(200, { 'content-type': 'text/plain' }); return res.end('ok ' + clients.size + ' players'); }
  let p = decodeURIComponent(url.pathname); if (p.endsWith('/')) p += 'index.html';
  const file = path.normalize(path.join(ROOT, p));
  const rel = path.relative(ROOT, file);
  if (rel.startsWith('..') || path.isAbsolute(rel) || rel.split(path.sep).some((s) => s.startsWith('.')) || rel.startsWith('server' + path.sep) || rel === 'package.json') { res.writeHead(404); return res.end('not found'); }
  fs.stat(file, (e, st) => {
    if (e || !st.isFile()) { res.writeHead(404); return res.end('not found'); }
    res.writeHead(200, { 'content-type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', 'cache-control': 'no-cache', 'x-content-type-options': 'nosniff' });
    fs.createReadStream(file).pipe(res);
  });
});

// ------------------------------------------------------------------ minimal RFC 6455 WebSocket
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const clients = new Map();       // id -> client

function frame(opcode, payload) {
  const len = payload.length; let head;
  if (len < 126) head = Buffer.from([0x80 | opcode, len]);
  else if (len < 65536) { head = Buffer.alloc(4); head[0] = 0x80 | opcode; head[1] = 126; head.writeUInt16BE(len, 2); }
  else { head = Buffer.alloc(10); head[0] = 0x80 | opcode; head[1] = 127; head.writeBigUInt64BE(BigInt(len), 2); }
  return Buffer.concat([head, payload]);
}
function send(c, obj) { if (c.sock.destroyed || c.sock.writableLength > 1 << 20) return; try { c.sock.write(frame(1, Buffer.from(JSON.stringify(obj)))); } catch (e) { /* closed */ } }
function broadcast(obj, except) { const data = frame(1, Buffer.from(JSON.stringify(obj))); for (const c of clients.values()) if (c !== except && !c.sock.destroyed && c.sock.writableLength < 1 << 20) { try { c.sock.write(data); } catch (e) { /* closed */ } } }

server.on('upgrade', (req, sock) => {
  const url = new URL(req.url, 'http://x');
  const key = req.headers['sec-websocket-key'];
  if (url.pathname !== '/ws' || !key || (req.headers.upgrade || '').toLowerCase() !== 'websocket') { sock.destroy(); return; }
  if (ALLOW_ORIGIN && req.headers.origin !== ALLOW_ORIGIN) { sock.write('HTTP/1.1 403 Forbidden\r\n\r\n'); sock.destroy(); return; }
  if (clients.size >= MAX_PLAYERS) { sock.write('HTTP/1.1 503 Service Unavailable\r\n\r\n'); sock.destroy(); return; }
  const accept = crypto.createHash('sha1').update(key + GUID).digest('base64');
  sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  sock.setNoDelay(true);
  const id = crypto.randomBytes(5).toString('hex');
  const c = { id, sock, presence: {}, buf: Buffer.alloc(0), tokens: 80, tt: Date.now(), alive: Date.now(), frag: null };
  clients.set(id, c);
  send(c, { t: 'hi', id, peers: [...clients.values()].filter((o) => o !== c).map((o) => ({ peer: o.id, presence: o.presence })) });
  broadcast({ t: 'join', peer: id }, c);
  sock.on('data', (d) => { c.buf = Buffer.concat([c.buf, d]); if (c.buf.length > 1 << 16) return drop(c); parse(c); });
  sock.on('close', () => drop(c)); sock.on('error', () => drop(c));
});

function drop(c) { if (!clients.has(c.id)) return; clients.delete(c.id); try { c.sock.destroy(); } catch (e) { /* */ } broadcast({ t: 'x', peer: c.id }); }

function parse(c) {
  for (;;) {
    const b = c.buf; if (b.length < 2) return;
    const fin = !!(b[0] & 0x80), op = b[0] & 0x0f, masked = !!(b[1] & 0x80); let len = b[1] & 0x7f, off = 2;
    if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
    else if (len === 127) { if (b.length < 10) return; const big = b.readBigUInt64BE(2); if (big > 65536n) return drop(c); len = Number(big); off = 10; }
    if (!masked) return drop(c);
    if (len > 16384) return drop(c);
    if (b.length < off + 4 + len) return;
    const mask = b.subarray(off, off + 4); const data = Buffer.from(b.subarray(off + 4, off + 4 + len));
    for (let i = 0; i < len; i++) data[i] ^= mask[i & 3];
    c.buf = b.subarray(off + 4 + len);
    if (op === 8) { try { c.sock.write(frame(8, data.subarray(0, 2))); } catch (e) { /* */ } return drop(c); }
    if (op === 9) { try { c.sock.write(frame(10, data)); } catch (e) { /* */ } continue; }
    if (op === 10) { c.alive = Date.now(); continue; }
    if (op === 0 || op === 1) {
      c.frag = op === 1 ? [data] : (c.frag || []).concat([data]);
      if (fin) { const full = Buffer.concat(c.frag); c.frag = null; message(c, full.toString('utf8')); }
    }
  }
}

function message(c, text) {
  c.alive = Date.now();
  const now = Date.now(); c.tokens = Math.min(80, c.tokens + (now - c.tt) * 0.04); c.tt = now;      // 40 msgs/s, burst 80
  if (c.tokens < 1) return; c.tokens -= 1;
  let m; try { m = JSON.parse(text); } catch (e) { return; }
  if (!m || typeof m !== 'object') return;
  if (m.t === 'p' && m.d && typeof m.d === 'object' && !Array.isArray(m.d)) {
    const merged = { ...c.presence }, patch = {};
    for (const k of Object.keys(m.d)) { if (!/^[A-Za-z_][A-Za-z0-9_-]{0,31}$/.test(k) || k === '__proto__') continue; patch[k] = m.d[k]; if (m.d[k] === null) delete merged[k]; else merged[k] = m.d[k]; }
    if (JSON.stringify(merged).length > 4096) return;
    c.presence = merged; broadcast({ t: 'p', peer: c.id, d: patch }, c);
  } else if (m.t === 'e' && typeof m.topic === 'string' && TOPIC_RE.test(m.topic) && TOPICS.has(m.topic)) {
    if (JSON.stringify(m.data === undefined ? null : m.data).length > 4096) return;
    broadcast({ t: 'e', topic: m.topic, data: m.data, peer: c.id }, c);
  }
}

setInterval(() => {
  const now = Date.now();
  for (const c of clients.values()) {
    if (now - c.alive > 45000) { drop(c); continue; }
    try { c.sock.write(frame(9, Buffer.alloc(0))); } catch (e) { /* */ }
  }
}, 15000).unref();

server.listen(PORT, () => console.log('Pickle City server on http://localhost:' + PORT + '  (WebSocket /ws, max ' + MAX_PLAYERS + ' players)'));
